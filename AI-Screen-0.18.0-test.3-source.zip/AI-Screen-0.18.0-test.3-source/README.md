# AI Screen · Windows AI 屏幕助手

用快捷键框选屏幕，完成截图、标注、贴图、长截图、录屏、文字识别、翻译和 AI 提问。基于 Electron、TypeScript 和 React，提供 Windows 64 位安装版及解压版。

当前版本：**0.18.0-test.3（测试版）**。本次整理发布流程、完整分发包和使用文档；功能沿用现有截图与录屏版本。

## 下载与运行

普通用户请打开本仓库右侧 **Releases**，在对应版本的 **Assets** 中下载：

| 文件 | 用途 |
| --- | --- |
| `AI-Screen-版本号-win-x64-setup.exe` | 安装版，安装后通过桌面或开始菜单启动 |
| `AI-Screen-版本号-win-x64.zip` | 解压版，完整解压后运行 `AI Screen.exe` |
| `AI-Screen-版本号-source.zip` / `Source code` | 开发者源码，需要自行安装依赖、构建 |
| `SHA256SUMS.txt` | 检查下载是否与发布文件一致 |

**不要只复制 `AI Screen.exe`，也不要在压缩软件里直接打开它。** 同目录的 `resources`、`locales`、DLL 等文件都需要保留。GitHub 的 **Code → Download ZIP** 下载的是源码，不能直接双击运行。

要求 Windows 10/11 **x64（Intel/AMD 64 位）**；不提供 Windows 7/8、32 位、macOS、Linux 或 ARM64 原生包。运行成品不需要安装 Node.js、npm、Python 或 FFmpeg。当前未签名，Windows 可能显示未知发布者/SmartScreen 提示，请先确认下载来源与校验值。Windows 11 和不同硬件组合仍需实机验证。

## 首次使用

1. 打开程序，默认进入**演示模式**，可以先试截图、标注、贴图、长截图和录屏。
2. 按 `Alt+A` 唤起截图；快捷键冲突时可在设置里修改，也可从主窗口或托盘进入。
3. 真实翻译、分析和提问：在服务设置中选择兼容 API，填写 API 根地址、支持图片输入的模型名称和自己的 API Key，测试连接后保存。本地免密服务可留空 Key。
4. 如需离线提取文字，将文字识别方式改为 **Windows 本地 OCR**，并确保系统安装了对应 OCR 语言包。
5. 关闭主窗口后程序仍在托盘运行，彻底退出请使用托盘菜单。更新前先退出旧版。

连接测试会发送内置小图片到所配置服务，可能产生少量费用。只有主动触发 AI 操作时才发送选区与相应对话；演示模式及本地 OCR 不向 AI 服务发送截图。每位用户自行配置服务，分发包不附带作者的密钥或设置。

详细操作、数据存放和常见问题见 [用户指南](docs/USER-GUIDE.md)。

## 开发

在 **Windows x64** 上安装 Node.js **22.12+ 的 22.x 版本**和 npm；项目中的 `.nvmrc` 指定 Node 22。首次安装需要联网下载 npm 依赖和 Electron。

```powershell
npm ci
npm run dev
```

```powershell
npm test             # 单元与本机模拟 HTTP/SSE 测试
npm run build        # 类型检查 + 生产构建 + 原生截图助手 + 第三方声明
npm start            # 运行已构建版本
npm run smoke        # 启动 Electron 做交互集成检查（需要桌面和 OCR 语言包）
npm run pack         # 生成完整运行目录
npm run release:win  # 测试、构建、安装版、解压版、干净源码包、校验值
npm run release:zip  # 同上，但只生成解压版和源码包，不制作安装版
npm run release:check # 核对当前版本 win-unpacked 的内容与源码构建一致
```

发布文件输出到 `release/v版本号/`，同版本已有分发文件时脚本会停止，防止覆盖。Windows 原生截图助手由系统 .NET Framework 64 位编译器构建。`npm ci` 使用锁文件固定依赖；开发、打包缓存和用户数据均不进入源码包。

[发布与 GitHub 上传步骤](docs/DISTRIBUTION.md)包含如何直接发压缩包、手动上传 Releases、触发 GitHub Actions 构建和安装包验证说明。

## 功能与边界

- 截图：窗口预选、区域框选、复制图片、画笔/箭头/矩形/文字标注、置顶贴图。
- 长截图：手动/实验性自动滚动、拼接预览、原图缩放、PNG 导出和 AI 分析；选区需在单个显示器内，滚动应保留足够重叠。动态重排与重复内容可能影响拼接。
- 录屏：MP4/WebM、暂停/继续、系统声音和麦克风选择、预览及另存。实际音频受系统权限和设备影响，长时间录制前先做短录测试。
- AI：兼容 Chat Completions 的视觉服务、流式回复、追问、自定义动作和 Markdown 显示；效果与费用取决于所配服务。

当前验证以本机 Windows 10 为主，多屏/混合 DPI、Windows 11、不同显卡和音频设备的完整兼容性尚未完成。发现问题请按 [问题反馈模板](.github/ISSUE_TEMPLATE/bug_report.yml)提供系统、版本、复现步骤及错误信息，勿提交密钥或私人截图。

## 目录与授权

`src/main` 为主进程和系统服务，`src/preload` 为受限 IPC 桥，`src/renderer` 为界面，`src/shared` 为共享契约与算法，`tests` 为测试，`scripts` 为开发和发布工具，`docs` 为使用说明和历史开发记录。

本项目采用 [MIT License](LICENSE)。程序包同时保留 Electron/Chromium 声明及自动汇总的第三方依赖许可证。`docs` 中旧版本路径、测试数据和交接记录属于历史材料；当前使用和发布步骤以本 README、用户指南及发布说明为准。
