# 架构与扩展方式

v0.16.1-test.2当前采集：`LiveRegionSource → CaptureProcessClient → 隔离Electron代理 → NativeCaptureClient → Windows GDI原生ROI工作进程`。原生程序复用DC/DIB，通过继承的stdin/stdout交换有界BGRA帧，最高30fps；启动失败可回退旧desktopCapturer，首帧后禁止换源。显示器与尺寸检查、帧队列和原像素校验保留。预览取样/PNG为独立Worker，PreviewPump完成间隔100ms且只保留一个在途/dirty。实际后端进入白名单诊断；构建用系统.NET编译器生成native-capture.exe，打包为resources外置文件，不能从ASAR内执行。实现与验收见[原生ROI提速报告](LONGSHOT-NATIVE-ROI-PERFORMANCE.md)。下方各版本段落为历史演进。

v0.16.0阶段4.1：`FrameFingerprint`在主进程读取位图后，对宽高及全部字节计算SHA-256，只持有上一摘要；`CaptureTelemetry`独立记录相邻变化/相同/连续相同与空返回重读，不将Worker去重当作读屏未更新。`diagnostics.ts`提供固定建议及白名单JSON构建，不接收图片/标题/URL/设置或自由错误文本。环境仅应用/系统版本和物理屏幕尺寸/DPI。`export-diagnostics`复用当前会话/longshot角色授权，冻结点击时快照，独立diagnosticPending挂起及采样版本隔离文件对话框；不改变用户paused或托盘suspended。完成中禁止导出/持有对话框时禁止完成；取消会话使迟到保存失效。复用原子文件写入，清理临时文件；完成页和预览共用面板，不写系统剪贴板或自动上传。LiveRegionSource只对缺失/空图等待80ms后重读一次，取消/显示器/像素尺寸检查保持，不缓存旧帧替代。测试与未验收应用矩阵见LONGSHOT-COMPATIBILITY和HANDOFF。

v0.15.0阶段3.3：预览比例与窗口布局独立。`preview-viewport`定义物理像素缩放、鼠标锚点和有界ROI；renderer的`usePreviewZoom`管理比例/跟随/浏览，`PreviewViewSender`只保留一个在途及最新待发请求。沿用受限preview-window IPC，新增view请求，严格校验当前thumbnail/session和递增sequence；主进程从实际窗口取得DPI，并将客户端可见尺寸夹在原生窗口范围内，不信任客户端DPI。`LongshotService`复用PreviewPump及概览/清晰缓存，纯浏览只请求Worker.viewport，不重采屏幕、不重建两张基础PNG；源内容变化时仍刷新基础预览和当前ROI。Worker通过StitchDocument分段采样当前可见区域，不flatten整幅长图；源物理可见范围与最多2048边长的输出采样分开，防止极大窗口缺一块。PNG仍在主进程编码，不是独立编码线程。

100%为源像素/屏幕物理像素1:1，CSS比例为zoom/devicePixelRatio；默认按宽度预览不变。numeric模式只建文档大小的CSS容器，图像只保存ROI PNG，按源坐标定位。跟随时使用Worker当前视口；浏览时向上插入正文按coveredTop差值调整，使同一段内容保持可见，固定header不位移；新请求到来丢弃过期回复，退出回收sender/监听器/ROI状态。菜单在受保护窗口内部绘制，不创建原生select/title弹窗。复制/保存/AI沿用原尺寸成品，采集队列、匹配阈值、原生输入与普通截图无修改。交付与边界以HANDOFF和专项计划阶段3.3为准。

v0.14.0阶段3.2：`PreviewWindowLayout`独立管理auto/manual、会话内期望大小和有令牌的拖动/八向缩放，屏幕几何与截图文档分离。React合成PointerEvent使用全局DIP，`PreviewGesture`限制一个在途IPC及一个最新点、最后点先于end；新手势等待前一end完成。白名单IPC再校验会话UUID、严格联合请求、数值范围和当前thumbnail的sender；工具栏/结果页无权调整它。LongshotSurfaces应用原生边界并仅向自身发布小型layout状态，手动模式忽略工具栏重排，复位复用PreviewPlacementManager并保留尺寸偏好；关闭释放布局/手势，新会话自动。尺寸改变通过既有PreviewPump请求分段原像素预览，暂停时也可刷新，采集管线与AI无修改。采集界面使用ARIA说明代替原生title弹窗，减少独立工具提示混入捕获的风险。

v0.13.0阶段3.1：`PreviewPlacementManager`在shared层提供纯DIP布局，按四周可用矩形减去工具栏保护区，综合预览宽高相对期望尺寸、遮挡、距离和轻量侧向偏好评分；优先可用外侧窗口，不够时采用避开中央40%范围的受保护内嵌预览。返回bounds/side/mode及可用空间，旧thumbnailBounds委托给它。LongshotSurfaces持有布局上下文、应用原生边界；LongshotWindow仅在工具栏move时触发重新避让，发布状态不重新布局。Windows分数DPI边界向外取整通过2DIP余量保护。采集状态机、帧源、队列、匹配、预览图像采样、OCR/AI/复制均保持。手动位置模式、大小和自由缩放留阶段3.2/3.3。

v0.12.0阶段2.3：`DocumentCoverage`维护带符号视口和连续正文覆盖；Engine先验证相邻帧，再用`StitchDocument.view → translation-verifier`检查整段历史交集，只有未覆盖行才能插顶/追加。StitchDocument将固定header/body/footer独立保存，内部行视图零像素复制，预览/匹配不flatten文档。`DocumentLocator`只为完整、像素一致的历史视口建立有界行指纹索引并精确复验，不跨未知缺口补图。回看更新参考位置而不增长成品，预览按当前视口跟随并带位置快照防止旧缓存。自动模式遇反向/历史重新定位暂停原有输入策略，手动双向能力不受影响。新模块/测试/边界详见专项计划和HANDOFF；下方为历史阶段记录。

v0.11.0阶段2.2：`VerticalMatcher → translation-verifier`先沿用严格全像素校验，再尝试独立的局部变化规则：单一小范围、像素上限、拼接边界保护及纵横分散纹理证据，多个可行偏移仍拒绝。固定边带复用零位移校验；MotionRegion仍要求整个建议正文严格对齐、经过明确确认才裁剪。Engine对静止局部变化返回duplicate、不换参考；拒绝只更新恢复元数据，不改变已接受图像/参考；返回可靠视口或新帧重新通过时清零连续拒绝并报告recoveredAfter。服务/UI显示“等待重新接上”及局部容错/恢复计数。这不包含缺失像素补洞、双向文档坐标或持续帧源。下方v0.10.0记录为上一阶段结构。

v0.10.0阶段2.1：手动采集为 `LiveRegionSource → CapturePipeline（有界预读）→ 顺序accept/Worker`，`PreviewPump`独立合并预览请求。最多3个帧位含在途读取/匹配，通常64MiB原始帧预算，大帧退为单帧串行；不将该预算视为进程RSS限制。队列满暂停生产而非仅保留最新帧。完成seal生产者并等待有效队列、在途预览结束后补采/合并；取消close并清除等待帧；暂停/菜单/正文确认用采样版本废弃在途读取并清空排队帧。预览与匹配复用同一Worker，各至多一个请求在途；PNG编码仍在主进程，不宣称独立编码线程。采集仍逐次desktopCapturer，尚未实现持续帧源、稳健动态匹配或双向覆盖。最新验收见HANDOFF和LONGSHOT-OPTIMIZATION-PLAN。

v0.7.0 默认手动连续采集，Worker 验证运动重叠；不再用两帧静止门槛阻塞手动采样。结束排空在途任务并补采当前视口。`MotionRegion` 分块提议正文，`review → confirm-region/keep-region` 是正交 UI 状态；只有明确确认才原子裁图并继续，帧尺寸、内存、接缝验证仍在 Worker。LiveRegionSource 将物理像素正文映射回实际屏幕几何，不用预览尺寸换算。原图复制/保存复用旧服务。最新边界见 MANUAL-LONGSHOT.md 与 HANDOFF 末尾；下方预览版和旧版长截图描述是历史。

当前开发框架为 v0.7.0-preview.1，长截图最新结构以 [LONGSHOT-V2-PLAN.md](LONGSHOT-V2-PLAN.md) 为准。LongshotSurfaces 管理原生挖空遮罩与独立缩略窗，LongshotWindow 管理紧凑工具栏/最终结果，React 通过 useLongshotSession 共用会话订阅。Worker 使用 `ScrollCaptureEngine → ContentRegion / VerticalMatcher → StitchDocument`，旧 LongshotStitcher 名称仅为兼容导出。外围截图背景只在采集窗口内存中持有，完成/取消释放。普通截图与 AI 服务仍沿用下方分层；下方 v0.6.1 长截图描述保留为历史参考。验收状态见 HANDOFF 末尾。

v0.6.1 长截图通过既有 CaptureModeExtension 接入自动/手动滚动。LiveRegionSource 与普通快照隔离，Worker 进行原像素保守匹配及分段缩略图生成，LongshotService 管理采样、暂停、恢复及输出，独立 LongshotWindow 提供可见面板和结果。自动模式由 AutoScrollPolicy 调度 WindowsLongshotScroller，隐藏原生 helper 只负责目标校验及滚轮输入。原生 DPI、捕获排除面板、限制与验收边界见 [长截图架构](LONGSHOT.md)；分阶段后续工作见 LONGSHOT-IMPROVEMENTS.md，交付见 HANDOFF.md。

v0.4.0 将截图 UI 拆为控制器、选区、模式/操作工具栏、放大镜、标注和贴图模块；窗口预选复用截图前的原生候选快照。具体职责、状态机、异步合成及新增接口见 [QQ 风格交互改造](QQ-REFACTOR.md)。AI/OCR/翻译仍复用下述 TaskService/Provider 结构。

## 分层

```mermaid
flowchart TD
    UI[React: 主窗口 / 选区 / 结果 / 长截图] --> Bridge[Preload: ScreenBridge]
    Bridge --> IPC[主进程: 白名单 IPC + Zod 校验]
    IPC --> Capture[CaptureService]
    IPC --> Settings[SettingsStore]
    IPC --> Tasks[TaskService]
    IPC --> Modes[CaptureModeRegistry]
    Modes --> Longshot[LongshotService]
    Longshot --> Live[LiveRegionSource: 实时选区]
    Longshot --> Worker[Worker: 保守原像素匹配]
    Longshot --> Auto[AutoScrollPolicy]
    Auto --> Native[WindowsLongshotScroller: 原生校验与滚轮]
    Capture --> OS[Electron 屏幕与剪贴板]
    Settings --> DPAPI[Windows 系统加密]
    Tasks --> AI[AIProvider]
    Tasks --> OCR[OCRProvider]
    AI --> Demo[DemoProvider]
    AI --> Compatible[CompatibleProvider]
    OCR --> Vision[VisionOCRProvider]
```

渲染进程只访问 `window.screenAI`。主进程负责原始截图、密钥、请求和剪贴板；不会把解密后的 API Key 返回给 renderer。窗口按角色限制 IPC 调用，拒绝 iframe 调用，禁用 Node 集成，开启沙箱与上下文隔离，禁止外部导航和弹窗。

## 数据与状态

- CaptureService 一次枚举整组显示器，按 displayId 保存每屏原始 NativeImage。完整屏幕预览使用质量 95 的 JPEG 并在当次快照内缓存；最终选区仍从原始位图无损裁剪。每屏提交局部 DIP，按实际位图尺寸换算，负坐标只影响窗口位置。
- WindowManager 预热并复用隐藏选区页，只有明确唤起时才读取屏幕。capturePrepared 确认订阅建立，captureChanged 发布新会话，captureReady 确认图片解码；通过 1px 内存探测促成隐藏窗口绘制后才显示，避免空白和灰屏。主进程将 sender.id 绑定到当前 active display，并同时检查 sessionId，迟到就绪信号无法放行其他会话。
- 取消、提交或失败时立即解除 active display 身份、隐藏窗口、发送空会话并清除原图；保留空页面便于下次唤起。显示器变化和 renderer 退出销毁对应预热窗口，退出应用时销毁所有缓存窗口。预热页仍有 capture 角色用于握手，但没有有效选区及原图访问身份；不执行后台屏幕采集。
- 长截图拥有独立会话：`preparing/capturing/finishing/done/error`，以及正交的 `scrollMode/paused/scrollSteps`。手动模式逐帧交给后台 Worker，稳定帧门槛仅用于实验自动模式；按原生显示器像素请求屏幕，拒绝重采样尺寸。v0.8.2 统一使用256 MiB像素预算、30000px高度和单帧128 MiB限制，与普通截图分开管理。预览从分段原图按窗口/DPI采样完整概览及末段，不合并原图；最多每250ms编码，独立源坐标避免节流期间用新尺寸拉伸旧预览。
- 自动滚动要求冻结目标 HWND，绑定后锁定 PID、窗口范围，并以 3×3 点、焦点、鼠标、修饰键和鼠标键校验。遮罩仍持前台权限时预热 helper，仅首次绑定/用户继续尝试激活；每步 `SendInput(-120)`，不自动点击、不向变化后的其他窗口改投。系统不允许激活时暂停，保留手动入口。
- AutoScrollPolicy 在重复帧后等待 1200ms 复核，连续三轮无变化且此前有追加才自动结束，否则暂停。总步数 1200、每次继续后 10 分钟窗口；结束原因随 LongshotState 展示，不能把停止等同于保证页面完整。
- 长截图面板优先在选区外，无空间则使用捕获排除的可见悬浮面板；原生驱动只透过本进程认证的受保护面板校验原目标。Worker 从接受的片段直接生成小缩略图，不合并/清除原始分段。托盘打开暂停采样/调度并使在途探针失效。取消/关闭按会话 ID、采样版本及 abort 隔离旧结果，停止 helper 与 Worker；自动结束在采集循环之外触发生成，避免自等待。主进程保留原图，界面只收缩略 PNG，复制与原子保存复用 ClipboardService/独立文件服务；不会自动请求 AI。
- TaskService 保存一个裁剪图和当前会话，状态为 loading / done / error / cancelled。使用 AbortController 取消请求并忽略过期结果。最近 12 条消息用于追问上下文。
- OCRProvider 接口把文字识别从 AI 调用中隔离。当前支持视觉模型或 WindowsOCRProvider；Windows 实现通过隐藏的系统 PowerShell/WinRT 进程识别，图片通过 stdin 的内存数据传入，不落临时文件。进程支持取消和超时；打包版脚本位于 resources/windows-ocr.ps1。
- SettingsStore 以原子文件替换方式保存设置。快捷键先注册再保存；保存失败时尝试恢复旧快捷键。密钥独立加密，公开设置只包含 hasApiKey。
- Provider 默认使用演示实现；真实请求有 60 秒超时，禁止跟随重定向，不把可能回显密钥的错误响应正文展示给用户。流式 SSE 解析支持 UTF-8 分块和 CRLF，只有 DONE 或 finish_reason 才认为完整；异常断流标记失败。
- 每次任务分配 requestId，增量 IPC 只传 requestId 和累计文本；结果窗口只接受当前任务的进度，避免重复传输截图以及旧请求污染当前结果。取消保留已接收文本，不把未完成回复写入会话历史。
- 服务测试使用独立的 64×64 内置图片与当前表单设置，不修改持久配置、剪贴板或结果会话。它验证请求与返回格式，无法证明模型确实理解图片。
- ShortcutRecording 管理全局快捷键暂停所有权；Home 录制期间禁止保存与截图，松键、Esc、失焦、关闭及 renderer 退出恢复旧注册。窗口事件提供主进程兜底，防止 renderer 异常留下暂停状态。
- 自定义动作通过 settingsSchema 校验（最多 8 项、唯一 ID、名称 16 字、提示词 4000 字）。IPC 只接受 ID，主进程从已保存且启用的动作读取提示词，单次替换语言/问题变量；actionLabel 与 customActionId 随结果状态传递。提示词不执行代码。
- Markdown 使用 react-markdown + GFM，禁用 HTML、替换图片为文字。highlight.js 只加载常见语言，复制从代码文本提取；外链没有 href，仅显式点击经 result 专用 IPC 和 HTTP(S) 校验交给系统浏览器。

## 新增能力的入口

| 需求 | 入口与步骤 |
| --- | --- |
| 新 AI 厂商 | 实现 providers/types.ts 的 AIProvider；添加设置枚举与 provider 工厂；不要在 renderer 中请求 |
| 其他本地 OCR | 实现 OCRProvider；沿用 TaskService 的本地识别注入；新增配置选择引擎 |
| 新工具栏动作 | 扩展 shared/contracts.ts 的 ActionId 和 shared/actions.ts；添加主进程路由与提示词 |
| 其他流式协议 | 适配 AIProvider 的 onProgress 回调；保留 requestId 和完成/失败/取消状态机 |
| 跨屏拼接 | 已有每屏独立 overlay；后续单独定义跨屏 DIP、像素密度和拼接策略 |
| 长截图调度 | CaptureModeExtension 的 scrollMode 上下文；LongshotService 管会话，AutoScrollPolicy 管停止策略，ScrollDriver 管受限原生输入，匹配留在 Worker |
| 录屏 | 复用范围选择和模式注册；尚需独立采集/编码、停止取消及视频文件输出后端 |
| 历史记录 | 添加独立 repository 接口；用户显式启用后持久化，设计删除与保留策略 |
| 自定义动作 | 设置中添加名称/提示词即可；custom-actions.ts 处理数据和变量，TaskService 沿用现有 AIProvider |

## 已知取舍

截图来自 Electron desktopCapturer 的屏幕缩略图 API，请求原生像素尺寸；使用返回图片的真实尺寸计算裁剪，避免仅按设备缩放倍数猜测。DRM 内容、UAC 安全桌面及部分 GPU 窗口可能无法捕获，需要在真实设备上验证。

OCR 和错误使用纯文本，AI 结果使用受限 Markdown。没有引入数据库、自动更新框架或通用插件运行环境。多屏截图按显示器分别采集，并不保证所有屏幕在同一时刻冻结；不做跨屏拼接。真实多屏/混合 DPI 设备验收尚未完成。

Windows 前台激活和滚轮权限属于真实系统条件，Electron focused 状态不能替代 Win32 前台 HWND 校验。自动烟测可用仅测试 helper 在自建 Canvas 上建立前台输入条件；生产驱动仍不点击或绕过系统前台规则。录屏没有后端，固定栏移除、虚拟列表和慢加载页面的完整性也不作保证。

## 参考

- [Electron desktopCapturer](https://www.electronjs.org/docs/latest/api/desktop-capturer)
- [Electron safeStorage](https://www.electronjs.org/docs/latest/api/safe-storage)
- [Chat Completions 请求格式](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)
- [Chat Completions 流式事件](https://developers.openai.com/api/reference/resources/chat/subresources/completions/streaming-events)
- [Windows OCR 系统语言选择](https://learn.microsoft.com/en-us/uwp/api/windows.media.ocr.ocrengine.trycreatefromuserprofilelanguages)
