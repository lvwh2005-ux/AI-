# 自动 / 手动滚动长截图 · v0.6.1

**当前版本 v0.7.0 已以手动滚动为主流程**，修复滚动不停时无帧被接收、完成时遗漏末尾的问题，并增加固定侧栏正文确认。请先阅读 [手动长截图](MANUAL-LONGSHOT.md) 和 HANDOFF 最新记录；自动仅实验入口，不再是本轮验收门槛。下面 v0.7.0-preview.1 及 v0.6.1 描述均为历史。

**最新开发框架为 v0.7.0-preview.1**：用户要求重新规划 QQ 风格长截图，当前 A 阶段实现和使用边界见 [V2 规划](LONGSHOT-V2-PLAN.md) 及 HANDOFF 末尾。独立原生挖空选区、紧凑工具栏、实时缩略图和分层拼接已接入；固定头尾仅基础支持，复杂页面和编辑尚待后续。104 项测试及打包界面集成通过，新框架原生滚轮未验收，桌面继续使用 v0.6.1。以下为旧版使用和历史实现记录。

在 v0.5.0 手动采集和 v0.6.0 自动滚动基础上增量修复可见性。99 项测试、源码界面专项和打包版完整集成检查已通过，最终记录见 [HANDOFF](HANDOFF.md)。普通截图的 OCR、AI、标注和贴图保留；长图结果目前仅支持预览、复制和保存，编辑工具尚未接入。分阶段计划见 [体验修复](LONGSHOT-IMPROVEMENTS.md)。录屏仍未实现。

## 使用方法

1. 快捷键唤起，选择「长截图」，框住同一显示器内的滚动内容区域。
2. 避开固定页眉、页脚、侧栏、滚动条、动画和视频。默认选择「自动滚动采集」，也可选择「手动滚动采集」。
3. 自动模式逐步向原窗口发送滚轮，等待稳定画面后拼接；控制条显示模式、自动滚动次数、累计像素尺寸，可暂停、继续、转为手动。自动期间请保持目标可见，不移动鼠标、不按住修饰键或鼠标键；系统拒绝激活时按提示切回目标后继续，或转为手动。
4. 手动模式等待首帧就绪，每次向下滚动不超过选区高度的一半，稍停并确认累计高度增长。转为手动会保留可靠片段；如曾拒绝拼接，先回到最后成功位置再滚动。
5. 点击「完成」或等待自动结束，在预览中检查停止原因及末尾完整性，再复制或另存 PNG。预览可能缩小，输出仍使用原始像素。
6. 面板默认 440×380 DIP，必要时压缩至 360×380，优先放在选区外；无空间时使用屏幕内可见的悬浮面板，不再静默隐藏。面板开启系统捕获排除，Windows 10 2004+ 可覆盖内容而不进入最终图；更旧系统无外部空间时明确报错，需缩小选区。面板显示已接受内容的实时缩略图、首屏高度、新增像素及原因。Ctrl+Alt+Enter 完成、Ctrl+Alt+Esc 取消，仅在注册成功时有效；托盘仍提供备用操作。

7. 只有首屏、没有新增行时，完成页明确显示「首屏截图」「没有拼接出长图」，仍可复制首屏或保存。固定栏等内容目前仍可能触发保守拒绝，不将首屏冒充长图。

控制窗口获得焦点时 Esc 取消、Ctrl+Enter 完成。取消保存对话框不影响已完成图片；关闭预览清除本次内存数据，不保留历史。

## 结构和状态

`CaptureModeRegistry → LongshotService → LiveRegionSource → Worker/LongshotStitcher → PNG → Longshot 预览`

自动模式额外使用 `AutoScrollPolicy → WindowsLongshotScroller → 隐藏 PowerShell/Win32 helper`；手动模式不注入输入。

状态：`preparing → capturing → finishing → done`，`scrollMode: auto/manual`、`paused` 和 `scrollSteps` 独立保存。自动激活、遮挡、焦点或匹配不可靠时暂停，保留可靠内容；`resume` 仅恢复原目标，`manual` 停止注入输入并转手动。采集异常或像素资源上限进入 `error`，处理线程仍可用时允许完成已有部分。取消/关闭撤销会话；准备、采集和生成期间阻止开始另一张普通截图。

LiveRegionSource 每次读取当前屏幕并裁剪选区，不修改 CaptureService 的普通冻结快照。开始时关闭整组截图遮罩，在首轮采样前等待旧画面离开合成器；连续两次采样基本稳定才提交拼接。按顺序采集，没有无限帧队列。

既有 WindowDetector worker 同时返回原生显示器边界，按 Electron nativeOrigin 匹配，使用原生尺寸请求截图。150% 缩放时，1707×1067 DIP 四舍五入推算为 2561×1601，而设备可能实际为 2560×1600；多出一像素会使 Chromium 重采样并破坏匹配。原生尺寸缺失或返回尺寸不一致时明确失败，不继续错接。

坐标仍按局部 DIP 和实际位图转换，兼容负坐标布局，单张长图仅在一个显示器内。显示器的位置、尺寸、缩放变化或断开会取消本次采集；自动模式中目标应用窗口移动或改变大小会暂停并要求重新框选。

托盘菜单打开前暂停采样和自动调度并清空稳定性探针；菜单关闭后恢复，通过采样版本丢弃跨越菜单开闭的在途帧，避免菜单进入首帧。

## 自动滚动与目标锁定

- helper 在用户激活的截图遮罩仍持有前台权限时预热，遮罩关闭后才绑定和滚动。遵守 Windows 前台激活规则，不伪造点击、不绕过前台锁；激活失败显示原因，可继续原目标或改为手动。
- 主进程要求自动模式具备冻结候选中的目标 HWND，缺失时拒绝启动，用户可在原选区选择手动。绑定时比对原 HWND，随后固定 HWND、PID 和窗口范围，不随鼠标重新选另一个窗口。
- 用 3×3 点检查选区是否仍属于该窗口；仅本进程已认证、开启捕获排除的采集面板可透过 Z 序验证原目标，其他窗口仍拒绝。同时检查最小化、虚拟桌面隐藏、位置/大小、前台窗口和鼠标位置。光标进入面板仍会暂停；滚动前检查 Ctrl/Alt/Shift/Win 与鼠标按键，避免把滚轮变成缩放或其他操作。
- 只有首次绑定和用户显式「继续」时尝试激活目标并将鼠标放在选区中心；每步只校验，不重新抢回焦点或鼠标。允许中心每轴 12 个物理像素以内的小幅抖动，但鼠标必须仍在选区内且命中原窗口；明显移开时暂停。退出时仅在光标仍位于原停放点每轴 2 像素内时恢复原位置，不覆盖用户接管后的鼠标位置。
- 每步发送一个 `SendInput` 向下滚轮增量 `-120`，实际滚动像素由目标应用和系统滚轮设置决定。连续两帧稳定才提交，滚动后等待并重抓，不按固定像素距离强行拼接。
- 重复画面先等待 1200 ms 后再取稳定帧复核，再尝试滚动；连续三次仍无变化，只有此前已可靠追加内容时才自动结束。始终没有追加则暂停，不能据此声称已到页面底部。预览页可见显示停止原因。
- 单会话最多 1200 次自动滚动，每次继续重置 10 分钟计时窗口，但不重置累计步数；触及限制后可完成或转手动。画面持续不稳定也会暂停。

## 匹配与资源限制

- 首帧完整保留，静止重复帧不追加。
- 搜索上一接受帧与当前帧的正反向垂直位移，至少保留 `max(64 像素, 25% 帧高)` 重叠。
- 先用覆盖整幅宽度的行特征找候选，再验证重叠区域全部原像素，检查信息量与候选唯一性。
- 只追加新露出的底部行，分段保存，完成时才合并；后台线程执行匹配，不占用截图 React UI。
- 反向滚动、无可靠重叠、横移、动态内容、固定栏、空白/重复图案歧义均拒绝追加，已有图保持不变。
- 拒绝后回到最后接受的位置，再慢慢向下滚动；未恢复便完成时，预览提示「仅完成可靠片段」。

上限（v0.8.2）：宽度8192px、高度30000px，后台线程像素预算由64 MiB提高到256 MiB，单帧上限同步由32 MiB提高到128 MiB。预算检查同时计入成品与一帧，实际高度也受宽度与预算限制。合并、PNG编码和预览有额外临时内存；256 MiB不是整个Electron进程的内存上限。采集预览已改为按实际窗口/DPI生成概览与宽度适配的末段，详情见MANUAL-LONGSHOT.md。

## 输出和清理

原图仅在主进程；renderer 接收最宽 960px、最长 6000px 的缩略 PNG。复制复用 ClipboardService；另存通过系统对话框选路径，先写同目录临时文件，成功后替换目标。失败或取消清理临时文件，保留旧目标。

取消、关闭、显示器变化和应用退出撤销会话、终止拼接 worker 与原生滚动 helper、停止采样，释放图片和控制窗口。会话 ID、采样版本和异步操作标识阻止旧结果覆盖新状态；旧命令、迟到读取、被打断的继续请求不能恢复已取消内容。窗口先隐藏并撤销 IPC 所有权，再短暂延迟销毁，使关闭命令能够收到回复。

不请求 AI、不访问或发送密钥、不上传长图、不自动保存历史。没有放宽权限，也没有增加第三方运行依赖。

## 文件清单

v0.6.0 新增：

- `src/main/services/longshot-scroller.ts`、`longshot-scroller.ps1`：受限 Win32 自动滚动驱动。
- `src/shared/longshot-auto.ts`、`tests/longshot-auto.test.ts`：重复确认、停止条件、步数及时间策略。
- `src/main/smoke-window-input.ts`：仅在烟测中给指定合成窗口建立真实前台条件，不供生产采集调用。

v0.6.0 修改：`src/main/services/longshot.ts`、`capture-modes.ts`、`src/main/index.ts`、`longshot-window.ts`、`longshot-smoke.ts`；`src/shared/longshot.ts`、`contracts.ts`、`src/preload/index.ts`；`src/renderer/capture/ScreenshotController.ts`、`SelectionToolbar.tsx`、`capture-extra.css`、`views/Longshot.tsx`、`longshot.css`、`views/Home.tsx`；`tests/live-region-source.test.ts`；`scripts/build.mjs`、`package.json`、`package-lock.json`、README 及交接/架构/路线图/QQ 改造文档。

v0.6.1 修改和验证见 [分阶段修复记录](LONGSHOT-IMPROVEMENTS.md)。新增文档 `docs/LONGSHOT-IMPROVEMENTS.md`，没有新增运行模块或依赖；沿用既有服务分层，新增 Worker 缩略图操作与捕获排除面板的原生校验。

v0.5.0 基础模块：

- `src/shared/longshot.ts`、`longshot-stitcher.ts`、`longshot-stability.ts`
- `src/main/services/live-region-source.ts`、`longshot.ts`、`longshot-processor.ts`、`longshot-worker.ts`、`longshot-file.ts`
- `src/main/longshot-window.ts`、`src/main/longshot-smoke.ts`
- `src/renderer/views/Longshot.tsx`、`src/renderer/longshot.css`
- `tests/live-region-source.test.ts`、`longshot-stitcher.test.ts`、`longshot-stability.test.ts`、`longshot-file.test.ts`
- 本文档；普通截图、AI Provider 与 OCR Provider 沿用既有实现。

## 验证及已知限制

v0.6.0 已交付 `release/v0.6.0/win-unpacked`，既有桌面快捷方式已更新，旧版保留。测试使用自建长 Canvas、真实滚轮与生产 desktopCapturer，通过暂停/恢复、切焦点、手动回退、取消、自动完成及 Chromium 默认滚动验证；源码长截图和打包版完整 smoke 均退出0。先在内存核对已知颜色行，确认是合成内容才保存测试 PNG，不用 capturePage 替代屏幕采集。剪贴板注入测试写入器，设置使用隔离目录，不读取真实密钥、不请求真实 AI。详细日志和测试范围见 HANDOFF.md。

后台启动测试时，Electron 报告 focused 不等于 Win32 已给出前台输入权。自动烟测的前置可以在校验指定合成 Canvas 的 HWND、PID 和命中关系后，由仅 `--smoke-test` 使用的独立 helper 单击该测试页一次，建立正常前台条件；后续滚动、暂停恢复和结束仍走生产服务。此点击只属于测试准备，生产滚动驱动不自动点击，也不借测试前置绕过实际使用中的激活失败。

目前只支持单显示器内向下采集，不支持反向扩展、跨屏拼接或自动移除固定栏。滚轮可能作用于嵌套滚动容器，也可能被应用忽略或因权限级别不同被系统拒绝。3×3 检查不是完整遮挡扫描；切换窗口、移动鼠标、按键或持续动画会暂停。空白/重复内容、动态/虚拟列表、GPU/受保护内容可能拒绝匹配；很慢的延迟加载也可能晚于结束确认，需要检查预览末尾。真实 Windows 10/11、多屏/混合 DPI 与浏览器、PDF、编辑器兼容性仍需验收。

v0.6.1：99 项测试和构建通过；源码 `--longshot-ui-only` 在面板覆盖合成内容的条件下，逐像素比较最终 PNG 与 Canvas 原图，验证捕获排除、实时预览、实际结果可见及首屏提示。打包版 `--longshot-panel-overlay` 完整 smoke 退出0，复验真实滚轮、多步拼接、暂停恢复、手动回退、取消、原尺寸复制/保存以及普通截图/标注/贴图/演示 AI 回归。日志 `.runtime/longshot-ui-v0.6.1.log`、`.runtime/packaged-smoke-v0.6.1.log`；测试不写用户剪贴板、不读取真实 Key、不保存私人桌面内容。目录版 `release/v0.6.1/win-unpacked`，旧版本保留。此结果不等同于用户聊天网页的固定栏已经兼容。

下一轮按第二阶段处理实际应用、固定栏、虚拟列表及延迟加载；第三阶段将长图接入截图编辑工具。录屏继续独立开发。

## 研究参考

- [Crisp / ScrollCapture.cpp](https://github.com/shadesofdeath/Crisp/blob/main/src/ScrollCapture.cpp)，仓库为 [MIT](https://github.com/shadesofdeath/Crisp/blob/main/LICENSE)。参考「滚动、等待、采样、匹配、停止」的工作流，本项目没有复制其实现。
- [xutianyi1999/scrollshot](https://github.com/xutianyi1999/scrollshot)：本轮检查未确认明确可复用许可，仅借鉴交互，不复制源码；不要与同名其他仓库混淆。
- [QQScreenShot 提取版](https://github.com/insoxin/QQScreenShot)：调用 QQ 私有组件的提取/启动工程，不能据此把 QQ 内部拼接算法视为公开实现。本项目未引入其 DLL、图标或代码。
- [Electron desktopCapturer](https://www.electronjs.org/docs/latest/api/desktop-capturer)、[Chromium NativeDesktopMediaList](https://chromium.googlesource.com/chromium/src/+/refs/heads/main/chrome/browser/media/webrtc/native_desktop_media_list.cc)。
- [SendInput 成功数量与 UIPI 限制](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-sendinput)、[Windows 前台激活规则](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setforegroundwindow)。
