# 录屏 REC-01 / REC-02 实施与验证报告

后续状态：REC-03～05 已接入正常录屏、播放另存、控制恢复和声音，最新结果与声音验证边界见[阶段3～5报告](RECORDING-STAGES-03-05.md)。下文保留阶段1、2完成时的历史状态。

日期：2026-10-22。对应[开发计划](RECORDING-PLAN.md)的框架与技术实验两阶段，均已完成本轮门槛。正常录屏入口继续显示未接入；真实用户录制、控制条和另存对话框属于 REC-03。源码版本保留 `0.16.1-test.3`，未生成新的目录包或改桌面入口。

## 本轮实现

### REC-01：契约与会话框架

- 新增录屏选项/schema、状态、命令、能力、媒体信息与统计契约。当前明确只接受无声选项，声音请求会被拒绝。
- `RecordingService` 实现现有 `CaptureModeExtension`：独立会话 ID、递增状态 sequence、准备/倒计时/开始/暂停/继续/完成/取消与故障状态。
- 后端和文件输出采用接口注入；等待引擎确认后才改变状态。完成等待最后数据块及输出封尾，重复完成只停止一次。
- 准备阶段响应框选取消；媒体准备并完成交接后解除旧选区信号，录像由独立 AbortController 持有。旧会话的迟到数据和命令不能作用于新会话。
- 暂停时长通过单调时钟排除；完成命令冻结录制时长，写盘排空时间不计入该时长。暂停/继续目前以单元替身验证，真实交互验收留在 REC-04。
- 注册表新增显式 `available` 与活动会话互斥。正常应用已接入录屏生命周期与显示器/退出清理钩子，但 `available:false`，不会由实验代码开放用户录屏。
- 取消会等待在途准备/输出；清理失败保持错误和互斥锁，可重试关闭，不把删除失败报成取消成功。

### REC-02：独立媒体宿主与真实媒体实验

实际路线为：指定显示器源一次枚举 → `getDisplayMedia` 持续视频流 → `requestVideoFrameCallback` 驱动 canvas 裁剪 → `captureStream` → `MediaRecorder` → 有界压缩数据块 → 主进程文件。

媒体宿主使用独立 BrowserWindow、sandbox、上下文隔离、窄 preload 桥接和专用内存 Session。仅接受精确本地页面的主 frame、当前会话 ID、连续块号；拒绝重复屏幕授权、外来 renderer、音频权限和摄像头权限。主程序原 `defaultSession` 的拒绝策略保留。

宿主准备时显示一个开发实验按钮，之后可以隐藏或最小化。受信点击由测试中的 `webContents.sendInputEvent` 产生；媒体授权回调记录 `userGesture:true`。这验证了浏览器受信输入路径，不等于人工鼠标完整交互验收，也不是后台静默录像接口。

## 实验发现与对应修复

| 发现 | 证据与处理 |
| --- | --- |
| 本机权限名称与最新文档存在差异 | Electron 44.7.0 实际把屏幕请求报告为 `media`，且 `mediaTypes:[]`。专用 Session 只兼容这一空数组或新版 `display-capture`；命名的 `video/audio` 摄像头/麦克风请求继续拒绝。frame、页面、单次授权仍需匹配。[Electron 官方变更记录](https://github.com/electron/electron/blob/main/docs/breaking-changes.md) |
| 原始流式 WebM 初次加载 duration 为 Infinity | 第一轮录像能播放并在扫描后得到时长，尚不满足有限初始时长。写入第一块时为 Info 中的 Duration 预留 11 字节，结束时按会话时钟填值；后续压缩数据位置不再变动，不重编码。仅支持当前 Chromium 产出的无索引流式布局，异常布局拒绝，未做通用 WebM 修复器。[Matroska 元素定义](https://github.com/ietf-wg-cellar/matroska-specification/blob/master/ebml_matroska.xml) |
| H.264 的奇数尺寸发生截边 | 初始 601×361 canvas 被实际解码为 600×360，第一轮 MP4 判定失败。现对 MP4 在右/下补黑边至 602×362，保留完整 601×361 ROI；媒体状态分别记录 crop 和 padding。WebM 保留奇数尺寸。 |
| 不能依赖整段 Blob 或无限 Promise 链 | 引擎在 Blob 转换前预留预算，当前写入也计数，逐块确认后释放；主进程再按块号和预算校验。初始上限为单块 16MiB、待处理 8 块且最多 32MiB；超限明确失败。该预算不等于 Chromium、IPC 拷贝和 GPU 的总内存上限。 |

没有使用 QQ 私有 DLL、引入外部录屏依赖或复制调研项目源码。系统声音、麦克风和音画同步没有在此阶段实现。

## 最终媒体实验结果

最终报告：`.runtime/recording-spike/2026-10-22T11-41-13-704Z/report.json`。

环境：Windows 10 `10.0.19045`，Electron `44.7.0`，Chromium `152.0.7977.130`；单显示器 2560×1600，系统缩放 150%，Electron bounds 为 1707×1067 DIP。未关闭硬件加速；没有证据判定实际使用硬件编码器。

只把自建运动测试窗口内部的固定 ROI 写入视频，实际 ROI 为 601×361 像素。完整显示器流在媒体宿主中读取，未把 ROI 外的桌面画面写成录像；无音频。

| 实验 | 输出 | 会话时长 / 初始容器时长 | 裁剪回调帧数 | 写入文件 | 应用待处理峰值 | 停止至 ready |
| --- | --- | --- | --- | --- | --- | --- |
| 隐藏宿主，VP8，10 秒 | WebM 601×361 | 10.003s / 10.003s | 291 | 530,643 B | 63,708 B / 1 块 | 16.8ms |
| 最小化宿主，VP8，3 秒 | WebM 601×361 | 3.007s / 3.007s | 88 | 148,824 B | 52,222 B / 1 块 | 12.3ms |
| 隐藏宿主，VP9，3 秒 | WebM 601×361 | 3.003s / 3.003s | 87 | 175,307 B | 70,369 B / 1 块 | 12.7ms |
| 隐藏宿主，H.264，3 秒 | MP4 602×362 | 3.002s / 3.021s | 87 | 84,210 B | 84,210 B / 2 块 | 12.3ms |

四组均验证了：

1. 根据 `display_id` 唯一匹配指定显示器，每会话只枚举源一次，实际流为 2560×1600；找不到不回退主屏。
2. 从本应用落盘的文件重新加载、解码与拖动播放；尺寸与声明一致、初始时长有限。
3. 四角 RGB 标记在三个播放时间点均通过容差检查。10 秒样本在 1/5/9 秒读出的运动帧号为 17/57/97，证明隐藏时仍有持续内容变化。
4. 重复获取屏幕流被拒绝；使用同一 preload 的外来 renderer 调用配置被拒绝。
5. 每个会话结束后销毁宿主并取消服务，本次临时输出目录为空；测试视频作为实验产物单独保留。

帧数是裁剪回调期间的计数，不冒充编码帧数或 1080p 性能基准。四角色标与三个时间点采样也不等于逐帧逐像素比对。

10 秒 VP8 文件在播放扫描后，Chromium 将实际 duration 更新到 10.152s，比主进程会话时钟约多 149ms；其他三组保持在表列值附近。有限初始时长问题已解决，编码时间戳与会话计时的精细对齐仍应在后续暂停/继续与首尾帧验收中处理，不能宣称零时间偏差。

## 验证命令与结果

```powershell
npm run typecheck
npm test
npm run build
npm run recording:spike
```

- 类型检查与构建通过。完整单元测试 **285 项通过**，其中本轮新增录屏测试 22 项，原 263 项保留。
- 最终媒体验证用 `node scripts/recording-spike.mjs` 运行上述最终构建，退出 0，四组均 passed。原始 JSON、视频和 `latest.log` 保留在 `.runtime/recording-spike/`。
- 正常应用回归使用最终构建运行 `--smoke-test --longshot-ui-only --longshot-manual-b`，退出 0。普通截图、preload/IPC、Windows OCR、AI 演示、标注/贴图、录屏占位、长图布局/缩放/工具/连续/恢复/控制/双向/正文确认通过。日志：`.runtime/recording-app-regression.log`。
- 首次 esbuild 被沙箱阻止启动子进程（EPERM），使用自动审批通过的沙箱外测试执行后完成；未更改系统安全配置。
- 早期失败记录保留：首次媒体权限拒绝、第一轮 MP4 奇数截边，以及修复前 WebM 初始无有限时长；没有将这些早期结果计入最终通过。

## 文件与接入位置

| 文件 | 用途 |
| --- | --- |
| `src/shared/recording/{contracts,state,geometry,permissions}.ts` | 契约、纯状态、实际位图几何和权限兼容规则 |
| `src/main/services/recording/{backend,recording-service}.ts` | 后端/输出接口和独立会话编排 |
| `src/main/services/recording/{media-host,video-file-sink,webm-duration}.ts` | 媒体宿主、受限 IPC、有界文件输出和有限时长封装 |
| `src/preload/recording.ts` | 专用 sandbox 桥接，无任意 IPC 或 Node 暴露 |
| `src/renderer/recording/{engine.ts,media-host.html}` | 真实视频流、ROI、编码、数据块队列、实验按钮 |
| `src/main/recording-smoke.ts`、`scripts/recording-spike.mjs` | 隔离媒体实验、解码验证、JSON 证据 |
| `tests/recording-{framework,file,webm}.test.ts` | 状态/会话、互斥、坐标、取消、背压、封尾、错误重试与权限测试 |
| `src/main/{bootstrap,index}.ts`、`src/main/services/capture-modes.ts` | 隔离实验路由、正常应用生命周期接入、不可用能力和互斥 |
| `scripts/build.mjs`、`package.json` | 新宿主构建产物和实验命令 |

## 当前边界与下一步

REC-01/02 成立的是可替换框架与当前机器上的真实媒体路径。尚未完成用户控制条/预览保存流程、实际暂停视频验收、有声录制、Windows 播放器兼容、30 分钟资源、1080p/4K 性能、真实多屏/混合 DPI 与 Windows 11。H.264 的短样本通过不等于 REC-06 的 MP4 产品验收。

下一步为 **REC-03：正常“录屏”入口、明确开始与倒计时、无声 WebM 录制、控制条/托盘完成或取消、播放预览与另存。** 开放入口前继续处理计时与尾帧检查、媒体宿主窗口交接、捕获排除及保存失败路径。现有 release 目录不会因为本轮源码构建自动升级。
