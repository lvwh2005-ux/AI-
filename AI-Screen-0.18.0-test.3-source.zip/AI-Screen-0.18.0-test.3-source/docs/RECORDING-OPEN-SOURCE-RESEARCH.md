# 录屏开源源码调查

调查日期：2026-10-22。用于 [录屏开发计划](./RECORDING-PLAN.md) 的技术选型，本轮仅调查和规划，没有引入第三方源码、依赖或录制功能。

## 结论

优先参考 **pear-rec 的 Electron / React / TypeScript 分层和实时区域裁剪链路**，自行实现采集授权、会话状态、暂停计时与有界写盘。eSearch 适合核对选区、暂停、分段处理、FFmpeg 导出的完整流程；ShareX 适合作为以后 Windows 原生后端的实现参考。

它们均为独立开源项目，不能称作 QQ 官方源码。QQ 风格交互的本机静态证据另见 [QQ 调查](./RECORDING-QQ-INVESTIGATION.md)。本次公开搜索未找到腾讯发布的 QQ 截图录屏完整官方源码；这是本次搜索范围内的结论，不代表证明源码在任何地方都不存在。

## 搜索与证据边界

- 使用 GitHub 连接器搜索 `QQ截图`、`QQScreenShot`、`截图 录屏`、`electron screen recorder`，读取候选仓库信息、递归目录、许可证和具体源码。
- 下列实现链路属于静态源码观察，未下载或运行第三方程序，未实测其性能、稳定性和 Electron 44 兼容性。
- 引用固定到调查时的提交，避免默认分支后续变化影响复核。源码描述与本项目建议分开记录。

## 1. pear-rec：最贴近本项目技术栈

仓库：[027xiguapi/pear-rec](https://github.com/027xiguapi/pear-rec)。调查分支 main，提交 `73df24f79d47c316f5faf15862033103931894d1`。项目为 Electron、React、TypeScript；README 标示 Electron 26 / React 18。许可证为 [Apache-2.0](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/LICENSE)。

### 实际源码链路

| 环节 | 可复核源码 | 观察 |
| --- | --- | --- |
| 控制窗、显示器来源和文件保存 | [recorderScreenWin.ts](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/desktop/electron/win/recorderScreenWin.ts#L12) | 主进程创建录屏 BrowserWindow；`desktopCapturer.getSources` 选择屏幕；`downloadURL` 触发文件保存。 |
| Electron 采集及区域数据 | [ScreenRecorder.tsx](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/ScreenRecorder.tsx#L90) | `getUserMedia` 的 desktop 来源获取显示器流；`invokeRsGetBoundsClip` 取得选区。 |
| 实时区域裁剪 | [ScreenRecorder.tsx](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/ScreenRecorder.tsx#L130)、[worker.js](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/worker.js#L16) | TrackProcessor / TrackGenerator 的流转交 Worker，`new VideoFrame(frame, { visibleRect })` 裁剪，TransformStream 输出新视频帧并关闭输入帧。 |
| 混音和编码 | [ScreenRecorder.tsx](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/ScreenRecorder.tsx#L164) | AudioContext 合并系统声和麦克风，MediaRecorder 编码，`dataavailable` 收集 Blob。 |
| 暂停 / 继续 | [ScreenRecorder.tsx](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/ScreenRecorder.tsx#L271)、[PauseRecorder.tsx](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/PauseRecorder.tsx#L10) | 使用 `MediaRecorder.pause()` / `resume()`，同时暂停 / 继续 UI 计时。 |
| 输出 | [ScreenRecorder.tsx](https://github.com/027xiguapi/pear-rec/blob/73df24f79d47c316f5faf15862033103931894d1/packages/web/src/components/recorderScreen/ScreenRecorder.tsx#L217) | 停止后合成 WebM Blob；通过 Electron 下载保存；另有 FFmpeg WASM 转 GIF。该链路不能当作原生 MP4 输出证据。 |

### 可采纳与不能照搬的点

可参考其“主进程选来源 / 管文件、渲染层编排、Worker 裁剪、组件控制暂停”的结构。

不能直接照搬：

- 它用旧版 desktop `getUserMedia` 约束，需在本项目 Electron 44 用实际采集 spike 验证，不能仅改类型声明后认定兼容。
- `recordedChunks` 持有整段录制，`start()` 没有 timeslice；不适合作为本项目长录制的内存方案。
- `stop()` 返回后即清空 chunks，而停止与最终数据事件异步到达，存在时序风险，需以最终事件和写盘完成为准收尾。
- 麦克风被主动请求，音频源为空和权限失败需要独立处理；用户关闭麦克风时不应为了录视频仍强求麦克风权限。
- Worker 对选区做固定 `+1/+2/-3/-4` 调整，不能代替本项目的 DPI、物理像素、边界及奇偶尺寸模型。
- Worker 文件自身保留 WebRTC 作者和 BSD 风格许可证声明；若日后复用文件，还需保存其文件级来源与声明。

## 2. eSearch：选区、暂停和视频处理的完整参考

仓库：[xushengfeng/eSearch](https://github.com/xushengfeng/eSearch)。调查分支 master，提交 `9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d`。TypeScript / Electron，许可证 [GPL-3.0](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/LICENSE)。

[使用文档](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/docs/use/record.md) 区分当前普通 / 超级录屏与旧录屏。**本节核对的是旧录屏 `src/renderer/recorder/recorder.ts`，不能把其实现归给当前普通录屏引擎。** 文档仍保留旧录屏的暂停和长视频用途。

实际链路：

1. [recordInit](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/src/renderer/recorder/recorder.ts#L1034) 接受 sourceId、选区和屏幕尺寸，采集屏幕流并建立 WebM MediaRecorder。
2. [save](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/src/renderer/recorder/recorder.ts#L1076) 将段写入临时目录，调用 FFmpeg 的 `crop=w:h:x:y`；录制时并非只采集 / 编码 ROI。
3. [recordState](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/src/renderer/recorder/recorder.ts#L1146) 切换 MediaRecorder 的 pause / resume。
4. [runFfmpeg](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/src/renderer/recorder/recorder.ts#L501)、[joinAndSave](https://github.com/xushengfeng/eSearch/blob/9bd5e9226d7ed3671ec7be0210db6e2fe5fe0e3d/src/renderer/recorder/recorder.ts#L330) 执行后处理、裁切和拼接保存，支持多种输出格式。

可以借鉴“录制会话 / 后处理任务 / 保存结果”分离、临时文件组织和错误展示。不能直接用其“全屏 WebM 后裁剪”替代我们的实时 ROI 目标，也不能将分段重启编码视作已经满足无丢帧、连续时间戳和长录制要求。它还在渲染层使用 Node 文件与进程接口，与本项目通过窄 preload API 写盘的边界不同。本轮只研究实现思路，没有引入该项目源码。

## 3. ShareX：Windows 原生录制后端参考

仓库：[ShareX/ShareX](https://github.com/ShareX/ShareX)。提交 `1559a3a884c044af7c4aef81035dcc336126ea80`，调查分支 develop。C# / Windows 原生 API；[根许可证](https://github.com/ShareX/ShareX/blob/1559a3a884c044af7c4aef81035dcc336126ea80/LICENSE.txt) 为 GPL v3，所查录制文件头明确 v3 或更高版本。以下为该提交的新原生 `ShareX.ScreenRecordingLib`，不要与仓库中另存的 FFmpeg 录制模块混同。

| 源码 | 实际作用 |
| --- | --- |
| [ScreenRecorder.cs](https://github.com/ShareX/ShareX/blob/1559a3a884c044af7c4aef81035dcc336126ea80/ShareX.ScreenRecordingLib/ScreenRecorder.cs#L35) | 每次录制一个会话和专用线程；Prepare、Start、Pause、Resume、Stop；恢复时等待新目标首帧。 |
| [GraphicsCapture.cs](https://github.com/ShareX/ShareX/blob/1559a3a884c044af7c4aef81035dcc336126ea80/ShareX.ScreenRecordingLib/Video/GraphicsCapture.cs#L66) | Windows Graphics Capture 获取窗口 / 显示器；ROI 与各显示器求交；D3D11 纹理区域拷贝形成输出。 |
| [RecordingClock.cs](https://github.com/ShareX/ShareX/blob/1559a3a884c044af7c4aef81035dcc336126ea80/ShareX.ScreenRecordingLib/RecordingClock.cs#L31) | 媒体时间扣除已暂停时长；恢复后过滤暂停期间保留的旧时间戳。 |
| [MediaFoundationWriter.cs](https://github.com/ShareX/ShareX/blob/1559a3a884c044af7c4aef81035dcc336126ea80/ShareX.ScreenRecordingLib/Encoding/MediaFoundationWriter.cs#L43) | MF SinkWriter 输出 H.264，配置 D3D 管理器、硬件编码和音频编码。 |

这条链路说明可用 WGC → GPU ROI / 色彩处理 → Media Foundation 编码的独立原生后端。适合作为 Electron 路线达不到性能目标时的第二阶段参考。它不是 TypeScript 库，需要独立进程或原生模块、IPC、构建及分发；不应为首版一次引入。多显示器 ROI、暂停时清旧帧、时间戳归一化和固定输出尺寸值得纳入验收思路。未实测其 Windows 版本覆盖、设备兼容与吞吐量。

## QQ 名称仓库的辨别

[insoxin/QQScreenShot](https://github.com/insoxin/QQScreenShot) 是第三方维护的“QQ 截图工具提取版”。固定提交 `547a3f1ab7eafbc72b0283d6a24530c719b54821` 的 [README](https://github.com/insoxin/QQScreenShot/blob/547a3f1ab7eafbc72b0283d6a24530c719b54821/README.md) 自述录屏功能已逆出，使用 QQ 内部 DLL，并提示兼容模式和首录异常。

已读取完整递归目录：该提交主要是 QQ 资源、脚本和配置，未发现 `.cpp/.h/.sln/.vcxproj` 等录屏引擎工程源码，也没有在该 Git 树内发现 `.exe/.dll` 文件。README 所述可执行包不等于仓库提供完整可构建源码。其根目录虽标 GPL-3.0，不能据此将提取的 QQ 组件称为腾讯开源组件，不能当作可直接引入本项目的 QQ 录制 SDK。

其他命中名称包括 QQ 截图启动器、旧版截图复刻与截图编辑示例；本次未从这些候选获得比以上三项更完整且适配本项目的区域录屏源码证据，故不列作实现基线。

## 对本项目的建议

1. 先验证一条小链路：专用 session 的 recording worker BrowserWindow → 明确授权的屏幕流 → 物理像素 ROI 裁剪 → MediaRecorder → 小块有界传输 → 主进程临时文件。用录制 spike 验证 Electron 44 行为、容器与编码组合，避免从旧版示例直接推断。
2. QQ 静态证据用于约束开始 / 停止、系统声 / 麦克风开关和预览保存流程；编码、采集、IPC 与文件方案独立实现。
3. 原型必须实际检查 pause / resume 音画连续、时长与 seek、无音频设备、拒绝麦克风授权、混合 DPI、多显示器、长时间录制、磁盘写入失败、取消和退出清理。候选项目有对应 API 不等于这些性质已验证。
4. 保留 backend 接口以便以后接 WGC / Media Foundation。首版是否支持 MP4，以 spike 结果和输出兼容性为准，不把 WebM 改扩展名当作格式实现。

以上建议是架构选择，并非声称已实现或验证。分阶段交付及最终验收条件以 [RECORDING-PLAN.md](./RECORDING-PLAN.md) 为准。
