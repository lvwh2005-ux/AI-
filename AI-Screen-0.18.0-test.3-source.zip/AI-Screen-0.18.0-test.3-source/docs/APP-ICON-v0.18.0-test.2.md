# 应用图标更新 · v0.18.0-test.2

2026-10-23，按要求替换旧的深色方框与斜三角图标。

![新图标](../assets/icon.png)

新图形采用蓝色渐变圆角底、白色屏幕轮廓和浅青色 AI 星芒。首页品牌图形、Windows 可执行文件、窗口图标、托盘和桌面快捷方式使用同一设计。

资源：`assets/icon.svg` 为可编辑图形，`assets/icon.png` 为 512×512 透明 PNG，`assets/icon.ico` 包含 16、20、24、32、40、48、64、128、256 px。小于等于 24 px 的版本加粗屏幕线条。运行 `scripts/generate-icon.ps1` 可重新生成，沿用项目原有的代码绘图流程。

本次修改为图标资源和首页品牌图形。类型检查与生产构建通过，ICO 的九个目录尺寸与 PNG 子图尺寸一致，并检查了 16、32、512 px 预览。

目录包已生成。源码、构建与 ASAR 中的图标逐字节一致；从新可执行文件提取的关联图标也已确认是新图形。核对记录：`.runtime/icon-refresh-v0.18.0-test.2/icon-check.json` 和 `.runtime/recording-package/0.18.0-test.2.json`。

桌面 `AI Screen.lnk` 已更新到 v0.18.0-test.2，目标、工作目录和图标路径均重新读取核对，并通知 Windows 桌面刷新。旧快捷方式备份于 `.runtime/icon-refresh-v0.18.0-test.2/AI Screen.previous.lnk`。

运行 `release/v0.18.0-test.2/win-unpacked/AI Screen.exe` 或该版本目录中的“启动新版.cmd”。正在运行的旧版需要先从托盘退出，随后新实例的窗口与托盘图标才会更新。

旧资源与生成脚本保留在 `.runtime/icon-refresh-v0.18.0-test.2`，旧应用目录保留。
