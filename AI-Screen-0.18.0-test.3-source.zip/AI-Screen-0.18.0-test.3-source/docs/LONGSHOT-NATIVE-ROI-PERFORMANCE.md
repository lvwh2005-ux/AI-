# 长截图流畅度：原生ROI采集

2026-10-22；候选版本 `0.16.1-test.2`。用户已确认上一候选能够完成桌面长截图，本轮处理流畅度，不将兼容性修复当成速度已达标。

## 改动与边界

此前虽将采集迁到独立Electron进程，仍每帧调用 `desktopCapturer.getSources()` 获取整屏图像再裁切；受控连续场景约3.3fps、读屏约300ms。新路径保留独立采集代理，启动一个仅通过继承管道通信的Windows原生ROI工作进程，持续复用屏幕DC、内存DC和顶向下32位DIB；每个请求只用BitBlt取得原分辨率选区BGRA。实现依据 [Microsoft BitBlt](https://learn.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-bitblt) 与 [DIB创建文档](https://learn.microsoft.com/en-us/windows/win32/gdi/bitmap-creation)。没有调用QQ私有DLL，也没有宣称已实现DXGI Desktop Duplication。

工作进程没有窗口、输入注入、网络、文件图像、剪贴板或设置访问。首读失败可回退旧快照路径；第一帧成功后禁止切换像素源，后续错误停止采集并保留已验证长图。IPC校验尺寸、长度、魔数、时长并限制一个在途请求；取消/断管/超时清理工作进程。进程以Per-Monitor V2 DPI感知处理物理坐标，逐帧验证原显示器边界；显示器布局变化需重新框选。

采集上限30fps，防止空转；现有3帧/64MiB保序队列、共享Analysis Pixel Budget、原图校验与增量文档保持。预览完成间隔从250ms降为100ms，仍只有一个在途渲染和一个dirty标志；实际显示频率还取决于取样和PNG耗时，不承诺10fps或60fps。暂停或释放后工作进程不会持续自主读屏。

诊断现在记录实际 `gdi-roi` / `electron-snapshot` 后端，并显示“原生选区采集”或“显示器快照裁切”。启动回退会如实反映，不能只看版本号就认定使用了新后端。

这是原生GDI选区读取，不是视频流、降分辨率缩略图或有损编码。BI_RGB未定义的高字节设为255，RGB来自原生选区；在本次SDR受控屏幕上与旧采集逐字节一致。没有借放宽正文/历史校验阈值提速。

## 尺寸矩阵

`.runtime/longshot-capture-bench/2026-10-22T01-59-50-055Z.json`：13组尺寸×4种路径，每种预热1次、测量4帧。路径为旧主进程快照、旧独立快照、直接原生、完整独立原生；52组输入/输出全部逐像素正确。13组独立原生均有实际native-grab调用证据，每组4次，未把启动回退误记为原生结果。

| 物理尺寸 | 旧独立快照P50 | 完整独立原生P50 |
| --- | --- | --- |
| 400×400 | 255.22ms | 4.81ms |
| 400×500 | 250.71ms | 7.53ms |
| 800×800 | 255.36ms | 13.38ms |
| 1500×900 | 261.58ms | 26.02ms |
| 1600×1000 | 270.14ms | 26.50ms |

这些是读取时延，帧间还有限速、原图复制、匹配、绘制等待和队列约束，不能取倒数宣称真实滚动帧率。每组4个测量样本用于功能/回归对照，不能当成长期分布。实际持续帧率另行测试。

启动回退已通过真实进程测试：故意在缺少native-capture.exe的独立测试目录运行，实际后端回落为electron-snapshot，输入/输出像素一致。证据 `.runtime/longshot-capture-bench/2026-10-22T02-00-24-965Z.json`。没有在已经提交原生帧的会话中回退。

## 连续管线与正确性

源码原生手动专项 `--smoke-test --longshot-only --longshot-ui-only --longshot-manual-b --longshot-edge-control` 退出0。实际后端为gdi-roi，150%系统缩放。901×823连续场景73次读取、72次处理、61次追加、0拒绝、完成时1次过期丢弃，约21.84fps；原图新增1110行，全部像素正确。此前同类快照场景约3.3fps。预览节奏也已调整，因此是整条候选实现的对照，不把全部收益归为某一个IPC细节。

读屏平均56.01ms（含启动/等待）、匹配往返14.91ms、预览42.88ms；峰值2帧/5,932,184字节、0背压。不能将异步阶段耗时相加当成串行周期或CPU占用。

同一专项还通过：保护浮层/预览/菜单不混入原图、移动滚动条正文确认、双向回看、失联重接、暂停恢复、原图复制/PNG、诊断导出和取消清理。保护窗口行为需实测；[Electron文档](https://www.electronjs.org/docs/latest/api/browser-window#winsetcontentprotectionenable)说明Windows使用显示亲和性，本轮没有仅凭API名称假定新后端会正确排除浮层。

256项测试通过，包含新增原生二进制协议的任意分片、畸形/超大/多余数据、取消、并发读取、超时、进程退出、限速等待与启动回退/首帧后源一致性；构建和TypeScript检查通过。

日志：`.runtime/longshot-fast-capture-tests.log`、`longshot-fast-capture-build.log`、`longshot-fast-capture-native.log`。源码诊断备份 `.runtime/longshot-fast-source-stitch-diagnostics.json`。

## 长期资源与候选交付

长期基准已退出0：400×400/800×800各60秒、1600×1000共300秒，前后静置及12次取消重启，总计约8分钟、8,712帧。三组成品逐像素正确，实际后端均为gdi-roi，全部队列排空，0背压；进程树采样包含应用、采集代理、原生工作进程、GPU/Utility及自建画布渲染器。

| 尺寸/持续时间 | 处理帧数 | 实际帧率 | 读取P50/P95 | 队列峰值 |
| --- | --- | --- | --- | --- |
| 400×400 / 60秒 | 1295 | 21.56fps | 39.36 / 46.30ms | 2帧 / 1.28MB |
| 800×800 / 60秒 | 1326 | 22.07fps | 35.32 / 42.49ms | 2帧 / 5.12MB |
| 1600×1000 / 300秒 | 6091 | 20.29fps | 34.21 / 38.31ms | 2帧 / 12.80MB |

这里的读取包含限速等待、原图复制和IPC；与上表间隔绘制后的单次API读取口径不同。固定4800px范围往返，后续回看不会新增行，不将回看时新增速度为0当成采集卡住。预览实际完成次数分别507/386/1724，不把100ms节流当成保证每秒10次完成。

1600×1000高熵场景进程树Private Bytes峰值922.9MiB，Working Set之和峰值1263.2MiB，平均CPU约148.9%（一个逻辑核=100%）；包含测试画布及GPU开销，不能直接当成真实目标应用下的产品常驻内存。Working Set相加会重复共享页，Private Bytes不是RSS。后半段私有提交趋势约-4.69MiB/分钟，未观察到持续正向增长；前后静置末值约241.9/299.8MiB，存在保留堆/缓存差异，不能凭单次运行宣称完全无泄漏。采集阶段事件循环P95约20.8～24.2ms。

12次新建/取消读取/释放通过。恢复静置时进程数回到4，最终退出后只读检查原生及Electron采集助手残留0。采样间隔约1.5秒加枚举耗时，短生命周期进程可能未逐个被采到，因此退出残留另行检查，不用采样器“没看到”代替退出证据。

原始报告：`.runtime/longshot-resources/2026-10-22T02-01-33-716Z/benchmark.json`、`resources.json`、`process-tree.jsonl`；日志 `.runtime/longshot-fast-capture-resources.log`。这完成PERF-05B本机受控基准，不等于跨应用/多DPI验收。

## 候选包验收与入口

`release/v0.16.1-test.2/win-unpacked/AI Screen.exe` 已打包。ASAR版本0.16.1-test.2、两个Worker与原生路由已核对；native-capture.exe放在resources目录而非ASAR内部，和构建输出SHA-256相同。

打包版手动专项及自动/焦点/暂停恢复/取消/Chromium默认滚轮专项均退出0，stderr均为0字节。手动连续场景约21.94fps、59次追加、0拒绝，像素一致；自动主场景新增720行、8次真实滚轮输入，约6.49秒，保持自适应输入、到底复查及焦点保护。自动整轮采集profile记录124次native-grab、0次快照source-read，未静默回退。整轮事件循环P95约19.94ms、最大1.21秒；该轮包含测试同步像素校验及完成阶段，尚未按阶段归因这个最大值，不能据此声称全流程没有长尾。

日志 `.runtime/longshot-fast-packaged-manual.log`、`longshot-fast-packaged-auto.log`；诊断 `longshot-fast-packaged-stitch-diagnostics.json`；profile `longshot-fast-packaged-auto-spans.json`。已检查实际诊断后端gdi-roi及版本，退出后助手残留0。

桌面“AI Screen 长截图修复候选”已改指test.2；旧候选链接备份在新目录 `previous-candidate.lnk`。先从托盘退出旧实例再启动，避免单实例锁返回旧版本。稳定旧版入口保留；本次提供目录候选包，未制作正式NSIS安装包。

SHA-256：程序 `54b0ce3c9701c80157b71dca4dfe064a5938755869ceb4915de8c0e45ee3f9f1`；app.asar `e77d21c41118a900b2b58211e277681e9cf3d2617e81d8b30ad9c2a8e1756f25`；native-capture.exe `5cd1159da76e116faef207b73db2869c1ff67403d829f87fc96f26a35ae29be5`。

真实应用主观流畅度、100%/125%/200%实际系统缩放、混合DPI多屏、HDR、Windows11等尚未全面验证，不把合成场景等同真实应用矩阵。

| 阶段 | 状态 |
| --- | --- |
| 原生ROI采集、限速与诊断后端证据 | ✅ 已完成 |
| 预览100ms合并、256项测试/构建 | ✅ 已完成 |
| 13组尺寸矩阵与启动回退 | ✅ 已完成 |
| PERF-05B全进程长期基准/取消清理 | ✅ 已完成本机受控基准 |
| test.2目录包、自动/手动回归、候选快捷方式 | ✅ 已完成 |
| PERF-06真实应用/完整系统DPI矩阵 | ⬜ 未完成 |
| PERF-07正式安装包交付 | ⬜ 等待完整验收 |
