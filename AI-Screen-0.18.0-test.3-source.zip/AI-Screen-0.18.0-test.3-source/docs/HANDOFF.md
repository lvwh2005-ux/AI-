# 给 GPT-6.1-sol 的开发交接

**2026-10-22当前最新（大选区/预览）：** 用户test.2实际诊断2559×1543、199读/108拒绝/零增长且无读屏错误。已复现并修复正文占宽门槛、长分析带横向采样不足及白底重复前缀候选消歧；原像素验证、外围验证、显式正文确认保留。缩略图有界面积滤波；实时和完成页原图快捷入口，100%统一物理像素。263项测试、构建、源码及发布文件普通/大选区手动全套、自动/焦点/取消全套通过；最终错误日志0。打包连续901×823约21.69fps、2392×1303约14.60fps，拒绝0/背压0；大选区白底文字和移动滑块正文已验证。桌面候选指向v0.16.1-test.3，旧链接备份在该release目录。用户真实应用/完整DPI仍待复测；8分钟资源属于test.2历史证据，不能记作test.3长期实测。见[本次修复和交付](LONGSHOT-LARGE-ROI-PREVIEW-FIX.md)。以下test.2/test.1“当前”描述均为历史。

**2026-10-22当前最新（流畅度）：** 用户确认test.1可以拼接，但不够流畅。已以持久Windows GDI/DC/DIB的原生ROI工作进程替换逐帧整屏枚举，默认最高30fps，启动可回退但首帧后禁止换源；预览完成间隔100ms，诊断记录实际后端。256项测试、构建、13组×4路径像素矩阵、缺失原生程序回退、约8分钟全进程资源/8712帧/12次取消重启全部通过；PERF-05B本机受控基准现已完成。候选test.2打包版手动/自动/焦点与默认滚轮专项退出0，错误日志0；手动约21.94fps，三尺寸长期约20～22fps，原图一致。桌面“AI Screen 长截图修复候选”已指向v0.16.1-test.2，旧链接备份在该目录；先退出旧托盘实例再启动。实际三应用观感/完整DPI及正式NSIS仍未完成。详见[原生ROI提速与资源报告](LONGSHOT-NATIVE-ROI-PERFORMANCE.md)。下方“仍逐帧旧API”“05B未执行”“当前test.1”均为历史，勿覆盖最新结果。

**2026-10-22本轮最新：** 已读到用户v0.16.0诊断：91帧/23次变化/57次拒绝、0追加、overlap-rejected；不能把像素变化直接当成正文已更新。已复现并修复固定侧栏/输入区加外侧移动滑块导致正文建议被拒绝的缺口，保持显式确认和原像素验证。249项测试、构建、源码原生手动专项及候选打包版含移动滑块专项均退出0。候选 `release/v0.16.1-test.1/win-unpacked/AI Screen.exe` 和桌面 `AI Screen 长截图修复候选.lnk` 已提供，原入口保留；先退出旧托盘实例再启动候选。该修复尚不能证明用户三应用全部通过；05B长期资源、06完整应用/DPI、07正式安装包仍未完成。当前构建/测试审批已恢复，不能继续沿用下方历史“本轮未打包/无新测试”的说法。详见[实际诊断与修复/交付证据](LONGSHOT-DESKTOP-MATCH-FIX.md)。

**2026-10-22桌面应用兼容调查：** 用户确认从桌面快捷方式测试，Codex/微信/企业微信均为“首屏正常，手动滚动后长图不增长”，先排除自动输入路径。已只读核对快捷方式与ASAR：实际仍为旧v0.16.0，包中缺少有界搜索、独立采集和预览助手。使用REA/Ghidra完成QQ截图启动器与Camera.dll第一轮静态取证：有DXGI循环读取、失败转GDI、后台拼接任务及独立派发缩略图的函数调用证据；尚无用户失败场景运行复现，不能认定更换采集后端即可修复。微信/企业微信测试工具读窗均超时，不等同本产品故障。优先查最早失败层，再做05B/06/07，详情与阶段表见[桌面应用与QQ逆向调查](LONGSHOT-DESKTOP-REA-INVESTIGATION.md)。本轮未修改产品源码、打包或更新快捷方式。

**2026-10-22最新任务：** 用户已授权继续完成PERF-05B/06/07，撤销下方“阶段02/03/04完成后停止”的旧范围限制。新增约8分钟原生资源基准、进程树CPU/内存/句柄采样和阶段汇总工具；TypeScript、PowerShell解析、Node脚本语法检查通过。Chrome/Edge/微信安装版本已核实。实际原生基准和微信窗口读取均被自动审批服务断流阻止，动作未执行；普通沙箱内本次build/test又遇到esbuild `spawn EPERM`。未打包、未改版本号或桌面入口，不得把工具准备记成阶段验收。审批恢复后从资源基准执行开始，再做真实应用/真实系统DPI，最后打包/更新入口。详情见[交付执行状态](LONGSHOT-DELIVERY-STATUS.md)。下方2026-10-20的244项测试与原生回归是历史结果，本次没有新的运行通过证据。

用户目标：搭建一个类似 Windows 截图的 AI 屏幕助手大体框架，并保留后续完善空间。不是仅做网页概念稿，也不是本阶段完成所有产品能力。

最新交付为 **v0.16.0，长截图专项4.1：兼容性诊断、报告与空返回有界重读**，验收与运行位置见本文末尾；下面各版本段落保留为历史。用户要求优先手动滚动，不再死磕自动。阶段2已完成有界采集、局部容错与恢复、双向覆盖/回看，阶段3完成自动避让、拖动/大小、原图比例/可见区供图。4.1交付证据与本地报告，不代表真实应用矩阵完成。请先读MANUAL-LONGSHOT、LONGSHOT-COMPATIBILITY、专项计划和ARCHITECTURE。下一小阶段4.2使用公开浏览器页面/演示窗口验证手动兼容；持续帧源、微信、混合DPI等尚未验收，自动仍实验后端。下方旧自动验收不能当作当前版本自动已全面验收。

**最新任务优先级（2026-10-20）：** 用户授权“完成2,3,4”，PERF-02/03/04均已完成并停止扩展。先读[当前性能计划](LONGSHOT-PERFORMANCE-PLAN.md)和[阶段02/03/04报告](LONGSHOT-STAGES-02-04.md)。已统一整帧分析配额、删除高度穷举回退，预览取样/编码使用独立Worker与不可变共享文档段，并完成自适应滚轮幅度/等待、半格兼容与稳定判断。244项测试、构建、13组416次CPU位移及最终自动/手动原生整套通过，错误日志均为空；实际轮幅变化、焦点保护与默认Chromium连续多帧已验证。预览压力下匹配P50 55.25→14.00ms，但常用路径纯CPU与原生吞吐未继续变快，不代表大小选区整体速度已统一。PERF-05A保留已完成状态；05B全进程资源、06真实应用/多DPI、07发布仍未执行。源码未发布，桌面入口仍v0.16.0，旧ROI原始证据保留。下方各版本与首轮结果均为历史。

## 已搭建

Electron + TypeScript + React 桌面工程。主进程 / preload / renderer / shared 分离；全局快捷键、托盘、当前显示器冻结截图、矩形框选、悬浮工具栏、图片复制、结果窗口、配置、密钥系统加密、演示与兼容 API、视觉 OCR 适配器、追问和请求取消。构建、类型检查、单元测试、Electron 集成冒烟与 Windows 打包命令已提供。

请先阅读 README.md、docs/ARCHITECTURE.md 和 docs/PRODUCT.md，再执行必要检查。按用户最新偏好，UI 采用白灰工作台与紧凑悬浮工具栏，后续迭代保留此视觉方向。

## 接手后的第一轮

1. 审查主进程、IPC、窗口生命周期和异步请求之间的边界，修复有证据的具体问题。
2. 跑 typecheck、test、build、smoke，记录真实结果；不要将未接入的真实 AI 测试写成通过。
3. 重点检查选区边缘、取消和关闭窗口时的清理、快捷键冲突回滚，以及多轮对话上下文。
4. 避免在未授权范围内大改架构或自动启用联网服务，默认保持演示模式。
5. 将交接检查结论写在本文件末尾，向主代理说明接手完成、修复和剩余风险。

## 建议的下一轮优先级（按 v0.3 更新）

- P0：混合 DPI / 多显示器人工验收，真实视觉模型联调。
- P1：处理用户在 v0.3 的实际体验反馈。
- P2：用户授权阶段四后进行安装包与签名、更新、开机启动。
- P3：可选历史、贴图、标注、滚动截图、跨屏选区。

## 第一阶段验证记录

2026-10-09，在 Windows 10、Node 22.23.2 环境完成：

- `npm run build`：通过（包含 TypeScript 严格类型检查）。
- `npm test`：最终 23 项测试通过，覆盖几何裁剪、服务请求、角色权限、请求竞态、取消和会话清理。
- `npm run smoke`：通过，真实 Electron 44.7.0 验证三个窗口、preload 隔离、IPC 角色授权、屏幕读取与裁剪、系统加密往返、演示回复、追问与请求取消。
- `.runtime/smoke-home.png`：已视觉检查；布局正常，较矮窗口通过滚动访问底部设置。
- GPT-6.1-sol 修复后，主代理再次完成类型检查、构建、23 项测试及源码版/打包版 Electron smoke，全部通过。目录版位于 `release/win-unpacked/AI Screen.exe`；打包版检查日志位于 `.runtime/packaged-smoke.log`。开发启动流程也已验证。
- 真实 AI / OCR / 翻译服务：未配置 Key，未联网联调，不计为通过。
- 100%~200% 混合 DPI、多显示器边界、真实剪贴板粘贴、托盘与全局快捷键冲突：仍需人工验收。
- `npm audit`：8 项 moderate，全部来自 electron-builder 开发打包依赖链（sprintf-js → roarr → global-agent → @electron/get）；没有 high / critical，未涉及 React/Zod 运行依赖。发行前应复核并升级打包链。

构建工具启动子进程在当前 Codex 沙箱中会遇到 EPERM；已在经审批的执行环境运行检查。Electron 二进制官方地址下载慢，已通过镜像下载同版本并由安装器核对 npm 包自带的官方校验和。普通开发环境可直接按 README 的命令运行。

## GPT-6.1-sol 接手记录

2026-10-09：已由用户指定的 GPT-6.1-sol 完成第一轮接手，仅收束第一阶段框架，不扩展功能范围。

- 修复动作 IPC 的角色与参数约束：截图窗口必须提交选区；结果窗口只能操作当前会话，不能提交截图矩形或复制图片；空问题和无效选区在副作用前拒绝。
- 将窗口关闭清理挂接到窗口创建时，结果窗口关闭即取消并清除会话；窗口在加载期间被关闭时不再返回已销毁对象。截图取消、关闭或失败恢复此前可见的主窗口和结果窗口。
- 为截图过程增加失效标记，显示器变化也取消正在等待的截图；阻止重复选区操作，异步复制完成后检查截图是否仍有效，避免关闭后续截图窗口。结果加载失败清理任务，恢复原窗口。
- 结果界面订阅事件后，不允许迟到的初始读取覆盖更新状态。TaskService 仅增加可测试的服务/剪贴板注入，默认演示和真实服务选择不变；保留异步剪贴板写入前后的取消检查。
- 新增 9 项回归测试，覆盖角色参数、取消后的迟到 OCR、旧请求成功/失败、会话清除、剪贴板等待期间取消、12 条上下文及新截图重置、演示 OCR 不自动复制。`npm run typecheck` 通过，`npm test` 共 23 项通过。测试首次遇到沙箱子进程 `EPERM`，随后通过审批在沙箱外运行成功。
- 补充真实 Electron smoke 的角色参数拒绝与运行中关闭结果窗口清理断言；最终 build/smoke 已由主代理统一执行并通过，接手代理没有竞争运行构建或打包。

仍待第二阶段：真实视觉服务联调、混合 DPI / 多显示器人工验收。当前没有配置真实 AI，因此不能称为真实 AI 联调通过。异步系统剪贴板写入一旦开始，系统没有撤销接口；取消仍确保迟到完成不会恢复已取消的结果状态。

按用户最新要求，第一阶段已结束；后续按 ROADMAP.md 分次推进，下一次优先只做阶段二 A，不自动继续。

## 第二阶段记录 · v0.2.0

2026-10-09，用户授权阶段二，并明确选择「先完成接入功能，我之后在设置中配置」。因此本轮完成阶段二开发，不读取或要求聊天中提供真实 API Key。

已实现：

- 设置中新增「测试服务连接」，使用当前表单和内置小图片测试接口，独立于保存设置与截图会话。
- 默认流式回复，SSE 支持 UTF-8 任意分块、CRLF、完成标记与断流检查；非流式 JSON 服务可兼容。增量事件携带 requestId，取消保留已接收文字。
- Windows 本地 OCR：系统 PowerShell + WinRT，进程隐藏、可取消、30 秒超时；图片只经内存/stdin 传递。脚本作为打包资源保存，缺少系统语言包时提示切换识别方式。
- 选区移动、八向缩放、屏幕边界限制、最小 4 DIP；取消拖动恢复先前选区。
- 配置新增 stream 和 ocr，旧设置通过 schema 默认值自动兼容，默认仍为演示 + 视觉 OCR。

验证：33 项单元/本机 HTTP 集成测试通过；类型检查与构建通过；Electron smoke 已通过 Windows OCR 真实文字识别、服务测试 IPC/HTTP/SSE、React 框选/移动/缩放及原有桌面集成检查。主窗口截图已检查。选区交互 smoke 使用合成 PointerEvent 并替代 native pointer-capture；真实鼠标、混合 DPI 与跨显示器仍属于人工验收。

真实外部 AI 未配置，未调用外部模型；模型质量验收待用户自行配置。阶段三和发布尚未开始。

最终检查：v0.2.0 目录版打包成功，OCR 脚本资源已包含；33 项测试全部通过，源码版与打包版 smoke 均通过 Windows OCR、服务测试、选区调整与原有流程。程序为 release/win-unpacked/AI Screen.exe，打包版日志为 .runtime/packaged-smoke.log。

## 第三阶段记录 · v0.3.0

2026-10-09，用户授权「做阶段三」，中途切换后要求继续完成。本轮完成体验与稳定性开发，没有进入发布阶段；沿用用户之后自行配置服务的决定。

已实现：

- 每块显示器独立截图和遮罩，鼠标所在屏幕优先聚焦；发送方窗口身份绑定 displayId。负坐标布局与混合 DPI 使用局部 DIP 和真实位图尺寸裁剪。任一屏幕取消/关闭、提交动作、屏幕配置变化均清理整个窗口组；异步代次标记防止迟到加载恢复遮罩。
- 工具栏通过 ResizeObserver 测量实际高度，含自定义按钮及问题输入时避让屏幕边缘；小屏可换行和滚动。
- 快捷键录制：基于键盘事件生成组合键，临时注销旧快捷键，松键后恢复。Esc、失焦、窗口关闭及 renderer 退出有恢复路径；录制期间主进程拒绝保存和截图。
- 自定义动作：最多 8 项，名称/提示词/启用状态，唯一 ID；在主进程读取已保存配置，支持单次替换 `{{language}}` / `{{question}}`。含问题变量时展开输入框，动作名称与 ID 用于结果和重试，已完成提示词进入对话上下文。
- AI 结果使用 Markdown/GFM、常见代码高亮和原始代码复制；OCR/错误纯文本显示，禁用 HTML 与外部图片，仅显式点击经主进程校验的 HTTP(S) 链接。

验证结果：

- `npm test`：55 项全部通过，新增多屏服务/几何、快捷键、动作配置/请求和 Markdown 安全测试。测试先遇到沙箱 EPERM，审批后执行成功。
- `npm run smoke`：类型检查、构建和源码版 Electron 集成通过。
- 打包版 smoke：退出码 0，验证真实 Windows OCR、模拟 HTTP/SSE、选区调整、整组取消、快捷键录制暂停/恢复、自定义按钮到裁剪/结果的完整路由、GFM/高亮及外链限制。
- `.runtime/smoke-home.png`、`smoke-settings.png`、`smoke-result.png` 已视觉检查；结果截图仅含内置合成图片和测试文字，不保存桌面截图。
- 当前机器检测到 **1 个显示器**。多屏与混合 DPI 仅有模拟几何和服务测试覆盖，真实硬件人工验收未完成；不支持跨屏拼接。
- 没有配置或调用真实外部模型；AI 效果仍待用户自行设置后验证。

交付位置：`release/v0.3/win-unpacked/AI Screen.exe`，需保留整个目录，OCR 脚本已包含。原 `release/win-unpacked` 在打包覆盖时因 DLL 被占用而失败，已改为独立版本输出；不要把旧目录视为本次交付。运行新版前从托盘退出旧实例。

本次实际打包命令：

```powershell
npm run pack -- --config.electronDist=node_modules/electron/dist --config.win.signAndEditExecutable=false --config.directories.output=release/v0.3
```

打包版测试日志：`.runtime/packaged-smoke-v0.3.log`，错误日志为空。目录版尚未签名，也没有安装、升级或卸载验收。阶段四按用户下一次明确授权再开展。

## 图标修正 · v0.3.1

用户反馈托盘与快捷方式图标不一致：托盘原先是代码生成的纯色方块，EXE 在禁用资源编辑时保留了 Electron 默认图标。

- 新增 `assets/icon.ico`（9 个尺寸，16–256 px）、预览 PNG 及可复现的 `scripts/generate-icon.ps1`，沿用蓝色框选标志。
- 主窗口与 Tray 使用构建到 `dist/main/icon.ico` 的同一文件；electron-builder 将同一 ICO 嵌入 EXE。
- 打包配置改为 `signExecutable: false`，保留图标及版本信息编辑。后续不要传 `signAndEditExecutable: false`。
- 类型检查与目录版构建通过，已从 EXE 提取图标并目视验证；ASAR 内图标与源文件字节一致，普通启动成功。
- 桌面「AI Screen.exe - 快捷方式」已更新目标与 IconLocation，指向 v0.3.1 EXE；已备份快捷方式到 `.runtime` 并重启旧后台实例使托盘更新。

构建命令：`npm run pack -- --config.electronDist=node_modules/electron/dist --config.directories.output=release/v0.3.1`。

## 截图唤起优化 · v0.3.2

2026-10-13，用户反馈快捷键调出慢、出现整屏灰屏。本轮只修复这一体验问题。

- CaptureService 从每屏重复枚举改为一次读取整组；完整屏幕预览改用 quality=95 的 JPEG 并缓存，最终裁剪、复制及 AI 图片仍从原始 NativeImage 生成 PNG。
- 预热隐藏选区窗口，反复唤起复用 React 页面；没有在预热时读取屏幕，也没有连续监控。取消/提交时清除源图及 renderer 图片、选区、问题、忙状态，只保留空界面。
- 图片解码握手和 1px compositor 探测完成后才显示窗口。隐藏窗口 rAF 实测受到系统降速，因此最终实现不等待 rAF，也不复制完整画面来触发绘制；探测数据只短暂存在内存。
- 移除框选前 screen-shade 和截图路由的实色背景，初次进入保持原画面，拖出选区后才突出选区；仅隐藏可见的本应用窗口时保留 32ms 合成等待，替代原先所有调用的固定 160ms。
- renderer 就绪信号由当前 sender/display/session 共同约束；超时、窗口退出、屏幕变化及准备过程中取消会结束等待，防止迟到信号恢复旧窗口。
- 构建、类型检查及 58 项单元/集成测试通过，新增一次枚举、预览缓存与原图裁剪、取消及迟到读取测试。打包后的检查日志见 `.runtime/packaged-smoke-v0.3.2.log`。

交付与构建目录：`release/v0.3.2/win-unpacked`；命令 `npm run pack -- --config.electronDist=node_modules/electron/dist --config.directories.output=release/v0.3.2`。多屏硬件验收仍待完成。

最终打包版 smoke 退出码 0、错误日志为空：冷启动（含界面准备）404ms，复用 309ms；通过生产 IPC 连续唤起为 281/316/291ms。本机单屏，耗时仅代表当前机器与这一轮测试。就绪前隐藏、旧就绪信号拒绝、准备中取消、窗口复用以及既有 OCR/AI 演示/选区流程均通过。桌面快捷方式已切换到 v0.3.2，后台实例已重启使优化生效。

## 简约工具栏 · v0.3.3

用户反馈工具栏需要更简约。将常用操作收为约 44 DIP 高的单行，使用统一描边 SVG、短标签、小分隔线与轻量询问状态；移除常驻说明条，服务地址保留在 AI 按钮悬停说明，处理/错误按需显示。询问输入框及自定义操作沿用现有流程，小屏自动隐藏短标签但保留完整 aria-label 和 title。

类型检查与构建通过；打包版 smoke 验证图标、单行高度、询问展开、边缘避让及原有截图/取消/动作流程。连续唤起 320/294/293ms。已视觉检查 `.runtime/smoke-toolbar.png`，预览仅包含应用工具栏，真实屏幕图片和选区已隐藏。日志为 `.runtime/packaged-smoke-v0.3.3.log`，退出码 0、错误日志为空。

交付目录 `release/v0.3.3/win-unpacked`。桌面快捷方式及后台实例已切换到此版本；原图标和服务配置沿用。

## 白灰界面与页面优化 · v0.3.4

按用户要求将工具栏、主页面和结果页统一为白灰配色。全局 styles.css 整理为共享颜色、控件和选区基础样式；Home 独立 home.css，Result 独立 result.css，录制器、自定义动作和 Markdown 同步为浅色。Electron 原生主题固定 light，普通窗口启动背景改浅灰，截图窗口仍透明。

主页面采用页头、左侧截图入口、右侧分组设置与 sticky 保存区；服务字段为 2×2，操作偏好在默认尺寸下完整显示，窄窗可滚动。结果页用白底阅读卡片、可展开选区缩略图和独立追问区，表格/代码浅灰底。所有已有配置和请求流程保留。

类型检查、源码版与打包版 smoke 通过。新增检查 light color-scheme、默认与 800×560 最小窗口无横向溢出且保存区可见。主页面、最小窗口、自定义动作、工具栏和结果页预览已视觉检查；截图来自独立演示配置，工具栏预览使用合成背景并等待绘制，不保存真实桌面内容。

打包版日志 `.runtime/packaged-smoke-v0.3.4.log`，退出码 0，错误日志为空；连续唤起 286/296/294ms。交付 `release/v0.3.4/win-unpacked`，桌面快捷方式及后台实例已更新。

## QQ 风格截图交互改造 · v0.4.0 · 2026-10-15

按用户本轮明确授权，在现有版本上按三个优先级依次整合，没有从零重写。具体文件索引、状态机与扩展方式见 QQ-REFACTOR.md。

已完成窗口候选预选、单击整窗/拖动框选、四模式入口、就近工具栏、双击复制、右键两级返回、原图放大镜、四种标注及撤销清除、独立置顶贴图、AI 识屏窗口/整屏分析。OCR、自定义动作保留在更多菜单。翻译、分析和询问仍由原 TaskService/Provider 请求，结果窗口改为选区附近置顶显示。长截图/录屏有真实模式与选区状态、能力查询、受限 IPC 和独立后端注册接口，但没有采集后端，不能输出长图/视频，入口明确标记待接入。

验证：72 项测试全部通过；TypeScript、构建通过。源码与打包版真实 Electron smoke 通过，涵盖窗口预选点击、拖动/缩放、右键重选、原图取色、四种标注、PNG 合成像素和 2× DIP 线宽、贴图独立生命周期/缩放、创建期间取消、处理中右键重选、双击生产复制路径、demo AI 识屏、扩展模式和原有设置/加密/OCR/流式/Markdown/取消能力。测试隔离 userData，不调用真实 AI、不读取真实 Key、不覆盖用户剪贴板、不保存桌面内容。

源码日志 .runtime/refactor-smoke-v0.4.0.log；打包日志 .runtime/packaged-smoke-v0.4.0.log，最终退出码 0，错误日志为空。源码重复唤起 280/286/286ms，打包版该轮为 413/412/419ms；这是单机样本，不是固定性能保证。无选区时没有整屏灰色遮罩。工具栏 UI 使用合成中性背景检查，见 .runtime/smoke-toolbar.png。

交付目录 release/v0.4.0/win-unpacked；必须保留整个目录。桌面快捷方式指向此版本，图标继续使用同一 exe/ICO。真实服务效果、Windows 11 与真实多显示器/混合 DPI 仍待验收；本机为 Windows 10、单显示器，负坐标/混合 DPI 使用纯几何及服务测试覆盖。预选仅识别顶层窗口，受保护内容和 UAC 桌面受系统限制。后续优先实际设备体验验收，再滚动采集拼接，最后独立录屏编码模块。

## 手动滚动长截图 · v0.5.0 · 2026-10-15

在已有模式扩展上接入独立 LiveRegionSource、LongshotService、Worker/LongshotStitcher 和 LongshotWindow。用户选择内容区域、开始后遮罩关闭，直接滚动原应用；连续稳定采样后自动匹配并追加底部新像素。控制条位于选区外，无处放置时通过托盘/可用全局键操作，打开托盘菜单时暂停采样并丢弃在途帧。

支持开始、完成、取消、累计真实像素高度、预览、完整 PNG 复制与另存。反向、过快无重叠、横移、动态内容、固定栏和重复图案不可靠时拒绝追加，保留可靠片段并明确提示。单屏、仅向下手动滚动；未做自动滚动或录屏。原图保留像素预算 64 MiB、宽度8192/高度30000上限，完成时合并及PNG有额外临时内存。文件职责、输入约束、全部修改/新增清单及用法见 LONGSHOT.md。

处理了本机150% DPI原生尺寸问题：DIP 1707×1067推算2561×1601会触发缩放，改用既有Win32 worker的原生2560×1600尺寸，按nativeOrigin关联。采集源与普通冻结截图完全分开，没有放宽权限或增加运行依赖。关闭窗口先隐藏/解除所有权，50ms后销毁，避免关闭命令无回复以及旧closed回调取消新会话。

验证结果：92项测试全部通过；类型检查、构建、源码与打包版完整Electron smoke均通过，退出码0。覆盖真实自建长Canvas页面document.scrollBy的两次向下追加、静止去重、已知颜色行顺序、原生菜单暂停/恢复、导出PNG像素尺寸、取消保存不写文件、注入剪贴板完整尺寸、跨窗口/旧会话拒绝、关闭和再次开始/取消清理。普通截图、选区调整、OCR、loopback HTTP/SSE、AI演示、自定义动作、Markdown、标注、贴图等回归通过。ASAR内worker已在打包版实际运行通过。

日志：.runtime/longshot-only.log、.runtime/longshot-smoke-v0.5.0.log、.runtime/packaged-smoke-v0.5.0.log；最终错误日志为空。打包版普通截图连续唤起304/311/309ms，是本机该轮样本。测试使用隔离演示设置、自建合成内容；先在内存验色后才保存 .runtime/longshot-smoke.png，不保存私人桌面、不读真实Key、不覆盖用户剪贴板、不调用真实AI。

交付：release/v0.5.0/win-unpacked（整个目录），保留v0.4.0及更早版本。完成打包验证后更新桌面原快捷方式和统一exe图标，并启动新版检查。真实Windows 11/混合DPI双屏、浏览器/PDF/编辑器各类实际页面仍需兼容性验收；下一轮优先这些体验，固定栏/自动滚动和录屏分别扩展。

## 自动滚动长截图 · v0.6.0 · 2026-10-15

按用户提供的 GitHub 搜索研究后，在 v0.5.0 上增量开发。参考 Crisp、xutianyi1999/scrollshot 的滚轮、等待、重叠检测及静止确认流程；QQScreenShot 等提取项目依赖私有 DLL，不能当作 QQ 算法源码。本项目没有引入第三方截图 DLL、复制参考项目实现或增加运行依赖，具体出处见 LONGSHOT.md。

已实现：

- 长截图范围选择后可选「自动滚动采集」或「手动滚动采集」。自动驱动采用隐藏 PowerShell/Win32 `SendInput(-120)`，持续采集仍由原 LiveRegionSource 负责，匹配仍由原 Worker/LongshotStitcher 执行；普通 CaptureService 快照、ClipboardService、OCR、翻译及 AI Provider 不变。
- 主进程把冻结截图候选 HWND 交给驱动，缺失时只允许手动。绑定后固定 HWND/PID/窗口边界，检查选区 3×3 命中、前台、最小化、遮挡、鼠标和修饰键。绑定失败后只能恢复原目标，不会改投另一窗口；仅首次和明确继续尝试激活，无自动点击或每步强抢焦点。
- 初始绑定和继续时将鼠标放到中心，每步不再重新定位；中心每轴允许 12 个物理像素抖动，仍必须在选区且命中原窗口。明显移开会暂停，结束时只有光标仍在原点每轴 2 像素内才恢复原位置。
- 两帧稳定后拼接；重复先等待 1200ms 再复核，连续三次滚动仍无变化且此前确实追加过内容，才自动生成预览。始终没有移动、重叠不可靠、反向或动态画面均明确暂停，不静默错接。预览显示停止原因，仍需用户确认末尾完整。
- 暂停、继续、转为手动、完成和取消均可从独立控制条操作，无空间时从托盘操作。保留高度/帧数/滚动次数、完整 PNG 复制和另存。状态为 preparing/capturing/finishing/done/error，auto/manual 与 paused 独立。上限仍为宽8192、高30000、64MiB保留像素；另限累计1200步、每次继续后10分钟。
- 自动结束在采集 Promise 外触发，避免 finish 等待自身；取消、显示器变化和退出清理进程、定时器、Worker、原帧和窗口。迟到的恢复或滚轮回复不覆盖完成、暂停或手动状态。长图不自动发送给 AI。

新增文件：`src/main/services/longshot-scroller.ts`、`longshot-scroller.ps1`、`src/shared/longshot-auto.ts`、`tests/longshot-auto.test.ts`；`src/main/smoke-window-input.ts` 仅用于自建测试窗口前台准备。修改文件完整清单见 LONGSHOT.md，涵盖长截图服务、模式/IPC合约、控制与入口界面、窗口定位高度、构建资源和文档。

验证：

- TypeScript、构建、97项单元/服务测试通过；保留正常重叠、重复、重叠不足、反向、动态、尺寸变化、负坐标/DPI等覆盖，新增自动停止、延迟内容、无移动不误称完成、资源/次数/时长约束。
- 源码原生长截图独立 smoke 退出码0，日志 `.runtime/longshot-auto-v0.6.0.log`。使用真实受信任 Windows 滚轮和自建 Canvas 页面，经生产 desktopCapturer 多步采集、拼接、已知首尾像素、自动停止、完整复制/PNG保存、暂停恢复、外部焦点暂停、手动回退和自动中取消。另有不拦截默认滚轮、不调用 JS scrollBy 的 Chromium 默认滚动验证。
- 最终打包版完整 Electron smoke 退出码0、错误日志为空，见 `.runtime/packaged-smoke-v0.6.0.log`。涵盖上述长截图及普通框选/窗口预选/移动缩放/复制、OCR、loopback HTTP/SSE、AI演示/询问/自定义动作、Markdown、四种标注、贴图、IPC隔离和取消回归。普通截图该轮连续唤起274/288/317ms，仅为本机样本。
- 后台测试启动没有原生前台权限，测试 helper 仅对指定 data: 合成窗口校验 PID/HWND/客户区和命中后做真实点击，建立正常交互前置；生产滚动模块不点击。测试禁用合成页面的键盘翻页，剪贴板和保存路径注入测试写入器，使用隔离配置，不读真实 Key、不访问真实 AI、不覆盖用户剪贴板、不保存私人桌面。只有验色后的合成内容写入 `.runtime/longshot-smoke.png`、`longshot-auto-smoke.png`；默认滚轮段不保存图片。

交付：`release/v0.6.0/win-unpacked` 整个目录；exe版本资源0.6.0，原生脚本打包前后SHA256一致。已备份原桌面快捷方式至 `.runtime/AI Screen-shortcut-before-v0.6.0.lnk`，更新目标、工作目录与同一exe图标；仅重启已确认路径的旧版主进程。新实例已响应，实际打开快捷方式后主窗口可见，标题为 AI Screen · 屏幕助手，重复启动复用原实例。服务配置不迁移、不改动，v0.5.0及更早目录保留。

限制与下一步：本机Windows10/单屏150%验证，Windows11与真实混合DPI双屏仍需硬件验收。仅单屏向下，不自动去固定栏；空白/重复、动画、虚拟列表、很慢的延迟加载、嵌套滚动和受保护/权限更高的窗口可能暂停或需要手动。三次静止不是DOM到底证明，3×3不是完整遮挡扫描。下一轮优先用户实际浏览器/PDF/编辑器页面兼容、固定栏与延迟加载，再独立完成录屏；录屏仍未接入，真实外部模型质量待用户配置服务验收。

## 长截图体验修复第一阶段 · v0.6.1 · 2026-10-15

用户反馈采集过程不可见、结束后没有长图、缺少长图编辑，允许按额度分阶段处理。本轮仅完成第一阶段：过程可见、结果可信；第二阶段实际复杂页面拼接和第三阶段长图编辑尚未实现。完整计划及文件职责见 [LONGSHOT-IMPROVEMENTS.md](LONGSHOT-IMPROVEMENTS.md)。

确定的问题及改动：

- 原控制条在选区外放不下时会隐藏，改为 440×380 DIP 面板，优先外放，无空间时使用支持系统捕获排除的可见悬浮面板。结果窗口主动显示、恢复并聚焦，不再让用户寻找后台结果。
- 控制面板开启 `setContentProtection(true)`；原生校验只透过本进程、开启捕获排除且通过 HWND/PID/显示亲和性验证的面板查找原目标。其他窗口遮挡、鼠标进入面板仍会暂停。Windows 10 2004 以前若无外放空间，明确报错，不继续采集黑块。
- Worker 从已接受的分段像素直接生成小缩略图；预览不清除原始分段，不为每次刷新合并整张长图。面板显示实时内容、首屏高度、新增行、累计尺寸、暂停和失败原因。
- 完成时检查实际追加行数。没有新增行则标为「首屏截图」「没有拼接出长图」，可复制首屏或保存；不再将单帧伪称为长图完成。没有放宽原保守匹配器，因此固定栏等原因仍可能只留下首屏。
- 复制、PNG 保存、捕获源与普通截图快照隔离沿用原实现；没有新增运行依赖，不自动上传长图。

修改文件：`src/main/index.ts`、`src/main/longshot-window.ts`、`src/main/longshot-smoke.ts`；`src/main/services/longshot.ts`、`longshot-worker.ts`、`longshot-processor.ts`、`longshot-scroller.ts`、`longshot-scroller.ps1`；`src/shared/longshot.ts`、`longshot-stitcher.ts`；`src/renderer/views/Longshot.tsx`、`views/Home.tsx`、`longshot.css`；`tests/live-region-source.test.ts`、`tests/longshot-stitcher.test.ts`；`package.json`、`package-lock.json`、README 与架构/交接/路线图/QQ/长截图文档。新增 `docs/LONGSHOT-IMPROVEMENTS.md`，没有另建重复截图模块。

验证：

- 类型检查、构建、99 项测试通过，新增跨分段缩略图内容/所有权/后续追加及负坐标全屏面板定位覆盖。
- 源码界面专项 `--smoke-test --longshot-only --longshot-ui-only` 退出0。将面板覆盖已知合成页面，经生产 desktopCapturer 采集，在内存逐像素比较最终图与原 Canvas，确认面板未混入图片；验证实时预览增长、可见结果、原尺寸复制/保存、首屏提示和关闭清理。日志 `.runtime/longshot-ui-v0.6.1.log`，错误日志空；只保存验过的合成内容及本应用界面至 `.runtime/longshot-ui-controls.png`、`longshot-ui-preview.png`、`longshot-ui-smoke.png`。
- 打包版完整 `--smoke-test --longshot-panel-overlay` 退出0，日志 `.runtime/packaged-smoke-v0.6.1.log`，错误日志空。特意将面板盖在自动目标 3×3 校验点上，验证原生滚轮多步追加、静止去重、有条件自动完成、暂停恢复、外部焦点暂停、手动回退、取消、默认 Chromium 滚轮、完整图片复制/PNG 保存，以及普通截图/预选/调整/OCR/loopback HTTP/SSE/演示 AI/自定义询问/标注/贴图/IPC 隔离回归。普通截图重复唤起279/299/303ms，为本机样本。
- 第一轮原生测试受到额外滚动输入影响而失败；取得用户「现在方便，继续回归」答复后，上述最终打包版完整回归通过。没有将受干扰测试算为通过；合成 Canvas 测试不等于用户聊天网页已兼容。
- 隔离 userData 与服务配置，注入剪贴板写入器和合成图保存目的地，不读取真实 Key、不请求外部模型、不覆盖用户剪贴板、不保存私人桌面内容。

交付完成：目录 `release/v0.6.1/win-unpacked`，整个目录需保留；exe 版本资源0.6.1，原生 PowerShell 源文件与打包资源 SHA256 一致。桌面原快捷方式已备份到 `.runtime/AI Screen-shortcut-before-v0.6.1.lnk`，目标、工作目录、图标均更新为新版；仅停止核验路径的 v0.6.0 主进程。实际打开原快捷方式后，新版 PID240832 主窗口可见、响应、标题 AI Screen · 屏幕助手，只有一个主实例。v0.6.0 及更早版本目录保留，原配置继续使用。

已知限制及下一轮：第一阶段没有解决固定标题、侧栏、输入栏、动画或虚拟列表的匹配；用户实际页面仍可能不追加，本版会说明原因。下一轮先做第二阶段：用带固定区域的合成页面复现，设计有效滚动区域及固定内容保留，再验证实际页面首尾与接缝。第三阶段才将原尺寸长图接入标注、裁剪、贴图、OCR、翻译与自定义 AI，不应截取缩小预览替代原图。真实 Windows 11/混合 DPI 双屏仍待硬件验收；录屏后端和真实模型质量验收未完成。

## 按 QQ 交互重建长截图 V2 框架 · v0.7.0-preview.1 · 2026-10-15～16

用户认为原长截图仍不可用，要求先规划，再重建框架，并按额度分阶段优化算法。已先写 `docs/LONGSHOT-V2-PLAN.md`，然后实施 A 阶段；B 阶段复杂页面算法、C 阶段长图编辑留待继续。旧源码备份为 `.runtime/before-v0.7.0-framework.zip`，旧目录版保留。新的长截图内部已替换，普通截图/服务层按职责复用。

已实现的交互：框选后关闭原冻结遮罩，在原页面上显示选区外围压暗、外侧边框、就近 440/360×112 DIP 工具栏及独立 220×310 DIP 长图缩略窗。原生窗口用 `setShape` 挖出整个选区，选区内没有本应用的绘制或输入区域。外围背景仅沿用开始截图的 JPEG，在内存中持有；选区内始终是实际应用。工具栏支持自动暂停/继续、转手动、完成与取消；完成会销毁采集表面，显示原图结果，复制/保存继续复用旧服务。没有放置假标注/AI 按钮。

确定并修正的原型问题：本机透明鼠标穿透窗口即使 isContentProtected=true，仍可能污染实际屏幕采集。因此最终采用普通不透明受保护窗口 + 原生挖空形状，不采用 layered click-through 遮罩；缩略窗也使用普通受保护窗口。整屏选择若外围为空，必须隐藏遮罩，不能以空 setShape 列表显示（空列表会恢复矩形）。这些行为已通过遮罩边框及压暗区故意落在合成采集区内的逐像素对比验证，未以属性值代替像素验证。

算法框架：`LongshotWorker → ScrollCaptureEngine → ContentRegion / VerticalMatcher → StitchDocument`。旧 `longshot-stitcher.ts` 仅作兼容导出。位移检测继承原来的正反向候选、唯一性与全像素验证，但与文档提交分离；有效区域先只处理全宽固定头尾，正文匹配成功后才锁定。图像文档将固定底部独立保存，新增正文插在底部之前，头尾只保留一次。固定部分变化、反向、无重叠或动态内容拒绝并保留已有图。尚未加入局部分块运动/侧栏模型和连续多帧区域确认。

新增文件：

- `src/main/longshot-surfaces.ts`：选区表面和独立缩略窗生命周期。
- `src/renderer/longshot/useLongshotSession.ts`、`CaptureToolbar.tsx`、`LiveThumbnail.tsx`：会话订阅、采集工具栏、缩略视图。
- `src/shared/scroll-capture/types.ts`、`engine.ts`、`content-region.ts`、`vertical-matcher.ts`、`stitch-document.ts`、`layout.ts`：算法接口、调度、有效区域、位移、分段图像及窗口几何。
- `tests/scroll-capture-engine.test.ts`、`docs/LONGSHOT-V2-PLAN.md`。

修改文件：`src/main/index.ts`、`longshot-window.ts`、`longshot-smoke.ts`、`services/longshot.ts`、`services/longshot-worker.ts`；`src/shared/longshot.ts`、`longshot-stitcher.ts`；`src/renderer/main.tsx`、`views/Longshot.tsx`、`views/Home.tsx`、`longshot.css`；`tests/longshot-stitcher.test.ts`；`package.json`、`package-lock.json`、README、HANDOFF、ROADMAP、ARCHITECTURE、QQ-REFACTOR、LONGSHOT、LONGSHOT-IMPROVEMENTS 文档。没有新增运行依赖。

验证完成：

- 类型检查、构建通过；104 项测试全部通过。固定头尾合成测试对比三帧拼成的完整原像素，验证 footer 不重复、正文无丢行；变化帧不提交，重复/反向/尺寸/动态/重叠不足/预算等原有覆盖保留。新增负坐标、分数 DIP 原生挖空形状与缩略窗避让测试。
- 源码界面专项通过，随后最终目录版 `AI Screen.exe --smoke-test --longshot-ui-only` 完整集成退出0，错误日志0字节：`.runtime/packaged-v2-ui.log`、`packaged-v2-ui-error.log`。通过生产 desktopCapturer 和 JS 滚动自建 Canvas 验证实际像素采集、增长、结果、原尺寸复制/PNG 保存、首屏提示，以及采集中取消和完成后的所有表面销毁。故意让遮罩边框/压暗区、工具栏、缩略窗覆盖合成内容，最终 PNG 与 Canvas 逐像素相等才保存。原生滚轮不在这个 UI 专项模式中。
- 同一打包检查还通过普通框选、窗口预选/拖动/缩放、OCR、本机 HTTP/SSE、演示 AI/询问、自定义动作、Markdown、标注、贴图、IPC 隔离、取消和配置加密。重复截图唤起283/300/283ms，仅为本机样本。
- 使用隔离 userData、注入剪贴板写入器和合成图保存路径，不读取真实 Key、不请求外部模型、不写用户剪贴板、不保存私人桌面内容。外围桌面快照仅在窗口内存显示，销毁/完成即释放。

交付：`release/v0.7.0-preview.1/win-unpacked/AI Screen.exe`（需保留整个目录），作为独立开发预览。**桌面快捷方式和日常 v0.6.1 实例未更新**：新框架原生滚轮需要键鼠静止验证，已询问时间，尚未收到本轮答复；不以旧 v0.6.1 的原生验收冒充新框架通过。运行预览版前需从托盘退出已有旧版，避免单实例机制激活旧版。

下一轮优先：先完成新窗口结构下真实滚轮的目标绑定/穿透、暂停恢复、遮挡、取消与输出回归，再按 B 阶段处理实际聊天页面固定栏、侧栏、重复文本、动态和延迟加载，核对首尾及接缝。当前固定头尾仅全宽稳定两帧模型，不能称为 QQ 级通用算法；Windows 11/真实混合 DPI 未验证，录屏未接入。C 阶段才做原尺寸长图编辑及 AI。

## B 阶段 · 手动连续滚动采集与正文拼接 · v0.7.0 · 2026-10-16

用户中途明确调整优先级：「没必要死磕自动滚动……确保我自主滚动长截图能把截图拼起来」。本轮据此交付手动采集与拼接改造，自动仅保留实验入口，不以自动输入回归阻塞交付。用户也选择「先完成开发，稍后验收」，本轮没有发送系统滚轮、移动光标或按键。旧源码备份 `.runtime/before-v0.7.0-b.zip`，预览和旧目录版保留。

已修复两个实际采集问题：手动模式原先要求相邻画面静止，连续滚动时可能不接收任何新帧；改为逐帧采集，由后台验证运动中的重叠。完成时原先停止后丢弃在途画面，可能少最后一段；现在排空在途任务，再补采当前视口后生成结果。默认入口、控制器和服务均为手动；首屏出现后可连续缓慢向下滚动，无需每步停顿。

正文处理：全图匹配失败且尚未有追加时，MotionRegion 对最多十个纵向块估计位移，要求连续块共识，逐列细化横向边界，再对完整候选正文验证唯一重叠。裁掉的外部像素必须静止，不能用裁剪掩盖动画或另一列滚动文字。候选通过后暂停提交，显示蓝框和「使用正文区域 / 保留原范围」。只在明确确认后，原子地从首屏重建正文图并追加已验证内容，更新原生选区、继续手动采集。保留原范围不改像素，不重复弹同一建议。已积累长图后不会自动改变坐标模型。

新增数值状态：regionCandidate/contentRect、sourcePixelWidth/Height、verifiedTransitions、lastOverlapRows。confirm-region/keep-region 经原角色和会话 IPC 白名单调用，旧/外来窗口无法操纵。原图仍在主进程/Worker，renderer 只收缩略图及几何。LiveRegionSource 通过实际位图比例把正文像素映回全局 DIP，覆盖负坐标；工具栏坐标取整供 Electron 原生窗口使用。缩略图按实际图像矩形放置蓝框，改变窗口比例后仍对齐。结果页在复制后继续显示不完整/失败原因。

新增：`src/shared/scroll-capture/motion-region.ts`、`tests/manual-scroll-capture.test.ts`、`docs/MANUAL-LONGSHOT.md`。

修改：`src/shared/scroll-capture/engine.ts`、`types.ts`、`src/shared/longshot.ts`、`longshot-auto.ts`；`src/main/services/longshot.ts`、`longshot-worker.ts`、`longshot-processor.ts`、`live-region-source.ts`、`capture-modes.ts`；`src/main/index.ts`、`longshot-window.ts`、`longshot-smoke.ts`、`smoke-window-input.ts`；`src/renderer/capture/SelectionToolbar.tsx`、`ScreenshotController.ts`、`src/renderer/longshot/CaptureToolbar.tsx`、`LiveThumbnail.tsx`、`useLongshotSession.ts`、`src/renderer/views/Longshot.tsx`、`Home.tsx`、`longshot.css`；`tests/live-region-source.test.ts`；版本文件、README 和架构/路线/长截图/QQ/交接文档。没有新增运行依赖。普通复制、PNG 保存、OCR、AI、标注和贴图仍复用既有逻辑。

验证结果：

- TypeScript、构建、111 项测试全部通过，日志 `.runtime/tests-manual-b.log`。覆盖连续变步长、停顿去重、固定侧栏正文明确确认/保留、从首屏开始的完整正文、动画不能静默裁掉、独立滚动列、缺重叠、尺寸和预算限制、确认时超高不改变原图、负坐标的像素回映。
- 源码完整手动集成退出0，`.runtime/manual-b-full-smoke.log`；最终目录版 `--smoke-test --longshot-ui-only --longshot-manual-b` 完整集成退出0，`.runtime/packaged-manual-v0.7.0.log`，错误日志0字节。通过实际 desktopCapturer 采集自建页面，JS 连续分数像素步进期间图片持续增长；立即完成也包含最后视口。带固定侧栏、标题和底栏的页面经明确确认后，所有正文像素从首屏到末尾与 Canvas 相等，实际保存 PNG 也逐像素复验，复制写入器收到完整尺寸。检查保留原范围、取消与所有采集表面清理。
- WindowFromPoint 只读探针验证普通选区和确认正文区命中自建原应用，不被遮罩挡住。探针只验证 HWND/PID/客户端和命中，不注入鼠标/键盘。缩略窗变为宽矮比例时，蓝框四边仍与实际图像几何一致。故意覆盖选区的遮罩、边框、工具栏与缩略窗未进入成品。
- 同一目录版还通过普通截图/窗口预选/移动缩放/OCR、本机 HTTP/SSE、演示 AI/自定义询问/Markdown、标注、贴图、IPC 隔离与取消回归。使用隔离配置与注入剪贴板，不读真实 Key、不写用户剪贴板、不调用真实外部模型；只保存验证过的合成图与本应用界面。
- 合成输出：`.runtime/manual-continuous-b.png`、`manual-sidebar-b.png`；确认界面截图 `manual-b-region-toolbar.png`、`manual-b-region-thumbnail.png`。测试没有冒充用户真实网页或人工物理滚轮验证。

交付完成：`release/v0.7.0/win-unpacked/AI Screen.exe`，需保留整个目录，版本资源0.7.0.0。桌面已有 `AI Screen.exe - 快捷方式.lnk` 已备份为 `.runtime/AI Screen-shortcut-before-v0.7.0.lnk`，目标/工作目录/图标均更新。启动前未发现本项目运行中的旧主实例，没有停止其他应用。通过原桌面快捷方式打开后，新主实例 PID242620 响应，窗口可见、标题 AI Screen · 屏幕助手，只有一个新主实例。v0.6.1、v0.7.0-preview.1 及更早目录保留。

实际边界：单屏、仅向下，仍需要足够重叠；无法恢复从未采到的跳过内容。整片空白/重复图案、动画视频、布局重排、嵌套滚动或虚拟列表可能拒绝追加，需要等稳定、回到重叠位置或重选。侧栏建议仅裁去静止外围，经确认输出正文，不能称为所有聊天网页通用拼接。人工物理滚轮、Windows 11/混合 DPI 双屏未全面验收；自动为实验入口，不作为本轮可靠能力承诺。下一轮优先用户实际手动页面反馈，再推进 C 阶段原图标注/裁剪/贴图/OCR/翻译/AI。

## 长截图布局专项 · v0.7.1-layout.1 · 2026-10-16

用户反馈功能仍不可用，最新要求明确改为先按 QQ 附图完成布局，之后再提供功能要求。**本轮只交付样式，没有修复拼接算法，也没有宣称真实页面长截图已可用。** 本轮不继续自动滚动、帧率或拼接算法开发。

布局：选区细蓝框及左上白色尺寸标签；外围压暗；右侧高窄白底长图预览，底部与选区对齐，顶部适当上伸；440/360×44 DIP 单行白色工具栏优先在选区下方靠右，间隔8 DIP，空间不足沿用原有上方/侧边/屏内避让。缩略预览优先右侧，其次左侧；空间不足在屏内避让工具栏和选区中心，绝不暗中缩小采集区域。保留负坐标及整数原生窗口边界。真实缩略图仍按原图比例适配，正文候选蓝框继续相对图片定位。

工具栏视觉顺序：竖向截图、滚动、标注、分享、保存、取消、完成。方向目前是不可操作的文字入口；标注/分享/采集中保存是禁用的样式占位，悬停有明确说明。真实采集界面仍使用旧的手动状态、自动暂停/继续及转手动、完成、取消、正文确认命令，完成后的复制/PNG 保存继续复用旧逻辑。工具栏的原状态数据保留在可访问文本与提示中，预览底部悬停显示进度，异常/暂停/正文确认信息保持显示。没有给这些占位按钮接假功能。

新增：`src/renderer/longshot/ToolbarChrome.tsx`（共享外观及原创线性图标）、`LayoutPreview.tsx`（纯示例布局）、`layout-preview.css`；`src/main/longshot-layout-preview.ts`（独立预览入口及自建界面检查）。修改：`src/main/index.ts`、`longshot-window.ts`、`longshot-surfaces.ts`、`longshot-smoke.ts`；`src/shared/scroll-capture/layout.ts`；`src/renderer/main.tsx`、`longshot.css`、`longshot/CaptureToolbar.tsx`、`LiveThumbnail.tsx`、`views/Home.tsx`；两项现有测试文件、版本文件、README 和本文档。无新依赖。

独立预览：`AI Screen.exe --longshot-layout-preview`，使用 `.runtime/layout-preview` 隔离 userData，在正常初始化配置/托盘/快捷键之前分流，不读取真实设置，不使用 preload，不提供 screenAI 桥，不采集屏幕、不滚动、不使用剪贴板。左侧与右侧文章都是自建示例，不是拼接结果。自动滚动/完成在这个独立预览中只展示样式，红色取消或 Esc 可关闭。真实采集路径已同步上述样式，但算法和已知限制沿用上一版。

验证：类型检查、构建及112项测试通过；新增负坐标/分数DPI右侧长预览定位验证。源码长截图界面集成通过，最终目录版完整 `--smoke-test --longshot-ui-only` 通过（普通截图、OCR、演示AI、标注、贴图、长截图表面排除及完成/取消清理）。最终目录版 `--longshot-layout-preview --layout-smoke` 在1600×900和960×700内容区通过边界/对齐/按钮不溢出/无桥检查，截图经实际查看，修正了紧凑尺寸预览缩放和截图时机。日志 `.runtime/layout-tests.log`、`packaged-layout-ui.log`、`packaged-layout-preview.log`，后两者错误日志均0字节。仍有既有Vite大包体警告，不影响构建。测试仅保存自建界面和合成内容，不写用户剪贴板、不读真实Key。

交付：新目录 `release/v0.7.1-layout.1/win-unpacked` 保留完整目录；双击其上一级 `长截图布局预览.cmd` 可单独查看样式，并支持与原正式版同时运行。宽屏图 `.runtime/longshot-layout-wide.png`，紧凑图 `.runtime/longshot-layout-compact.png`。旧版本和原桌面快捷方式保留，未用预览版替换日常入口。下一步等待用户针对布局及各按钮给出功能要求，不自行恢复大规模算法重构。

## 确认布局接入实际采集 · v0.7.1 · 2026-10-16

用户确认布局并授权替换原布局，由开发者决定功能是否重写。决定保留现有采集、拼接、完成、取消、剪贴板和 PNG 保存，不为界面更换重写后端；当前的真实网页拼接限制仍存在。本次使确认的布局成为日常长截图入口，删除独立示例及旧多行状态布局，原结果查看/复制/保存窗口仍保留其职责。

删除源码：`src/main/longshot-layout-preview.ts`、`src/renderer/longshot/LayoutPreview.tsx`、`src/renderer/longshot/layout-preview.css`。`src/main/index.ts` 删除专用预览启动分支，`src/renderer/main.tsx` 删除无桥示例路由；当前版本不再提供独立假内容页面。历史 release 目录作为旧版本保留，不删除存档。

修改：`src/main/longshot-surfaces.ts`、`services/longshot.ts`、`longshot-smoke.ts`、`index.ts`；`src/shared/scroll-capture/layout.ts`；`src/renderer/main.tsx`、`longshot.css`、`longshot/ToolbarChrome.tsx`、`CaptureToolbar.tsx`、`LiveThumbnail.tsx`、`useLongshotSession.ts`、`views/Home.tsx`；版本文件、README、MANUAL-LONGSHOT 和本文档。没有新增依赖。

实际交互：选区内是原应用，外围原生挖空遮罩压暗；左上尺寸标签、右侧优先的窄长预览、右下优先的44 DIP单行工具栏。预览宽度上限390 DIP，随实际已拼接图像适配，始终显示高度和采集消息，避免拒绝追加却只在悬停提示中可见。长图标注和分享仍禁用，明确提示暂未开放；方向只说明当前竖向模式。保留已有手动默认、自动暂停/继续/转手动、正文确认/保留和完成/取消命令。

工具栏下载按钮现在调用现有 `save` 命令：采集中先复用 `finish()`，等待补采和生成原图，确认仍是同一个会话，再进入原保存对话框和 PNG 写入。取消选择保存位置后保持结果可见。没有增加第二套保存或拼接实现，没有自动上传。renderer允许有效采集状态下的保存，并在请求期间禁用重复操作；取消和会话归属检查保留。

原生定位修复：本机150% DPI下，无边框缩略窗初建时得到394×600 DIP，而请求为390×596 DIP。像工具栏一样，在加载后对遮罩和预览显式 `setBounds`，修正实际屏幕上的4 DIP偏差。验收核对真实 HWND 窗口尺寸和选区底边，而非只测CSS或纯函数。

验证完成：类型检查、构建、112项现有单元测试通过（`.runtime/install-layout-tests.log`）。源码长截图集成、最终目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0；`.runtime/packaged-installed-layout.log`，错误日志0字节。集成新增实际工具栏下载按钮点击、PNG原像素核对、取消保存保留结果、真实窗口尺寸/底边/按钮不溢出及没有旧示例/多行状态布局检查。普通截图、窗口预选、移动缩放、放大镜、OCR、演示翻译/AI/询问、标注、贴图、IPC及配置隔离继续通过；合成连续滚动、固定侧栏确认/保留、补采末尾、原图复制和PNG逐像素核对通过。仅使用隔离设置、注入剪贴板与保存路径和自建页面，无系统滚轮注入、不读真实Key、不写用户剪贴板、不保存私人桌面。

运行：`release/v0.7.1/win-unpacked/AI Screen.exe`，版本资源0.7.1，需保留整个目录。原桌面 `AI Screen.exe - 快捷方式.lnk` 已备份至 `.runtime/AI Screen-shortcut-before-v0.7.1.lnk`，目标、工作目录及图标更新为新版。启动前未发现旧主实例，无需停止其他应用；经原快捷方式打开，新主进程PID256640有可见主窗口、Responding=true，标题 AI Screen · 屏幕助手。旧版本保留。

已知限制：本轮不是算法重写；合成验证不等于用户实际网页已修复，快滚、无重叠、重复/动态内容、虚拟列表等仍可能拒绝追加。单显示器内向下采集，自动滚动仍实验；长图标注、分享、裁剪、贴图及AI接入继续留待后续，普通截图已有这些工具不受影响。下一轮按用户实际长图操作需求推进，不以示例界面冒充采集成品。

## 长图画笔、分享及完成后 AI · v0.8.0 · 2026-10-16

用户要求实现长图画笔、分享，并在长截图完成后增加 AI 分析。已接入真实结果页及采集工具栏，不是示例或禁用占位。分享先按说明过的本地菜单方式实现（复制后手动粘贴到QQ/微信、导出PNG后手动发送），不是Windows原生分享面板，不自动向外部应用发送消息。

新增：`src/renderer/longshot/ResultEditor.tsx`、`editor.css`；`src/main/longshot-tools-smoke.ts`；`docs/LONGSHOT-TOOLS.md`。

修改：`src/shared/longshot.ts`、`contracts.ts`，`src/preload/index.ts`；`src/main/index.ts`、`services/longshot.ts`、`longshot-window.ts`、`longshot-smoke.ts`、`smoke.ts`；`src/renderer/views/Longshot.tsx`、`Home.tsx`、`longshot.css`、`longshot/ToolbarChrome.tsx`、`CaptureToolbar.tsx`、`useLongshotSession.ts`；版本文件、README、MANUAL-LONGSHOT 和本文档。没有增加运行依赖。普通截图的 AnnotationLayer、annotationGeometry、AnnotationCompositor、TaskService、CompatibleProvider、AI Result 和 ClipboardService 都继续复用原实现。

标注：结束采集后提供自由画笔、箭头、矩形、文字、颜色、线宽、字号、撤销/重做/清除及25%～200%/适应宽度缩放。采集工具栏的画笔先复用finish补采和完成，再直接进入画笔；分享也先完成再开分享菜单。结果页加载原尺寸PNG；图像与SVG放在相同的原图尺寸坐标系，整体CSS缩放，指针通过真实元素边框归一化，正确处理滚动偏移。原图不变，标注存在renderer会话内；关闭前需复制或保存，未导出标注不自动留历史。

导出：`commandLongshot`可为copy/save/analyze携带统一annotationsSchema验证后的标注，其他命令不接受非空标注。主进程基于不可变原图合成输出；长截图使用独立AnnotationCompositor实例，复用类和几何逻辑，避免普通截图的重置/取消误伤长图。IO期间禁用重复编辑/输出，会话取消释放合成器；导出后仍核对当前会话。新增受角色与UUID会话校验的`getLongshotImage`，只允许完成后的当前长图原图读取，没有放开普通runAction的角色边界。getSettings仅向longshot增加既有公共配置读取，不含API Key。

AI：结果页显式点击分析后，发送当前含标注的完整原尺寸PNG，复用TaskService及既有悬浮结果窗口，支持加载、流式、取消、答案复制与追问。用户标注页保持可用；已启动AI窗口有独立生命周期，关闭AI清理其请求/图片，退出应用统一取消。完成、标注、分享不自动上传。没有将缩略预览当原图、静默裁掉图片或自动分块；模型对长图/请求大小的限制与识别质量仍取决于服务。真实服务质量未用用户Key验收。

界面问题修正：发现基础longshot.css导入顺序覆盖editor的网格行定义，图片遮住工具行，已提高编辑页规则优先级并加入元素边界检查。结果窗最低尺寸620×480 DIP（受显示器可用范围限制），分享菜单使用受窗口边界约束的固定位置，640×560内容区实际渲染已检查。

验证完成：类型检查、构建与112项单元测试通过；最终目录版 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，`.runtime/packaged-longshot-tools.log`，错误日志0字节。新增集成验证四种工具的真实React事件、50%缩放并实际滚动后的标注坐标、撤销/重做/清除、原图不变、导出尺寸与红线位置、未触及首行像素不变、PNG与注入剪贴板bitmap SHA256一致；明确分析前确认demo，再核对TaskService接收的整张含标注PNG与导出像素相同。验证原图接口的伪造ID/外窗口拒绝、畸形标注拒绝、AI关闭后编辑页可用、640×560分享菜单在窗内、20,000px高合成图末尾标注不被截断，并实际点击采集工具栏画笔/分享验证对应结果页。普通截图/OCR/翻译/AI/询问/标注/贴图/IPC、合成连续长截图及固定侧栏确认等原有回归继续通过。

测试只使用隔离设置、自建Canvas、注入剪贴板和保存路径；不发系统滚轮或移动光标，不覆盖用户剪贴板、不读取真实Key、不调用真实外部模型、不保存私人桌面、不向聊天应用发送图片。界面证据 `.runtime/longshot-tools-editor.png`、`longshot-tools-compact.png` 仅含自建图像；源验收日志 `longshot-tools-smoke.log`，单元日志 `longshot-tools-tests.log`。既有Vite大包体提示仍在，构建成功。

交付：`release/v0.8.0/win-unpacked/AI Screen.exe`，文件版本0.8.0、产品版本0.8.0.0，需保留完整目录。桌面原快捷方式备份为 `.runtime/AI Screen-shortcut-before-v0.8.0.lnk` 后更新目标/工作目录/图标。只停止核对路径的旧v0.7.1主进程PID256640，经原快捷方式启动v0.8.0，主进程PID254560有可见窗口、Responding=true，标题 AI Screen · 屏幕助手。旧版本保留。

下一轮/边界：长图裁剪、贴图和Windows原生分享面板未实现；剪贴板分享仍需要用户在目标应用粘贴发送。新增功能没有重写拼接算法，用户实际页面连续滚动问题不能据此称为修复；仍为单屏向下、需重叠，真实模型对超长图片的识别和所有真实网站/混合DPI多屏待实际验收。长图使用说明见 LONGSHOT-TOOLS.md。

## 用户视频诊断 · 2026-10-16 · 未发布修复版

用户反馈预览跑到左侧、手动滚动不增长，并明确要求上下滚动都能采集。本轮只读分析约9秒提供视频、生产源码、合成复现及本机QQ截图组件；没有修改生产代码、运行版本或快捷方式。完整证据、原因和实施顺序见 [LONGSHOT-DIAGNOSIS-2026-10-16.md](LONGSHOT-DIAGNOSIS-2026-10-16.md)。

已确定：布局右侧不足时主动回退左侧；匹配器显式拒绝负位移、文档只支持底部追加；整幅校验对局部像素变化过严；拒绝后只保留旧成功参考，失去重叠后缺少恢复；读屏/匹配/预览串行且无真实FPS测量。当前手动采集不再等待静止帧，不能误诊成仍有稳定帧门槛。视频证明原页面滚动而预览未明显增长，不能单靠它断言具体拒绝原因或真实采集帧率。

REA查到QQ独立截图资源及原生事件入口，但未取得核心拼接算法。只读证据保存 `.runtime/qq-video-review/`，工具会话已关闭。此前Canvas合成回归没有覆盖用户实际操作，不能当作真实手动长截图验收。下一轮优先右侧预览和可观测状态，再做双向文档坐标/覆盖区间、有界采集及匹配恢复；不继续优先投入自动滚动。

## 用户纠正与旧开始卡片移除 · v0.8.1 · 2026-10-16

最新要求覆盖上一节的布局建议：空间不足时预览放左侧可以接受，不修改 thumbnailBounds 或现有避让规则。用户指出第二张照片中的“长截图 · 已选择范围”卡片多余，已删除该长截图分支及其提示、手动开始/实验自动按钮和对应样式；区域录屏尚未接入的独立说明保留。

现在选长截图并完成框选或单击选窗口后，ScreenshotController 直接将本次最终矩形交给现有手动采集后端，不依赖尚未提交的 React rect 状态。startMode 以同步 phaseRef 防重复发起。真正采集仍用既有 QQ 风格独立工具栏和预览，没有第二套采集逻辑；启动期间短条显示进入中，失败显示错误、重试、重选/普通截图和退出，不恢复旧卡片。此行为表示松开选区即开始本地采集，不自动请求 AI。

修改：`src/renderer/capture/ScreenshotController.ts`、`SelectionToolbar.tsx`、`src/renderer/capture-extra.css`、`src/main/services/capture-modes.ts`、`src/main/longshot-smoke.ts`、版本文件、Home版本标记及README/用法/诊断/交接文档。新增 `docs/CONTINUOUS-SCREEN-AI.md`。没有新运行依赖，没有修改拼接算法。

验证：类型检查和构建通过，112项测试通过；源码完整集成及最终目录版 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0。长截图集成的手动入口改为真实React模式按钮与框选PointerEvents，验证松手后冻结遮罩退出、现有采集控制窗直接出现，无需调用开始按钮；实验自动后端仍独立覆盖。普通截图/OCR/演示翻译与AI/标注/贴图、长图标注与分享、原图复制/PNG、正文确认和取消清理继续通过。使用隔离配置、自建内容、注入剪贴板和保存路径；没有真实Key/外部模型调用、系统滚轮或私人桌面保存。合成页面验证仍不代表用户真实滚动拼接已修复。

日志：`.runtime/remove-longshot-card-build.log`、`remove-longshot-card-tests.log`、`remove-longshot-card-smoke.log`、`packaged-remove-longshot-card.log`；最终目录版错误日志0字节。初次打包默认下载Electron等待较久，停止仅本轮启动的builder进程后，按既有构建记录使用本地 `--config.electronDist=node_modules/electron/dist` 完成，没有新增或修改依赖。

交付：`release/v0.8.1/win-unpacked/AI Screen.exe`，文件/产品版本0.8.1/0.8.1.0，需保留整个目录。原桌面快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.8.1.lnk`，目标、工作目录和图标更新为新版。只停止核对路径且没有可见窗口的旧v0.8.0主进程PID260136；经原快捷方式启动新版，主进程PID255056、Responding=true。旧版本目录保留。

连续AI识屏结论：技术上可通过多张清晰画面/视频实现内容理解，不需要先拼长图；当前AIRequest/buildMessages每次仅发送一张静态图片，没有连续识屏。这能替代总结/翻译/问答场景，不能替代完整长图导出，也不能保证恢复未采到或模糊文字。本轮仅评估，没有实现；不同服务的多图/视频能力需要实际适配与验证。建议先本地采集、用户完成后显式分析，保留可查阅帧和数量/预算反馈；先验收替代工作流，再决定是否移除长截图，不据尚未实现的方案提前删除。详细边界及官方视频理解参考见 CONTINUOUS-SCREEN-AI.md。

## 长截图扩容及原生DPI预览 · v0.8.2 · 2026-10-16

用户授权扩大容量、优化发糊的实时预览，提供屏幕分辨率2560×1600。本轮保持现有右侧优先/空间不足向左避让、松开选区直接手动采集、独立结果编辑器和显式AI分析，不继续投入自动滚动。

容量：统一常量位于新增 `src/shared/longshot-limits.ts`，实际Worker和核心默认值均为256MiB（旧生产值64MiB、旧核心默认值128MiB）；单帧上限由预算一半得到，32→128MiB。宽8192、高30000物理像素上限不变；预算检查仍预留一帧，达到限制仍明确停止。2560×1600原生整屏按现有公式的成品理论高度上限4953→24614px，实际步长/匹配可能更早停止。256MiB不是全进程内存上限，分段合并、原生图像和PNG有额外临时分配。

预览：旧生产代码只生成240×360以内的图，再在最高390DIP宽的窗中显示，150%DPI时像素明显不足。新增 `src/shared/scroll-capture/preview.ts` 定义窗口/DPI换算、2048px每边上限及250ms预览间隔；LongshotWindow根据实际缩略窗显示器和边界计算所需物理像素。Worker从分段原图直接采样完整概览和按宽度适配的末段，不调用bitmap合并整张长图。首屏两种预览相同时共享像素缓冲和PNG，传输列表去重；原生图像构建使用Buffer视图避免再复制完整预览缓冲，逐像素采样不为每个像素创建subarray对象。

界面：预览头部有真实的“概览 / 清晰”按钮和完整图像尺寸，默认清晰；清晰显示最新区域，底部明确“显示末段”，不伪装成全图。概览仍显示全部成品；正文候选待确认时自动显示概览，蓝框仍按原始选区定位。两个视图不裁切或改变成品。头部32DIP、脚部56DIP，图片有独立空间、不被浮层覆盖。较长图概览中的字会因全图缩放变小；可切到清晰或在完成后的原图编辑器100%查看。

性能与生命周期：预览编码最多每250ms一次，不限制原采样循环接收帧；没有新建持续timer。节流后静止/拒绝帧也能刷新待显示内容，达到预算时先刷新已接收的最后内容再停。每张预览带独立源区域，等待新预览期间不按最新成品尺寸拉伸旧图。取消、完成和退出清理两张预览及几何，会话过期时丢弃异步返回，不发布到新会话。采样、匹配、预览仍有串行等待，不宣称改成了独立高帧率采集队列。

新增文件：`src/shared/longshot-limits.ts`、`src/shared/scroll-capture/preview.ts`、`tests/longshot-preview.test.ts`。修改：`src/shared/scroll-capture/engine.ts`、`stitch-document.ts`、`src/shared/longshot.ts`；`src/main/services/longshot-processor.ts`、`longshot-worker.ts`、`longshot.ts`；`src/main/longshot-window.ts`、`longshot-smoke.ts`；`src/renderer/longshot/LiveThumbnail.tsx`、`longshot.css`、`views/Home.tsx`；版本文件及README、MANUAL-LONGSHOT、LONGSHOT、ARCHITECTURE和本文档。没有新依赖。

验证：类型检查、构建、116项测试通过；新增2560×1600合成帧经真实匹配器拼至2560×7600（原始像素超过64MiB），逐像素与源图相等；验证DPI尺寸、超大请求受限、末段跨分段/固定底栏采样、预览不修改原图。源码与最终目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 均退出0，目录版错误日志0字节。真实desktopCapturer和自建滚动内容验证原生DPI预览像素足够显示、不再受240×360上限限制、真实React模式按钮切换、最新末段坐标、正文蓝框、窗口排除、长图标注/分享/演示AI、复制/PNG及取消清理。普通截图/OCR/翻译/AI/标注/贴图和IPC回归通过。已实际查看 `.runtime/longshot-installed-thumbnail.png`、`longshot-clear-live-preview.png`，仅含自建内容。

日志 `.runtime/longshot-capacity-preview-build.log`、`longshot-capacity-preview-tests.log`、`longshot-capacity-preview-smoke.log`、`packaged-longshot-capacity-preview.log`。使用隔离设置、注入剪贴板和保存路径；不读取真实Key、不调用外部模型、不注入系统滚轮、不保存私人桌面。2560×1600容量回归是内存合成图，不冒充用户真实GitHub或聊天页面验收。Windows混合DPI多屏、所有真实页面、接近256MiB极限的整套编辑/编码流程没有全面验收。

交付：`release/v0.8.2/win-unpacked/AI Screen.exe`（保留完整目录）。原桌面快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.8.2.lnk` 后，目标、工作目录和图标已更新。确认旧v0.8.1主进程PID255056没有可见窗口，再仅停止核对路径的该进程；经原快捷方式启动新版，主进程PID251180、Responding=true。旧版本保留。

剩余限制：仍是单显示器、向下拼接，不能因此称为双向滚动或动态聊天页面问题已修复；固定侧栏、动画、虚拟列表、丢失重叠仍可能拒绝。连续AI识屏仍未实现。下一轮优先在用户实际GitHub/聊天选区反馈中区分达到容量、匹配拒绝和读取超时，再决定是否重构双向覆盖/稳健匹配。

## 长截图专项阶段1：诊断与可靠暂停 · v0.9.0 · 2026-10-17

用户提供专项文本并要求分阶段一步一步完成。本轮完成阶段1，不一次重写全部功能。详细现状审计、四阶段范围、验收标准与交付问答见 [LONGSHOT-OPTIMIZATION-PLAN.md](LONGSHOT-OPTIMIZATION-PLAN.md)。阶段2进一步拆为采集方式/有界队列、稳健主体匹配/恢复、双向文档覆盖；阶段3布局与可读缩放；阶段4自动策略和真实应用矩阵。普通截图、AI、翻译未改实现，相关变动仅长截图协议扩展、托盘控制及版本标记。

审计结论：正常手动模式是用户自己滚动，Electron desktopCapturer读取整显示器原生图像再裁切，无DOM依赖；实验自动早已使用SendInput -120滚轮单位，不能把它误诊为WM_MOUSEWHEEL方案或固定120px。手动读屏/匹配/预览串行并额外等60ms；自动探测300ms、滚轮后450ms、底部复核1200ms保持。本轮没有宣称提速或微信兼容。微信真实失败根因尚未确认，不能由JS层推断Electron原生后端，也不能把GPU、UIPI或聊天输入框写成已验证根因。

新增模块：`src/shared/scroll-capture/telemetry.ts`（数值诊断/活动状态）、`src/renderer/longshot/DiagnosticsPanel.tsx`、`tests/longshot-telemetry.test.ts`、`docs/LONGSHOT-OPTIMIZATION-PLAN.md`。

修改文件：`src/main/services/longshot.ts`；`src/shared/scroll-capture/types.ts`、`vertical-matcher.ts`、`engine.ts`（仅增加原因代码）；`src/shared/longshot.ts`、`contracts.ts`、`src/preload/index.ts`；`src/main/longshot-window.ts`、`longshot-surfaces.ts`、`index.ts`（托盘暂停控制）；`src/renderer/longshot/useLongshotSession.ts`、`CaptureToolbar.tsx`、`LiveThumbnail.tsx`、`src/renderer/longshot.css`；`src/main/longshot-smoke.ts`；版本文件、Home版本标记及README/MANUAL-LONGSHOT/HANDOFF。没有新依赖。

诊断：实际采到/处理/新增/去重/拒绝/待确认/过期丢弃/读屏失败计数，读屏/Worker往返/预览的当前、平均和最大耗时；最近32次读屏完成时间估算采集速率，暂停/继续清空速率窗口。审阅确认同一帧不重复计入采集/处理，成功确认后清掉旧body-review问题。新增结构化问题代码，包括capacity、size-changed、reverse-scroll、no-overlap、overlap-rejected、fixed-region-changed和输入/读取/处理错误；没有放宽匹配阈值。最近问题表示已观测拒绝条件，不等于查明微信渲染根因。

实时活动是独立枚举（capturing/matching/previewing/waiting-change/waiting-stable/scrolling/paused/reviewing/finishing/completed/error等），不替换既有生命周期状态。诊断使用专门数值事件合并更新，普通更新最多每200ms一次、控制动作即时发布，事件只含id和数值快照，不携带PNG/窗口标题/聊天内容/Key。窗口缓存和renderer按会话/sequence处理，取消清理timer及订阅。该路径不重排窗口，不为诊断刷新重新发布大预览。

暂停：手动工具栏及托盘新增暂停/继续。暂停先使采样版本失效，在途读屏会丢弃，已经提交Worker的帧等其处理结束再确认暂停。继续保留成功参考，不能自动填补暂停期间跳过内容；正文待确认不能通过继续/切手动绕过。暂停后直接完成只输出已有段，正常完成仍补采最后视口。取消、读屏失败和会话关闭沿用释放链路。

验证：类型检查、构建和122项单元测试通过；源码集成及最终目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 通过，最终错误日志0字节。新增自建原生滚动内容验证手动暂停后无新提交、继续后接上、反向拒绝代码与耗时计数显示、数值事件不含图片、暂停后完成不补采新页面、诊断面板在窗内及会话清理。原连续手动/固定侧栏确认/PNG逐像素/注入复制、长图标注/分享/演示AI、普通截图/OCR/翻译/AI/标注/贴图及IPC回归通过。

第一次目录版回归暴露既有验证时序：预览窗改大小可先生成旧文档的新PNG，成品追加状态又先于新预览发布，原等待条件只比较URL导致过早拿823px预览和1003px成品比较。已让验证等待预览源坐标与当前文档一致，不修改实际图像或容错阈值；重新打包后全回归通过。首次失败日志保留 `.runtime/packaged-longshot-stage1-attempt1.log` 及其错误日志，最终为 `packaged-longshot-stage1.log`。另外有 `longshot-stage1-build.log`、`longshot-stage1-tests.log`、`longshot-stage1-smoke.log`。诊断截图 `.runtime/longshot-stage1-diagnostics.png` 已实际查看，只含自建图像和数值。

一次自建场景诊断快照：平均读屏约260ms、匹配约7ms、预览约11ms、实际采集约3.0帧/秒。它不是微信或全应用基准；下一阶段应优先评估逐次getSources采集成本及持续帧源，不能只缩短sleep或并行几毫秒匹配就承诺明显提速。CPU/完整进程组内存基准、Chrome/Edge/GitHub/微信/设置/资源管理器/独立Win32应用的真实矩阵均未验收。测试用隔离配置、自建fixture、注入剪贴板和保存路径，不调用外部AI、不读取真实Key、不注入系统滚轮、不保存私人桌面。

交付：`release/v0.9.0/win-unpacked/AI Screen.exe`，文件/产品版本0.9.0/0.9.0.0，需保留完整目录。桌面原快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.9.0.lnk`，目标、工作目录和图标更新。只停止核对路径且没有可见窗口的旧v0.8.2主进程PID251180；经原快捷方式启动新版，主进程PID265760、Responding=true。旧版本保留。

尚未完成：采集与拼接解耦、持续帧源/自适应稳定检测、稳健动态正文与双向覆盖、预览四向空间评分/手动位置/自由大小及Ctrl+滚轮缩放、自动自适应步长及真实应用兼容验收。仍单屏向下、严格重叠，自动为实验后端。本阶段交付定位与控制能力，不把这些待办写成修复完成。

## 长截图专项阶段2.1：有界采集与预览调度 · v0.10.0 · 2026-10-17

用户要求继续分阶段实施，本轮限定阶段2.1。普通截图、翻译、AI、标注、贴图实现不重写；右侧空间不足可移左侧的预览规则保持。详细结构、预算、时序和测量边界见 LONGSHOT-OPTIMIZATION-PLAN 当前阶段。

新增文件：
- `src/main/services/capture-pipeline.ts`：单生产者/顺序消费者、有界预读、读屏前容量预留、背压、seal排空、close取消、等待消费者与失败传播。
- `src/main/services/preview-pump.ts`：一个在途任务加dirty标志、合并请求、完成后250ms间隔、取消延时任务和等待在途预览。
- `tests/longshot-pipeline.test.ts`：8项纯像素队列/预览测试，验证慢匹配不丢中间帧、实际拼接逐像素正确、帧数/字节边界、大帧串行、完成排空、取消/源/消费者错误及慢预览合并。
- `tests/longshot-service-pipeline.test.ts`：2项真实LongshotService配隔离内存后端的并发边界测试，不触碰桌面/凭证/剪贴板。

修改文件：`src/main/services/longshot.ts`、`live-region-source.ts`；`src/shared/scroll-capture/telemetry.ts`；`src/renderer/longshot/DiagnosticsPanel.tsx`；`src/main/longshot-smoke.ts`；`tests/live-region-source.test.ts`；`scripts/test.mjs`；版本文件、`src/renderer/views/Home.tsx`；README、MANUAL-LONGSHOT、ARCHITECTURE、LONGSHOT-OPTIMIZATION-PLAN和本文档。没有新增运行依赖。单测构建将Electron标记external，避免把其Node启动安装逻辑打包到测试目录；这不是Electron安装故障或运行时变更。服务新增可注入Processor工厂，生产默认仍是原LongshotProcessor/Worker。

旧手动流程为读屏→匹配→预览→60ms等待；新流程读取可以与上一帧匹配重叠，匹配仍严格保序，不等待预览Promise，也不再额外等待60ms。管线最多3个帧位，通常64MiB原始像素/预留，包含在途读屏和匹配；单帧超过64MiB时退为单帧串行，最大128MiB限制不变。按实际原生像素边界预留，尺寸不符报错。满时停止生产并提示暂缓滚动，不能静默仅保留最新帧。文档256MiB、宽8192/高30000限制不变；管线预算不包括NativeImage整屏、Worker传输副本、分段文档、预览/PNG临时内存，不是全进程RSS上限。

预览用独立合并调度，最多一个在途任务和一个待刷新标志；匹配与预览复用原Worker，各最多一个请求在途，仍可能等待一个已有预览任务，PNG编码仍在主进程。保留从分段像素采样、原生DPI供图和独立预览源坐标。并未新增持续MediaStream/WGC帧源，desktopCapturer逐次getSources仍是主要读屏路径，不把线程调度解耦写成彻底消除原生采集开销。

生命周期仍为preparing→capturing→finishing→done，异常error；paused、scrollMode和正文确认独立。正常完成seal生产者，排空有效队列和在途预览后补采当前视口，再取原图；暂停后完成不补采。暂停/菜单/正文确认/切换使版本失效、清除等待帧；已经提交的匹配结束后才确认暂停。取消/异常close队列并清理预览定时器、旧会话及Worker。达到容量先停生产再等待预览，防止闭合队列空转。读屏/预览报错后，晚到的可靠匹配可保留，但不得将error改回capturing或清掉故障代码；可用线程中的已有可靠部分仍可尝试完成，处理线程失效时明确失败。

诊断新增当前缓冲/排队帧、记账字节、峰值与背压次数，仍通过数值事件合并发送，不重复携带PNG。采样方法、窗口预选、工具栏定位、复制/保存、翻译/AI协议均沿用原实现。本轮未放宽匹配阈值或改变负位移拒绝，动态容错和双向覆盖留给2.2/2.3。

验证：最终类型检查、构建与132项单元测试通过。新增服务测试覆盖“第二次读屏失败先于首个Worker结果返回”仍保留error/原始故障计数，同时首个可靠结果可保存；“容量限制遇到在途预览”停止生产、不空转，取消后晚返回不发布状态。预读/背压的压力由受控慢消费者测试触发，不冒充真实应用卡顿已修复。

源码初版管线集成通过，之后补充并发异常收尾保护；最终目录版以最新打包日志为准。原生集成使用生产desktopCapturer与自建真实滚动页面，验证连续运动中追加、最终原图及保存PNG逐像素相等、静止去重、首屏提示、完成补采、暂停后无新提交/无排队、正文裁剪确认/保留、捕获排除与全部采集窗清理。长图标注/分享/演示AI，普通截图/OCR/演示翻译/AI/标注/贴图及IPC回归保持。隔离配置、注入剪贴板/保存路径，不读取真实Key、不请求外部AI、不注入系统滚轮、不保存私人桌面。

源码连续滚动记录：901×823选区，采集16/处理15帧、11次追加、0拒绝、1帧完成时丢弃，约3.29帧/秒；峰值2帧/5932184字节、0背压。已通过的一次目录版记录为约3.33帧/秒、15采集/14处理、11次追加、0拒绝，峰值相同。不同阶段计时并发重叠，Worker往返含排队/回调等待；没有同条件旧版基线，不能声称固定百分比提升。不是微信或跨应用速度结果。诊断截图 `.runtime/longshot-stage2.1-diagnostics.png` 已实际查看，新增数字可见且在窗口内。

日志：`.runtime/longshot-stage2.1-typecheck.log`、`longshot-stage2.1-tests.log`、`longshot-stage2.1-build.log`、`longshot-stage2.1-smoke.log`/其错误日志、`longshot-stage2.1-package.log`、`packaged-longshot-stage2.1.log`/其错误日志。`packaged-longshot-stage2.1-pre-final.log`保存最终导出异常收尾保护之前的通过记录；最新目录版复验与正常运行确认补记在下方。

已知限制与下一步：仍为单显示器、向下、严格重叠；快速滚动超过实际读屏能力、固定/动态内容、虚拟列表、失去重叠仍可能拒绝，不保证补回未采像素。阶段2.2优先稳健主体匹配和失败恢复；阶段2.3再做文档坐标与上下覆盖/回看去重。持续帧源需另行验证精确像素和捕获排除；预览四向评分/拖动/大小/自由缩放、真实微信及Chrome/Edge/GitHub/设置/资源管理器/独立Win32矩阵尚未验收，不把本轮原生合成页面测试写成兼容性完成。

最终交付确认：最新目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，错误日志0字节。最新连续滚动记录约3.28帧/秒、15采集/14处理、11次追加、0拒绝、1帧完成时丢弃；缓冲峰值2帧/5932184字节，无背压；完成时缓冲帧、字节和排队均为0。最终诊断截图已再次查看。此记录对应包含异常后导出收尾保护的最后构建。

运行位置 `release/v0.10.0/win-unpacked/AI Screen.exe`，产品版本0.10.0.0，需保留完整目录。既有桌面快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.10.0.lnk`，目标、工作目录及图标均指向新版；旧版本目录保留。核对路径、身份且确认没有可见窗口后停止旧v0.9.0主进程PID235752；最终验证后经原快捷方式启动最新包，主进程PID259100，Responding=true。

## 长截图专项阶段2.2：局部变化校验与重新连接 · v0.11.0 · 2026-10-17

本轮按用户“继续”推进下一小阶段。基于v0.10.0有界管线增量修改，不重建项目，不调整普通截图/AI/翻译/标注/贴图实现，保留当前右侧优先/空间不足向左的预览定位。自动滚动仍是实验后端，不注入系统滚轮验收；双向覆盖在2.3实施。

新增文件：`src/shared/scroll-capture/translation-verifier.ts`（全像素校验及独立的受限局部变化规则）；`tests/longshot-robust-match.test.ts`（13项原生像素、动态差异、拒绝、固定栏和恢复测试）。

修改文件：`src/shared/scroll-capture/vertical-matcher.ts`、`content-region.ts`、`motion-region.ts`、`engine.ts`、`types.ts`；`src/shared/longshot.ts`和`scroll-capture/telemetry.ts`；`src/main/services/longshot.ts`；`src/renderer/longshot/DiagnosticsPanel.tsx`；`src/main/longshot-smoke.ts`；`tests/longshot-telemetry.test.ts`；package.json/package-lock.json、Home版本标记；README、MANUAL-LONGSHOT、ARCHITECTURE、LONGSHOT-OPTIMIZATION-PLAN及本文档。没有新依赖、持续帧源、OCR或AI请求路径。

匹配原理：保留旧严格路径的RGB平均差0.35/显著变化像素约0.02%、最小64px/25%重叠和候选唯一性校验。失败后才尝试局部规则：变化像素通常不超过重叠的0.2%，最小预算32、最大1024；变化必须集中在一个有界窄小包围框内，远离重叠上下边界；框外仍受严格预算约束，并要求至少3个纵向区间、2个横向区间有稳定纹理证据。精确公式见专项计划，所有尺寸为物理像素。重复纹理、多解、长条/分散变化、大动画、横移和靠近接缝的局部变化仍拒绝。原始像素不涂抹、不重排；已有重叠保持最先采到的内容，只有可靠新增行追加，不能把ignoredPixels理解为已删除图中该像素。

固定区域：已锁定头尾采用零位移全像素校验，允许受限小闪烁，边界/大变化仍拒绝。首次固定栏闪烁可由多个同位移条带建立正文提议，条带间隙保留在建议矩形内，最终整个正文仍必须严格对齐。外围只允许静止或受限小变化；独立运动列和大动画不能借此被静默丢弃。必须用户明确确认才裁剪，保留原范围会更新正确拒绝代码。预算不足时提前跳过提议，避免不必要的临时像素分配。

恢复：没有位移、仅局部变化的可靠画面返回duplicate，不增长文档或更新干净参考。失败帧只更新连续拒绝元数据，不替换可靠参考，也不影响原图；连续3帧拒绝时界面显示“等待重新接上”。返回最后可靠视口去重并清掉旧拒绝，新的可连接视口通过校验后恢复追加。结果携带verification/ignoredPixels、consecutiveRejections/recoveredAfter，数值诊断显示局部容错次数、重新连接次数及连续拒绝。该恢复不是向上补图、跨缺口跳接或未采像素补全。

状态机仍是preparing/capturing/finishing/done/error及独立paused/scrollMode/regionCandidate；新增seeking-overlap仅为活动反馈，不阻塞读屏/控制。错误/暂停/正文确认优先，重新接上立即退出旧等待状态。队列上限、暂停排空、完成补采、异常/取消释放沿用2.1。复制/保存复用ClipboardService和longshot-file，长图标注/分享/AI走已有结果编辑器及服务；翻译、普通截图和贴图未改实现。

验证：146项单元测试、类型检查和构建通过，原有132项不改阈值保留。新增13项匹配/恢复及1项数值诊断：包含2560×1600帧中960个局部差异像素仍拼到2560×2200且逐像素等于源图；18组多尺寸/位移的局部变化、缺失重叠和反向对抗；静止闪烁去重、接缝保护、分散变化、全图弱变化、重复纹理拒绝；固定栏闪烁确认前不裁图；无重叠帧不换参考、返回同一视口及可靠新视口恢复；原有容量/队列/异步错误测试继续通过。

源码完整原生集成已通过，使用生产desktopCapturer、自建原生DPI页面和真实React控件，验证连续拒绝显示等待、返回成功视口清除拒绝、局部叠加差异下静止去重和滚动继续追加，最终原图逐像素与干净源Canvas相等。原连续手动/固定栏确认与保留/暂停完成取消/捕获排除/复制PNG和长图标注分享演示AI回归通过；普通截图/OCR/演示翻译AI/标注贴图、IPC仍通过。源码一次连续滚动场景约3.48fps，峰值2帧/5932184字节；非同条件速度基线，不宣称百分比提速。隔离配置、注入剪贴板/保存路径，不读取真实Key、不调用外部AI、不保存私人桌面、不发送系统滚轮或真实聊天消息。

日志：`.runtime/longshot-stage2.2-typecheck.log`、`longshot-stage2.2-tests.log`、`longshot-stage2.2-build.log`、`longshot-stage2.2-smoke.log`/错误日志、`longshot-stage2.2-package.log`、`packaged-longshot-stage2.2.log`/错误日志。诊断截图 `.runtime/longshot-stage2.2-diagnostics.png`已实际查看，显示等待重新接上、拒绝计数、局部/恢复行，面板及提示在窗口内。最终目录版验证和桌面入口确认补记在下方。

已知限制：仍单屏向下；局部容错限制严格，多个远离变化、视频/大动画、滚动快到丢失重叠、布局重排、虚拟列表或缺少分散纹理仍可能拒绝。采集方式与实际帧率上限未根本改变，不能恢复未采画面。原图动态内容可能保留早期状态。微信、Chrome/Edge/GitHub、设置、资源管理器、独立Win32/混合DPI矩阵尚未逐一验收，不把自建页面测试冒充真实应用兼容。下一阶段2.3引入带符号视口坐标/覆盖范围，完成向上补顶、向下补底和回看去重；预览拖动/缩放及持续帧源仍分后续阶段。

最终交付：最新目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，错误日志0字节，含ROBUST RECOVERY PASS和既有全部回归。目录版连续滚动记录约3.37fps，15帧采集/14处理、11次追加、0拒绝、1帧完成时丢弃，缓冲峰值2帧/5932184字节；此为干净自建页面的采集记录，不是动态场景成功率基准。完整运行目录 `release/v0.11.0/win-unpacked/AI Screen.exe`，产品版本0.11.0.0，需保留整个目录。

桌面既有快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.11.0.lnk` 后更新目标、工作目录及图标；确认旧v0.10.0目录保留。更新前未发现旧版常规主进程，无需停止用户程序。经原桌面快捷方式启动新版，主进程PID262436，Responding=true。运行设置和密钥未由测试工具读取或变更。

## 长截图专项阶段2.3：双向覆盖及回看 · v0.12.0 · 2026-10-17

按用户继续指令完成本阶段。新增 `src/shared/scroll-capture/document-coverage.ts`、`document-locator.ts`、`tests/longshot-bidirectional.test.ts`。修改该目录的engine、stitch-document、vertical-matcher、translation-verifier、motion-region、types、preview、telemetry；shared/longshot与longshot-auto；main/services/longshot与capture-modes；renderer/longshot/LiveThumbnail和DiagnosticsPanel；main/longshot-smoke；manual-scroll-capture、scroll-capture-engine、longshot-stitcher、longshot-telemetry、longshot-robust-match测试；版本/Home标记及README、MANUAL、ARCHITECTURE、专项计划和本文档。没有新依赖，没有重写普通截图、AI、OCR、翻译、贴图或窗口定位。

覆盖模型：以首个正文视口为0，保存带符号viewport和连续coveredTop/coveredBottom。相邻匹配允许正负位移，随后还核对与全部已覆盖历史的交集，不只信任上一帧；历史变化/位置冲突报history-changed，保留旧图/参考。通过后只插顶部和/或追加底部未覆盖行，回看零新增则duplicate并更新参考坐标。所有预算/像素验证先于提交，容量失败不能移动原点。首次固定栏识别后才锁定正文高度，header/body/footer分开保存，双向扩展仍只出现一次固定头尾；向上首次正文提议确认后才裁剪。

远距离历史定位：相邻重叠失败可按行指纹索引寻找完整已覆盖视口；最多32查询行、每个指纹64行位置、16候选，再对全BGRA严格逐字节复核。多解拒绝；不采用局部容错做全局猜测，也不跨未知缺口。索引仅存哈希/行号、按文档revision更新，prefix/suffix/裁剪/clear失效。RowFrame内部行视图和pixelRow让历史校验跨分段访问，不flatten整幅长图、不持久保存新原始帧副本；renderer/IPC仍只收有界PNG及标量。文档256MiB并预留原始选区帧、宽8192/高30000、队列3帧/通常64MiB保持；索引/原生图像/PNG仍有额外开销，不把该预算冒充RSS上限。

预览：清晰视图跟随当前文档位置，提供顶部/当前区域/末段标签。位图返回位置快照，缓存同时比较viewport和coveredTop，回看即使图像尺寸不变也会刷新。修正“detail y=0就共用overview PNG”的旧假设：顶部局部图必须独立采样编码，仅源区域高度也相同才共享。新预览仍沿用实际窗口/DPI、分段采样和250ms合并调度；不改变右侧优先、空间不足向左的布局，拖动/大小/自由缩放仍下一阶段。

状态机及控制：生命周期preparing/capturing/finishing/done/error不变，paused/scrollMode/正文确认独立；签名坐标是文档物理像素，不是屏幕DIP。新增结果/诊断含顶部/底部新增、viewport/覆盖区间、回看及历史定位计数。appendedRows旧兼容字段表示总增长，用于结果编辑器判断长图，不限底部。手动文案改为上下滚动。实验自动遇负位移或历史定位暂停后续输入，可转手动；未发系统滚轮验证。正常完成排空/补采当前视口可继续补顶，暂停完成/取消释放沿用2.1。复制/PNG、长图标注分享/AI和普通翻译走原服务，无自动上传。

验证：161项测试及类型检查/构建通过，新增15项；5项旧“反向必须拒绝”预期改为验证顶部新增/回看去重和准确像素，没有放松阈值掩盖问题。包括多尺寸216步往返、2560×1600上移600/再下移1200但仅补底600的原图一致性、固定头尾仅一次、向上正文确认、完整历史变化拦截、精确回看/歧义/索引失效、视图跨分段且预览不flatten、预算到顶后仍可去重和顶部容量失败原子性、自动策略/方向数值计数。原局部容错及普通功能测试保留。

源码完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，错误日志0字节。新增自建原生页面从中间开始，8次下扩、远跳回看精确去重、上滚补顶、顶部detail像素验证及向下已覆盖位置去重；原图和PNG逐像素与源Canvas相等，注入复制尺寸和全部窗口清理正确。缺失重叠恢复改用未采过的远跳触发，反向不再当错误。保留连续手动/局部变化、正文确认与保留、暂停/完成/取消、捕获排除、长图标注分享演示AI、普通截图/OCR/演示翻译AI/标注贴图/IPC回归。源码普通连续场景约3.33fps，非同条件速度对比或微信结果。

测试隔离设置、注入剪贴板/保存路径，不读取真实Key、不调用外部AI、不发真实聊天消息、不注入系统滚轮、不保存私人桌面。`.runtime/longshot-stage2.3-top-preview.png`已实际查看，显示新增顶部和“显示顶部”，像素已与源图验证；另有longshot-stage2.3-diagnostics.png。日志为同目录longshot-stage2.3-tests/typecheck/build/smoke/package，以及packaged-longshot-stage2.3.log/错误日志。最新目录版结果和桌面入口见下方补记。

已知边界：仍单显示器竖向，无法补回未采像素；远距离定位只支持完整、唯一、完全一致的旧视口，动态/部分边缘视口需减小滚动距离。重复或像素相同内容、重排和虚拟列表可能没有足够定位证据，不能保证任意页面的真实滚动位置。动态历史可能被拒绝，旧图不覆盖；采集API和实际帧率未根本提升。真实微信、Chrome/Edge/GitHub、系统设置/资源管理器/独立Win32及混合DPI矩阵未逐一验收。下一阶段3做预览评分、拖动/大小/缩放，持续帧源与应用矩阵另行推进。

最终目录版验证：`packaged-longshot-stage2.3-retry.log` 对应完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，错误日志0字节；包含普通截图/贴图/演示AI及长图工具、连续采集、拒绝后恢复、控制收尾、双向覆盖、固定栏和预览排除全部通过标记。双向测试完成原图与保存PNG逐像素比较、注入复制尺寸验证。目录版普通连续场景约3.29fps，15帧采集/14处理、11次追加、0拒绝、1帧完成时丢弃，缓冲峰值2帧/5932184字节、0背压；仅为自建干净页面记录，不能作为真实应用兼容性或提速结论。

首次目录版回归停在既有QQ RESET之后的贴图步骤，数分钟无新日志或错误，结束了身份已核对的测试主进程；该次 `packaged-longshot-stage2.3.log` 保留为未完成记录，不算通过。未改代码重跑完整流程后通过，未复现；挂起原因尚未定位，不将其写成已修复的生产缺陷。没有遗留smoke主进程。

最终运行位置 `release/v0.12.0/win-unpacked/AI Screen.exe`，产品版本0.12.0.0，需保留完整目录。既有桌面快捷方式先备份为 `.runtime/AI Screen-shortcut-before-v0.12.0.lnk`，随后目标、工作目录、图标均更新至新版；v0.11.0及其他旧版目录保留。核对路径、主进程身份且确认没有可见窗口后停止旧v0.11.0主进程PID262436；经原桌面快捷方式启动新版，主进程PID254532，Responding=true、文件版本0.12.0。未读取或修改用户真实设置/Key。

## 长截图专项阶段3.1：四周预览布局 · v0.13.0 · 2026-10-17

按用户继续开发指令推进下一小阶段。只增量修改预览布局；没有重写长截图采集/拼接或普通截图、翻译、OCR、AI、标注与贴图。本阶段未交付自由拖动/调整大小/缩放，分别留3.2和3.3。

新增文件：`src/shared/scroll-capture/preview-placement.ts`、`tests/longshot-placement.test.ts`、`src/main/longshot-placement-smoke.ts`。修改文件：`src/shared/scroll-capture/layout.ts`；`src/main/longshot-surfaces.ts`、`longshot-window.ts`、`longshot-smoke.ts`；package.json/package-lock.json、Home版本标记；README、MANUAL-LONGSHOT、ARCHITECTURE、LONGSHOT-OPTIMIZATION-PLAN和本文档。没有新增运行依赖、网络服务或IPC命令。

旧布局按右、左、角落顺序找候选；新PreviewPlacementManager在纯shared模块内统一评估四向可用矩形，减去工具栏保护区，再按相对可读宽高、遮挡、距离和较小侧向偏好评分。可用外侧窗口优先，不为靠右而强行压窄；相近时优先右侧。四周没有至少240×240DIP空间时，使用避开选区中央40%范围的受捕获保护悬浮窗；极小工作区可缩小并标记constrained，工具栏覆盖全工作区时明确返回重叠元数据，不能承诺不可能的避让。选区本身不缩小、不平移。

全部几何为全局DIP，预览只用当前选区所属显示器工作区；负坐标不归零。默认期望宽280–390DIP，高至少360DIP并受工作区限制；侧向预览尽量底部对齐。Windows在150%DPI实测会将无边框窗口尺寸向外取整1DIP，曾造成底边越界及中央区域擦边；工作区与中央保护区增加2DIP余量后，保留严格原生边界断言通过。不是降低截图或预览图像分辨率。

LongshotSurfaces保存选区/工作区上下文并应用布局，旧thumbnailBounds委托新管理器兼容已有调用。LongshotWindow监听工具栏move，仅实际移动时触发避让；正常采集/数值诊断发布不重布局。预览保留focusable=false、showInactive和捕获保护；遮罩输入孔、生命周期及取消销毁逻辑沿用。生命周期仍preparing/capturing/finishing/done/error，暂停/模式/正文确认独立。采集方式、队列、250ms预览合并、匹配阈值、步长、复制/PNG及AI调用方式完全沿用本轮之前版本；不能将新布局说成提速或微信兼容修复。

验证：174项单元测试、类型检查及构建通过。新增13项布局测试，覆盖四向、可读宽度优先、避让工具栏、全选区中央保护、分数DPI边缘余量、负坐标、另一显示器工具栏、任务栏外延选区不变、无效/极小范围、确定性/平移不变性及108组组合；原161项保留。源码隔离长截图原生集成退出0、错误日志0字节；新增实际原生窗右/左/上/下/全选布局、同一显示器边界、焦点/保护标记、真实工具栏移动避让及状态发布不重置检查。其后完整长图工具、连续采集、拒绝后恢复、暂停完成取消、双向覆盖、正文确认及PNG逐像素回归通过。

原生集成使用当前2560×1600/150%DPI显示器、自建合成Canvas页面及生产desktopCapturer；采集目标始终自建页面，布局专项暂停采样后临时改可视框以验证空间场景，恢复后继续已有采集。没有发送系统滚轮、读取真实Key、外部AI请求、真实聊天消息、用户剪贴板写入或私人桌面保存。副屏/负坐标为单元几何验证，不能冒充实机多屏。源码连续场景记录约3.53fps，仅为本次合成场景，不作前后性能结论。日志 `.runtime/longshot-stage3.1-tests.log`、`longshot-stage3.1-build.log`、`longshot-stage3.1-smoke.log`/错误日志；最终目录版验证及入口确认补记在下方。

已知限制：预览尚不能手动拖动/改变大小/自由缩放；工具栏移动可能重新选择预览方位，手动位置锁定尚待3.2。超小工作区可能只容纳紧凑预览；窗口周围空间有限不能保证文字足够大，3.3解决比例。显示器热插拔/采集中改变布局未专项处理和验收。真实微信、浏览器、系统应用、混合DPI多屏矩阵仍未完成；原拼接重叠和动态内容限制保持。下一阶段3.2实现预览拖动、manual/auto模式、恢复自动和大小调整，3.3实现可读缩放。

最终目录版 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，`packaged-longshot-stage3.1.err.log` 0字节；日志含PLACEMENT、QQ普通截图/标注/贴图/演示AI、长图工具、连续采集、恢复、控制、双向、正文及UI全部通过标记。连续合成场景约3.40fps，15帧采集/14处理、11次追加、0拒绝、1帧完成时丢弃；峰值2帧/5932184字节，无背压。这不是速度提升或真实微信兼容性结论。最后移除一个未使用布局助手后重新构建/类型检查，主进程运行JS的SHA256保持一致（96023F117519DAD72A279C5521887A7B115EAD44163E0DB6842A3AE13FDD9F98），没有引入未验收的行为差异。

运行位置 `release/v0.13.0/win-unpacked/AI Screen.exe`，产品版本0.13.0.0；需保留完整目录。桌面原快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.13.0.lnk`，目标、工作目录、图标均更新至新版；v0.12.0及其他旧目录保留。更新时未发现旧版常规主进程，未停止用户程序。经原快捷方式启动新版，正常主进程PID249148，Responding=true、文件版本0.13.0；没有遗留smoke主进程。测试未读取或修改真实设置/密钥。

## 长截图专项阶段3.2：预览拖动与调整大小 · v0.14.0 · 2026-10-18

本阶段按“继续”推进3.2，增量扩展3.1布局和现有会话，不重写普通截图、OCR、翻译、AI或拼接引擎。新增：`src/shared/scroll-capture/preview-window.ts`、`src/renderer/longshot/preview-gesture.ts`、`usePreviewWindow.ts`、`src/main/longshot-preview-window-smoke.ts`、`tests/longshot-preview-window.test.ts`。修改：preview-placement.ts；main的longshot-surfaces.ts、longshot-window.ts、services/longshot.ts、index.ts、longshot-smoke.ts；shared的contracts.ts、longshot.ts；preload/index.ts；renderer的LiveThumbnail.tsx、CaptureToolbar.tsx、ToolbarChrome.tsx、longshot.css；版本/Home标记及README、MANUAL、ARCHITECTURE、专项计划和本文档。无新依赖。

已实现：拖动预览标题区域移动、八方向手柄调整大小、auto/manual状态及“复位”。主进程PreviewWindowLayout记录原始手势边界、开始点、UUID令牌和递增revision，按全局DIP及当前显示器工作区裁限；通常最小240×240DIP，初始受限尺寸允许保持更小。只在实际变化时进入manual；仅单击不切换。manual时工具栏移动、PNG或数值发布不重新放置；复位取消旧手势，复用3.1算法并尽量保留会话内大小偏好。新会话重新自动，不持久保存位置/大小。移动预览不改采集选区。保留2DIP边缘余量，不让Windows高DPI取整将其推离屏幕。

交互使用窗口内PointerEvent/手柄，预览继续focusable=false，不依赖激活系统标题栏或原生边框。PreviewGesture保持一个在途IPC及一个最新点；提前松手也先提交最后点、再End，新手势等待上一End。失败后尝试结束旧令牌，复位等待手势收尾；指针取消/捕获丢失结束当前操作，关闭清理模型。回复与独立layout事件按会话和revision过滤，仅带少量几何信息，不重复发送PNG。新增IPC严格校验联合请求、会话UUID、有限坐标及当前thumbnail sender；工具栏、结果页、home或过期会话不能操作布局。

尺寸改变时LongshotSurfaces通知LongshotWindow→LongshotService.refreshPreview→既有PreviewPump，按实际窗口/DPI从原始分段重新采样，暂停期间同样刷新。保留250ms合并及每边2048px预算；不将旧小PNG当高清源拉伸。读屏API、捕获排除、队列、匹配阈值、滚轮策略及原图输出未变。生命周期仍preparing/capturing/finishing/done/error，UI布局模式与截图状态分离；复制、PNG、长图标注分享/AI沿用旧服务，无自动上传。

回归曾在预览调整后出现拒绝：临时诊断将一帧差异定位到384×38像素的矩形，与浏览器原生title悬停提示一致。原生提示可能独立成窗，不应假定继承宿主捕获保护；现移除采集工具栏/预览的title，保留可见按钮、状态与ARIA说明，新增实际采集DOM无title检查。未枚举提示子窗口确认其类名，不夸大为已完全确认底层机制。去除后不需要额外读屏/诊断包装即可通过正式回归；未放宽像素比较。临时独立读取因未使用生产原生尺寸曾触发重采样比较失败，不作为生产采集错误结论；所有私有访问/额外探针/帧日志均已从最终源码移除，坏帧未写入磁盘。

验证：193项测试通过，新增19项，原174项保留；包含点击不切模式、手动保持、负坐标限制、八方向对边/最小最大、复位取消旧请求/保持大小、新会话默认、严格输入及慢IPC/提前松手/失败释放等。类型检查与构建通过。源码隔离原生长图集成退出0、错误日志0字节，新增真实React合成PointerEvent→preload→IPC→原生窗边界链路，验证八方向、手动稳定/复位、暂停时重新供图、旧/外来请求拒绝、极端移动、保护和不抢焦点；之后原有长图工具、连续采集、失败恢复、控制、双向、正文确认及原图/PNG逐像素回归通过。源码一次干净连续场景约3.32fps，不作速度提升或微信兼容结论。

`.runtime/longshot-stage3.2-preview.png`是仅含合成Canvas的预览窗，已实际查看：标题抓手、尺寸、概览/清晰/诊断/复位、暂停信息和边角均可见。使用2560×1600/150%DPI单屏、自建页面与生产desktopCapturer；不发送系统滚轮，不读取真实Key，不调用外部AI，不写用户剪贴板或私人桌面。合成PointerEvent覆盖真实React处理器与主进程，不能冒充人工硬件鼠标、触屏或混合DPI实机验收。日志为longshot-stage3.2-tests/typecheck/build/smoke及错误日志；临时debug日志/中止运行不作为最终通过记录，最终目录版和桌面入口补记下方。

已知限制与下一步：3.3尚需Ctrl+滚轮、50/75/100/125%与适应窗口、按可见区供图；调整窗口大小不等同于原图比例缩放。手动放置允许覆盖选区或与工具栏相邻，用户可移开/复位；只限原显示器工作区，不跨屏拖放，不记录跨会话位置。error后已停止处理的预览不承诺随大小重新高清供图，可完成已有原图后检查。热插拔、真实微信及其他应用矩阵、实机混合DPI/硬件指针仍未验收。自动滚动继续低优先级。

最终交付：v0.14.0最新目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，`packaged-longshot-stage3.2.err.log` 0字节；包含PREVIEW WINDOW、PLACEMENT、普通截图/OCR/演示翻译AI/标注贴图、长图工具、连续采集、恢复、控制、双向、正文与UI全部通过标记。193项最终单元测试、类型检查、构建和打包通过。最终源码无临时诊断包装或额外读取；原图和PNG逐像素核对、注入复制尺寸、完成取消销毁均通过。一次目录版合成连续场景约3.27fps，15采集/14处理、12次追加、0拒绝、1帧完成时丢弃，峰值2帧/5932184字节、0背压；非真实应用或前后速度对比。

运行位置 `release/v0.14.0/win-unpacked/AI Screen.exe`，产品版本0.14.0.0；完整目录保留。桌面原快捷方式已备份为 `.runtime/AI Screen-shortcut-before-v0.14.0.lnk`，目标、工作目录和图标更新至新版，v0.13.0及其他旧目录保留。更新时无旧版常规主进程，未停止用户程序。经原快捷方式启动新版，常规主进程PID261588，Responding=true、版本0.14.0；无遗留smoke主进程。未读取/变更真实服务配置或密钥。

## 长截图专项阶段3.3：原图比例与可见区 · v0.15.0 · 2026-10-18

本轮沿用现有项目与模式机制，只扩展预览供图和交互；不改读屏API、匹配阈值/策略、采集队列、自动输入或普通截图/AI服务。无新依赖。

新增文件：
- `src/shared/scroll-capture/preview-viewport.ts`：比例/DPI、鼠标锚点和ROI边界。
- `src/renderer/longshot/usePreviewZoom.ts`：比例、浏览/跟随、滚动位置与请求状态。
- `src/renderer/longshot/PreviewZoomControls.tsx`：四档比例、加减、适应窗口和跟随；菜单绘在保护窗内部。
- `src/renderer/longshot/preview-view-sender.ts`：一个在途+最新待发、错误与销毁隔离。
- `src/main/longshot-preview-zoom-smoke.ts`：原生窗/IPC/Worker缩放与采集跟随验收。
- `tests/longshot-preview-zoom.test.ts`：8项缩放、供图、安全和请求调度测试。

修改文件：
- shared：`scroll-capture/preview.ts`、`preview-window.ts`、`engine.ts`、`longshot.ts`。
- main：`longshot-window.ts`、`longshot-surfaces.ts`、`longshot-smoke.ts`；`services/longshot.ts`、`longshot-processor.ts`、`longshot-worker.ts`。
- renderer：`longshot/LiveThumbnail.tsx`、`longshot.css`、`views/Home.tsx`版本号。
- 测试：`tests/longshot-preview.test.ts`预览新增28DIP工具行供图尺寸；`longshot-service-pipeline.test.ts`处理器接口保留原有竞态检查。
- 版本/文档：package.json/lock、README、MANUAL-LONGSHOT、ARCHITECTURE、LONGSHOT-OPTIMIZATION-PLAN及本文。

比例菜单50/75/100/125%，Ctrl+滚轮与加减范围25–400%；100%按物理屏幕像素而非CSS像素，CSS比例zoom/devicePixelRatio。Ctrl+滚轮锚定鼠标下的源图位置，靠近文档边界则夹紧；普通滚轮只浏览预览，点击“跟随”重新追踪当前采集视口。适应窗口回完整概览，清晰回按宽度默认；窗口复位只改变自动位置，保留3.2拖动/八向调整和当前比例。新会话恢复默认清晰。预览与UI生命周期不改变采集会话状态机。

供图链：renderer有限DIP/比例请求 → 当前thumbnail/session白名单IPC → 主进程真实窗口/DPI夹紧 → PreviewPump合并 → Worker.viewport直接采样StitchDocument分段ROI → PNG与源区域元数据 → 可滚动CSS文档中的局部图片。纯缩放/浏览复用概览和清晰缓存，不重截屏、不重建整张长图。源文档变化才刷新基础预览；老sequence/旧尺寸回复不发布。follow根据当前视口/方向定位，manual按coveredTop差值保持同一正文，固定header不移。客户端无权指定可信DPI或任意图像数据。

每张预览最多2048×2048像素，250ms合并，PNG仍在主进程编码，匹配/取样仍共享Worker。通常窗口100%直接显示原始像素；若把预览放大到可见物理尺寸超过2048，整个可见区降采样而非缺边，缩小窗口可检查原像素。>100%是原像素放大；不是AI锐化或生成细节。快速浏览可能短暂等ROI，不承诺完全无延迟。新增有界ROI图像与PNG临时内存仍在文档256MiB预算之外；该预算不是RSS限制。

201项单元测试通过，原193项保留；覆盖100–200%DPI的物理比例、轮事件单位/范围、鼠标锚定/边界、ROI裁剪/方向/补顶固定头、严格schema/额外字段、跨分段逐像素/导出不变、超大窗口有界采样，以及慢IPC最新请求/失败/销毁。类型检查/构建通过。源码隔离长图集成退出0，既有双向/连续/恢复/正文及原图/PNG回归通过。最终目录版还增加采集期间100%预览随下扩和上补、原图ROI像素核对，结果补记本节末尾。

`.runtime/longshot-stage3.3-preview.png`已查看：四档菜单入口、适应窗口/跟随、可滚动清晰图像、状态与原标题布局正常。测试为2560×1600/150%DPI单屏、自建Canvas、生产desktopCapturer和合成DOM输入；不发系统滚轮、不读取真实Key、不调用外部AI、不写用户剪贴板或保存私人桌面。脚本曾因同一JS回调中点击后立刻查询React菜单而中断；已改为等待实际渲染，失败运行不计验收通过。真实硬件鼠标、触屏、微信、公开浏览器网页/系统应用及混合DPI实机仍未专项验收。

下一阶段4优先手动跨应用矩阵：用公开网页/演示聊天/临时测试目录，区分读屏未变化、匹配拒绝、固定区域和真实缺口，再按证据修复，不预设微信GPU或换API必然解决。持续帧源/WGC/DXGI成本需另评估；本轮不改善快速滚过未采内容的可靠性。长图裁剪/贴图仍未接入，自动输入低优先。

最终交付：`release/v0.15.0/win-unpacked/AI Screen.exe`，产品版本0.15.0.0。最终目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，`.runtime/packaged-longshot-stage3.3.err.log`为0字节。普通截图/OCR/演示翻译AI/标注贴图、预览布局/拖动/八向大小、四档原图缩放/Ctrl+滚轮/浏览跟随、采集中100%随下扩和上补、长图工具、连续/恢复/控制/双向/正文确认、原图与PNG逐像素及取消清理全部通过。201项测试与类型检查/构建通过，最终日志分别为longshot-stage3.3-tests/build/package与packaged-longshot-stage3.3。构建保留已有的大chunk提示，不影响生成运行。一次目录版干净合成场景约3.39fps，15采集/14处理、11次追加、0拒绝、1帧完成时过期丢弃；缓冲峰值2帧/5932184字节、0背压，不是同条件提速或微信兼容结论。

原桌面快捷方式已备份为 `.runtime/AI Screen-shortcut-before-v0.15.0.lnk`，目标、工作目录、图标均更新至v0.15.0。经原快捷方式启动新版，常规主进程PID268768，Responding=true、版本0.15.0.0；未停止用户程序，无遗留smoke主进程。v0.14.0及其他旧目录完整保留。使用新版时保持win-unpacked完整目录，不单独移动EXE。

## 长截图专项阶段4.1：兼容性诊断与空返回恢复 · v0.16.0 · 2026-10-19

按用户“继续处理”推进。此前Edge的computer-use自动化因无法确认当前URL中止；本轮继续代码与隔离集成开发，不绕过该工具限制、不声称真实Edge已验收。阶段4拆为4.1诊断/报告/边界、4.2实际公开浏览器及Win32演示窗口、4.3微信演示/系统应用及实机多屏。当前完成4.1，整个跨应用阶段仍未完成。

新增文件：

- `src/main/services/frame-fingerprint.ts`：相邻完整像素/宽高摘要，只保留一个摘要，不保存额外原始帧或导出摘要。
- `src/shared/scroll-capture/diagnostics.ts`：固定处理建议与白名单JSON；不读取设置/图片/窗口数据。
- `src/main/longshot-diagnostics-smoke.ts`：预览和完成页导出、挂起/恢复、取消迟到响应验证。
- `tests/longshot-diagnostics.test.ts`：8项证据、建议、隐私白名单、有限数值/拷贝隔离及原子文件测试。
- `docs/LONGSHOT-COMPATIBILITY.md`：证据矩阵、验收步骤和诊断解读；未验收应用明确标注。

修改文件：shared/longshot.ts、scroll-capture/telemetry.ts；main/services/live-region-source.ts、longshot.ts、longshot-file.ts；main/index.ts、smoke.ts、longshot-smoke.ts；renderer/longshot/DiagnosticsPanel.tsx、LiveThumbnail.tsx、ResultEditor.tsx、longshot.css；tests/live-region-source.test.ts（新增4项重读边界）；package.json/lock、Home版本号及README、MANUAL、ARCHITECTURE、ROADMAP、专项计划与本文。无新运行依赖。

相邻读屏SHA-256覆盖宽高及全部字节，记录变化、相同和连续相同；首次读取不算变化，暂停/恢复重置连续计数。Worker新增、去重/回看、拒绝仍独立统计，不把duplicate等同于采集过期。面板给出停止/正文确认/暂停/背压/拒绝/相同/回看的固定建议。相同画面不能区分页面没动与返回旧图；变化也不代表成功拼接。没有推断微信GPU、自绘或特定浏览器根因。计算在主进程，开销计入读屏耗时；不宣称无开销/提速。

导出沿用longshot角色和活动会话UUID校验，新命令export-diagnostics不接受标注。报告仅含应用/系统版本、屏幕物理尺寸/DPI、采集尺寸/相对文档坐标、计数/阶段耗时/问题代码和固定建议；无像素、摘要、标题、URL、路径、ID、提示词、配置、原始错误文本或Key，不上传/不写剪贴板。elapsedMs为请求时距会话开始的总时间，包含等待/暂停。选择路径期间用独立diagnosticPending与采样版本暂缓采集，保持用户paused和托盘suspended；完成中禁导出，导出挂起期间禁完成，取消仍可用。取消/错误后恢复或保留原暂停；截图取消使迟到路径失效。PNG文件原子写入抽为共用内部saveFile，JSON复用wx临时文件、当前会话检查和rename/清理，未重写图片输出。完成释放liveViewport PNG与摘要。

源码回归曾出现缺失/空显示器图像而立即停止。LiveRegionSource现在只对缺失/空NativeImage等待80ms后进行一次新读取；仍失败明确报错，不复用旧帧、不补图。取消、显示器位置/DPI变化、返回分辨率不一致和其他异常不被宽松吞掉，重读次数进入数值诊断。仅有一次该原生失败记录，未捕获内部系统原因；单元覆盖空返回恢复/穷尽、取消、显示器变化、异常/重采样不重试，不能据此称任意设备问题已解决。读屏API、匹配规则、有界队列、窗口预选、普通截图、OCR/翻译/AI和滚轮策略保持。

首次源码回归停在侧栏步骤，只有Script failed to execute而无具体renderer原因；旧测试在独立thumbnail PNG/蓝框未就绪时直接读取DOM存在时序风险，改为等待真实图像解码/蓝框几何有效，保留原严格像素/边界断言。另一次源码运行出现上述空源错误；这些失败日志保留，不计通过。最终源码`longshot-stage4.1-source-final.log`退出0，错误日志0字节，完整长图布局/缩放/工具/连续/恢复/控制/双向/固定栏/导出/取消通过。没有将不明脚本错误写成已确认生产拼接缺陷。

最终验证：213项单元测试、类型检查/构建/目录打包通过；新增8项诊断和4项源重读测试，原201项保留。最终目录版完整 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出0，`packaged-longshot-stage4.1.err.log`为0字节。通过普通截图/OCR/演示翻译AI/标注贴图、布局/拖动/八向大小、四档原图比例/Ctrl+滚轮/跟随、长图工具、连续/失联恢复/双向/正文确认及原图/PNG核对。新增预览真实React→preload→IPC导出，文件选择模拟挂起期间滚动不提交、取消/错误恢复、暂停和托盘挂起保留、finish/外来/旧会话拒绝、源取消后迟到路径不写入、完成页拼接/首屏报告与原图尺寸一致。保存路径/文件选择及剪贴板均注入；没有实际操作用户文件对话框，不冒充人工硬件验收。

目录版干净合成连续场景：901×823选区 → 901×1933成品，1110新增行、12个有效片段（含首屏）；15次读取/14次处理、11次追加、0拒绝、1帧完成时过期丢弃，约3.39fps。缓冲峰值2帧/5932184字节、0背压。读屏平均约291ms（含摘要）、Worker往返约203ms、预览约15ms，异步时间可重叠，不能相加或用作同条件提速结论。单屏结果报告901×823、1帧、0新增，明确single-frame。JSON样本为longshot-stage4.1-diagnostics/stitched-report/single-report；`.runtime/longshot-stage4.1-diagnostics-panel.png`已实际查看，状态建议、版本/DPI、读屏变化/相同/重试及可滚动数值可见。

运行/交付：`release/v0.16.0/win-unpacked/AI Screen.exe`，产品版本0.16.0.0，完整目录保留；v0.15.0及其他旧目录未删。原桌面快捷方式备份 `.runtime/AI Screen-shortcut-before-v0.16.0.lnk`，目标/工作目录/图标均更新。经原快捷方式启动正常主进程PID277300，Responding=true；更新时无旧正常主进程，未停止用户程序。没有遗留smoke主进程。

边界和下一步：本轮为Windows10 10.0.19045、2560×1600、150%DPI单屏，自建Electron44.7.0页面与生产desktopCapturer，使用DOM输入、隔离设置/注入后端；不发系统滚轮、不操作私人聊天、不写用户剪贴板、不读取真实Key、不调用外部AI、不保存私人桌面。没有真实Chrome/Edge/微信及CPU/RSS矩阵证据，源摘要和有限重读不解决任意快速滚动、页面重排或未知缺口。4.2优先公开网页/演示窗口的实际手动矩阵，按证据处理输入/采集/拼接问题；自动、持续帧源、长图裁剪/贴图、录屏、连续AI识屏和正式签名/安装发布仍未完成。

## ROI尺寸专项阶段1 · 2026-10-19

本窗口已完成ROI-01，证据、变更、命令和局限详见 [LONGSHOT-ROI-STAGE1-EVIDENCE.md](LONGSHOT-ROI-STAGE1-EVIDENCE.md)。原生14帧的正文都通过120px真值核验：400×400成功，800×400要求裁正文，1600×400/400×900/1600×900固定400正文场景拒绝；同面积全滚动控制成功。原始帧与离线5次重放结果一致，最早差异在固定边缘模型和全宽匹配/正文提议。诊断默认关闭、阈值未改；216测试、类型检查、构建通过，未打包/更新快捷方式。下一步ROI-02完整矩阵归因；真实Chrome/GitHub/微信和多DPI未验收。

## ROI性能专项首轮 · 2026-10-19 · 未发布源码

最新目标与进度见LONGSHOT-PERFORMANCE-PLAN.md、20项诊断见LONGSHOT-PERFORMANCE-REPORT.md。已实现单次匹配32,768源像素样本、最多64候选/65,536像素对齐探测、BGRA精确快判、独立PNG Worker及自动有界异步提交反馈。旧保守匹配和多条带尚未收敛到全帧共享预算；固定450/300ms等待和原生滚轮步长未乱调。225测试、构建和最终UI-only原生回归通过，错误日志为空；真实自动主要场景通过，后续焦点因遮挡保护中止，不能记整套通过。

最终单独CPU矩阵416/416位移及输出像素正确：400×500 P50 3.49→1.80ms、1500×900 15.86→6.25ms。实际901×823采集仅3.307→3.360fps，不能宣称端到端明显提速。更关键证据为source-dispatch同步调用P50 221.19ms、事件循环P95 241.04ms、Worker CPU仅2.32ms但往返220.32ms；下一步优先隔离采集阻塞与回复饥饿，再补HUD/真实px每秒/进程树资源矩阵。三应用/多DPI未测，未打包或改桌面入口，v0.16.0旧目录保留。

## 录屏分线 REC-00 · 2026-10-22 · 仅规划

用户明确先写计划书，再先搭框架、分步实现。本窗口主计划为 [RECORDING-PLAN.md](RECORDING-PLAN.md)，已有模块职责、状态、会话/权限、文件生命周期、REC-00～REC-08 阶段与验收要求。下一步固定为 REC-01：共享契约、状态机、后端/输出接口和服务骨架，真实录像需 REC-02 媒体实验通过后再接入。

现有源码 `0.16.1-test.3`，`record` 为占位；defaultSession 媒体权限均拒绝、框选取消会触发 modeAbort，计划已记录专用媒体 Session 与交接处理。优先实验持续视频流和有界压缩数据落盘，先无声 WebM，随后暂停、声音和 MP4。

本机 QQ Camera.dll 的第一轮录屏静态调查见 [RECORDING-QQ-INVESTIGATION.md](RECORDING-QQ-INVESTIGATION.md)：已定位开始/结束与音频开关扩展派发，编码后端尚未确认；证据和快照保存于 `.runtime/rea-qq/recording-*`，原生会话已关闭。公开项目见 [RECORDING-OPEN-SOURCE-RESEARCH.md](RECORDING-OPEN-SOURCE-RESEARCH.md)。本次只更新计划与文档，未修改功能代码、依赖、版本或桌面入口，未运行录屏或生成候选包；不以旧长图测试数量作为录屏验收。

## 录屏 REC-01 / REC-02 · 2026-10-22 · 源码与媒体实验完成

用户授权实施1、2阶段。实现与证据见 [RECORDING-STAGES-01-02.md](RECORDING-STAGES-01-02.md)：独立RecordingService、契约/状态机/接口、会话ID与sequence、截图交接、互斥、有界写盘、专用媒体宿主Session/sandbox/preload、连续显示器流ROI、WebM时长预留封装、H.264奇数尺寸填边和隔离实验路由。正常应用注册录屏扩展但available=false，原录屏占位提示保留；没有改用户现有候选包、快捷方式或版本。

285项单元测试（新增22项）、类型检查、构建通过。最终 `.runtime/recording-spike/2026-10-22T11-41-13-704Z/report.json` 四组均passed：隐藏VP8 10秒，最小化VP8/隐藏VP9/隐藏H.264各3秒；输出WebM601×361、MP4602×362（右下各补1px），有限初始时长、seek、四角色标与三时点运动帧号通过，单会话源枚举一次、重复授权/外来sender拒绝。最终正常应用 `--smoke-test --longshot-ui-only --longshot-manual-b`退出0，日志`.runtime/recording-app-regression.log`，普通截图/OCR/AI演示/标注贴图/长图布局缩放工具与连续双向正文确认回归通过。

环境仅Windows10/Electron44.7.0/Chromium152/单屏2560×1600/150%，写入仅自建测试窗ROI、无声；受信输入由sendInputEvent产生。WebM初始有限时长已补，但10秒样本扫描后的媒体时长比会话时钟多约149ms，后续需精细时间戳与尾帧验收；帧计数为裁剪回调，不冒充编码fps。未测真实多屏/混合DPI硬件、1080p长录、声音与Windows播放器；短MP4实验不等于REC-06完成。下一步REC-03正常入口、开始与倒计时、无声WebM、控制条/托盘、预览另存；保留available=false直至正常用户路径验收通过。

## 录屏 REC-03～05 · 2026-10-22 · 正常入口、控制恢复与声音

按用户“3,4,5”实现。主计划 [RECORDING-PLAN.md](RECORDING-PLAN.md) 已更新；实现、证据、命令和限制见 [RECORDING-STAGES-03-05.md](RECORDING-STAGES-03-05.md)。正常应用的 RecordingService 现为 productionReady，Alt+A → 录屏 → 范围/声音确认 → 独立控制窗口真实开始 → 3 秒倒计时 → 录制/暂停/继续/完成 → 播放预览/另存 WebM。系统声与麦克风默认都关闭；已启用的源可分别静音，编码轨道保持稳定。源码版本仍是 0.16.1-test.3，没有新包或桌面入口变更。

接入选区交接、受保护控制条与边框、托盘和 Ctrl+Alt+Space/Enter/Esc、快捷键冲突警告、严格媒体权限和会话身份、源结束/显示变化/锁屏休眠的有效片段完成、保存取消/失败重试、目标同卷临时文件复制/替换，以及退出保存/放弃/继续使用。结果窗口通过仅当前成品可访问的 recording-video 协议提供 Range 文件流。系统声 loopback，麦克风独立取得，AudioContext 独立增益混合；双源各 0.5、单源 1，关闭语音处理和自动增益。设备结束触发完成；故障/取消等待在途操作和设备清理。

295 项单元测试、类型检查和构建通过。最终 `npm run recording:smoke` 退出 0，报告 `.runtime/recording-ui/2026-10-22T12-35-07-599Z/report.json`：正常入口 30.045815 秒、601×361，1/15/29 秒 ROI 色标和重叠控制条捕获排除正确；实际播放推进、seek、保存通过。暂停 5 秒后会话 4.073693 秒、视频 4.116 秒、音频 4.08 秒，无暂停标记画面/880Hz；四种声音组合、分别静音、源终止、保存取消/失败/覆盖重试、麦克风拒绝授权均通过。已查看 controls/result 截图，控件位于原生可见区域。

最终原应用 `--smoke-test --longshot-ui-only --longshot-manual-b` 退出 0，`.runtime/recording-app-regression.log` 含 SMOKE PASS；普通截图/OCR/服务模拟/AI演示/标注贴图、长图布局/缩放/工具/连续/恢复/双向/正文确认和原像素导出回归通过。受信开始用 sendInputEvent，框选用合成 DOM 输入；文件选择/麦克风拒绝由测试注入，不冒充人工对话框/硬件操作。

声音保存测试仅使用定向 WebFrameMain 440Hz 和虚拟麦克风 660Hz，不采集物理麦克风或保存私人系统声音。真实 Windows 回环另用无虚拟设备的进程做仅数值检测，获得 live loopback 音轨但 RMS/440Hz 全零，未通过有声断言；只读 Core Audio 显示默认输出 muted=True、音量约0.67。保留用户静音设置，失败记录 `.runtime/recording-ui/2026-10-22T12-28-05-218Z/report.json`；不得写成真实系统声或物理麦克风已验收。真实锁屏/休眠/拔设备/退出交互、声道差异、长录/1080p、多屏DPI与Windows11仍待REC-07。REC-03/04为本机受控验收，REC-05为实现和合成输入验收。

下一步 REC-06 有声 MP4；REC-07 补硬件/性能，REC-08 独立候选目录和运行入口。先退出旧实例再 npm run dev 或构建后 npm start，旧 release/v0.16.1-test.3 包不包含本轮录屏。没有新增外部运行依赖、QQ DLL 或开源源码复制。

## 录屏 REC-06～08 · v0.17.0-test.1 · 2026-10-22 · 交用户手动检查

用户要求完成剩余部分并自行检查后反馈。交付目录 `release/v0.17.0-test.1/win-unpacked/AI Screen.exe`，版本根目录有“启动录屏候选.cmd”和“使用说明.txt”，保留旧长图目录和原快捷方式。主计划及 README/ROADMAP 已更新，详细证据、未验范围与复验命令见 [RECORDING-DELIVERY-v0.17.0-test.1.md](RECORDING-DELIVERY-v0.17.0-test.1.md)。下一步等用户手动反馈，不继续自行扩展功能。

新增原生 H.264/AAC MP4、默认格式选择、按实际格式预览/另存与扩展名校验；保留 VP8/Opus WebM。MP4 原生头的零时长导致 Windows 播放器读不到 duration，已在停止后按 fragment/sample 时间戳填写 movie/track/media 头，不改 mdat、不重编码，元数据预算16MiB。另存仍原子替换；正常启动有限清理超过7天的应用 UUID 临时录像，跳过链接/目录/近期文件。无外部转码依赖。Windows 播放器 COM、独立 Edge/Chrome 对最终目录版有声 MP4 均播放/定位通过。

299 项测试、类型检查和构建通过。最终离线打包使用本机 `node_modules/electron/dist`，避免中途 Electron 下载 ETIMEDOUT；保持图标和版本编辑配置。ASAR 主进程、preload、媒体引擎、HTML/JS/CSS及原生助手与最终构建哈希匹配，报告 `.runtime/recording-package/0.17.0-test.1.json`，最终 archive SHA-256 `9fec51124495732fa3b4360c516e752b84579e18b74d987c7eebd61bc5e5f725`。

最终目录版 MP4 `.runtime/recording-ui/2026-10-22T13-58-10-267Z/report.json`、WebM `.runtime/recording-ui/2026-10-22T14-00-08-280Z/report.json` 退出0，覆盖正常框选入口、真实开始、30秒动态帧计数、暂停排除/恢复蓝色画面、四种声音、独立静音、播放定位、源结束、保存取消/失败/覆盖重试与拒绝麦克风。最终音视频均定向捕获隐藏的自建 WebFrameMain，源丢失拒绝，不回退到真实桌面/系统声；不能冒充新增原生桌面捕获排除验证。

原截图与长图目录版完整回归 `.runtime/recording-v0.17-packaged-regression.log` 退出0并含SMOKE PASS；功能断言全部通过，日志有一条子进程清理时 script execution has been terminated 诊断，未将其写成0错误日志。源头/匹配/滚轮策略未改。

REC-07 的原生桌面短矩阵通过10次会话、1080p三场景和大选区。30分钟实际完成1800.1193秒、50,471编码样本、28.0376fps，AAC1800.062104秒，尾差约57.2ms；59次进程私有内存采样590～624MiB，预热后前后5次均值增长9MiB。**长段色标未通过**：测试窗口中途被其他窗口覆盖，固定ROI因此包含其他桌面画面。已删除原长视频、提取帧和两个关联的独立浏览器测试配置，仅留数值摘要 `.runtime/recording-stress/2026-10-22T13-13-21-446Z/long-recording-summary.json` 与失败report；不要恢复/传播这些被清理的媒体或声称受控长段画面已验收。

后续压力测试默认改为隐藏 WebFrameMain 源，修正后的短矩阵 `.runtime/recording-stress/2026-10-22T14-05-47-294Z/report.json` 全通过：连续会话约29.3～29.7fps，1080p静态/滚动/动画29.75/29.51/29.45fps，2566×1544窗口源大选区29.63fps；含MP4封尾停止17～31ms、动态计时误差<1秒、会话临时目录清空。未重新跑隔离源30分钟色标长测。真实系统声音、物理麦克风、左右声道、拔屏/设备、锁屏/休眠/退出人工操作、多屏/DPI/Windows11依旧明确未验，交用户手动检查并反馈。

最终候选正常 GUI 主实例 PID292952，已确认 Browser/GPU/Utility 与 renderer 进程存活、Responding=true。启动时清除了开发环境 ELECTRON_RUN_AS_NODE，版本根目录启动脚本也显式清除此局部变量；原先错误 Node 启动的自建进程274844已停止。未终止其他用户程序，未留下smoke主实例。

## 2026-10-23 · 录屏反馈已交付 v0.17.0-test.2

准备/录制工具条统一浅色样式，424×56 / 328×56 DIP；Windows100%强制最小56高度，已统一。框选自动进入准备，按钮点击开始后倒计时；删除返回普通截图。两种状态拖动手柄/空白/计时，主进程边界约束，状态变化保持位置；设备弹层按内容高度收缩。
麦克风可选择默认或具体设备，显式开启后才取得预览输入并本地测电平，开始时传递同一流。权限检查只在当前本地媒体主帧明确麦克风授权后允许audio检查，摄像头及其他来源仍拒绝。配置开始后冻结。输出文件推迟至媒体准备成功，并使用最终选择格式；取消延迟打开的输出会清理。
301项测试、构建、完整MP4/WebM录制及错误恢复、100%/125%/150%/200%缩放通过；打包真实Senary麦克风两次数值检测通过，没有保存音频。最终目录包原截图/长图回归退出0、SMOKE PASS。旧capture-refactor-smoke中“返回普通截图”断言已改为自动准备及重选保留录屏模式，避免继续测试已经删除的流程。
最终ASAR ccc25b8f1486d94fff6fea9866c0f3037020f226245ddb1d2ee80573b8573e9a，包审计 .runtime/recording-package/0.17.0-test.2.json。详细证据见docs/RECORDING-UI-FIX-v0.17.0-test.2.md。
桌面仅保留AI Screen.lnk并指向release/v0.17.0-test.2/win-unpacked/AI Screen.exe。旧快捷方式备份.runtime/desktop-shortcuts-test2。未改系统音量，未终止用户程序；只停止过未结束的本轮smoke测试进程286704。实际听感、真实系统回环、多屏硬件与Windows11仍不可冒充通过。
