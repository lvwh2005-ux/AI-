# 分发与 GitHub 发布

## 直接发给别人

本次版本为 `0.18.0-test.3`，产物放在 `release/v0.18.0-test.3/`：

| 文件 | 接收者怎么用 |
| --- | --- |
| `AI-Screen-0.18.0-test.3-win-x64.zip` | 完整解压后打开 AI Screen.exe；可以直接发这个压缩包 |
| `AI-Screen-0.18.0-test.3-win-x64-setup.exe` | 安装后从快捷方式打开（完整构建时生成） |
| `AI-Screen-0.18.0-test.3-source.zip` | 开发者源码，不适合发给只想运行的人 |
| `SHA256SUMS.txt` | 上述文件的 SHA-256 |
| `RELEASE-NOTES.md` | 可粘贴到 GitHub Release 的说明 |
| `RELEASE-CHECK.json` | 文件核对结果与未执行的验证项 |

建议给接收者附一句：

> 这是 Windows 10/11 的 64 位测试版。请先全部解压，打开 AI Screen.exe，保留完整目录，无需装 Node.js。默认演示模式，实际 AI 需要在设置里填写你自己的服务和 Key；使用前可看包内“使用说明.txt”。关闭窗口后程序仍在托盘，退出请从托盘操作。

不要压缩整个开发目录。里面的 `node_modules`、`.runtime`、`.npm-cache`、`.electron-cache`、历史 `release`、用户设置和测试媒体都不应发送。分发 ZIP 中必须保留程序依赖文件与许可证。解压版仅免安装，设置仍保存在当前 Windows 用户目录，不是随包移动的个人数据。

## 上传 GitHub 源码

当前工作目录尚未初始化 Git；无需把它的大量历史构建上传。推荐先解压本次的 `source.zip`，在解压出的干净目录初始化仓库。源码 ZIP 通过明确目录清单生成，包含 `.github`、`.gitignore`、源码、测试、图标及文档，不包含运行缓存或密钥设置。

1. 在自己的 GitHub 账号下创建空仓库，名称可用 `ai-screen`；先不要自动添加 README、许可证或 .gitignore，包内已经有了。
2. 在解压出的源码目录打开 PowerShell，执行下面命令。将占位地址换成自己的实际仓库地址。

```powershell
git init -b main
git add .
git status --short
git commit -m "Prepare AI Screen Windows distribution"
git remote add origin https://github.com/YOUR-ACCOUNT/YOUR-REPOSITORY.git
git push -u origin main
```

首次提交前可检查 `git status`，应只有源码、图标、文档和 GitHub 配置；不能出现缓存、个人配置或测试录像。项目已按 MIT 授权，版权署名为 AI Screen contributors，可按实际维护者身份调整署名。

## 上传可运行文件到 Releases

1. 进入仓库 → Releases → Draft a new release，选择或创建 tag `v0.18.0-test.3`。
2. 将 `RELEASE-NOTES.md` 的内容放入说明，将安装包、解压包、`SHA256SUMS.txt` 加入附件；可以同时附源码 ZIP 和核对报告。
3. 此版本带测试标记，勾选 **This is a pre-release**。检查附件完整后发布。
4. 给普通用户分享该版本的 Release 页面链接，让他们选 `win-x64.zip` 或 `setup.exe`，不要让他们下载自动生成的 Source code。

测试版请分享具体版本页面：`https://github.com/你的账号/仓库名/releases/tag/v0.18.0-test.3`。不要依赖 `/releases/latest` 指向测试版。GitHub 的 Releases 支持二进制附件及草稿/测试版，见 [GitHub 官方发布说明](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)。

## 在本机重新构建

Windows x64、Node.js 22.12+ 的 22.x 和 npm：

```powershell
npm ci
npm run release:win
```

脚本依次执行测试、类型检查/构建、Windows x64 安装版及 ZIP 打包、包内文件与原构建逐字节核对、源码清单归档、实际解压两个 ZIP 再核对、输出 SHA-256。第三方许可证自动从锁文件中的运行依赖汇总；缺少许可证文件时停止。打包使用 npm 安装的固定版本 Electron；首次 NSIS/压缩工具下载需要联网。

只需要解压版、暂时无法下载 NSIS 时可用 `npm run release:zip`。只生成源码用 `npm run release:source`；Windows 原生截图助手需要系统自带的 .NET Framework 64 位编译器（`%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe`）。企业精简系统缺失时需先修复系统环境。

成品文件已存在时不会覆盖；下一次发布先执行 `npm version 版本号 --no-git-tag-version` 同步修改 package.json 与锁文件，并更新面向用户的版本说明。构建失败后要重试同版本，只能在确认没有已分发的同名文件后，人工将该版本目录移动为备份；不要删除整个 release。打包过程不会上传到 GitHub，也不包含自动更新功能。

如果构建已成功，仅后续核对步骤中断，可执行 `node scripts/release.mjs --verify-only` 继续核对现有产物；它不会重新打包程序。核对还会检查源码包是否与当前源码一致，发现过期时会停止。仅 ZIP 的构建同时加 `--zip-only`。安装版可能比 ZIP 多一个 NSIS 安装用的 `resources/elevate.exe`，其余文件均按路径和 SHA-256 比较。

## GitHub Actions

- **CI**：push / pull request 时在 Windows 上执行 `npm ci`、测试和构建。
- **Build Windows release**：手动从 Actions 运行，或推送与 package.json 一致的 `v*` tag 后运行；生成分发文件并保存为 Actions artifact。下载 artifact，取出内部的程序 ZIP / 安装包再上传到 Release。

Actions 不自动公开 Release；工作流只有读取仓库权限。它们不使用个人密钥或 AI 服务，不在云端执行需要真实桌面、OCR 语言包和麦克风的 GUI 检查。GitHub 托管 runner 的构建只能在仓库上传后验证，本机不能代替一次真实工作流运行。

## 兼容性与发布前验证

ZIP 解压和构建文件核对可验证带齐资源，但不能证明每台电脑均兼容。安装包生成成功也不等于已验证安装、升级或卸载。

正式推广前建议在另一台普通用户权限的 Windows 电脑依次检查：安装/卸载或全新 ZIP 解压；无开发环境时启动；截图/快捷键/本地 OCR；长截图接缝；MP4/WebM 预览与保存；实际系统声和麦克风；使用自己的 AI 服务；重启应用和升级后的设置保留。

此版没有代码签名，可能出现 SmartScreen/未知发布者提示。系统范围参考 [Electron 官方支持说明](https://github.com/electron/electron)；本项目仅构建 x64，Windows 11、多屏/混合 DPI 和不同音频设备完整矩阵仍待实机验证。安装版和解压版都不携带开发者个人设置，接收者各自配置 Key。
