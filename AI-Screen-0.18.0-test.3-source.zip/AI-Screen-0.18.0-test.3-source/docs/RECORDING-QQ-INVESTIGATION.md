# QQ 录屏第一轮静态调查

2026-10-22。用于[录屏开发计划](RECORDING-PLAN.md)的框架选型。本轮使用 reverse-engineer-anything 技能及 REA/Ghidra，复用同一目标的已有分析快照，补查录屏相关字符串、交叉引用和两个控制函数。

## 目标与方法

- 本机 QQ：`E:\常用应用\QQ\versions\9.9.31-49738`。
- 目标：`resources/app/QQScreenShot/BinRelease-x64/Camera.dll`，64 位 PE，大小 2,524,200 字节。
- SHA-256：`b2b65d4552bc58d04e09b664e2f12c586d06429680caccee7d382a8380d4c2a1`。
- Provider：Ghidra 12.1.4；分析器输出为伪代码，不是 QQ 原始源码。部分名称来自产物保留的日志、RTTI、控件和资源标识；原始类型和回调实现不完整。
- 只读静态分析，不注入运行中的 QQ，不启动录像、不读取聊天数据库、不修改第三方文件。

## 已观察到的内容

| 内容 | 精确位置与证据 | 能说明什么 |
| --- | --- | --- |
| 录屏 UI 和倒计时 | 字符串 `CaptureRecordToolbar`、`RecordCountDownWnd.cpp`、`RecordState.cpp`、`RecordTimeCountDownTips`；`ev_75c4fe4ece98f9de3d8fdbf7029753adaabebf56287e6a15a92f3a8b111c28e2` | 存在相应实现线索；单凭字符串不能证明具体运行时序 |
| 开始/结束控制函数 | `0x1800b8ba0`；`ev_fd67ad9601a291d377f71045bf2b32030b26f712ca201ec3b8ccddf1300c07c6` | `OnClickBtnRecordCtrl` 的两个分支分别包含 `OnStartRecord`、`OnEndRecord`；开始分支修改按钮/准备状态并进入后续函数 |
| 停止通过扩展派发 | 同一函数的结束分支，解析 `OnStop(m_dwRecordID)`，枚举扩展对象并经虚表偏移 `0x30` 传入录制 ID | 已观察到控制器将停止事件分发给扩展；尚未确认每个扩展的最终目标 |
| 声音开关通过扩展派发 | `0x1800b7660`；`ev_ee35d4010d33e5346aad885e2011626d45f7776d36f7e573c9c97af214f53449` | 控件 `CaptureRecordVoiceCtrl` 改变状态，解析 `OnAudioSwitch(m_dwRecordID, m_bIsSoundOpen, m_bIsVoiceOpen)`，虚表偏移 `0x38` 传递录制 ID 与两个开关值 |
| 录屏工具线索 | `CaptureRecordBtnBrush/Arrow/Text/Rectangle/Circle/Laser/Undo/Clear`，同一字符串证据 | 有画笔等工具标识；是否、如何合成进最终视频仍未知 |

上述停止和声音行为已从伪代码确认到回调派发层，强于只有字符串命中；尚未跟进录制扩展的完整后端，不能据此宣称恢复了 QQ 录屏算法。

## 对本项目的设计启示

1. 选择/倒计时/控制界面与采集编码服务分开，通过会话 ID 和明确命令通信。
2. “结束”和“取消”是不同操作：结束要等待媒体尾块和文件封装，取消释放资源并删除本会话临时输出。本项目具体语义由计划定义，不能说成已完全复现 QQ。
3. 系统声音与麦克风使用独立开关和状态，后端处理实际音轨。字段含义来自保留文本与参数位置，底层音频 API 尚未确认。
4. 画笔等属于后续扩展，基础录制链路应先独立成立。

这些为独立实现的架构选择，不涉及复制 QQ 素材或依赖 QQ 私有 DLL。

## 本轮尚未回答

- 真正录屏扩展的注册位置、入口和采集编码实现。
- QQ 此版本实际采用的画面采集 API、编码器、硬件加速、码率与帧率。
- 暂停/继续的时间戳、丢帧及音画同步机制。
- MP4/GIF/WebM 等实际输出格式、封装和尾部修复。
- 录屏中标注是否录入视频、工具条捕获排除的具体机制。
- 真实运行资源、最大时长、多屏与混合 DPI 行为。

QQ 安装目录中的 `ffmpeg.dll / avcodec-58.dll / avformat-58.dll / avsdk/txffmpeg.dll` 仅为文件清单观察，没有建立其与此录屏调用链的关系，不能据此认定 QQ 截图录像使用 FFmpeg。旧长截图报告中的 DXGI/GDI 证据也不能直接移用于录像。

## 可复用证据

- 搜索：正则 `record|recorder|录屏|录像|mp4|h264|encoder|ffmpeg|pause|VideoCapture`，大小写不敏感，范围是 Ghidra 已定义字符串，不是文件所有潜在文本。
- 开始标识引用：`0x1801bc136 → 0x1800b8bd0/0x1800b8bd7`；Evidence `ev_e29acfbd8203dec1a5d9d7fb9a652e5c17428b9bbe7c6b593fab2f738e60f1af`。
- 停止标识引用：`0x1801c18d8 → 0x1800b8d7e/0x1800b8d8f/0x1800b8e02`；Evidence `ev_296bded84cc9cdc5320d4474fac3a4bf8c3edf571f2419a538a14dc6517e9b73`。
- 音频标识引用：`0x1801c0d98` 的引用包含 `0x1800b79e4`；Evidence `ev_9e8ebdc2291aec43e349421a9a245e3de71f7ddff3e052f8850cfb8e74cbd3b8`。
- 导出文件：`.runtime/rea-qq/recording-research-evidence.json`，31 条记录，包含同目标此前保留的长图证据和本次补充；数量不表示恢复了 31 项录像功能。
- 可复用快照：`.runtime/rea-qq/recording-analysis-snapshot.json`；本轮结束已关闭原生会话。

后续只有在某个实现选择确实需要 QQ 后端证据时再定向追踪，优先按计划完成本项目的可替换录屏框架与受控媒体实验。
