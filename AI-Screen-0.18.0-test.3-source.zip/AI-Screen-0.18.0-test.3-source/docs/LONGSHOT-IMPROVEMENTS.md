# 长截图体验修复 · 分阶段推进

此文保留 v0.6.1 历史。用户随后要求重建长截图框架，最新计划已由 [LONGSHOT-V2-PLAN.md](LONGSHOT-V2-PLAN.md) 取代：A 阶段 v0.7.0-preview.1 框架已实现，B 阶段复杂页面算法、C 阶段原图编辑待推进。交付和验收状态以 HANDOFF 末尾为准。

用户反馈：采集界面不可见、结束后看不到拼接长图、缺少对长图的后续编辑。以用户提供的 QQ 长截图交互图为参考，继续扩展现有工程，不重写普通截图和 AI 链路。

## 第一阶段：过程可见、结果可信 · v0.6.1

本轮范围：

- 选区外放不下面板时，使用可见的悬浮面板，取消静默隐藏到托盘的做法。
- 使用系统的捕获排除机制，面板可覆盖选区但不进入最终图片。Windows 10 2004 以前不支持该行为，明确停止并提示缩小选区，不继续采集黑块。
- 后台 Worker 从已接受的像素分段生成小缩略图，不为每次预览分配完整长图，也不清空拼接状态。
- 采集面板显示实时预览、首屏高度、新增像素、累计尺寸、暂停/失败原因。
- 结果窗口直接显示；只有首屏时明确标为「首屏截图」「没有拼接出长图」，不再宣称完成长图。复制和 PNG 保存继续可用。
- 只将本进程已开启捕获排除的控制面板视为透明遮挡；其他窗口遮挡和鼠标进入控制面板仍会暂停自动滚动。

涉及文件：`src/main/longshot-window.ts`、`services/longshot.ts`、`longshot-worker.ts`、`longshot-processor.ts`、`longshot-scroller.ts/.ps1`、`src/main/index.ts`；`src/shared/longshot.ts`、`longshot-stitcher.ts`；`src/renderer/views/Longshot.tsx`、`longshot.css`、`views/Home.tsx`；相关测试、版本与交接文档。没有新增运行依赖。

验证完成：99 项测试、类型检查和构建通过；源码界面专项 smoke 退出0。专项测试让面板实际覆盖合成内容，经生产 desktopCapturer 采集后，逐像素与已知 Canvas 比较，确认面板未进入长图；检查实时缩略图增长、结果可见、原尺寸复制/保存、首屏输出提示和关闭清理。目录版完整 smoke（`--longshot-panel-overlay`）退出0，故意让面板覆盖自动目标的校验点，真实 Windows 滚轮、多步拼接、暂停恢复、焦点暂停、手动回退、取消和默认浏览器滚轮通过，普通截图/标注/贴图/演示 AI 回归通过。日志 `.runtime/longshot-ui-v0.6.1.log`、`.runtime/packaged-smoke-v0.6.1.log`；只保存验证后的合成图片与本应用界面，不保存用户页面、不读真实密钥、不覆盖剪贴板。运行目录 `release/v0.6.1/win-unpacked`，交付状态见 HANDOFF.md 最新记录。

## 第二阶段：实际页面的拼接兼容性

尚未完成，不将第一阶段的界面修复称为拼接算法已修好。

优先解决聊天网页等页面里的固定输入栏、固定标题/侧栏、重复元素、滚动容器与加载动画。现有保守拼接器会拒绝这些内容，因而可能只留下首屏；第一阶段会明确显示这一原因。

先用带固定头尾/侧栏的合成页面复现，再设计可调整的有效滚动区域和固定内容保留策略，保证新增行来自同一内容流。扩大容差或跳过不匹配部分不能代替正确拼接。完成时检查首尾、接缝和实际高度，并允许用户在不可靠时保留可靠部分或重选。

## 第三阶段：长图完成后的截图工具

尚未实现。将最终原尺寸图片作为可编辑文档，接入现有画笔、箭头、矩形、文字、撤销/清除、裁剪及贴图，再接 OCR、翻译和自定义 AI 询问。复用 AnnotationLayer/合成器、ClipboardService、TaskService 与 Provider；避免截取缩小预览来冒充完整图片。

需要单独处理长图滚动/缩放与像素坐标映射、大图内存和编辑导出。AI 仍需用户主动调用，不自动上传长图。录屏不在这三个阶段的本轮范围内。

参考：[Electron 窗口捕获排除](https://www.electronjs.org/docs/latest/api/browser-window#winsetcontentprotectionenable)、[Windows 显示亲和性](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setwindowdisplayaffinity)。
