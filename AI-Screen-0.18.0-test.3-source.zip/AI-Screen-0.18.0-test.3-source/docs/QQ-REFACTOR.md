# QQ 风格截图交互改造与后续升级

当前 v0.7.0 按用户最新要求优先手动长截图，已接入连续滚动采样、末尾补采、分块正文建议和明确确认；自动仅实验入口，不再作为交付门槛。111 项测试及手动集成通过，目录版最终状态见 HANDOFF。使用说明见 [MANUAL-LONGSHOT.md](MANUAL-LONGSHOT.md)，以下版本记录保留为历史。

最新开发版 v0.7.0-preview.1 已按用户的新 QQ 长截图参考重建 A 阶段框架：原生挖空选区、外围压暗、就近工具栏、独立缩略图，拼接拆为匹配与图像文档并增加全宽固定头尾基础支持。104 项测试及打包界面集成通过，新框架原生滚轮及复杂页面算法待继续；桌面仍为 v0.6.1。最新计划见 [LONGSHOT-V2-PLAN.md](LONGSHOT-V2-PLAN.md)，以下保留早期版本记录。

当前 v0.6.1 完成长截图体验修复的第一阶段：可见面板、实时拼接缩略图、明确的首屏提示和结果展示。99 项测试、界面专项与打包原生完整回归通过，见 [长截图说明](LONGSHOT.md) 和 [分阶段计划](LONGSHOT-IMPROVEMENTS.md)。固定栏拼接和长图编辑仍待后续阶段；录屏未接入。最终交付见 [HANDOFF](HANDOFF.md)；下文保留 v0.4.0 的基础重构记录。

2026-10-15，在 v0.3.4 基础上增量改造。仅借鉴窗口预选、选区编辑、就近工具栏等交互，自绘 SVG，没有采用 QQ 图标、素材或私有组件。

## 实现范围

1. 截图流程拆分：原 Capture.tsx 收敛为组合入口，ScreenshotController 管理流程，SelectionOverlay 管理显示及事件绑定，两个 Toolbar 管理各自工具。
2. Windows 原生窗口预选：持久隐藏 PowerShell worker 预热 Win32 API，截图前一次性获取前到后窗口列表。鼠标移动仅在 renderer 本地命中。单击选择窗口，拖动超过 4 DIP 转自由框选。顶层窗口跨显示器时按每屏裁剪，不跨屏拼图。
3. 保留选区移动和八方向缩放；双击选区复制，右键先清选区、再次右键退出，Esc 退出。文字标注输入框内 Esc 先取消文字编辑。
4. 白灰工具栏：复制 / 翻译 / AI 分析 / 询问 AI / 画笔 / 固定 / 更多。OCR 与原自定义动作收进更多；仍沿用原提示词及服务设置。
5. 工具栏按实测尺寸放到选区右下，间隔 12 DIP；下方不足翻到上方，最后夹在当前显示器范围内。展开输入、更多或标注面板会重新测量。满屏或极小屏幕无法在选区外放下时允许贴近选区内部。
6. 放大镜独立模块：从保留的原始位图取 15×15 像素局部块和 BGRA 颜色，显示全局 DIP 坐标、HEX、RGB；不使用 JPEG 预览取色。单个未完成请求串行采样，约 32 ms 间隔，隐藏后停止。仅当前 sender + sessionId 可读取当前屏幕取样。
7. 标注：画笔、箭头、矩形、文字、撤销、清除、颜色及线宽。坐标相对选区归一化，跟随移动/缩放；退出画笔后可继续调选区。SVG 预览与原图 PNG Canvas 合成复用同一几何函数。复制、AI、贴图均得到含标注图片。
8. PinWindowManager 管理独立无 parent 的置顶图片窗口，支持拖动、缩放、复位、关闭；遮罩关闭后保留，退出应用销毁。每张图片只在内存保留，最多 12 张。尚未完成创建的贴图会响应截图取消。
9. 翻译及 AI 结果仍复用 Result/TaskService，结果窗改为靠选区的置顶窗口；可继续追问、取消和重试。AI 识屏支持直接分析候选窗口或当前显示器，也能继续自由框选。
10. v0.4.0 为长截图、录屏建立模式、范围选择、能力描述、CaptureModeRegistry/CaptureModeExtension 及受限启动 IPC；当时没有注册后端。后续长截图通过该接口接入，录屏仍明确待接入，不伪造输出。

## v0.6.0 长截图入口和控制

选好范围后提供「自动滚动采集」默认入口和「手动滚动采集」，不是重复的普通复制按钮。自动入口需冻结候选 HWND，启动后关闭截图遮罩，由独立服务采样、匹配并逐步滚动原窗口。原始目标变化、焦点/鼠标变化或不可靠重叠会暂停，支持显式继续和转手动，保留已可靠拼接的内容。

v0.6.1 改为 440×380 DIP 可见采集面板，优先放在选区外，放不下则在支持捕获排除的系统上悬浮显示，不再藏到托盘。实时显示已拼接内容与新增高度；完成页显示停止原因和缩略预览，复制/保存使用原图，只有首屏则明确提示未拼出长图。连续无变化只是一项停止条件，不保证慢加载页面已到底。实现、研究来源和文件变更详见 LONGSHOT.md；不使用第三方截图实现或 QQ 私有 DLL。

## 状态机

`idle → window-hover → selecting → selected ⇄ annotating → ai-processing`

- START 建立截图会话；POINTER_DOWN 开始选择/移动/缩放；SELECT 完成有效选区。
- RESET 从 selected/annotating/selecting 返回 window-hover；处理中右键也可重选，会废弃当前输出、释放处理锁并忽略迟到错误。异步锁按独立 token 释放，旧请求不能解除新请求的锁。
- PROCESS 锁住截图操作；提交失败 FAIL 返回 selected，保留选区及标注。
- CLOSE 从任意活动状态回到 idle。AI 请求的 loading/done/error/cancelled 仍由独立 TaskService 管理。
- 模式 screenshot/longshot/record/ai-screen 与流程状态独立；输入框、菜单、当前标注工具也独立。
- 贴图是独立窗口生命周期，创建成功后结束当前截图，因此没有把 pinned 当作遮罩的持续状态。

## 复用关系

| 能力 | 复用实现 |
| --- | --- |
| 原始截图、DPI 裁剪 | CaptureService、toPixelRect |
| 选区拖动/缩放 | selection、adjustSelection、resizeHandles |
| 截图窗口预热/解码后显示 | WindowManager 的 prepare/captureReady/showCaptures |
| 图片/文字复制 | 原 Electron ClipboardItem PNG / writeText 路径整理为 ClipboardService |
| OCR | 原 TaskService + OCRProvider / WindowsOCRProvider |
| 翻译 | 原 TaskService translate + CompatibleProvider 提示词 |
| 分析、询问、自定义动作 | 原 TaskService、CompatibleProvider、custom-actions |
| 流式、取消、错误、追问 | 原 requestId + AbortController + Result |
| 设置与密钥 | 原 SettingsStore 和 Windows 加密，不迁移用户密钥 |

## 文件索引

新增主进程：`services/window-detector.ts/.ps1`、`services/clipboard.ts`、`services/capture-modes.ts`、`services/annotation-compositor.ts`、`pin-window.ts`、`capture-refactor-smoke.ts`。

新增 renderer：`capture/ScreenshotController.ts`、`SelectionOverlay.tsx`、`ModeToolbar.tsx`、`SelectionToolbar.tsx`、`MagnifierOverlay.tsx`、`AnnotationLayer.tsx`、`annotation.css`，以及 `views/Pin.tsx`、`pin.css`。

新增 shared：`screenshot-state.ts`、`window-candidates.ts`、`capture-modes.ts`、`annotations.ts`、`pin.ts`。新增测试 `screenshot-state.test.ts`、`window-candidates.test.ts`、`annotations.test.ts`。

修改：`main/index.ts`、`main/windows.ts`、`main/services/capture.ts`、`main/action-input.ts`、`main/smoke.ts`、`preload/index.ts`、`shared/contracts.ts`、`shared/geometry.ts`、`renderer/views/Capture.tsx`、`renderer/views/Home.tsx`、`renderer/main.tsx`、`renderer/components/CaptureIcon.tsx`、`renderer/capture-extra.css`、`tests/geometry.test.ts`、`tests/action-input.test.ts`、`scripts/build.mjs`、`package.json`、`package-lock.json` 及 README/架构/交接/路线图。

## 验证与限制

自动化结果与最终交付路径在 HANDOFF.md 最新记录中更新。测试使用隔离数据目录、合成图片及本机模拟服务，不读取真实 API Key、不调用真实 AI、不覆盖用户剪贴板、不保存桌面内容。

已知限制：窗口预选识别顶层窗口，不识别网页 DOM 或应用内部控件；worker 不可用时普通截图可自由框选/整屏预选，自动长截图因缺少冻结目标而拒绝启动，仍可选手动。受保护内容与 UAC 安全桌面受系统限制。负坐标/混合 DPI 的几何覆盖不代替真实 Windows 10/11 多屏验收。长截图目前只向下、单屏，不自动剔除固定栏；录屏尚未实现，真实模型质量待用户配置服务后验证。

建议下一轮优先完成自动长截图焦点、暂停恢复、浏览器/PDF/编辑器以及真实双屏/混合 DPI 验收，再改进固定栏、动态列表和延迟加载；录屏后端单独实现编码、停止/取消及输出生命周期。
