import {spawn} from 'node:child_process';
import {mkdir,createWriteStream} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
mkdir(path.join(root,'.runtime','recording-spike'),{recursive:true},error=>{
  if(error)throw error;
  const log=createWriteStream(path.join(root,'.runtime','recording-spike','latest.log'));
  const environment={...process.env};delete environment.ELECTRON_RUN_AS_NODE;
  const child=spawn(path.join(root,'node_modules','electron','dist','electron.exe'),['.','--recording-spike'],{cwd:root,env:environment,windowsHide:true,stdio:['ignore','pipe','pipe']});
  child.stdout.on('data',data=>{process.stdout.write(data);log.write(data);});child.stderr.on('data',data=>{process.stderr.write(data);log.write(data);});
  const timer=setTimeout(()=>{child.kill();},150000);
  child.on('error',error=>{clearTimeout(timer);console.error(error);log.end();process.exitCode=1;});
  child.on('exit',code=>{clearTimeout(timer);log.end();process.exitCode=code??1;});
});
