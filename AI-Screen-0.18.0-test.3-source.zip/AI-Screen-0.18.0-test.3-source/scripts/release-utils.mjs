import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { lstat, readFile, readdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const projectRoot = fileURLToPath(new URL('../', import.meta.url));
export const manifest = JSON.parse(await readFile(path.join(projectRoot, 'package.json'), 'utf8'));
if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(manifest.version)) throw new Error('Unsafe release version');
export const output = path.join(projectRoot, 'release', `v${manifest.version}`);
export const sourceName = `AI-Screen-${manifest.version}-source.zip`;
export const zipName = `AI-Screen-${manifest.version}-win-x64.zip`;
export const installerName = `AI-Screen-${manifest.version}-win-x64-setup.exe`;

export function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd: projectRoot, stdio: 'inherit', windowsHide: true, ...options });
    child.once('error', reject);
    child.once('exit', code => code === 0 ? resolve() : reject(new Error(`${path.basename(command)} exited with ${code}`)));
  });
}
export async function sha256(file) {
  const hash = createHash('sha256');
  for await (const chunk of createReadStream(file)) hash.update(chunk);
  return hash.digest('hex');
}
export async function inventory(root, relative = '') {
  const files = [];
  for (const name of (await readdir(path.join(root, relative))).sort()) {
    const file = relative ? `${relative}/${name}` : name;
    const full = path.join(root, file), info = await lstat(full);
    if (info.isSymbolicLink()) throw new Error(`Unexpected symlink: ${file}`);
    if (info.isDirectory()) files.push(...await inventory(root, file));
    else files.push({ file, sha256: await sha256(full) });
  }
  return files.sort((a, b) => a.file.localeCompare(b.file));
}
export async function removeStaging(directory) {
  const target = path.resolve(directory);
  if (path.dirname(target) !== output || !/^\.(source|verify)-\d+-\d+$/.test(path.basename(target))) {
    throw new Error('Refusing to remove a path outside this release staging area');
  }
  await rm(target, { recursive: true, force: true });
}
export function zipTool(mode, source, destination) {
  if (process.platform !== 'win32') throw new Error('Release packaging requires Windows.');
  const powershell = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  return run(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', path.join(projectRoot, 'scripts', 'zip-tool.ps1'), '-Mode', mode, '-Source', source, '-Destination', destination]);
}
