import { copyFile, lstat, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { manifest, output, projectRoot, removeStaging, sourceName, sha256, zipTool } from './release-utils.mjs';

const directories = ['src', 'scripts', 'tests', 'assets', 'docs', '.github'];
const rootFiles = ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'README.md', 'LICENSE', '.gitignore', '.gitattributes', '.nvmrc'];
const extension = /\.(?:ts|tsx|mjs|css|html|json|md|ps1|cs|svg|png|ico|yml|yaml|txt)$/i;
const forbidden = /^(?:settings\.json(?:\.tmp)?|\.env.*|.*\.(?:pem|key|pfx|p12|log|exe|dll|zip))$/i;
const secret = /(?:sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)/;

export async function sourceFiles() {
  const files = [...rootFiles];
  async function visit(directory) {
    for (const name of (await readdir(path.join(projectRoot, directory))).sort()) {
      const relative = `${directory}/${name}`;
      const info = await lstat(path.join(projectRoot, relative));
      if (info.isSymbolicLink()) throw new Error(`Source archive refuses symlink: ${relative}`);
      if (info.isDirectory()) await visit(relative);
      else if (info.isFile() && extension.test(name) && !forbidden.test(name)) files.push(relative);
      else throw new Error(`Unexpected source file; review before including: ${relative}`);
    }
  }
  for (const directory of directories) await visit(directory);
  for (const relative of files) {
    const info = await lstat(path.join(projectRoot, relative));
    if (!info.isFile() || info.isSymbolicLink() || info.size > 20 * 1024 * 1024) throw new Error(`Invalid source file: ${relative}`);
    if (!/\.(png|ico)$/i.test(relative) && secret.test(await readFile(path.join(projectRoot, relative), 'utf8'))) {
      throw new Error(`Possible credential in ${relative}; source archive stopped.`);
    }
  }
  return files.sort();
}

export async function createSourcePackage() {
  const files = await sourceFiles();
  await mkdir(output, { recursive: true });
  const staging = path.join(output, `.source-${Date.now()}-${process.pid}`);
  const sourceRoot = path.join(staging, `AI-Screen-${manifest.version}-source`);
  for (const relative of files) {
    const destination = path.join(sourceRoot, relative);
    await mkdir(path.dirname(destination), { recursive: true });
    await copyFile(path.join(projectRoot, relative), destination);
  }
  const archive = path.join(output, sourceName);
  await zipTool('Create', staging, archive);
  await writeFile(path.join(output, 'SOURCE-MANIFEST.json'), JSON.stringify({ version: manifest.version, files: await Promise.all(files.map(async file => ({ file, sha256: await sha256(path.join(sourceRoot, file)) }))) }, null, 2) + '\n');
  await removeStaging(staging);
  console.log(`Source package: ${archive} (${files.length} files; no runtime/cache/user profiles)`);
  return archive;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await createSourcePackage();
