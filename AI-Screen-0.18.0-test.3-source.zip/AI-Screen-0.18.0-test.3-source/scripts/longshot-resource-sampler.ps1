param([int]$RootProcessId,[string]$Output,[string]$StageFile,[string]$StopFile)
$ErrorActionPreference='Stop'
$writer=New-Object System.IO.StreamWriter($Output,$false,(New-Object System.Text.UTF8Encoding($false)))
$previous=@{}
$owned=@{}
$lastTime=[DateTime]::UtcNow
try {
  while(!(Test-Path -LiteralPath $StopFile)) {
    $all=@(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine)
    $ids=New-Object 'System.Collections.Generic.HashSet[int]'
    [void]$ids.Add($RootProcessId)
    foreach($item in $all){if($owned.ContainsKey([int]$item.ProcessId)-and $owned[[int]$item.ProcessId]-eq $item.CreationDate.ToUniversalTime().Ticks){[void]$ids.Add([int]$item.ProcessId)}}
    do {$added=$false;foreach($item in $all){if($ids.Contains([int]$item.ParentProcessId)-and !$ids.Contains([int]$item.ProcessId)){[void]$ids.Add([int]$item.ProcessId);$added=$true}}}while($added)
    $now=[DateTime]::UtcNow;$seconds=($now-$lastTime).TotalSeconds;$cpu=0.0;$workingSet=0L;$privateBytes=0L;$handles=0;$threads=0;$processes=@()
    foreach($item in $all) {
      $processId=[int]$item.ProcessId
      if(!$ids.Contains($processId)){continue}
      $owned[$processId]=$item.CreationDate.ToUniversalTime().Ticks
      try {
        $process=Get-Process -Id $processId -ErrorAction Stop
        $key=[string]$processId+':'+[string]$process.StartTime.Ticks
        $total=$process.TotalProcessorTime.TotalSeconds
        $delta=0.0;if($previous.ContainsKey($key)){$delta=[Math]::Max(0,$total-$previous[$key]);$cpu+=$delta}
        $previous[$key]=$total
        $workingSet+=$process.WorkingSet64;$privateBytes+=$process.PrivateMemorySize64;$handles+=$process.HandleCount;$threads+=$process.Threads.Count
        $role='other-descendant'
        if($processId -eq $RootProcessId){$role='main'}elseif($item.Name -eq 'native-capture.exe'){$role='native-capture'}elseif($item.CommandLine -match '--longshot-capture-helper'){$role='capture-helper'}elseif($item.CommandLine -match '--type=gpu-process'){$role='gpu'}elseif($item.CommandLine -match '--type=renderer'){$role='renderer'}elseif($item.CommandLine -match '--type=utility'){$role='utility'}elseif($item.Name -match 'powershell'){$role='native-worker'}
        $processes+=@{pid=$processId;parentPid=[int]$item.ParentProcessId;role=$role;name=$item.Name;workingSetBytes=$process.WorkingSet64;privateBytes=$process.PrivateMemorySize64;cpuSeconds=$total;cpuCorePercent=$(if($seconds -gt 0){100*$delta/$seconds}else{0})}
      }catch{}
    }
    $stage='startup';try{$stage=(Get-Content -LiteralPath $StageFile -Raw|ConvertFrom-Json).stage}catch{}
    $sample=@{at=$now.ToString('o');stage=$stage;rootPid=$RootProcessId;processCount=$processes.Count;workingSetSumBytes=$workingSet;privateBytesSum=$privateBytes;handles=$handles;threads=$threads;cpuCorePercent=$(if($seconds -gt 0){100*$cpu/$seconds}else{0});processes=$processes}
    $writer.WriteLine(($sample|ConvertTo-Json -Depth 5 -Compress));$writer.Flush();$lastTime=$now
    if(!($all|Where-Object ProcessId -eq $RootProcessId)){break}
    Start-Sleep -Milliseconds 1500
  }
} finally {$writer.Dispose()}
