// Node 22: node --experimental-strip-types scripts/recording-stress-review.mjs <report.json>
import{readFile,writeFile,stat}from'node:fs/promises';
import path from'node:path';
import assert from'node:assert/strict';
import{finalizeRecordingMP4}from'../src/main/services/recording/mp4-info.ts';
const reportPath=path.resolve(process.argv[2]),report=JSON.parse(await readFile(reportPath,'utf8'));assert.equal(report.failure,undefined);assert.equal(report.cases.filter(c=>c.name.startsWith('repeat-')).length,10);
const reviewed=[];
for(const c of report.cases){
  assert.equal(c.status,'passed');const video=c.container.tracks.find(t=>t.kind==='vide');assert.ok(video.framesPerSecond>=27,`${c.name}: ${video.framesPerSecond} fps`);assert.ok(c.stopMs<3000,`${c.name}: stop exceeded 3s`);assert.ok(c.stats.pendingPeakBytes<=32*1024*1024&&c.stats.pendingPeakChunks<=8);
  const first=c.decoded.samples[0],timing=c.decoded.samples.slice(1).map(sample=>{const expected=(sample.time-first.time)*10,actual=(sample.counter-first.counter+65536)%65536;return{time:sample.time,expectedCounterAdvance:expected,actualCounterAdvance:actual,errorSeconds:(actual-expected)/10};});
  for(const t of timing)assert.ok(Math.abs(t.errorSeconds)<1,`${c.name}: stale/frozen fixture at ${t.time}s (${t.errorSeconds}s offset)`);
  reviewed.push({name:c.name,framesPerSecond:video.framesPerSecond,stopMs:c.stopMs,timing});
}
const long=report.cases.find(c=>c.name==='1080p-30min');assert.ok(long&&long.durationMs>=1800000);const file=path.join(path.dirname(reportPath),'1080p-30min.mp4'),before=(await stat(file)).size,start=performance.now();await finalizeRecordingMP4(file);const headerFinalizationMs=performance.now()-start;assert.equal((await stat(file)).size,before);assert.ok(long.stopMs+headerFinalizationMs<3000);
const result={status:'passed',reviewed,headerFinalizationMs,longStopPlusHeaderMs:long.stopMs+headerFinalizationMs,longMemoryGrowthMiB:long.memoryGrowthMiB};await writeFile(path.join(path.dirname(reportPath),'review.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
