import {build} from 'esbuild';
import {spawn} from 'node:child_process';
const outdir='.runtime/longshot-preview-bench';
await build({entryPoints:['src/main/longshot-preview-bench.ts','src/main/services/longshot-worker.ts','src/main/services/longshot-preview-worker.ts'],entryNames:'[name]',outdir,outExtension:{'.js':'.cjs'},bundle:true,platform:'node',format:'cjs',target:'node22'});
const child=spawn(process.execPath,[`${outdir}/longshot-preview-bench.cjs`],{stdio:'inherit',windowsHide:true});child.on('exit',code=>{process.exitCode=code??1;});
