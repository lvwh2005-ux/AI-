param([Parameter(Mandatory=$true)][string]$Clip,[Parameter(Mandatory=$true)][string]$OutputPath)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$player = $null
try {
  $player = New-Object -ComObject WMPlayer.OCX
  $player.settings.autoStart = $false
  $player.settings.mute = $true
  $player.settings.enableErrorDialogs = $false
  $player.URL = (Resolve-Path -LiteralPath $Clip).Path
  $player.controls.play()
  $timer = [Diagnostics.Stopwatch]::StartNew()
  while ($timer.Elapsed.TotalSeconds -lt 15 -and $player.controls.currentPosition -lt 0.3) { [Windows.Forms.Application]::DoEvents(); if ($player.openState -eq 13 -and $player.playState -ne 3) { $player.controls.play() }; Start-Sleep -Milliseconds 50 }
  if ($player.error.errorCount -gt 0) { throw $player.error.item(0).errorDescription }
  $duration = $player.currentMedia.duration
  $played = $player.controls.currentPosition
  if ($duration -le 0 -or $played -lt 0.3) { throw "Windows Media Player did not advance: duration=$duration position=$played state=$($player.playState)" }
  $seek = [Math]::Min($duration * 0.5, 2)
  $player.controls.currentPosition = $seek
  $seekTimer = [Diagnostics.Stopwatch]::StartNew()
  while ($seekTimer.Elapsed.TotalMilliseconds -lt 500) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 50 }
  $afterSeek = $player.controls.currentPosition
  if ($afterSeek -lt ($seek - 0.1)) { throw 'Windows Media Player seek failed' }
  [pscustomobject]@{ player='Windows Media Player COM';status='passed';file=[IO.Path]::GetFileName($Clip);duration=$duration;playedPosition=$played;seekTarget=$seek;positionAfterSeek=$afterSeek;playState=$player.playState;errors=$player.error.errorCount } | ConvertTo-Json | Set-Content -LiteralPath $OutputPath -Encoding UTF8
  Get-Content -LiteralPath $OutputPath
} finally {
  if ($null -ne $player) { $player.controls.stop(); $player.close(); [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($player) }
}
