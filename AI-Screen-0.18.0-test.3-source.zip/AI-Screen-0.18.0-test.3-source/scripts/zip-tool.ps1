param(
    [Parameter(Mandatory = $true)][ValidateSet('Create', 'Extract')][string]$Mode,
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Destination
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourcePath = [IO.Path]::GetFullPath($Source)
$destinationPath = [IO.Path]::GetFullPath($Destination)
if (Test-Path -LiteralPath $destinationPath) { throw 'ZIP destination already exists; use a new path.' }
if ($Mode -eq 'Create') {
    # Enumerate .github/.gitignore too; Compress-Archive can omit hidden files.
    $root = $sourcePath.TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
    $archive = [IO.Compression.ZipFile]::Open($destinationPath, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($file in [IO.Directory]::EnumerateFiles($root, '*', [IO.SearchOption]::AllDirectories)) {
            $entry = $file.Substring($root.Length).Replace('\', '/')
            $null = [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file, $entry, [IO.Compression.CompressionLevel]::Optimal)
        }
    } finally { $archive.Dispose() }
} else {
    # The framework rejects entries escaping the extraction directory.
    [IO.Compression.ZipFile]::ExtractToDirectory($sourcePath, $destinationPath)
}
