$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$assetDirectory = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../assets'))
[System.IO.Directory]::CreateDirectory($assetDirectory) | Out-Null

# The editable SVG and Windows raster sizes share the same screen/sparkle mark.
$svg = @'
<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256" fill="none">
  <defs>
    <linearGradient id="blue" x1="12" y1="12" x2="244" y2="244" gradientUnits="userSpaceOnUse">
      <stop stop-color="#5884F5"/><stop offset="1" stop-color="#3265D8"/>
    </linearGradient>
  </defs>
  <rect x="12" y="12" width="232" height="232" rx="46" fill="url(#blue)"/>
  <rect x="12.6" y="12.6" width="230.8" height="230.8" rx="45.4" stroke="white" stroke-opacity=".18" stroke-width="1.2"/>
  <path d="M126 76H78C62 76 54 84 54 100V164C54 180 62 188 78 188H178C194 188 202 180 202 164V136" stroke="white" stroke-width="14" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M178 44C181 65 186 75 210 81C188 86 184 95 178 118C173 96 167 87 146 81C167 76 173 66 178 44Z" fill="#DBFFF8"/>
</svg>
'@
[System.IO.File]::WriteAllText((Join-Path $assetDirectory 'icon.svg'), $svg, [System.Text.UTF8Encoding]::new($false))

function New-AppIconPng([int]$Size) {
    $large = [System.Drawing.Bitmap]::new($Size * 4, $Size * 4, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [System.Drawing.Graphics]::FromImage($large)
    $graphics.Clear([System.Drawing.Color]::Transparent)
    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $graphics.ScaleTransform($Size * 4 / 256.0, $Size * 4 / 256.0)

    $tile = [System.Drawing.Drawing2D.GraphicsPath]::new()
    $tile.AddArc(12, 12, 92, 92, 180, 90)
    $tile.AddArc(152, 12, 92, 92, 270, 90)
    $tile.AddArc(152, 152, 92, 92, 0, 90)
    $tile.AddArc(12, 152, 92, 92, 90, 90)
    $tile.CloseFigure()
    $background = [System.Drawing.Drawing2D.LinearGradientBrush]::new(
        [System.Drawing.Rectangle]::new(12, 12, 232, 232),
        [System.Drawing.ColorTranslator]::FromHtml('#5884F5'),
        [System.Drawing.ColorTranslator]::FromHtml('#3265D8'), 45.0)
    $graphics.FillPath($background, $tile)
    $edge = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(46, 255, 255, 255), 1.2)
    $graphics.DrawPath($edge, $tile)

    # Stronger strokes at small sizes keep the tray/taskbar silhouette readable.
    $strokeWidth = if ($Size -le 24) { 18.0 } else { 14.0 }
    $outline = [System.Drawing.Pen]::new([System.Drawing.Color]::White, $strokeWidth)
    $outline.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $outline.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $outline.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round
    $screen = [System.Drawing.Drawing2D.GraphicsPath]::new()
    $screen.AddLine(126, 76, 78, 76)
    $screen.AddBezier(78, 76, 62, 76, 54, 84, 54, 100)
    $screen.AddLine(54, 100, 54, 164)
    $screen.AddBezier(54, 164, 54, 180, 62, 188, 78, 188)
    $screen.AddLine(78, 188, 178, 188)
    $screen.AddBezier(178, 188, 194, 188, 202, 180, 202, 164)
    $screen.AddLine(202, 164, 202, 136)
    $graphics.DrawPath($outline, $screen)

    $sparkle = [System.Drawing.Drawing2D.GraphicsPath]::new()
    $sparkle.AddBezier(178, 44, 181, 65, 186, 75, 210, 81)
    $sparkle.AddBezier(210, 81, 188, 86, 184, 95, 178, 118)
    $sparkle.AddBezier(178, 118, 173, 96, 167, 87, 146, 81)
    $sparkle.AddBezier(146, 81, 167, 76, 173, 66, 178, 44)
    $sparkle.CloseFigure()
    $sparkleFill = [System.Drawing.SolidBrush]::new([System.Drawing.ColorTranslator]::FromHtml('#DBFFF8'))
    $graphics.FillPath($sparkleFill, $sparkle)

    $bitmap = [System.Drawing.Bitmap]::new($Size, $Size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $scaled = [System.Drawing.Graphics]::FromImage($bitmap)
    $scaled.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $scaled.CompositingQuality = [System.Drawing.Drawing2D.CompositingQuality]::HighQuality
    $scaled.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $scaled.DrawImage($large, 0, 0, $Size, $Size)
    $stream = [System.IO.MemoryStream]::new()
    $bitmap.Save($stream, [System.Drawing.Imaging.ImageFormat]::Png)
    $bytes = $stream.ToArray()
    $stream.Dispose(); $scaled.Dispose(); $bitmap.Dispose()
    $sparkleFill.Dispose(); $sparkle.Dispose(); $screen.Dispose(); $outline.Dispose()
    $edge.Dispose(); $background.Dispose(); $tile.Dispose(); $graphics.Dispose(); $large.Dispose()
    return ,$bytes
}

$sizes = @(16, 20, 24, 32, 40, 48, 64, 128, 256)
$images = [System.Collections.Generic.List[byte[]]]::new()
foreach ($size in $sizes) { $images.Add((New-AppIconPng $size)) }
[System.IO.File]::WriteAllBytes((Join-Path $assetDirectory 'icon.png'), (New-AppIconPng 512))

$file = [System.IO.File]::Create((Join-Path $assetDirectory 'icon.ico'))
$writer = [System.IO.BinaryWriter]::new($file)
$writer.Write([uint16]0); $writer.Write([uint16]1); $writer.Write([uint16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {
    $dimension = if ($sizes[$i] -eq 256) { 0 } else { $sizes[$i] }
    $writer.Write([byte]$dimension); $writer.Write([byte]$dimension)
    $writer.Write([byte]0); $writer.Write([byte]0)
    $writer.Write([uint16]1); $writer.Write([uint16]32)
    $writer.Write([uint32]$images[$i].Length); $writer.Write([uint32]$offset)
    $offset += $images[$i].Length
}
foreach ($bytes in $images) { $writer.Write($bytes) }
$writer.Dispose()
Write-Output 'Generated assets/icon.svg, icon.png (512 px) and icon.ico (16-256 px).'
