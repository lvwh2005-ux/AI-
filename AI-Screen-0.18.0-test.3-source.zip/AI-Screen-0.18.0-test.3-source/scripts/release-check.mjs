import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { extractFile, listPackage } from '@electron/asar';
import { readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { manifest, output, projectRoot, sha256 } from './release-utils.mjs';

export async function checkPackage(root = path.join(output, 'win-unpacked')) {
  const archive = path.join(root, 'resources', 'app.asar');
  const packed = JSON.parse(extractFile(archive, 'package.json').toString('utf8'));
  assert.equal(packed.version, manifest.version, 'Packaged version differs from source');
  assert.equal(packed.main, 'dist/main/index.cjs');
  const entries = listPackage(archive).map(entry => entry.replaceAll('\\', '/'));
  for (const entry of entries) {
    assert.ok(!/(?:^|\/)(?:\.runtime|\.env[^/]*|settings\.json|\.git)(?:\/|$)/i.test(entry)
      && !/^\/(?:tests|src)(?:\/|$)/.test(entry), `Private or development path in package: ${entry}`);
    assert.ok(!(entry.startsWith('/dist/') && entry.endsWith('.map')), `Build source map in release: ${entry}`);
  }
  const checked = [];
  async function compare(directory) {
    for (const item of await readdir(path.join(projectRoot, directory), { withFileTypes: true })) {
      const file = `${directory}/${item.name}`;
      if (item.isDirectory()) await compare(file);
      else if (!file.endsWith('.map') && file !== 'dist/main/native-capture.exe' && file !== 'dist/THIRD-PARTY-NOTICES.txt') {
        const packedHash = createHash('sha256').update(extractFile(archive, path.normalize(file))).digest('hex');
        assert.equal(packedHash, await sha256(path.join(projectRoot, file)), `${file} differs from build`);
        checked.push(file);
      }
    }
  }
  await compare('dist');
  for (const [source, destination] of [
    ['dist/main/native-capture.exe', 'resources/native-capture.exe'],
    ['src/main/providers/windows-ocr.ps1', 'resources/windows-ocr.ps1'],
    ['src/main/services/window-detector.ps1', 'resources/window-detector.ps1'],
    ['src/main/services/longshot-scroller.ps1', 'resources/longshot-scroller.ps1'],
    ['docs/PORTABLE-README.txt', '使用说明.txt'], ['LICENSE', 'LICENSE.txt'],
    ['dist/THIRD-PARTY-NOTICES.txt', 'THIRD-PARTY-NOTICES.txt'],
  ]) assert.equal(await sha256(path.join(root, destination)), await sha256(path.join(projectRoot, source)), `${destination} missing or differs`);
  for (const required of ['AI Screen.exe', 'LICENSE.electron.txt', 'LICENSES.chromium.html', 'icudtl.dat', 'resources.pak']) {
    assert.ok((await stat(path.join(root, required))).size > 0, `Missing runtime file: ${required}`);
  }
  const executable = await readFile(path.join(root, 'AI Screen.exe'));
  assert.equal(executable.toString('ascii', 0, 2), 'MZ');
  const pe = executable.readUInt32LE(0x3c);
  assert.equal(executable.readUInt16LE(pe + 4), 0x8664, 'Release must be Windows x64');
  return { version: packed.version, status: 'passed', checkedBuildFiles: checked.length, nativeCapture: true, architecture: 'x64' };
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  console.log(JSON.stringify(await checkPackage(process.argv[2] ? path.resolve(process.argv[2]) : undefined), null, 2));
}
