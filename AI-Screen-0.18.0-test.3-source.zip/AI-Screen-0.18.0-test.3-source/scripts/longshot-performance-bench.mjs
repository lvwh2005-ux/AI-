import {build} from 'esbuild';
import {spawn} from 'node:child_process';
const output=process.argv[2];if(!output)throw new Error('Specify output JSON path');
const target='.runtime/longshot-performance-bench.cjs';
await build({entryPoints:['src/main/longshot-performance-bench.ts'],outfile:target,bundle:true,platform:'node',format:'cjs',target:'node22'});
const child=spawn(process.execPath,[target,output],{stdio:'inherit',windowsHide:true});child.on('exit',code=>{process.exitCode=code??1;});
