import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';

export async function writeThirdPartyNotices() {
  const lock = JSON.parse(await readFile('package-lock.json', 'utf8'));
  const sections = [
    'AI Screen — third-party notices',
    'The application is MIT licensed. Dependencies retain their own licenses.',
    'Electron and Chromium notices are distributed separately as LICENSE.electron.txt and LICENSES.chromium.html.',
  ];
  for (const [directory, entry] of Object.entries(lock.packages)) {
    if (!directory || entry.dev || entry.link) continue;
    const metadata = JSON.parse(await readFile(path.join(directory, 'package.json'), 'utf8'));
    const files = (await readdir(directory)).filter(name => /^(licen[cs]e|copying|notice)(\.|$)/i.test(name)).sort();
    if (!files.some(name => /^(licen[cs]e|copying)(\.|$)/i.test(name))) {
      throw new Error(`Missing license text for ${metadata.name}; review before distribution.`);
    }
    sections.push(`\n${'='.repeat(72)}\n${metadata.name}@${metadata.version}\nLicense: ${entry.license ?? metadata.license ?? 'see text below'}`);
    for (const file of files) sections.push(`\n--- ${file} ---\n${await readFile(path.join(directory, file), 'utf8')}`);
  }
  await writeFile('dist/THIRD-PARTY-NOTICES.txt', sections.join('\n') + '\n', 'utf8');
}
