import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { lstat, mkdir, readFile, readdir, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { createSourcePackage, sourceFiles } from './source-package.mjs';
import { checkPackage } from './release-check.mjs';
import { installerName, inventory, manifest, output, projectRoot, removeStaging, run, sha256, sourceName, zipName, zipTool } from './release-utils.mjs';

if (process.platform !== 'win32' || process.arch !== 'x64') throw new Error('Build this release on Windows x64.');
const zipOnly = process.argv.includes('--zip-only');
const verifyOnly = process.argv.includes('--verify-only');
const unexpected = process.argv.slice(2).filter(arg => !['--zip-only', '--verify-only'].includes(arg));
if (unexpected.length) throw new Error(`Unknown arguments: ${unexpected.join(' ')}`);
await mkdir(output, { recursive: true });
for (const file of verifyOnly ? [] : [zipName, sourceName, installerName]) {
  try { await stat(path.join(output, file)); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
  throw new Error(`${file} already exists. Bump the version before building another release.`);
}
const require = createRequire(import.meta.url);
if (!verifyOnly) await run(process.execPath, [require.resolve('electron-builder/cli.js'), '--win', ...(zipOnly ? ['zip'] : ['nsis', 'zip']), '--x64', '--publish', 'never'], {
  env: { ...process.env, CSC_IDENTITY_AUTO_DISCOVERY: 'false' },
});
const packageReport = await checkPackage();
try { await stat(path.join(output, sourceName)); }
catch (error) { if (error.code === 'ENOENT') await createSourcePackage(); else throw error; }

// Check the actual sent archives after extraction, including dotfiles and byte hashes.
const extracted = path.join(output, `.verify-${Date.now()}-${process.pid}`);
await zipTool('Extract', path.join(output, zipName), path.join(extracted, 'application'));
await checkPackage(path.join(extracted, 'application'));
const runtimeFiles = await inventory(path.join(output, 'win-unpacked'));
const archiveFiles = await inventory(path.join(extracted, 'application'));
const expectedFiles = new Map(runtimeFiles.map(item => [item.file, item.sha256]));
const actualFilesByName = new Map(archiveFiles.map(item => [item.file, item.sha256]));
const differences = [];
for (const item of archiveFiles) {
  if (expectedFiles.get(item.file) !== item.sha256) differences.push(item.file);
}
for (const item of runtimeFiles) {
  // NSIS adds this installation helper after the ZIP target is produced.
  // It is not needed to run the ZIP; if present, its hash is still checked above.
  if (item.file !== 'resources/elevate.exe' && !actualFilesByName.has(item.file)) differences.push(item.file);
}
assert.equal(differences.length, 0, `ZIP runtime files differ: ${differences.join(', ')}`);
await zipTool('Extract', path.join(output, sourceName), path.join(extracted, 'source'));
const sourceRoot = path.join(extracted, 'source', `AI-Screen-${manifest.version}-source`);
const sourceManifest = JSON.parse(await readFile(path.join(output, 'SOURCE-MANIFEST.json'), 'utf8'));
assert.equal(sourceManifest.version, manifest.version);
assert.deepEqual(sourceManifest.files.map(item => item.file).sort(), await sourceFiles(), 'Source file list changed since archiving');
const actualFiles = [];
async function inspectSource(directory, relative = '') {
  for (const name of await readdir(directory)) {
    const full = path.join(directory, name), file = relative ? `${relative}/${name}` : name;
    const info = await lstat(full);
    assert.ok(!info.isSymbolicLink());
    if (info.isDirectory()) await inspectSource(full, file);
    else actualFiles.push(file);
  }
}
await inspectSource(sourceRoot);
assert.deepEqual(actualFiles.sort(), sourceManifest.files.map(item => item.file).sort(), 'Unexpected or missing source archive entries');
for (const item of sourceManifest.files) {
  assert.equal(await sha256(path.join(sourceRoot, item.file)), item.sha256, `Source archive damaged: ${item.file}`);
  assert.equal(await sha256(path.join(projectRoot, item.file)), item.sha256, `Source archive is stale: ${item.file}`);
}

const artifacts = [zipName, ...(!zipOnly ? [installerName] : []), sourceName];
const checksums = await Promise.all(artifacts.map(async file => `${await sha256(path.join(output, file))}  ${file}`));
await writeFile(path.join(output, 'SHA256SUMS.txt'), checksums.join('\n') + '\n');
const report = { ...packageReport, sourceFiles: sourceManifest.files.length, runtimeFiles: archiveFiles.length, archivesExtractedAndVerified: true, installerBuilt: !zipOnly, installerExecutionTested: false, artifacts };
await writeFile(path.join(output, 'RELEASE-CHECK.json'), JSON.stringify(report, null, 2) + '\n');
await writeFile(path.join(output, 'RELEASE-NOTES.md'), `# AI Screen v${manifest.version}\n\nWindows 10/11 x64 测试版，MIT 授权。\n\n- 安装版：\`${installerName}\`（${zipOnly ? '本轮未生成' : '已生成'}）。\n- 解压版：\`${zipName}\`，完整解压后运行 AI Screen.exe，无需 Node.js。\n- 开发者源码：\`${sourceName}\`，需要 Node.js 22.12+ 和 npm。GitHub 自动生成的 Source code 也是源码。\n- 首次为演示模式；实际 AI 需要自行设置服务地址、视觉模型和 API Key。\n- 未进行代码签名，可能有 SmartScreen 提示；Windows 11、多屏/混合 DPI、真实音频设备仍需实机验证。\n- 目录版与两种 ZIP 的内容和 SHA-256 已核对；安装程序${zipOnly ? '未生成' : '尚未执行安装/卸载测试'}。\n\n请同时保留 SHA256SUMS.txt 和包内使用说明。\n`);
console.log(JSON.stringify(report, null, 2));
console.log(`Release files: ${output}`);
await removeStaging(extracted);
