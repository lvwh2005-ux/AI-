import { build } from 'esbuild';
import { readdir } from 'node:fs/promises';
import { spawn } from 'node:child_process';

const files = (await readdir('tests')).filter((file) => file.endsWith('.test.ts'));
await build({ entryPoints: [...files.map((file) => `tests/${file}`),'src/main/services/longshot-worker.ts','src/main/services/longshot-preview-worker.ts'], entryNames:'[name]',outdir: '.runtime/tests', outExtension: { '.js': '.cjs' }, bundle: true, external: ['electron'], platform: 'node', format: 'cjs', target: 'node22' });
const child = spawn(process.execPath, ['--test', ...files.map((file) => `.runtime/tests/${file.replace(/\.ts$/, '.cjs')}`)], { stdio: 'inherit', windowsHide: true });
child.on('exit', (code) => process.exit(code ?? 1));
