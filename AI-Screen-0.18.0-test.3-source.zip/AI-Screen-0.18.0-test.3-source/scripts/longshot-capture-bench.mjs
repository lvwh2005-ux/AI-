import {build} from 'esbuild';
import {copyFile,mkdir} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import path from 'node:path';
import electron from 'electron';
import {buildNativeCapture} from './build-native-capture.mjs';
const outdir='.runtime/longshot-capture-bench/bin';
await build({entryPoints:{bench:'src/main/longshot-capture-bench.ts','capture-bootstrap':'src/main/bootstrap.ts','longshot-worker':'src/main/services/longshot-worker.ts','longshot-preview-worker':'src/main/services/longshot-preview-worker.ts'},
  outdir,outExtension:{'.js':'.cjs'},bundle:true,platform:'node',format:'cjs',target:'node22',external:['electron']});
await copyFile('src/main/services/window-detector.ps1',path.join(outdir,'window-detector.ps1'));
await buildNativeCapture(outdir);
if(process.argv.includes('--fallback-only')){
  await mkdir(path.join(outdir,'fallback'),{recursive:true});
  await copyFile(path.join(outdir,'capture-bootstrap.cjs'),path.join(outdir,'fallback/capture-bootstrap.cjs'));
}
const environment={...process.env};delete environment.ELECTRON_RUN_AS_NODE;
const child=spawn(electron,[path.resolve(outdir,'bench.cjs'),...process.argv.slice(2)],{env:environment,stdio:'inherit',windowsHide:true});child.on('exit',code=>{process.exitCode=code??1;});
