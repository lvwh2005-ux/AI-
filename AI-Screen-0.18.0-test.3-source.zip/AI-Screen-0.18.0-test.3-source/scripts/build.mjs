import { build } from 'esbuild';
import { build as buildRenderer } from 'vite';
import { copyFile } from 'node:fs/promises';
import {buildNativeCapture} from './build-native-capture.mjs';
import {writeThirdPartyNotices} from './third-party-notices.mjs';

export async function buildMain() {
  await build({
    entryPoints: { index: 'src/main/bootstrap.ts', preload: 'src/preload/index.ts', 'recording-preload': 'src/preload/recording.ts', 'longshot-worker': 'src/main/services/longshot-worker.ts', 'longshot-preview-worker':'src/main/services/longshot-preview-worker.ts' },
    outdir: 'dist/main', outExtension: { '.js': '.cjs' },
    bundle: true, platform: 'node', format: 'cjs', target: 'node22',
    external: ['electron'], sourcemap: true,
  });
  await copyFile('src/main/providers/windows-ocr.ps1', 'dist/main/windows-ocr.ps1');
  await copyFile('src/main/services/window-detector.ps1', 'dist/main/window-detector.ps1');
  await copyFile('src/main/services/longshot-scroller.ps1', 'dist/main/longshot-scroller.ps1');
  await copyFile('assets/icon.ico', 'dist/main/icon.ico');
  await buildNativeCapture();
  await build({ entryPoints: ['src/renderer/recording/engine.ts'], outfile: 'dist/recording/engine.js', bundle: true, platform: 'browser', target: 'chrome142' });
  await copyFile('src/renderer/recording/media-host.html','dist/recording/media-host.html');
  await writeThirdPartyNotices();
}
await buildMain();
if (process.argv[1]?.endsWith('build.mjs')) await buildRenderer();
