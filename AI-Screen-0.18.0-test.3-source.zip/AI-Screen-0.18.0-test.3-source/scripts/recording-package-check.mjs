import {extractFile,listPackage} from '@electron/asar';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=path.resolve(process.argv[2]??'release/v0.17.0-test.1/win-unpacked'),archive=path.join(root,'resources','app.asar'),hash=data=>createHash('sha256').update(data).digest('hex');
const packed=JSON.parse(extractFile(archive,'package.json').toString('utf8')),source=JSON.parse(await readFile('package.json','utf8'));assert.equal(packed.version,source.version);assert.equal(packed.main,'dist/main/index.cjs');
const entries=listPackage(archive).map(e=>e.replaceAll('\\','/')),extract=file=>extractFile(archive,path.normalize(file));for(const forbidden of['/.runtime','/.env','/settings.json'])assert.ok(!entries.some(e=>e===forbidden||e.startsWith(forbidden+'/')));
const checked=[];for(const file of['dist/main/index.cjs','dist/main/preload.cjs','dist/main/recording-preload.cjs','dist/recording/engine.js','dist/recording/media-host.html','dist/renderer/index.html']){const expected=hash(await readFile(file)),actual=hash(extract(file));assert.equal(actual,expected,`${file} differs from final build`);checked.push({file,sha256:actual});}
const html=extract('dist/renderer/index.html').toString('utf8');for(const asset of[...html.matchAll(/(?:src|href)="\.\/assets\/([^"]+)"/g)].map(m=>m[1])){const file=`dist/renderer/assets/${asset}`;assert.equal(hash(extract(file)),hash(await readFile(file)));checked.push({file,sha256:hash(extract(file))});}
assert.equal(hash(await readFile(path.join(root,'resources','native-capture.exe'))),hash(await readFile('dist/main/native-capture.exe')));
const report={status:'passed',version:packed.version,executable:path.join(root,'AI Screen.exe'),archiveSha256:hash(await readFile(archive)),checked,includesNativeCapture:true,privateRootFilesAbsent:true};await mkdir('.runtime/recording-package',{recursive:true});await writeFile(`.runtime/recording-package/${packed.version}.json`,JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
