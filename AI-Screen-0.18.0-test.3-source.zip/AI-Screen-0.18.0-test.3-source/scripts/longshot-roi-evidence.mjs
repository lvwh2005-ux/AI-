import {build} from 'esbuild';
import {spawn} from 'node:child_process';
import electron from 'electron';
import path from 'node:path';
import {copyFile} from 'node:fs/promises';
const outdir='.runtime/longshot-roi-stage1/bin';
await build({entryPoints:{evidence:'src/main/longshot-roi-evidence.ts','longshot-worker':'src/main/services/longshot-worker.ts','longshot-preview-worker':'src/main/services/longshot-preview-worker.ts'},outdir,
  outExtension:{'.js':'.cjs'},bundle:true,external:['electron'],platform:'node',format:'cjs',target:'node22'});
await copyFile('src/main/services/window-detector.ps1',path.join(outdir,'window-detector.ps1'));
const environment={...process.env};delete environment.ELECTRON_RUN_AS_NODE;
const child=spawn(electron,[path.resolve(outdir,'evidence.cjs'),...process.argv.slice(2)],{env:environment,stdio:'inherit',windowsHide:true});
child.on('error',error=>{console.error(error);process.exitCode=1;});
child.on('exit',code=>{process.exitCode=code??1;});
