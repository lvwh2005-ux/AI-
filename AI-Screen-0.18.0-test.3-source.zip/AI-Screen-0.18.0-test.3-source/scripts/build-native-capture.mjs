import {spawn} from 'node:child_process';
import {mkdir} from 'node:fs/promises';
import path from 'node:path';

export async function buildNativeCapture(outdir='dist/main'){
  if(process.platform!=='win32')return;
  await mkdir(outdir,{recursive:true});
  const compiler=path.join(process.env.SystemRoot??'C:\\Windows','Microsoft.NET/Framework64/v4.0.30319/csc.exe');
  const source=path.resolve('src/main/services/native-capture.cs');
  const output=path.resolve(outdir,'native-capture.exe');
  const child=spawn(compiler,['/nologo','/optimize+','/target:exe','/platform:x64','/out:'+output,source],{stdio:'inherit',windowsHide:true});
  await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',code=>code===0?resolve():reject(new Error('Native capture compilation failed: '+code)));});
}
if(process.argv[1]?.endsWith('build-native-capture.mjs'))await buildNativeCapture(process.argv[2]);
