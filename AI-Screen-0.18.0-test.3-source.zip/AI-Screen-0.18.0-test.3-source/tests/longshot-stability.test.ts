import { it } from 'node:test';
import assert from 'node:assert/strict';
import { stableLongshotFrame } from '../src/shared/longshot-stability';
it('waits for a settled region and rejects motion, changing dimensions and empty frames', () => {
  const frame = { width: 120, height: 80, data: new Uint8Array(120 * 80 * 4).fill(255) };
  assert.equal(stableLongshotFrame(frame, { ...frame, data: frame.data.slice() }), true);
  const changed = frame.data.slice(); changed.fill(30, 120 * 10 * 4, 120 * 20 * 4);
  assert.equal(stableLongshotFrame(frame, { ...frame, data: changed }), false);
  assert.equal(stableLongshotFrame(frame, { ...frame, width: 121 }), false);
  assert.equal(stableLongshotFrame({ width: 0, height: 0, data: new Uint8Array() }, { width: 0, height: 0, data: new Uint8Array() }), false);
});
