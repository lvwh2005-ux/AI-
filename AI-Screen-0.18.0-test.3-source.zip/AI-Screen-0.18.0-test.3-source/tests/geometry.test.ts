import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { adjustSelection, selection, toolbarPosition, toPixelRect } from '../src/shared/geometry';

describe('capture geometry', () => {
  it('normalizes reverse dragging', () => {
    assert.deepEqual(selection({ x: 80, y: 90 }, { x: 10, y: 20 }), { x: 10, y: 20, width: 70, height: 70 });
  });
  it('maps fractional DPI coordinates outward so text edges are retained', () => {
    assert.deepEqual(toPixelRect({ x: 11, y: 9, width: 100, height: 51 }, { width: 800, height: 600 }, { width: 1000, height: 750 }), { x: 13, y: 11, width: 126, height: 64 });
  });
  it('clamps a selection at the bitmap boundary', () => {
    assert.deepEqual(toPixelRect({ x: 790, y: 590, width: 30, height: 30 }, { width: 800, height: 600 }, { width: 1600, height: 1200 }), { x: 1580, y: 1180, width: 20, height: 20 });
  });
  for (const x of [NaN, Infinity, -1, 800]) it(`rejects invalid/outside x=${x}`, () => {
    assert.throws(() => toPixelRect({ x, y: 0, width: 20, height: 20 }, { width: 800, height: 600 }, { width: 800, height: 600 }));
  });
  it('places a toolbar below a top-edge selection and keeps it on-screen', () => {
    assert.deepEqual(toolbarPosition({ x: 700, y: 4, width: 90, height: 30 }, { width: 800, height: 600 }), { left: 290, top: 46 });
  });
  it('aligns the toolbar to the selection right edge and flips above at the bottom', () => {
    assert.deepEqual(toolbarPosition({ x: 200, y: 500, width: 400, height: 90 }, { width: 800, height: 600 }, { width: 300, height: 44 }), { left: 300, top: 444 });
  });
  it('clamps expanded question and annotation panels inside the current monitor', () => {
    const value = toolbarPosition({ x: 0, y: 0, width: 30, height: 600 }, { width: 800, height: 600 }, { width: 540, height: 180 });
    assert.ok(value.left >= 8 && value.top >= 8 && value.left + 540 <= 792 && value.top + 180 <= 592);
  });
});
it('moves a selection and clamps it to all screen edges', () => {
  const rect = { x: 20, y: 30, width: 100, height: 80 };
  assert.deepEqual(adjustSelection(rect, 'move', { x: -200, y: 999 }, { width: 800, height: 600 }), { x: 0, y: 520, width: 100, height: 80 });
});
it('resizes corners without crossing the opposite edge or screen boundary', () => {
  const rect = { x: 20, y: 30, width: 100, height: 80 };
  assert.deepEqual(adjustSelection(rect, 'nw', { x: 999, y: 999 }, { width: 800, height: 600 }), { x: 116, y: 106, width: 4, height: 4 });
  assert.deepEqual(adjustSelection(rect, 'se', { x: 999, y: 999 }, { width: 800, height: 600 }), { x: 20, y: 30, width: 780, height: 570 });
});
