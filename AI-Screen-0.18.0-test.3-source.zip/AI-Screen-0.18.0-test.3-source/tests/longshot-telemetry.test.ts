import assert from 'node:assert/strict';
import {test} from 'node:test';
import {CaptureTelemetry} from '../src/shared/scroll-capture/telemetry';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import type {BitmapFrame, StitchResult} from '../src/shared/scroll-capture/types';

const result=(kind:StitchResult['kind']):StitchResult=>({kind,width:128,height:320,appendedRows:0});
test('diagnostics distinguish read, processing, append, duplicate, rejection, review and discarded frames',()=>{
  const meter=new CaptureTelemetry();
  for(const time of [100,300,500,700,900,1100])meter.captured(time);
  meter.result(result('initial'));meter.result(result('appended'));meter.result(result('duplicate'));
  meter.result({...result('rejected'),reasonCode:'no-overlap'});meter.result(result('review'));meter.discard();meter.error('capture-error');
  const data=meter.snapshot();
  assert.deepEqual([data.captured,data.processed,data.appended,data.duplicates,data.rejected,data.reviews,data.discarded,data.readErrors],[6,5,1,1,1,1,1,1]);
  assert.equal(data.captureFps,5);assert.equal(data.lastIssue,'capture-error');
  meter.captured(1300);meter.result(result('appended'));assert.equal(meter.snapshot().lastIssue,undefined);
});
test('timings are independent, finite and snapshots cannot mutate the session',()=>{
  const meter=new CaptureTelemetry();meter.measure('capture',10);meter.measure('capture',30);meter.measure('match',7);meter.measure('preview',5);
  meter.measure('capture',NaN);meter.measure('match',-1);meter.phase('paused');
  const data=meter.snapshot();assert.deepEqual(data.capture,{last:30,average:20,max:30,count:2});assert.equal(data.match.average,7);assert.equal(data.preview.max,5);
  const sequence=data.sequence;data.capture.average=999;data.activity='error';
  assert.equal(meter.snapshot().capture.average,20);assert.equal(meter.snapshot().activity,'paused');assert.equal(meter.snapshot().sequence,sequence);
});
test('capture rate uses a bounded recent sample window and a pause resets it',()=>{
  const meter=new CaptureTelemetry();for(let i=0;i<40;i++)meter.captured(i<8?i*1000:8000+(i-8)*100);
  assert.equal(meter.snapshot().captureFps,10);meter.resetRate();assert.equal(meter.snapshot().captureFps,undefined);
  meter.captured(100_000);assert.equal(meter.snapshot().captureFps,undefined);meter.captured(100_500);assert.equal(meter.snapshot().captureFps,2);
  assert.equal(meter.snapshot().captured,42);
});
test('effective progress counts only unique committed rows across duplicate/revisit/rejected frames',()=>{
  const meter=new CaptureTelemetry();meter.result(result('initial'),false,100);
  meter.result({...result('appended'),appendedRows:120},false,1100);
  meter.result({...result('duplicate'),revisited:true},false,2100);
  meter.result(result('rejected'),false,3100);
  assert.equal(meter.snapshot().effectiveNewRowsPerSecond,40);
  meter.result({...result('appended'),appendedRows:80,addedTop:80},false,4100);
  assert.equal(meter.snapshot().effectiveNewRowsPerSecond,50);
  meter.measure('queueWait',7);meter.measure('endToEnd',280);
  const snapshot=meter.snapshot();snapshot.queueWait.last=999;assert.equal(meter.snapshot().queueWait.last,7);
  meter.resetRate();assert.equal(meter.snapshot().effectiveNewRowsPerSecond,undefined);
});
test('confirming a reviewed body clears its issue without double-counting captured/processed frames',()=>{
  const meter=new CaptureTelemetry();meter.captured(100);meter.result(result('initial'));meter.captured(300);meter.result({...result('review'),reasonCode:'body-review'});
  meter.resolveReview(result('appended'));const value=meter.snapshot();
  assert.equal(value.captured,2);assert.equal(value.processed,2);assert.equal(value.appended,1);assert.equal(value.lastIssue,undefined);assert.equal(value.lastResult,'appended');
});

test('local verification and reconnect diagnostics clear a stale issue without treating recovery as new capture',()=>{
  const meter=new CaptureTelemetry();
  meter.result({...result('rejected'),reasonCode:'no-overlap',consecutiveRejections:1});
  meter.result({...result('rejected'),reasonCode:'overlap-rejected',consecutiveRejections:2});
  meter.result({...result('duplicate'),recoveredAfter:2,consecutiveRejections:0,verification:'localized',ignoredPixels:24});
  const value=meter.snapshot();assert.equal(value.recoveries,1);assert.equal(value.localizedFrames,1);assert.equal(value.rejectionStreak,0);
  assert.equal(value.lastIssue,undefined);assert.equal(value.processed,3);assert.equal(value.captured,0);assert.equal(value.lastIgnoredPixels,24);
});
function page(offset:number,height=320):BitmapFrame{
  const width=128,data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}
test('real matcher reports upward growth and size changes without mutating accepted pixels on rejection',()=>{
  const engine=new ScrollCaptureEngine();engine.push(page(200));const original=engine.bitmap();
  const up=engine.push(page(100));assert.equal(up.addedTop,100);assert.equal(up.viewportY,-100);
  const grown=engine.bitmap();assert.deepEqual(grown.data.subarray(100*128*4),original.data);
  assert.equal(engine.push(page(300,319)).reasonCode,'size-changed');assert.deepEqual(engine.bitmap(),grown);
  assert.equal(engine.push(page(300)).kind,'appended');
});
test('capacity and invalid frames are reported separately from overlap rejection',()=>{
  const engine=new ScrollCaptureEngine({maxHeight:320});engine.push(page(0));
  assert.equal(engine.push(page(100)).reasonCode,'capacity');
  assert.equal(engine.push({width:128,height:320,data:new Uint8Array(1)}).reasonCode,'invalid-frame');
  const full=new ScrollCaptureEngine();full.push(page(0));assert.ok(['no-overlap','overlap-rejected'].includes(full.push(page(400)).reasonCode!));
});
