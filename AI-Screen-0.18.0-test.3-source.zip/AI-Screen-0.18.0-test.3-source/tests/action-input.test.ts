import { it } from 'node:test';
import assert from 'node:assert/strict';
import { parseActionInput } from '../src/main/action-input';

const rect = { x: 0, y: 0, width: 8, height: 8 };
it('requires a selection for capture actions and rejects previous-session followups', () => {
  assert.equal(parseActionInput({ action: 'copy-image', rect }, 'capture').action, 'copy-image');
  assert.throws(() => parseActionInput({ action: 'ask', question: 'old session' }, 'capture'), /框选/);
});
it('limits result actions to the current session without capture rectangles or image copying', () => {
  assert.equal(parseActionInput({ action: 'ask', question: ' followup ' }, 'result').question, 'followup');
  assert.throws(() => parseActionInput({ action: 'analyze', rect }, 'result'), /无权限/);
  assert.throws(() => parseActionInput({ action: 'copy-image' }, 'result'), /无权限/);
  assert.throws(() => parseActionInput({ action: 'analyze' }, 'home'), /无权限/);
  assert.throws(() => parseActionInput({ action: 'ask', question: 'followup', annotations: [] }, 'result'), /无权限/);
});
it('rejects empty questions and invalid capture selections before side effects', () => {
  assert.throws(() => parseActionInput({ action: 'ask', question: '   ', rect }, 'capture'), /问题/);
  assert.throws(() => parseActionInput({ action: 'analyze', rect: { ...rect, width: Infinity } }, 'capture'));
});
