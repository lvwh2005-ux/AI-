import assert from 'node:assert/strict';
import {test} from 'node:test';
import {CapturePipeline, type PipelineStats} from '../src/main/services/capture-pipeline';
import {PreviewPump} from '../src/main/services/preview-pump';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';

const gate=()=>{let resolve!:()=>void;const promise=new Promise<void>(done=>{resolve=done;});return{promise,resolve};};
const tick=()=>new Promise<void>(resolve=>setImmediate(resolve));
const sleep=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms));
function page(offset:number,height=320):BitmapFrame {
  const width=128,data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}

test('bounded prefetch reads ahead of a slow matcher, preserves intermediate overlaps and exact output',async()=>{
  const frameBytes=128*320*4, first=gate(),engine=new ScrollCaptureEngine(),reads:number[]=[],processed:number[]=[],stats:PipelineStats[]=[];
  const queue=new CapturePipeline({maxFrames:3,maxBytes:frameBytes*3,maxFrameBytes:frameBytes,
    bytes:(frame:BitmapFrame)=>frame.data.byteLength,
    consume:async(frame)=>{if(!processed.length)await first.promise;processed.push(frame.data[0]);assert.ok(['initial','appended'].includes(engine.push(frame).kind));},
    changed:value=>stats.push(value),failed:assert.fail});
  const read=(offset:number)=>queue.capture(frameBytes,async()=>{reads.push(offset);return page(offset);});
  await read(0);await read(96);await read(192);
  const fourth=read(288);await tick();
  assert.deepEqual(reads,[0,96,192],'capture continues while first match is blocked; fourth read waits for capacity');
  assert.equal(queue.stats.bufferedFrames,3);assert.equal(queue.stats.waitingForSpace,true);
  first.resolve();await fourth;queue.seal();await queue.idle();
  assert.deepEqual(engine.bitmap(),page(0,608),'all intermediate frames needed for overlap survive');
  assert.equal(processed.length,4);assert.equal(queue.stats.bufferedBytes,0);assert.equal(queue.stats.backpressureWaits,1);
  assert.ok(stats.every(value=>value.bufferedFrames<=3&&value.bufferedBytes<=frameBytes*3));
});

test('a large allowed frame uses one serial slot instead of exceeding the prefetch budget',async()=>{
  const first=gate(),processed:number[]=[],reads:number[]=[];
  const queue=new CapturePipeline({maxFrames:3,maxBytes:16,maxFrameBytes:32,bytes:()=>24,
    consume:async(value:number)=>{if(value===1)await first.promise;processed.push(value);},failed:assert.fail});
  await queue.capture(24,async()=>{reads.push(1);return 1;});
  const next=queue.capture(24,async()=>{reads.push(2);return 2;});await tick();
  assert.deepEqual(reads,[1]);assert.equal(queue.stats.bufferedBytes,24);
  first.resolve();await next;queue.seal();await queue.idle();assert.deepEqual(processed,[1,2]);
  assert.equal(queue.stats.peakFrames,1);assert.equal(queue.stats.peakBytes,24);
});

test('Done seals the producer, wakes backpressure and drains every already queued frame in order',async()=>{
  const first=gate(),processed:number[]=[],reads:number[]=[];
  const queue=new CapturePipeline({maxFrames:3,maxBytes:12,maxFrameBytes:4,bytes:()=>4,
    consume:async(value:number)=>{await first.promise;processed.push(value);},failed:assert.fail});
  for(let value=1;value<=3;value++)await queue.capture(4,async()=>{reads.push(value);return value;});
  const waiting=queue.capture(4,async()=>{reads.push(4);return 4;});await tick();
  queue.seal();await waiting;assert.deepEqual(reads,[1,2,3]);
  first.resolve();await queue.idle();assert.deepEqual(processed,[1,2,3]);assert.equal(queue.stats.bufferedFrames,0);
});

test('pause/review clears waiting frames; cancel releases queued pixels and rejects a late read',async()=>{
  const first=gate(),late=gate(),processed:number[]=[],discarded:number[]=[];
  const queue=new CapturePipeline({maxFrames:3,maxBytes:12,maxFrameBytes:4,bytes:()=>4,
    consume:async(value:number)=>{await first.promise;processed.push(value);},discarded:count=>discarded.push(count),failed:assert.fail});
  await queue.capture(4,async()=>1);await queue.capture(4,async()=>2);
  queue.discardQueued();
  const read=queue.capture(4,async()=>{await late.promise;return 3;});
  queue.close();first.resolve();await queue.consumerIdle();assert.deepEqual(processed,[1]);
  late.resolve();await read;await queue.idle();assert.deepEqual(discarded,[1,1]);assert.equal(queue.stats.bufferedBytes,0);
});

test('a failed consumer stops producer and clears the queue without unhandled rejection',async()=>{
  const first=gate(),errors:unknown[]=[],processed:number[]=[];
  const queue=new CapturePipeline({maxFrames:2,maxBytes:8,maxFrameBytes:4,bytes:()=>4,
    consume:async(value:number)=>{processed.push(value);await first.promise;throw new Error('worker failed');},failed:error=>errors.push(error)});
  await queue.capture(4,async()=>1);await queue.capture(4,async()=>2);
  const waiting=queue.capture(4,async()=>3);first.resolve();await waiting;
  await assert.rejects(queue.idle(),/worker failed/);assert.equal(errors.length,1);assert.deepEqual(processed,[1]);assert.equal(queue.stats.bufferedBytes,0);
});

test('changed size and failed source cannot overrun a reservation or leave a waiting producer',async()=>{
  const make=()=>new CapturePipeline({maxFrames:3,maxBytes:12,maxFrameBytes:8,bytes:(value:number)=>value,consume:async()=>{},failed:assert.fail});
  const changed=make();await assert.rejects(changed.capture(4,async()=>8),/尺寸已变化/);await changed.idle();
  const failed=make();await assert.rejects(failed.capture(4,async()=>{throw new Error('screen unavailable');}),/screen unavailable/);
  await failed.capture(4,async()=>assert.fail('closed source must never be re-read'));await failed.idle();
  assert.equal(failed.stats.bufferedBytes,0);await assert.rejects(make().capture(9,async()=>9),/超过缓冲容量/);
});

test('slow previews coalesce requests without blocking capture/matching; stop cancels delayed work',async()=>{
  const rendering=gate(),starts:number[]=[],errors:unknown[]=[];
  const pump=new PreviewPump(25,async()=>{starts.push(performance.now());if(starts.length===1)await rendering.promise;},error=>errors.push(error));
  pump.request();await sleep(5);assert.equal(starts.length,1);
  let processed=0;
  const queue=new CapturePipeline({maxFrames:3,maxBytes:12,maxFrameBytes:4,bytes:()=>4,
    consume:async()=>{processed++;for(let i=0;i<1000;i++)pump.request();},failed:assert.fail});
  for(let i=0;i<8;i++)await queue.capture(4,async()=>i);
  queue.seal();await queue.idle();assert.equal(processed,8);assert.equal(starts.length,1,'blocked preview never blocks reads or match commits');
  rendering.resolve();await pump.idle();await sleep(45);
  assert.equal(starts.length,2,'thousands of requests collapse to one trailing preview');assert.ok(starts[1]-starts[0]>=25);
  pump.request();pump.stop();await pump.idle();await sleep(40);assert.equal(starts.length,2);assert.deepEqual(errors,[]);
});

test('preview failure reports once and stop prevents a queued successor',async()=>{
  const errors:unknown[]=[];let renders=0;
  const pump=new PreviewPump(1,async()=>{renders++;throw new Error('preview failed');},error=>errors.push(error));
  pump.request();await sleep(15);pump.request();await sleep(10);await pump.idle();
  assert.equal(renders,1);assert.equal(errors.length,1);
});
