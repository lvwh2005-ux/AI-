import assert from 'node:assert/strict';
import {test} from 'node:test';
import {analysisFrame,analysisCandidates,ANALYSIS_BUDGET} from '../src/shared/scroll-capture/analysis-frame';
import {VerticalMatcher} from '../src/shared/scroll-capture/vertical-matcher';
import {verifyTranslation} from '../src/shared/scroll-capture/translation-verifier';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';
import {StageProfiler,type ProfileSpan} from '../src/shared/scroll-capture/profiler';
function scene(width:number,height:number,offset:number,unaligned=false):BitmapFrame{
  const data=new Uint8Array(new ArrayBuffer(width*height*4+(unaligned?1:0)),unaligned?1:0);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}
test('analysis bytes stay bounded for wide/tall/odd sources and map to exact immutable source pixels',()=>{
  for(const [width,height] of [[1,1001],[3001,7],[1601,1001]]){
    const source=scene(width,height,0),sample=analysisFrame(source);
    assert.ok(sample.width*sample.height<=ANALYSIS_BUDGET.maxPixels);
    assert.equal(sample.data.length,sample.width*sample.height*4);
    for(let y=0;y<sample.height;y++)for(let x=0;x<sample.width;x++){
      const at=(sample.sourceRows[y]*width+sample.sourceColumns[x])*4;
      assert.deepEqual(sample.data.subarray((y*sample.width+x)*4,(y*sample.width+x+1)*4),source.data.subarray(at,at+4));
    }
    sample.data.fill(0);assert.notEqual(source.data[3],0);
  }
});
test('bounded candidates recover odd displacements and reverse direction without a decimation phase lock',()=>{
  const width=191,height=1024,matcher=new VerticalMatcher();
  for(const offset of [1,121,237,-119]){
    const a=scene(width,height,1000),b=scene(width,height,1000+offset);
    const candidates=analysisCandidates(analysisFrame(a),analysisFrame(b),768);
    assert.ok(candidates?.includes(offset));const result=matcher.match(a,b);
    assert.equal(result.kind,'match');if(result.kind==='match')assert.equal(result.shift,offset);
  }
});

test('tall desktop strips retain horizontal glyph evidence inside the existing sample budget',()=>{
  const sample=analysisFrame(scene(256,1543,0),8192);
  assert.ok(sample.width>=16);assert.ok(sample.width*sample.height<=8192);
  assert.ok(sample.sourceRows.at(-1)!>1500,'Rows still span the whole original strip');
});
test('exact-pixel fast path preserves local changes, alpha checks and unaligned input behavior',()=>{
  const a=scene(128,320,0),b=scene(128,320,0,true);
  assert.deepEqual(verifyTranslation(a,b,0),{verification:'strict',ignoredPixels:0});
  for(let x=0;x<12;x++)b.data[x*4+3]=0;
  assert.equal(verifyTranslation(a,b,0,{allowLocalized:false}),undefined);
  for(let x=0;x<12;x++)b.data[x*4+3]=255;
  for(let y=120;y<130;y++)for(let x=40;x<44;x++)b.data[(y*128+x)*4]^=255;
  const observed=verifyTranslation(a,b,0);assert.equal(observed?.verification,'localized');
  assert.equal(verifyTranslation(a,b,0,{allowLocalized:false}),undefined);
});
test('row views with unaligned offsets cannot be mistaken for identical word-aligned pixels',()=>{
  const data=new Uint8Array(128*4+4);for(let x=0;x<128;x++){data[x*4]=10;data[x*4+1]=80;data[x*4+2]=160;data[x*4+3]=255;}
  const before={width:128,height:320,rowAt:()=>({data,offset:0})},after={width:128,height:320,rowAt:()=>({data,offset:1})};
  assert.equal(verifyTranslation(before,after,0),undefined);
});
test('fixed alignment probes resolve repeated text-like row bands without height-wide search',()=>{
  const banded=(offset:number)=>{
    const frame=scene(191,823,0);
    for(let y=0;y<823;y++){
      const row=scene(191,1,Math.floor((y+offset)/12));frame.data.set(row.data,y*191*4);
    }return frame;
  };
  const spans:ProfileSpan[]=[],matcher=new VerticalMatcher({profiler:new StageProfiler(span=>spans.push(span))});
  const result=matcher.match(banded(0),banded(180));assert.equal(result.kind,'match');if(result.kind==='match')assert.equal(result.shift,180);
  assert.ok(spans.some(span=>span.stage==='analysis-candidate-probes'));
  assert.equal(spans.some(span=>span.stage==='analysis-fallback'),false);
});
