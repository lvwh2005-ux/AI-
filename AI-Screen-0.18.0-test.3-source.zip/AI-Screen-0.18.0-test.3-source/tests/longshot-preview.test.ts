import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ScrollCaptureEngine } from '../src/shared/scroll-capture/engine';
import { StitchDocument } from '../src/shared/scroll-capture/stitch-document';
import { previewPixelSize } from '../src/shared/scroll-capture/preview';
import { LONGSHOT_LIMITS } from '../src/shared/longshot-limits';
import type { BitmapFrame } from '../src/shared/scroll-capture/types';
import {referencePixel} from './preview-reference';
import {sampleSegments} from '../src/shared/scroll-capture/preview-snapshot';
import {previewFilterAxis} from '../src/shared/scroll-capture/preview-filter';

function pixels(width:number,height:number):BitmapFrame {
  const data=new Uint8Array(width*height*4);let n=17;
  for(let at=0;at<data.length;at+=4){n=Math.imul(n^(n>>>13),1597334677)+12345|0;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;}
  return {width,height,data};
}
const frame=(source:BitmapFrame,y:number,height:number)=>({width:source.width,height,data:source.data.slice(y*source.width*4,(y+height)*source.width*4)});

test('2560×1600 frames join beyond the old 64MiB budget using the real matcher and preserve all original pixels',()=>{
  assert.equal(LONGSHOT_LIMITS.maxBytes,256*1024*1024);
  const source=pixels(2560,7600),engine=new ScrollCaptureEngine();
  for(const y of [0,1000,2000,3000,4000,5000,6000])assert.equal(engine.push(frame(source,y,1600)).kind,y===0?'initial':'appended');
  const output=engine.bitmap();assert.equal(output.height,7600);assert.ok(output.data.length>64*1024*1024);
  assert.deepEqual(output.data,source.data);
  engine.clear();
});
test('preview sizes follow native DPI and visible image space, with bounded allocation',()=>{
  assert.deepEqual(previewPixelSize({width:390,height:800},1.5),{width:582,height:1023});
  assert.deepEqual(previewPixelSize({width:390,height:800},1),{width:388,height:682});
  assert.deepEqual(previewPixelSize({width:4000,height:4000},2),{width:2048,height:2048});
  assert.deepEqual(previewPixelSize({width:1,height:1},1),{width:1,height:1});
});
test('detail preview samples the latest original rows across segment and footer boundaries without flattening the document',()=>{
  const source=pixels(64,400),document=new StitchDocument();document.reset(frame(source,0,120));document.splitFooter(20);
  document.append(source,120,280);
  // The preserved footer is last, after all newly appended source rows.
  const original=document.bitmap(),region={x:8,y:300,width:48,height:100};
  const preview=document.preview(48,100,region);
  for(let y=0;y<100;y++)assert.deepEqual(preview.data.subarray(y*48*4,(y+1)*48*4),original.data.subarray(((y+300)*64+8)*4,((y+300)*64+56)*4));
  preview.data.fill(0);assert.deepEqual(document.bitmap(),original);
  assert.throws(()=>document.preview(48,100,{...region,y:350}),/范围/);
});
test('whole overview and width-fitted detail retain correct source geometry and never change export',()=>{
  const source=pixels(128,1600),engine=new ScrollCaptureEngine();
  for(const y of [0,130,260,390,520])assert.equal(engine.push(frame(source,y,320)).kind,y===0?'initial':'appended');
  const original=engine.bitmap(),size={width:64,height:120},previews=engine.previews(size);
  assert.deepEqual(previews.overviewRegion,{x:0,y:0,width:128,height:840});
  assert.deepEqual(previews.detailRegion,{x:0,y:600,width:128,height:240});
  assert.deepEqual({width:previews.detail.width,height:previews.detail.height},size);
  for(let y=0;y<120;y++)for(let x=0;x<64;x++){
    const at=(y*64+x)*4;
    assert.deepEqual(previews.detail.data.subarray(at,at+4),referencePixel(original,previews.detailRegion,64,120,x,y));
  }
  assert.deepEqual(engine.bitmap(),original);
  assert.throws(()=>engine.previews({width:999999,height:400}),/尺寸/);
  engine.clear();assert.equal(engine.previews(size).overview.data.length,0);
});

test('reduced text strokes retain area coverage rather than disappearing with sampling phase',()=>{
  const data=new Uint8Array(64*64*4).fill(255);
  // One-pixel vertical strokes fall between every old nearest-neighbour sample.
  for(let y=0;y<64;y++)for(let x=3;x<64;x+=4){const at=(y*64+x)*4;data[at]=data[at+1]=data[at+2]=0;}
  const frame=sampleSegments({width:64,height:64,parts:[data.subarray(0,64*17*4),data.subarray(64*17*4)]},16,16);
  for(let at=0;at<frame.data.length;at+=4)assert.deepEqual([...frame.data.subarray(at,at+4)],[191,191,191,255]);
  assert.equal(data[0],255,'Filtering cannot modify export pixels');
  for(const taps of previewFilterAxis(5,30000,31)){
    assert.ok(taps.length<=8);assert.ok(Math.abs(taps.reduce((sum,tap)=>sum+tap.weight,0)-1)<1e-10);
    assert.ok(taps.every(tap=>tap.index>=5&&tap.index<30005));
  }
});

test('fractional preview reductions integrate original pixels across segment boundaries',()=>{
  const original=pixels(61,97),stride=61*4,region={x:3,y:7,width:53,height:81};
  const filtered=sampleSegments({width:61,height:97,parts:[original.data.subarray(0,13*stride),original.data.subarray(13*stride,57*stride),original.data.subarray(57*stride)]},17,26,region);
  for(let y=0;y<filtered.height;y++)for(let x=0;x<filtered.width;x++){
    const expected=referencePixel(original,region,filtered.width,filtered.height,x,y),at=(y*filtered.width+x)*4;
    for(let c=0;c<4;c++)assert.ok(Math.abs(filtered.data[at+c]-expected[c])<=1);
  }
});
