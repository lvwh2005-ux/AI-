import { describe,it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp,readFile,readdir,rm } from 'node:fs/promises';
import os from 'node:os';import path from 'node:path';import {randomUUID} from 'node:crypto';
import {LocalVideoFileSink} from '../src/main/services/recording/video-file-sink';
import {RECORDING_LIMITS,type RecordingMediaInfo} from '../src/shared/recording/contracts';
const info:RecordingMediaInfo={mimeType:'video/webm;codecs=vp8',width:101,height:99,sourceWidth:1920,sourceHeight:1080,sourceFrameRate:30,codecs:{}};
async function fixture(run:(sink:LocalVideoFileSink,root:string)=>Promise<void>){const root=await mkdtemp(path.join(os.tmpdir(),'ai-screen-recording-'));const sink=await LocalVideoFileSink.create(root,randomUUID());try{await run(sink,root);}finally{await sink.abort();const relative=path.relative(path.resolve(os.tmpdir()),path.resolve(root));assert.ok(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative)&&path.basename(root).startsWith('ai-screen-recording-'));await rm(root,{recursive:true,force:true});}}
describe('recording bounded file sink',()=>{
  it('writes exact ordered bytes and closes only after the final block',()=>fixture(async(sink,root)=>{
    const writes=[sink.append(0,new Uint8Array([1,2])),sink.append(1,new Uint8Array([3,4,5]))];
    const output=await sink.finish(info,1200);await Promise.all(writes);assert.deepEqual([...await readFile(output.path)],[1,2,3,4,5]);
    assert.equal(output.bytes,5);assert.equal(output.durationMs,1200);assert.match(output.path,/\.webm$/);assert.equal((await readdir(root)).length,1);
    await assert.rejects(sink.append(2,new Uint8Array([6])),/关闭/);
  }));
  it('rejects oversized, out-of-order and excess pending blocks before queue growth',()=>fixture(async(sink)=>{
    await assert.rejects(sink.append(1,new Uint8Array([1])),/顺序/);
    await assert.rejects(sink.append(0,new Uint8Array(RECORDING_LIMITS.maxChunkBytes+1)),/缓冲/);
    const writes=Array.from({length:8},(_,i)=>sink.append(i,new Uint8Array([i])));
    await assert.rejects(sink.append(8,new Uint8Array([8])),/缓冲/);await Promise.all(writes);
    assert.equal(sink.peaks.chunks,8);await sink.append(8,new Uint8Array([8]));
  }));
  it('bounds bytes even with fewer than eight blocks',()=>fixture(async(sink)=>{
    const a=sink.append(0,new Uint8Array(RECORDING_LIMITS.maxChunkBytes)),b=sink.append(1,new Uint8Array(RECORDING_LIMITS.maxChunkBytes));
    await assert.rejects(sink.append(2,new Uint8Array([1])),/缓冲/);await Promise.all([a,b]);assert.equal(sink.peaks.bytes,RECORDING_LIMITS.maxPendingBytes);
  }));
  it('cancel waits for writes/finalization and removes only its generated output',()=>fixture(async(sink,root)=>{
    const write=sink.append(0,new Uint8Array([1,2,3]));void write.catch(()=>{});const finishing=sink.finish(info,1000);void finishing.catch(()=>{});
    await sink.abort();await Promise.allSettled([write,finishing]);assert.deepEqual(await readdir(root),[]);await sink.abort();
  }));
  it('does not claim success for an empty recording',()=>fixture(async(sink)=>{await assert.rejects(sink.finish(info,0),/未生成/);}));
});
