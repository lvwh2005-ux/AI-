import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import {cropFrame} from '../src/shared/scroll-capture/motion-region';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';

const body={x:160,y:48,width:620,height:600};
function desktop(offset:number,thumbTop:number,options:{wide?:boolean;split?:boolean;texture?:boolean}={}):BitmapFrame{
  const width=800,height=720,data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const inside=x>=body.x&&x<body.x+body.width&&y>=body.y&&y<body.y+body.height;
    const row=inside?y-body.y+offset:y+8000;
    let n=Math.imul(row+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    data.set([n&255,n>>>8&255,n>>>16&255,255],(y*width+x)*4);
    if(x>=780&&y>=body.y&&y<body.y+body.height){
      const thumb=y>=thumbTop&&y<thumbTop+80;
      const other=options.split&&y>=thumbTop+110&&y<thumbTop+140;
      const value=thumb||other?125:245;
      data.set(options.texture&&thumb?[n&255,n>>>8&255,n>>>16&255,255]:[value,value,value,255],(y*width+x)*4);
    }
    if(options.wide&&x>=740&&x<780&&y>=body.y&&y<body.y+body.height){
      const value=y>=thumbTop&&y<thumbTop+80?125:245;data.set([value,value,value,255],(y*width+x)*4);
    }
  }
  return {width,height,data};
}

test('desktop sidebar/input area and a moving narrow edge thumb offer explicit body review',()=>{
  const engine=new ScrollCaptureEngine(),first=desktop(0,100),next=desktop(120,160);
  engine.push(first);const saved=engine.bitmap(),result=engine.push(next);
  assert.equal(result.kind,'review');assert.deepEqual(result.regionCandidate,body);
  assert.deepEqual(engine.bitmap(),saved,'No scrollbar or fixed UI may be cropped before confirmation');
  const confirmed=engine.confirmRegion();assert.equal(confirmed.appendedRows,120);
  const expected=new Uint8Array(body.width*720*4),a=cropFrame(first,body),b=cropFrame(next,body);
  expected.set(a.data);expected.set(b.data.subarray((body.height-120)*body.width*4),a.data.length);
  assert.deepEqual(engine.bitmap(),{width:body.width,height:720,data:expected});
  assert.equal(engine.push(desktop(200,200)).kind,'appended');
  assert.equal(engine.push(desktop(120,160)).kind,'duplicate');
});

test('upward scrolling with an edge thumb can be reviewed, and keeping the scope preserves the original',()=>{
  const engine=new ScrollCaptureEngine(),first=desktop(200,240),next=desktop(80,180);engine.push(first);
  assert.equal(engine.push(next).kind,'review');
  const result=engine.confirmRegion();assert.equal(result.addedTop,120);assert.equal(result.coveredTop,-120);
  const expected=new Uint8Array(body.width*720*4),a=cropFrame(first,body),b=cropFrame(next,body);
  expected.set(b.data.subarray(0,120*body.width*4));expected.set(a.data,120*body.width*4);
  assert.deepEqual(engine.bitmap(),{width:body.width,height:720,data:expected});
  const keep=new ScrollCaptureEngine();keep.push(desktop(0,100));
  assert.equal(keep.push(desktop(120,160)).kind,'review');keep.keepRegion();
  assert.equal(keep.push(desktop(200,200)).kind,'rejected');assert.deepEqual(keep.bitmap(),desktop(0,100));
});

test('a stationary thumb continues to use the existing fixed-region proposal path',()=>{
  const engine=new ScrollCaptureEngine();engine.push(desktop(0,100));
  const proposal=engine.push(desktop(120,100));assert.equal(proposal.kind,'review');assert.deepEqual(proposal.regionCandidate,body);
});

test('scaled physical-pixel fixtures keep thumb review separate from full-pixel body verification',()=>{
  function scaled(frame:BitmapFrame,scale:number):BitmapFrame{
    const width=Math.round(frame.width*scale),height=Math.round(frame.height*scale),data=new Uint8Array(width*height*4);
    for(let y=0;y<height;y++)for(let x=0;x<width;x++){
      const at=(Math.floor(y/scale)*frame.width+Math.floor(x/scale))*4;
      data.set(frame.data.subarray(at,at+4),(y*width+x)*4);
    }
    return {width,height,data};
  }
  for(const scale of [1.5,2]){
    const engine=new ScrollCaptureEngine(),first=scaled(desktop(0,100),scale),next=scaled(desktop(120,160),scale);
    engine.push(first);const candidate=engine.push(next);assert.equal(candidate.kind,'review');
    assert.deepEqual(candidate.regionCandidate,{x:160*scale,y:48*scale,width:620*scale,height:600*scale});
    const result=engine.confirmRegion();assert.equal(result.appendedRows,120*scale);
    const rect=candidate.regionCandidate!,a=cropFrame(first,rect),b=cropFrame(next,rect),data=new Uint8Array(rect.width*720*scale*4);
    data.set(a.data);data.set(b.data.subarray((rect.height-120*scale)*rect.width*4),a.data.length);
    assert.deepEqual(engine.bitmap(),{width:rect.width,height:720*scale,data});
  }
});

test('a narrow changing edge is not enough: split, textured, broad, or oppositely moving content is rejected',()=>{
  for(const option of [{split:true},{texture:true},{wide:true}]){
    const engine=new ScrollCaptureEngine(),first=desktop(0,100,option);engine.push(first);
    assert.equal(engine.push(desktop(120,160,option)).kind,'rejected');assert.deepEqual(engine.bitmap(),first);
  }
  const engine=new ScrollCaptureEngine(),first=desktop(0,180);engine.push(first);
  assert.equal(engine.push(desktop(120,100)).kind,'rejected');assert.deepEqual(engine.bitmap(),first);
});
