import assert from 'node:assert/strict';
import {test} from 'node:test';
import {Worker} from 'node:worker_threads';
import {setTimeout as delay} from 'node:timers/promises';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import {AnalysisWork,FRAME_ANALYSIS_LIMITS} from '../src/shared/scroll-capture/analysis-work';
import {VerticalMatcher} from '../src/shared/scroll-capture/vertical-matcher';
import {snapshotPreviews} from '../src/shared/scroll-capture/preview-snapshot';
import {StageProfiler,type ProfileSpan} from '../src/shared/scroll-capture/profiler';
import {LongshotProcessor} from '../src/main/services/longshot-processor';
import {AutoScrollScheduler} from '../src/shared/auto-scroll-scheduler';
import {stableLongshotFrame} from '../src/shared/longshot-stability';
import {verifyTranslation} from '../src/shared/scroll-capture/translation-verifier';
import type {BitmapFrame,StitchResult} from '../src/shared/scroll-capture/types';
function page(offset:number,width=128,height=440):BitmapFrame{
  const data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}
test('whole transition shares sample/probe/candidate quotas across body strips without height search',()=>{
  const spans:ProfileSpan[]=[],engine=new ScrollCaptureEngine({profiler:new StageProfiler(span=>spans.push(span))});
  const before=page(0,1200,1000),after=page(120,1200,1000);
  for(let y=0;y<1000;y++)for(const [left,right]of [[0,240],[960,1200]])after.data.set(before.data.subarray((y*1200+left)*4,(y*1200+right)*4),(y*1200+left)*4);
  engine.push(before);assert.equal(engine.push(after).kind,'review');
  const totals=spans.filter(span=>span.stage==='frame-analysis-budget').at(-1)!.metrics!;
  for(const kind of ['samples','probes','verifications','matches'] as const)assert.ok(totals[kind]<=FRAME_ANALYSIS_LIMITS[kind]);
  assert.ok(totals.matches>1);assert.ok(!spans.some(span=>span.stage==='offset-search'||span.stage==='analysis-fallback'));
  assert.deepEqual(engine.bitmap(),before,'proposal does not silently crop or commit');
  const work=new AnalysisWork();work.take('samples',FRAME_ANALYSIS_LIMITS.samples);
  assert.equal(new VerticalMatcher().match(before,after,work).kind,'rejected');assert.equal(work.exhausted,true);
});
test('bounded analysis preserves odd displacement near the maximum document height',()=>{
  const a=page(1000,97,20000),b=page(1237,97,20000),result=new VerticalMatcher().match(a,b);
  assert.equal(result.kind,'match');if(result.kind==='match')assert.equal(result.shift,237);
});
test('large-DPI text bands retain a unique pixel-verified displacement without exhaustive fallback',()=>{
  const band=(offset:number)=>{
    const frame=page(0,191,1000);
    for(let y=0;y<1000;y++)frame.data.set(page(Math.floor((y+offset)/24),191,1).data,y*191*4);
    return frame;
  };
  const match=new VerticalMatcher().match(band(0),band(121));
  assert.equal(match.kind,'match');if(match.kind==='match')assert.equal(match.shift,121);
});
test('bounded coarse signatures preserve existing tiny colour tolerance while source pixels reject broad changes',()=>{
  const before=page(0,320,1000),next=page(121,320,1000);
  for(let at=0;at<next.data.length;at+=4)next.data[at]=Math.min(255,next.data[at]+1);
  assert.ok(verifyTranslation(before,next,121));
  const result=new VerticalMatcher().match(before,next);assert.equal(result.kind,'match');if(result.kind==='match')assert.equal(result.shift,121);
  for(let at=0;at<next.data.length;at+=4)next.data[at]=Math.min(255,next.data[at]+4);
  assert.equal(new VerticalMatcher().match(before,next).kind,'rejected');
});
test('immutable shared snapshots preserve old pixels across prefixes, new rows, reset and edge locking',()=>{
  const engine=new ScrollCaptureEngine({sharedDocument:true});engine.push(page(200));const old=engine.previewSnapshot();
  assert.ok(old.parts.every(part=>part.buffer instanceof SharedArrayBuffer));const bytes=old.parts.map(part=>part.slice());
  engine.push(page(100));engine.push(page(300));const snapshot=engine.previewSnapshot();
  assert.deepEqual(snapshotPreviews(snapshot,{width:96,height:160}),engine.previews({width:96,height:160}));
  engine.clear();assert.deepEqual(old.parts.map(part=>new Uint8Array(part)),bytes);
});
test('real independent preview worker samples shared snapshots and never changes final original pixels',async()=>{
  const spans:ProfileSpan[]=[],processor=new LongshotProcessor({profiler:new StageProfiler(span=>spans.push(span))});
  const reference=new ScrollCaptureEngine();
  try{
    for(const offset of [200,320,80,440]){const frame=page(offset);assert.deepEqual(await processor.push(frame),reference.push(frame));
      const size={width:120,height:180},bundle=await processor.preview(size);assert.deepEqual(bundle,reference.previews(size));
      const images=await processor.encodePreview([bundle.overview]);assert.ok(images[0].startsWith('data:image/png;base64,'));
    }
    assert.deepEqual(await processor.bitmap(),reference.bitmap());
    assert.ok(spans.some(span=>span.stage==='preview-sample-cpu'));
    assert.ok(!spans.some(span=>span.stage==='worker-roundtrip-preview'||span.stage==='preview-sample'));
  }finally{processor.dispose();}
});
test('a genuinely blocked preview thread cannot delay a matching commit; cancellation rejects late preview',async()=>{
  const gate=new Int32Array(new SharedArrayBuffer(4));
  const processor=new LongshotProcessor({previewWorker:()=>new Worker(`const {parentPort,workerData}=require('node:worker_threads');const gate=new Int32Array(workerData);parentPort.on('message',()=>{Atomics.store(gate,0,1);Atomics.wait(gate,0,1);});`,{eval:true,workerData:gate.buffer})});
  try{
    await processor.push(page(0));const pending=processor.preview({width:128,height:160});const rejection=assert.rejects(pending,/预览已结束/);
    const deadline=Date.now()+3000;while(!Atomics.load(gate,0)&&Date.now()<deadline)await delay(5);
    assert.equal(Atomics.load(gate,0),1);
    assert.equal((await processor.push(page(120))).kind,'appended');
    assert.equal(Atomics.load(gate,0),1,'preview remains blocked while matching completes');
    processor.dispose();await rejection;
  }finally{processor.dispose();}
});
test('automatic wheel amount learns physical displacement, bounds overlap and ignores revisit/rejection',()=>{
  const scheduler=new AutoScrollScheduler();
  const movement=(delta:number):StitchResult=>({kind:'appended',width:400,height:1000,appendedRows:delta,viewportDelta:delta});
  assert.equal(scheduler.units(800),120);scheduler.observe(movement(120),120);
  assert.equal(scheduler.units(400),90);assert.equal(scheduler.units(1600),390);
  scheduler.observe({...movement(900),relocated:true},120);scheduler.observe({...movement(900),kind:'rejected'},120);
  assert.equal(scheduler.units(400),90);
  scheduler.observe(movement(240),120);assert.equal(scheduler.units(400),60);
  scheduler.observe({...movement(0),kind:'duplicate'},60);assert.equal(scheduler.units(400),120);
  assert.ok(scheduler.units(20000)<=480&&scheduler.units(32)>=60);
  scheduler.unsettled();assert.equal(scheduler.settleDelayMs,140);scheduler.settled();assert.equal(scheduler.settleDelayMs,130);
  scheduler.reset();assert.equal(scheduler.units(800),120);
});
test('automatic stability tolerates one bounded animation but rejects geometry movement and scattered changes',()=>{
  const before=page(0,800,600),local=page(0,800,600);
  for(let y=180;y<210;y++)for(let x=300;x<345;x++)local.data[(y*800+x)*4]^=255;
  assert.equal(stableLongshotFrame(before,local),true);
  assert.equal(stableLongshotFrame(before,page(1,800,600)),false);
  for(let y=430;y<460;y++)for(let x=30;x<75;x++)local.data[(y*800+x)*4]^=255;
  assert.equal(stableLongshotFrame(before,local),false);
});
