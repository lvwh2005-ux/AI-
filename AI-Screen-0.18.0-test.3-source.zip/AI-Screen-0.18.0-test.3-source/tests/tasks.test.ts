import { it } from 'node:test';
import assert from 'node:assert/strict';
import { TaskService } from '../src/main/services/tasks';
import { settingsSchema, type ResultState } from '../src/shared/contracts';
import type { AIRequest, AIProvider } from '../src/main/providers/types';

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (reason: Error) => void;
  const promise = new Promise<T>((done, fail) => { resolve = done; reject = fail; });
  return { promise, resolve, reject };
}
function fixture(provider: AIProvider, copyText: (text: string) => Promise<void> = async () => {}) {
  const published: ResultState[] = [];
  const settings = { value: settingsSchema.parse({ provider: 'compatible' }), apiKey: async () => '' };
  const tasks = new TaskService(settings, (state) => published.push(state), copyText, () => provider);
  return { tasks, published };
}
const settle = () => Promise.resolve();

it('does not publish or copy a late OCR answer after cancellation', async () => {
  const response = deferred<string>();
  const copies: string[] = [];
  const { tasks, published } = fixture({ complete: () => response.promise }, async (text) => { copies.push(text); });
  const pending = tasks.run('ocr', 'image', '', false);
  await settle();
  tasks.cancel();
  response.resolve('late OCR');
  await pending;
  assert.equal(tasks.state?.status, 'cancelled');
  assert.deepEqual(copies, []);
  assert.deepEqual(published.map((state) => state.status), ['loading', 'cancelled']);
});
it('ignores stale success and errors after a replacement task completes', async () => {
  for (const failed of [false, true]) {
    const old = deferred<string>();
    let calls = 0;
    const { tasks } = fixture({ complete: () => ++calls === 1 ? old.promise : Promise.resolve('new answer') });
    const first = tasks.run('ask', 'old-image', 'first', false);
    await settle();
    await tasks.run('ask', 'new-image', 'second', false);
    if (failed) old.reject(new Error('old error')); else old.resolve('old answer');
    await first;
    assert.equal(tasks.state?.text, 'new answer');
    assert.equal(tasks.state?.image, 'new-image');
    assert.deepEqual(tasks.state?.history.map((turn) => turn.content), ['second', 'new answer']);
  }
});
it('clearing the session aborts work and prevents late replies from recreating it', async () => {
  const response = deferred<string>();
  let signal: AbortSignal | undefined;
  const { tasks, published } = fixture({ complete: (request) => { signal = request.signal; return response.promise; } });
  const pending = tasks.run('analyze', 'image', '', false);
  await settle();
  tasks.clear();
  assert.equal(signal?.aborted, true);
  const count = published.length;
  response.resolve('late reply');
  await pending;
  assert.equal(tasks.state, null);
  assert.equal(published.length, count);
});
it('keeps a cancellation while an asynchronous clipboard write is finishing', async () => {
  const copied = deferred<void>();
  const started = deferred<void>();
  const { tasks } = fixture({ complete: async () => 'OCR text' }, async () => { started.resolve(); await copied.promise; });
  const pending = tasks.run('ocr', 'image', '', false);
  await started.promise;
  tasks.cancel();
  copied.resolve();
  await pending;
  assert.equal(tasks.state?.status, 'cancelled');
  assert.deepEqual(tasks.state?.history, []);
});
it('retains only completed turns, bounds context, and resets it for a new image', async () => {
  const requests: AIRequest[] = [];
  const { tasks } = fixture({ complete: async (request) => { requests.push(request); return `answer ${request.question}`; } });
  for (let i = 0; i < 8; i++) await tasks.run('ask', 'image', `question ${i}`, i > 0);
  assert.equal(tasks.state?.history.length, 12);
  assert.equal(requests.at(-1)?.history.length, 12);
  await tasks.run('ask', 'new image', 'fresh', false);
  assert.deepEqual(requests.at(-1)?.history, []);
  assert.equal(tasks.state?.history.length, 2);
});
it('does not automatically copy demonstration OCR output', async () => {
  const copies: string[] = [];
  const tasks = new TaskService({ value: settingsSchema.parse({}), apiKey: async () => '' }, () => {}, async (text) => { copies.push(text); }, () => ({ complete: async () => 'demo OCR' }));
  await tasks.run('ocr', 'image', '', false);
  assert.equal(tasks.state?.status, 'done');
  assert.deepEqual(copies, []);
});
it('local OCR bypasses AI and key retrieval even in demo mode', async () => {
  const copies: string[] = [];
  const tasks = new TaskService({ value: settingsSchema.parse({ ocr: 'windows' }), apiKey: async () => { throw new Error('must not read key'); } }, () => {}, async (text) => { copies.push(text); }, () => { throw new Error('must not call AI'); }, { recognize: async () => 'local text' });
  await tasks.run('ocr', 'image', '', false);
  assert.equal(tasks.state?.source, 'local-ocr');
  assert.equal(tasks.state?.demo, false);
  assert.deepEqual(copies, ['local text']);
});
it('isolates streaming progress by request id and preserves partial text on cancellation', async () => {
  const pending = deferred<string>();
  let request: AIRequest | undefined;
  const updates: string[] = [];
  const tasks = new TaskService({ value: settingsSchema.parse({ provider: 'compatible' }), apiKey: async () => '' }, () => {}, async () => {}, () => ({ complete: (req) => { request = req; return pending.promise; } }), undefined, (update) => updates.push(update.requestId));
  const run = tasks.run('ask', 'image', 'question', false);
  await settle(); request!.onProgress!('partial');
  const id = tasks.state!.requestId;
  tasks.cancel(); request!.onProgress!('late'); pending.resolve('late'); await run;
  assert.equal(tasks.state?.text, 'partial');
  assert.deepEqual(updates, [id]);
});
