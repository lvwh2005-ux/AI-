import { it } from 'node:test';
import assert from 'node:assert/strict';
import { createElement } from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { MarkdownAnswer, codeBlockText, highlightedCode, safeMarkdownLink } from '../src/renderer/components/MarkdownAnswer';

function render(text: string) {
  return renderToStaticMarkup(createElement(MarkdownAnswer, { text, onCopy: async () => {}, onOpenLink: () => {} }));
}

it('renders Markdown headings, GFM tables and task lists', () => {
  const html = render('# 结果\n\n| 名称 | 内容 |\n| --- | --- |\n| 中文 | **重点** |\n\n- [x] 已完成\n- [ ] 待处理');
  assert.match(html, /<h1>结果<\/h1>/);
  assert.match(html, /<table>/);
  assert.match(html, /<strong>重点<\/strong>/);
  const checked = html.match(/<input[^>]*checked=""[^>]*>/)?.[0] ?? '';
  assert.match(checked, /type="checkbox"/);
  assert.match(checked, /disabled=""/);
});

it('drops raw HTML and never loads Markdown images', () => {
  const html = render('<script>alert(1)</script>\n\n<img src="https://evil.example/beacon" onerror="alert(1)">\n\n![示意图](https://evil.example/tracker.png)');
  assert.doesNotMatch(html, /<script|<img|onerror=|src=/i);
  assert.doesNotMatch(html, /evil\.example/);
  assert.match(html, /图片：示意图（外部图片已省略）/);
});

it('validates http(s) external links and rejects local, executable and credential URLs', () => {
  assert.equal(safeMarkdownLink('https://example.com/中文?a=1#part'), 'https://example.com/%E4%B8%AD%E6%96%87?a=1#part');
  assert.equal(safeMarkdownLink('http://localhost:8080/'), 'http://localhost:8080/');
  for (const value of ['javascript:alert(1)', 'data:text/html,x', 'file:///C:/secret', '//example.com', '/relative', 'mailto:user@example.com', 'https://user:password@example.com', 'https://exa\nmple.com', 'https://']) {
    assert.equal(safeMarkdownLink(value), null, value);
  }
  const html = render('[正常](https://example.com/page) [危险](javascript:alert) [本地](file:///C:/secret)');
  assert.match(html, /role="link"/);
  assert.match(html, /title="在浏览器打开：https:\/\/example\.com\/page"/);
  assert.doesNotMatch(html, /href=|javascript:|file:\/\//);
  assert.match(html, /<span>危险<\/span>/);
});

it('highlights supported fenced code and escapes apparent HTML inside the code', () => {
  const html = render('```javascript\nconst text = "<img src=x onerror=alert(1)>";\n```');
  assert.match(html, /hljs-keyword/);
  assert.match(html, /&lt;img src=x onerror=alert\(1\)&gt;/);
  assert.doesNotMatch(html, /<img/);
  assert.match(html, /aria-label="复制代码"/);
  assert.equal(highlightedCode('graph TD; A-->B;', 'mermaid'), null);
  assert.equal(highlightedCode('plain code', 'constructor'), null);
  assert.equal(highlightedCode('plain code', '__proto__'), null);
  assert.equal(highlightedCode('x'.repeat(80_001), 'javascript'), null);
});

it('renders an unfinished streamed fence as code without executing it', () => {
  const html = render('解释\n\n```python\nprint("中文")\nif');
  assert.match(html, /<pre>/);
  assert.match(html, /中文/);
  assert.match(html, /hljs-keyword/);
  assert.match(html, /复制代码/);
});

it('copies plain code content, preserving whitespace and real trailing blank lines', () => {
  const original = '  echo "<tag>"\n\t第二行\n';
  const children = createElement('code', { className: 'language-bash' }, original + '\n');
  assert.equal(codeBlockText(children), original);
  assert.equal(codeBlockText('without newline'), 'without newline');
  assert.equal(codeBlockText('\n'), '');
});
