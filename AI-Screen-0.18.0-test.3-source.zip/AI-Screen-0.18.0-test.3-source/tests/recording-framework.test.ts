import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { RecordingService } from '../src/main/services/recording/recording-service';
import type { RecordingBackend, RecordingBackendEvents, VideoFileSink } from '../src/main/services/recording/backend';
import { recordingOptionsSchema, type RecordingOptions, type RecordingMediaInfo, type RecordingRequest, type RecordingState, type RecordingStats } from '../src/shared/recording/contracts';
import { recordingTransition, newerRecordingState } from '../src/shared/recording/state';
import { recordingPixelRect, recordingSource } from '../src/shared/recording/geometry';
import { CaptureModeRegistry } from '../src/main/services/capture-modes';

function deferred<T>() { let resolve!: (v:T)=>void; let reject!: (e:Error)=>void; const promise = new Promise<T>((yes,no)=>{resolve=yes;reject=no;}); return {promise,resolve,reject}; }
const target = { displayId:'secondary', displayBounds:{x:-1707,y:-100,width:1707,height:1067}, scaleFactor:1.5, rect:{x:100,y:100,width:401,height:299} };
const media: RecordingMediaInfo = { mimeType:'video/webm;codecs=vp8',width:602,height:449,sourceWidth:2560,sourceHeight:1600,sourceFrameRate:30,codecs:{'video/webm;codecs=vp8':true} };
const stats: RecordingStats = {frames:300,chunks:10,bytes:1000,pendingPeakBytes:100,pendingPeakChunks:1};
class Backend implements RecordingBackend {
  events?: RecordingBackendEvents; disposed=0; stops=0; prepareGate?:ReturnType<typeof deferred<RecordingMediaInfo>>; stopGate?:ReturnType<typeof deferred<void>>;
  media=media;pauseGate?:ReturnType<typeof deferred<void>>;audioGate?:ReturnType<typeof deferred<void>>;
  async prepare(_r:RecordingRequest,e:RecordingBackendEvents){this.events=e;return this.prepareGate?this.prepareGate.promise:this.media;}
  async start(){} async pause(){await this.pauseGate?.promise;} async resume(){}
  async setAudio(){await this.audioGate?.promise;}
  async stop(){this.stops++;await this.stopGate?.promise;await this.events?.chunk(0,new Uint8Array([1,2,3]));return stats;}
  async dispose(){this.disposed++;this.prepareGate?.reject(new Error('cancelled'));}
}
class Sink implements VideoFileSink {
  aborted=0; chunks:number[]=[]; finishGate?:ReturnType<typeof deferred<void>>;
  async append(seq:number){this.chunks.push(seq);}
  async finish(info:RecordingMediaInfo,durationMs:number){await this.finishGate?.promise;return {path:'private-temp.webm',width:info.width,height:info.height,mimeType:info.mimeType,bytes:3,durationMs};}
  async abort(){this.aborted++;}
}
function harness(extra: {otherCaptureActive?:()=>boolean;sink?:(id:string,options:RecordingOptions)=>Promise<VideoFileSink>;countdownMs?:number}={}){
  const backend=new Backend(), sink=new Sink(), states:RecordingState[]=[], input=new AbortController(); let clock=0;
  const service=new RecordingService({backend:()=>backend,sink:extra.sink??(async()=>sink),target:()=>target,now:()=>clock,onState:s=>states.push(s),otherCaptureActive:extra.otherCaptureActive},recordingOptionsSchema.parse({countdownMs:extra.countdownMs??0}));
  const start=()=>service.start({displayId:target.displayId,rect:target.rect,signal:input.signal});
  return {backend,sink,service,states,input,start,tick:(ms:number)=>{clock+=ms;}};
}
describe('recording framework',()=>{
  it('uses the committed preparation format before opening output and rejects premature chunks',async()=>{
    let selected:RecordingOptions|undefined;const h=harness({sink:async(_id,options)=>{selected=options;return h.sink;}});
    h.backend.prepareGate=deferred<RecordingMediaInfo>();const preparing=h.start();void preparing.catch(()=>{});
    await new Promise(resolve=>setImmediate(resolve));assert.equal(selected,undefined);
    await assert.rejects(async()=>h.backend.events!.chunk(0,new Uint8Array([1])),/尚未就绪/);
    const options=recordingOptionsSchema.parse({mimeType:'video/mp4;codecs=avc1.42001E',countdownMs:0,microphone:true,microphoneDeviceId:'specific-input'});
    h.backend.prepareGate.resolve({...media,mimeType:options.mimeType,options});await preparing;
    assert.equal((selected as RecordingOptions|undefined)?.mimeType,options.mimeType);assert.equal((selected as RecordingOptions|undefined)?.microphoneDeviceId,'specific-input');await h.service.cancel();
  });
  it('requires a unique selected display and never falls back to primary',()=>{
    const sources=[{display_id:'main'},{display_id:'secondary'}];assert.equal(recordingSource(sources,'secondary'),sources[1]);
    assert.throws(()=>recordingSource(sources,'missing'),/匹配/);assert.throws(()=>recordingSource([...sources,sources[1]],'secondary'),/匹配/);
  });
  it('maps media edges for negative origins, non-integral DPI and odd sizes',()=>{
    assert.deepEqual(recordingPixelRect(target,{width:2560,height:1600}),{x:149,y:149,width:603,height:450});
    assert.deepEqual(recordingPixelRect({...target,rect:{x:0,y:0,width:1707,height:1067}},{width:2560,height:1600}),{x:0,y:0,width:2560,height:1600});
    for(const scaleFactor of [1,1.25,1.5,2])assert.equal(recordingPixelRect({...target,scaleFactor},{width:2560,height:1600}).width,603);
    assert.throws(()=>recordingPixelRect({...target,rect:{x:1700,y:0,width:8,height:10}},{width:2560,height:1600}),/超出/);
  });
  it('rejects invalid sizes and malformed options while accepting explicit audio choices',()=>{
    assert.throws(()=>recordingPixelRect(target,{width:0,height:1600}));
    assert.equal(recordingOptionsSchema.parse({microphone:true}).microphone,true);assert.throws(()=>recordingOptionsSchema.parse({microphone:'yes'}));assert.throws(()=>recordingOptionsSchema.parse({frameRate:0}));
  });
  it('rejects illegal transitions and stale or duplicate states',()=>{
    const state:RecordingState={id:'a',sequence:4,status:'stopping',elapsedMs:20};
    assert.throws(()=>recordingTransition(state,'recording'));assert.equal(recordingTransition(state,'ready').sequence,5);
    assert.equal(newerRecordingState(state,{...state,sequence:5},'a'),true);
    assert.equal(newerRecordingState(state,{...state,sequence:4},'a'),false);assert.equal(newerRecordingState(state,{...state,id:'old',sequence:10},'a'),false);
  });
  it('does not expose experimental registration as a production capability',async()=>{
    const h=harness(),registry=new CaptureModeRegistry();registry.register(h.service);
    assert.equal(registry.capabilities().find(x=>x.mode==='record')?.available,false);
    await assert.rejects(registry.start('record',{displayId:'main',rect:target.rect,signal:h.input.signal}),/尚未接入/);
    assert.equal(h.service.state,undefined);
  });
  it('checks the capture mutex before creating media or output',async()=>{
    const h=harness({otherCaptureActive:()=>true});await assert.rejects(h.start(),/长截图/);assert.equal(h.backend.events,undefined);
    const registry=new CaptureModeRegistry();registry.register({mode:'longshot',active:true,start:async()=>{},cancel:async()=>{}});
    registry.register({mode:'record',start:async()=>{throw Error('must not start');},cancel:async()=>{}});
    await assert.rejects(registry.start('record',{displayId:'x',rect:target.rect,signal:h.input.signal}),/正在进行/);
  });
  it('owns a detached session after preparation and publishes immutable sequenced states',async()=>{
    const h=harness();await h.start();h.input.abort();await Promise.resolve();assert.equal(h.service.state?.status,'recording');
    assert.deepEqual(h.states.map(x=>x.status),['preparing','countdown','recording']);
    assert.equal(h.service.state?.sequence,3);const state=h.service.state!;state.media!.width=1;assert.equal(h.service.state?.media?.width,602);
    await assert.rejects(h.start(),/当前录屏/);await h.service.cancel();assert.equal(h.service.active,false);assert.equal(h.sink.aborted,1);
  });
  it('excludes paused time and freezes duration before the stop drain',async()=>{
    const h=harness();await h.start();const id=h.service.state!.id;
    h.tick(2000);await h.service.command(id,'pause');h.tick(5000);assert.equal(h.service.state?.elapsedMs,2000);
    await h.service.command(id,'resume');h.tick(3000);h.backend.stopGate=deferred<void>();const stopping=h.service.command(id,'finish');h.tick(900);
    assert.equal(h.service.state?.elapsedMs,5000);h.backend.stopGate.resolve();await stopping;assert.equal(h.service.artifact?.durationMs,5000);
    await h.service.cancel();
  });
  it('waits for final data and output completion, and coalesces duplicate stop',async()=>{
    const h=harness();await h.start();h.backend.stopGate=deferred<void>();h.sink.finishGate=deferred<void>();const id=h.service.state!.id;
    const a=h.service.command(id,'finish'),b=h.service.command(id,'finish');assert.equal(h.backend.stops,1);assert.equal(h.service.state?.status,'stopping');
    h.backend.stopGate.resolve();await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(h.sink.chunks,[0]);assert.equal(h.service.artifact,undefined);
    h.sink.finishGate.resolve();await Promise.all([a,b]);assert.equal(h.service.state?.status,'ready');assert.equal(h.backend.disposed,1);await h.service.cancel();
  });
  it('cancels in-flight preparation, ignores late events and permits a fresh session',async()=>{
    const h=harness();h.backend.prepareGate=deferred<RecordingMediaInfo>();const preparing=h.start();void preparing.catch(()=>{});
    await new Promise(resolve=>setImmediate(resolve));const oldId=h.service.state!.id;const oldEvents=h.backend.events!;
    await h.service.cancel();await assert.rejects(preparing);assert.equal(h.sink.aborted,0,'no file is opened before preparation succeeds');
    await assert.rejects(async()=>oldEvents.chunk(0,new Uint8Array([1])),/取消/);oldEvents.failed(new Error('late'));assert.equal(h.service.state?.status,'cancelled');
    h.backend.prepareGate=undefined;await h.start();assert.notEqual(h.service.state!.id,oldId);await assert.rejects(h.service.command(oldId,'finish'),/失效/);await h.service.cancel();
  });
  it('disposes an output that opens after cancellation',async()=>{
    const opening=deferred<VideoFileSink>(),h=harness({sink:()=>opening.promise});const preparing=h.start();void preparing.catch(()=>{});await new Promise(resolve=>setImmediate(resolve));const cancelling=h.service.cancel();
    opening.resolve(h.sink);await cancelling;await assert.rejects(preparing);assert.equal(h.sink.aborted,1);assert.ok(h.backend.events);
  });
  it('surfaces a backend fault once and releases media/output',async()=>{
    const h=harness();await h.start();h.backend.events!.failed(new Error('encoder failure'));await new Promise(resolve=>setImmediate(resolve));
    assert.equal(h.service.state?.status,'error');assert.equal(h.service.state?.error?.message,'encoder failure');assert.equal(h.backend.disposed,1);assert.equal(h.sink.aborted,1);
    h.backend.events!.failed(new Error('duplicate'));assert.equal(h.states.filter(s=>s.status==='error').length,1);await h.service.cancel();
  });
  it('keeps the mutex and reports cleanup failure until a successful retry',async()=>{
    const h=harness();await h.start();let blocked=true;h.sink.abort=async()=>{if(blocked)throw Error('file locked');h.sink.aborted++;};
    await assert.rejects(h.service.cancel(),/清理失败/);assert.equal(h.service.state?.status,'error');assert.equal(h.service.active,true);
    blocked=false;await h.service.cancel();assert.equal(h.service.active,false);assert.equal(h.service.state?.status,'cancelled');
  });
  it('cancels a live countdown and releases devices without starting a recorder',async()=>{
    const h=harness({countdownMs:3000});let starts=0;h.backend.start=async()=>{starts++;};const starting=h.start();void starting.catch(()=>{});
    await new Promise(resolve=>setImmediate(resolve));assert.equal(h.service.state?.status,'countdown');await h.service.cancel();await assert.rejects(starting);
    assert.equal(starts,0);assert.equal(h.backend.disposed,1);assert.equal(h.sink.aborted,1);assert.equal(h.service.active,false);
  });
  it('finalizes source interruption after an in-flight pause acknowledgement',async()=>{
    const h=harness();await h.start();const id=h.service.state!.id;h.tick(2000);h.backend.pauseGate=deferred<void>();const pausing=h.service.command(id,'pause');
    await assert.rejects(h.service.command(id,'pause'),/上一个/);const interrupted=h.service.interrupt('显示器已断开');assert.equal(h.backend.stops,0);
    h.backend.pauseGate.resolve();await Promise.all([pausing,interrupted]);assert.equal(h.backend.stops,1);assert.equal(h.service.state?.status,'ready');assert.equal(h.service.state?.message,'显示器已断开');assert.equal(h.service.artifact?.durationMs,2000);await h.service.cancel();
  });
  it('serializes mute changes, refuses unavailable inputs, and finalizes after mute acknowledgement',async()=>{
    const h=harness();h.backend.media={...media,audio:{systemAvailable:true,microphoneAvailable:false}};await h.start();const id=h.service.state!.id;
    await assert.rejects(h.service.setAudio(id,{systemEnabled:true,microphoneEnabled:true}),/录制前/);h.backend.audioGate=deferred<void>();const muting=h.service.setAudio(id,{systemEnabled:false,microphoneEnabled:false});
    await assert.rejects(h.service.command(id,'finish'),/上一个/);const interrupted=h.service.interrupt('锁屏');assert.equal(h.backend.stops,0);h.backend.audioGate.resolve();await Promise.all([muting,interrupted]);
    assert.deepEqual(h.service.state?.audio,{systemEnabled:false,microphoneEnabled:false});assert.equal(h.service.state?.status,'ready');await h.service.cancel();
  });
  it('aborts output and releases the capture mutex after a final disk write fails',async()=>{
    const h=harness();h.sink.append=async()=>{throw Error('disk full');};await h.start();await assert.rejects(h.service.command(h.service.state!.id,'finish'),/disk full/);
    assert.equal(h.service.state?.status,'error');assert.equal(h.service.state?.error?.message,'disk full');assert.equal(h.sink.aborted,1);assert.equal(h.service.artifact,undefined);assert.equal(h.service.active,false);await h.service.cancel();
  });
});
