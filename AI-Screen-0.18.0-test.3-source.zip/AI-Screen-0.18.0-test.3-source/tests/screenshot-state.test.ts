import { it } from 'node:test';
import assert from 'node:assert/strict';
import { screenshotTransition as next, type ScreenshotPhase } from '../src/shared/screenshot-state';
it('runs hover, select, annotate, process and recover without losing editability', () => {
  let state: ScreenshotPhase = 'idle';
  for (const event of ['START', 'POINTER_DOWN', 'SELECT', 'ANNOTATE', 'PROCESS', 'FAIL'] as const) state = next(state, event);
  assert.equal(state, 'selected');
  assert.equal(next(state, 'RESET'), 'window-hover');
  assert.equal(next('window-hover', 'CLOSE'), 'idle');
});
it('ignores selection changes while processing and permits cancellation', () => {
  assert.equal(next('ai-processing', 'POINTER_DOWN'), 'ai-processing');
  assert.equal(next('ai-processing', 'RESET'), 'window-hover');
  assert.equal(next('ai-processing', 'CLOSE'), 'idle');
  assert.equal(next('idle', 'SELECT'), 'idle');
});
it('permits drawing a new region outside the current annotation selection', () => {
  assert.equal(next(next('annotating', 'POINTER_DOWN'), 'SELECT'), 'selected');
});
