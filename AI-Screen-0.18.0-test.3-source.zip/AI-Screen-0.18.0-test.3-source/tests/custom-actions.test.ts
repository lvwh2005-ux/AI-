import { it } from 'node:test';
import assert from 'node:assert/strict';
import { settingsSchema } from '../src/shared/contracts';
import { customAction, expandPrompt } from '../src/shared/custom-actions';
import { TaskService } from '../src/main/services/tasks';
import { parseActionInput } from '../src/main/action-input';
import { buildMessages } from '../src/main/providers/compatible';
import type { AIRequest } from '../src/main/providers/types';

const item = { id: 'summary', label: '总结要点', prompt: '请用{{language}}总结截图。补充要求：{{question}}', enabled: true };
it('migrates older settings and validates custom action ids, duplicates and limits', () => {
  assert.deepEqual(settingsSchema.parse({}).customActions, []);
  assert.throws(() => settingsSchema.parse({ customActions: [item, item] }));
  assert.throws(() => settingsSchema.parse({ customActions: [{ ...item, id: '../bad' }] }));
  assert.throws(() => settingsSchema.parse({ customActions: [{ ...item, prompt: ' ' }] }));
  assert.throws(() => settingsSchema.parse({ customActions: Array.from({ length: 9 }, (_, i) => ({ ...item, id: `action-${i}` })) }));
});
it('resolves only enabled saved actions and substitutes supported variables once', () => {
  assert.equal(customAction([item], item.id), item);
  assert.throws(() => customAction([{ ...item, enabled: false }], item.id));
  assert.throws(() => customAction([item], 'missing'));
  assert.equal(expandPrompt('用{{language}} {{question}} {{unknown}}', '中文', '{{language}}'), '用中文 {{language}} {{unknown}}');
});
it('validates custom action routing before side effects', () => {
  assert.throws(() => parseActionInput({ action: 'custom', rect: { x: 0, y: 0, width: 20, height: 20 } }, 'capture'));
  assert.throws(() => parseActionInput({ action: 'ask', question: 'question', customActionId: item.id }, 'result'));
  assert.equal(parseActionInput({ action: 'custom', customActionId: item.id }, 'result').action, 'custom');
});
it('uses the saved custom prompt in AI requests, titles and conversation context', async () => {
  let received: AIRequest | undefined;
  const tasks = new TaskService({ value: settingsSchema.parse({ provider: 'compatible', customActions: [item] }), apiKey: async () => '' }, () => {}, async () => {}, () => ({ complete: async (request) => { received = request; return '总结结果'; } }));
  await tasks.run('custom', 'fixture-image', '简短一点', false, item.id);
  assert.equal(received?.customPrompt, '请用简体中文总结截图。补充要求：简短一点');
  assert.equal(tasks.state?.actionLabel, '总结要点');
  assert.equal(tasks.state?.customActionId, item.id);
  assert.equal(tasks.state?.status, 'done');
  assert.equal(tasks.state?.history[0].content, received?.customPrompt);
  assert.match(JSON.stringify(buildMessages(received!)), /请用简体中文总结截图/);
});
