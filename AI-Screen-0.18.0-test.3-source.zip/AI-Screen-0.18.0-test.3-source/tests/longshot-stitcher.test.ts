import test from 'node:test';
import assert from 'node:assert/strict';
import { LongshotStitcher, type BitmapFrame } from '../src/shared/longshot-stitcher';
import {referencePixel} from './preview-reference';

test('progress preview samples all accepted segments without consuming or changing the original image', () => {
  const source = textured(), stitcher = new LongshotStitcher();
  assert.deepEqual(stitcher.preview(), { width: 0, height: 0, data: new Uint8Array() });
  stitcher.push(crop(source, 0)); stitcher.push(crop(source, 130));
  const before = stitcher.bitmap(), preview = stitcher.preview(64, 100);
  assert.ok(preview.width <= 64 && preview.height <= 100);
  for (let y = 0; y < preview.height; y++) for (let x = 0; x < preview.width; x++) {
    const expected=referencePixel(before,{x:0,y:0,width:before.width,height:before.height},preview.width,preview.height,x,y),at=(y*preview.width+x)*4;
    for(let c=0;c<4;c++)assert.ok(Math.abs(preview.data[at+c]-expected[c])<=1);
  }
  preview.data.fill(0);
  assert.deepEqual(stitcher.bitmap(), before);
  assert.equal(stitcher.push(crop(source, 260)).kind, 'appended');
  stitcher.clear(); assert.equal(stitcher.preview().data.length, 0);
});

function textured(width = 128, height = 1600, seed = 17): BitmapFrame {
  const data = new Uint8Array(width * height * 4);
  let random = seed;
  for (let index = 0; index < data.length; index += 4) {
    random = Math.imul(random ^ (random >>> 13), 1597334677) + 12345 | 0;
    data[index] = random & 255; data[index + 1] = random >>> 8 & 255; data[index + 2] = random >>> 16 & 255; data[index + 3] = 255;
  }
  return { width, height, data };
}

function crop(source: BitmapFrame, y: number, height = 320): BitmapFrame {
  return { width: source.width, height, data: source.data.slice(y * source.width * 4, (y + height) * source.width * 4) };
}

function textPage(width = 320, height = 1800): BitmapFrame {
  const data = new Uint8Array(width * height * 4).fill(255);
  // Uneven text lines and colored bullets on a white page, with blank margins.
  for (let y = 12; y < height - 10; y += 29) {
    const line = Math.floor(y / 29);
    for (let yy = y; yy < y + 11; yy++) {
      for (let x = 21; x < Math.min(width - 20, 125 + (line * 31 % 165)); x++) {
        if ((x * 11 + line * 7) % 17 > 9 || yy === y + 5 && x % 13 < 4) continue;
        const index = (yy * width + x) * 4;
        data[index] = 40 + line % 50; data[index + 1] = 45 + line % 30; data[index + 2] = 50 + line % 60;
      }
    }
    for (let yy = y; yy < y + 8; yy++) for (let x = 10; x < 16; x++) {
      const index = (yy * width + x) * 4; data[index] = line * 19 % 256; data[index + 1] = 90; data[index + 2] = 180;
    }
  }
  return { width, height, data };
}

test('joins successive textured frames using exact original BGRA rows', () => {
  const source = textured(), stitcher = new LongshotStitcher();
  assert.equal(stitcher.push(crop(source, 0)).kind, 'initial');
  const second = stitcher.push(crop(source, 130));
  assert.deepEqual({ kind: second.kind, appendedRows: second.appendedRows, overlapRows: second.overlapRows }, { kind: 'appended', appendedRows: 130, overlapRows: 190 });
  assert.equal(stitcher.push(crop(source, 270)).kind, 'appended');
  assert.equal(stitcher.push(crop(source, 400)).kind, 'appended');
  assert.deepEqual(stitcher.bitmap(), crop(source, 0, 720));
});

test('accepts real-style dark text and color bands across several white-background frames', () => {
  const source = textPage(), stitcher = new LongshotStitcher();
  assert.equal(stitcher.push(crop(source, 0, 440)).kind, 'initial');
  assert.equal(stitcher.push(crop(source, 171, 440)).kind, 'appended');
  assert.equal(stitcher.push(crop(source, 333, 440)).kind, 'appended');
  assert.deepEqual(stitcher.bitmap(), crop(source, 0, 773));
});

test('deduplicates repeated frames and owns accepted and returned pixel buffers', () => {
  const source = textured(), first = crop(source, 0), stitcher = new LongshotStitcher();
  stitcher.push(first);
  assert.equal(stitcher.push(crop(source, 0)).kind, 'duplicate');
  first.data.fill(0);
  const saved = stitcher.bitmap(); saved.data.fill(0);
  assert.deepEqual(stitcher.bitmap(), crop(source, 0));
  assert.equal(stitcher.push(crop(source, 140)).kind, 'appended');
  assert.equal(stitcher.push(crop(source, 140)).kind, 'duplicate');
  assert.equal(stitcher.bitmap().height, 460);
  const nodeBuffer = Buffer.from(crop(source, 0).data), bufferInput = new LongshotStitcher();
  bufferInput.push({ width: source.width, height: 320, data: nodeBuffer });
  nodeBuffer.fill(0);
  assert.deepEqual(bufferInput.bitmap(), crop(source, 0));
});

test('prepends reverse scrolling while missing overlap, resized capture and horizontal movement preserve output', () => {
  const source = textured(), stitcher = new LongshotStitcher();
  stitcher.push(crop(source, 200));
  assert.equal(stitcher.push(crop(source, 100)).addedTop,100);
  const original = crop(source,100,420);assert.deepEqual(stitcher.bitmap(),original);
  assert.equal(stitcher.push(crop(source, 800)).kind, 'rejected');
  assert.equal(stitcher.push(crop(source, 300, 319)).kind, 'rejected');
  const shifted = crop(source, 320);
  for (let y = 0; y < shifted.height; y++) {
    const start = y * shifted.width * 4;
    shifted.data.copyWithin(start, start + 4, start + shifted.width * 4);
  }
  assert.equal(stitcher.push(shifted).kind, 'rejected');
  assert.deepEqual(stitcher.bitmap(), original);
  assert.equal(stitcher.push(crop(source, 320)).kind, 'appended');
  assert.deepEqual(stitcher.bitmap(),crop(source,100,540));
});

test('rejects insufficient overlap, flat ambiguity and repeated horizontal strip patterns', () => {
  const source = textured(), stitcher = new LongshotStitcher();
  stitcher.push(crop(source, 0));
  assert.equal(stitcher.push(crop(source, 250)).kind, 'rejected');
  const flat = new LongshotStitcher();
  flat.push({ width: 128, height: 320, data: new Uint8Array(128 * 320 * 4).fill(255) });
  const almostFlat = new Uint8Array(128 * 320 * 4).fill(255); almostFlat[almostFlat.length - 100] = 0;
  assert.equal(flat.push({ width: 128, height: 320, data: almostFlat }).kind, 'rejected');
  const repeat = new LongshotStitcher(), page = textured();
  for (let y = 0; y < page.height; y++) page.data.set(page.data.subarray((y % 16) * page.width * 4, (y % 16 + 1) * page.width * 4), y * page.width * 4);
  repeat.push(crop(page, 0));
  assert.equal(repeat.push(crop(page, 5)).kind, 'rejected');
});

test('keeps a fixed header/footer once and still rejects animated overlapping content', () => {
  const source = textured();
  for (const footer of [false, true]) {
    const stitcher = new LongshotStitcher(), first = crop(source, 0), second = crop(source, 120);
    const start = footer ? first.height - 24 : 0;
    second.data.set(first.data.subarray(start * first.width * 4, (start + 24) * first.width * 4), start * first.width * 4);
    stitcher.push(first);
    const result = stitcher.push(second);
    assert.equal(result.kind, 'appended');
    assert.equal(footer ? result.fixedBottom : result.fixedTop, 24);
    const expected = crop(source, 0, 440);
    if (footer) {
      expected.data.set(source.data.subarray(296 * source.width * 4, 416 * source.width * 4), 296 * source.width * 4);
      expected.data.set(first.data.subarray(296 * source.width * 4), 416 * source.width * 4);
    }
    assert.deepEqual(stitcher.bitmap(), expected);
  }
  const stitcher = new LongshotStitcher(); stitcher.push(crop(source, 0));
  const animated = crop(source, 120);
  for (let y = 60; y < 90; y++) animated.data.fill(255, (y * animated.width + 30) * 4, (y * animated.width + 70) * 4);
  assert.equal(stitcher.push(animated).kind, 'rejected');
  assert.equal(stitcher.push(crop(source, 120)).kind, 'appended');
});

test('checks unsampled pixels throughout the overlap before accepting a coarse candidate', () => {
  const source = textured(320), stitcher = new LongshotStitcher();
  stitcher.push(crop(source, 0));
  const modified = crop(source, 120);
  // x=1 lies between coarse probes, so only full-pixel verification sees it.
  for (let y = 0; y < 190; y++) modified.data[(y * modified.width + 1) * 4] ^= 255;
  assert.equal(stitcher.push(modified).kind, 'rejected');
  assert.equal(stitcher.bitmap().height, 320);
  assert.equal(stitcher.push(crop(source, 120)).kind, 'appended');
});

test('enforces height and retained-memory limits, validates input and clears state', () => {
  const source = textured(), byHeight = new LongshotStitcher({ maxHeight: 400 });
  byHeight.push(crop(source, 0));
  assert.equal(byHeight.push(crop(source, 120)).kind, 'limit');
  assert.equal(byHeight.bitmap().height, 320);
  const bytes = source.width * 320 * 4, byMemory = new LongshotStitcher({ maxBytes: bytes * 2 + source.width * 4 * 100 });
  byMemory.push(crop(source, 0));
  assert.equal(byMemory.push(crop(source, 120)).kind, 'limit');
  assert.equal(byMemory.bitmap().height, 320);
  assert.equal(byMemory.push({ width: 2, height: 2, data: new Uint8Array(3) }).kind, 'rejected');
  assert.equal(new LongshotStitcher().push({ width: 8193, height: 1, data: new Uint8Array(8193 * 4) }).kind, 'limit');
  assert.throws(() => new LongshotStitcher({ maxHeight: 0 }), RangeError);
  byHeight.clear();
  assert.deepEqual(byHeight.bitmap(), { width: 0, height: 0, data: new Uint8Array(0) });
  assert.equal(byHeight.push(crop(source, 120)).kind, 'initial');
});
