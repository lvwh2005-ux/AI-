import{it}from'node:test';import assert from'node:assert/strict';
import{microphoneError}from'../src/renderer/recording/microphone';
import{recordingOptionsSchema}from'../src/shared/recording/contracts';
it('reports distinct microphone failure causes without blaming speaker mute',()=>{
  for(const[name,expected]of[['NotAllowedError','权限被拒绝'],['NotFoundError','没有找到'],['OverconstrainedError','已不可用'],['NotReadableError','独占']]){
    const error=new Error('browser message');error.name=name;assert.ok(microphoneError(error).includes(expected));
  }
  assert.equal(recordingOptionsSchema.parse({microphoneDeviceId:'input-123'}).microphoneDeviceId,'input-123');
  assert.throws(()=>recordingOptionsSchema.parse({microphoneDeviceId:''}));assert.throws(()=>recordingOptionsSchema.parse({microphoneDeviceId:'x'.repeat(513)}));
});
