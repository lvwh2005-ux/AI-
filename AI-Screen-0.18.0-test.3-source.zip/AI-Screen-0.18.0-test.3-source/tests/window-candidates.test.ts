import test from 'node:test';
import assert from 'node:assert/strict';
import { clipWindowToDisplay, pickWindow, type DetectedWindow } from '../src/shared/window-candidates';

const item = (id: string, x: number, y: number, width: number, height: number): DetectedWindow => ({ id, title: id, bounds: { x, y, width, height } });

test('native negative-coordinate windows map to monitor-local DIPs', () => {
  const candidate = item('1', -2400, 150, 900, 600);
  const clipped = clipWindowToDisplay(candidate, { x: -1707, y: 0, width: 1707, height: 960 }, { x: -2560, y: 0, width: 2560, height: 1440 });
  assert.ok(clipped);
  assert.equal(clipped.bounds.x, 160 * 1707 / 2560);
  assert.equal(clipped.bounds.y, 100);
  assert.equal(clipped.bounds.width, 900 * 1707 / 2560);
  assert.equal(clipped.bounds.height, 400);
});

test('spanning windows clip independently across different display scales', () => {
  const candidate = item('2', -150, 100, 450, 450);
  const left = clipWindowToDisplay(candidate, { x: -1280, y: 0, width: 1280, height: 720 }, { x: -1920, y: 0, width: 1920, height: 1080 })?.bounds;
  assert.ok(left);
  assert.ok(Math.abs(left.y - 100 / 1.5) < 1e-9);
  assert.deepEqual({ ...left, y: 0 }, { x: 1180, y: 0, width: 100, height: 300 });
  assert.deepEqual(clipWindowToDisplay(candidate, { x: 0, y: 0, width: 1920, height: 1080 }, { x: 0, y: 0, width: 1920, height: 1080 })?.bounds, { x: 0, y: 100, width: 300, height: 450 });
});

test('candidate picking respects occlusion, with exclusive right and bottom edges', () => {
  const windows = [item('front', 40, 40, 80, 80), item('back', 0, 0, 200, 200)];
  assert.equal(pickWindow(windows, { x: 40, y: 40 })?.id, 'front');
  assert.equal(pickWindow(windows, { x: 119.9, y: 119.9 })?.id, 'front');
  assert.equal(pickWindow(windows, { x: 120, y: 120 })?.id, 'back');
  assert.equal(pickWindow(windows, { x: 200, y: 200 }), undefined);
});

test('off-monitor, touching-only and invalid rectangles never become candidates', () => {
  const monitor = { x: 0, y: 0, width: 100, height: 100 };
  assert.equal(clipWindowToDisplay(item('1', 100, 0, 10, 10), monitor, monitor), undefined);
  assert.equal(clipWindowToDisplay(item('1', 0, 0, Infinity, 10), monitor, monitor), undefined);
  assert.equal(clipWindowToDisplay(item('1', 0, 0, 10, 10), monitor, { ...monitor, width: 0 }), undefined);
  assert.equal(pickWindow([item('1', 0, 0, 10, 10)], { x: NaN, y: 0 }), undefined);
});
