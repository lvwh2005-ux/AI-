import { it } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { saveLongshotPNG } from '../src/main/services/longshot-file';
it('replaces the chosen file only on completion and cleans cancelled temporary data', async () => {
  const directory = await mkdtemp(path.join(process.cwd(), '.runtime', 'longshot-file-'));
  try {
    const destination = path.join(directory, 'chosen.png');
    await writeFile(destination, 'original');
    let checks = 0;
    await assert.rejects(saveLongshotPNG(destination, new Uint8Array([1, 2, 3]), () => ++checks === 1), /取消/);
    assert.equal(await readFile(destination, 'utf8'), 'original');
    assert.deepEqual(await readdir(directory), ['chosen.png']);
    await saveLongshotPNG(destination, new Uint8Array([4, 5, 6]));
    assert.deepEqual([...await readFile(destination)], [4, 5, 6]);
    assert.deepEqual(await readdir(directory), ['chosen.png']);
  } finally {
    assert.ok(path.resolve(directory).startsWith(path.resolve('.runtime') + path.sep));
    await rm(directory, { recursive: true, force: true });
  }
});
