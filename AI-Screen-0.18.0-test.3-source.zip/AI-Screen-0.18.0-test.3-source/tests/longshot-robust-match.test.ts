import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import {VerticalMatcher} from '../src/shared/scroll-capture/vertical-matcher';
import {verifyTranslation} from '../src/shared/scroll-capture/translation-verifier';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';

function page(offset:number,height=440,width=320):BitmapFrame {
  const data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}
function patch(frame:BitmapFrame,x:number,y:number,width=8,height=16){
  for(let row=y;row<y+height;row++)for(let col=x;col<x+width;col++){
    const at=(row*frame.width+col)*4;frame.data[at]^=255;frame.data[at+1]^=255;frame.data[at+2]^=255;
  }return frame;
}

test('one small overlapping caret is tolerated using distributed anchors; output pixels remain original',()=>{
  const first=page(0),next=patch(page(120),120,80),engine=new ScrollCaptureEngine();engine.push(first);
  assert.equal(new VerticalMatcher({allowLocalized:false}).match(first,next).kind,'rejected');
  const result=engine.push(next);
  assert.equal(result.kind,'appended');assert.equal(result.verification,'localized');assert.equal(result.ignoredPixels,128);
  assert.deepEqual(engine.bitmap(),page(0,560),'overlap patch is never used to repaint accepted history');
  next.data.fill(0);assert.deepEqual(engine.bitmap(),page(0,560),'accepted source storage is owned');
  assert.equal(engine.push(page(240)).kind,'appended');assert.deepEqual(engine.bitmap(),page(0,680));
});

test('stationary blinking content deduplicates without growth or changing the clean reference',()=>{
  const engine=new ScrollCaptureEngine();engine.push(page(0));
  for(let i=0;i<3;i++){
    const result=engine.push(patch(page(0),100,180));assert.equal(result.kind,'duplicate');assert.equal(result.verification,'localized');
  }
  assert.deepEqual(engine.bitmap(),page(0));assert.equal(engine.push(page(120)).kind,'appended');
  assert.deepEqual(engine.bitmap(),page(0,560));
});

test('a localized difference near the append seam is rejected, then a clean frame recovers without gaps',()=>{
  const engine=new ScrollCaptureEngine();engine.push(page(0));
  assert.equal(engine.push(patch(page(120),100,310)).kind,'rejected');assert.deepEqual(engine.bitmap(),page(0));
  const good=engine.push(page(120));assert.equal(good.kind,'appended');assert.equal(good.recoveredAfter,1);
  assert.deepEqual(engine.bitmap(),page(0,560));
});

test('long thin changes, separated patches, broad animations and horizontal motion remain rejected',()=>{
  const bad=[patch(page(120),1,40,1,190),patch(patch(page(120),40,70,3,8),220,90,3,8),patch(page(120),80,80,40,30)];
  const horizontal=page(120);for(let y=0;y<440;y++)horizontal.data.copyWithin(y*320*4,(y*320+1)*4,(y+1)*320*4);bad.push(horizontal);
  for(const frame of bad){const engine=new ScrollCaptureEngine();engine.push(page(0));assert.equal(engine.push(frame).kind,'rejected');assert.deepEqual(engine.bitmap(),page(0));}
});

test('distributed low-contrast changes cannot hide behind one small dynamic patch',()=>{
  const first=page(0),next=patch(page(120),100,80,3,8);
  for(let at=0;at<next.data.length;at+=4)next.data[at]=Math.min(255,next.data[at]+4);
  assert.equal(verifyTranslation(first,next,120),undefined);
});

test('localized fallback needs texture in separated horizontal and vertical zones',()=>{
  const first=page(0),next=page(120);
  for(const frame of [first,next])for(let y=0;y<frame.height;y++)frame.data.fill(255,(y*320+65)*4,(y+1)*320*4);
  patch(next,150,80,3,8);
  assert.equal(verifyTranslation(first,next,120),undefined,'one narrow column cannot certify the whole region');
});

test('ambiguous periodic content and insufficient overlap cannot become valid via the fallback',()=>{
  const first=page(0),next=page(0);
  for(const frame of [first,next])for(let y=0;y<440;y++)frame.data.set(first.data.subarray(y%16*320*4,(y%16+1)*320*4),y*320*4);
  patch(next,120,80,3,8);assert.equal(new VerticalMatcher().match(first,next).kind,'rejected');
  const engine=new ScrollCaptureEngine();engine.push(page(0));assert.equal(engine.push(patch(page(380),100,25,3,8)).kind,'rejected');
});

function chrome(offset:number):BitmapFrame{
  const frame=page(offset,480);
  const fixed=page(8000,480);
  frame.data.set(fixed.data.subarray(0,60*320*4));frame.data.set(fixed.data.subarray(420*320*4),420*320*4);
  return frame;
}
test('small changes inside a locked fixed header are tolerated while its geometry and output stay fixed',()=>{
  const engine=new ScrollCaptureEngine();engine.push(chrome(0));
  const locked=engine.push(chrome(100));assert.equal(locked.kind,'appended');assert.equal(locked.fixedTop,60);assert.equal(locked.fixedBottom,60);
  const snapshot=engine.bitmap(),next=patch(chrome(180),90,20,3,10),result=engine.push(next);
  assert.equal(result.kind,'appended');assert.equal(result.verification,'localized');assert.equal(result.ignoredPixels,30);
  const output=engine.bitmap();assert.deepEqual(output.data.subarray(0,60*320*4),snapshot.data.subarray(0,60*320*4));
  assert.deepEqual(output.data.subarray(output.data.length-60*320*4),snapshot.data.subarray(snapshot.data.length-60*320*4));
  const shifted=chrome(240);shifted.data.set(page(1234,1).data,59*320*4);
  assert.equal(engine.push(shifted).reasonCode,'fixed-region-changed');assert.deepEqual(engine.bitmap(),output);
});

test('lost overlap never moves the reference; returning to the last viewport clears recovery and deduplicates',()=>{
  const engine=new ScrollCaptureEngine();engine.push(page(0));engine.push(page(100));const saved=engine.bitmap();
  for(let i=0;i<3;i++){const result=engine.push(page(900+i*100));assert.equal(result.kind,'rejected');assert.equal(result.consecutiveRejections,i+1);assert.deepEqual(engine.bitmap(),saved);}
  const back=engine.push(page(100));assert.equal(back.kind,'duplicate');assert.equal(back.recoveredAfter,3);assert.equal(back.consecutiveRejections,0);
  assert.equal(engine.push(page(180)).kind,'appended');assert.deepEqual(engine.bitmap(),page(0,620));
});

test('a blinking fixed header on the first scroll can offer a body crop, only explicit confirmation changes output',()=>{
  const engine=new ScrollCaptureEngine();engine.push(chrome(0));const saved=engine.bitmap();
  const proposal=engine.push(patch(chrome(100),145,20,3,10));assert.equal(proposal.kind,'review');
  assert.deepEqual(proposal.regionCandidate,{x:0,y:60,width:320,height:360});assert.deepEqual(engine.bitmap(),saved);
  const accepted=engine.confirmRegion();assert.equal(accepted.kind,'appended');assert.equal(accepted.width,320);assert.equal(accepted.height,460);
  const original=page(0,520).data.subarray(60*320*4,520*320*4);
  assert.deepEqual(engine.bitmap().data,original);
  assert.equal(engine.push(chrome(180)).kind,'appended');
});

test('a connected later viewport also recovers; new sessions reset recovery metadata and limits remain atomic',()=>{
  const engine=new ScrollCaptureEngine({maxHeight:600});engine.push(page(0));engine.push(page(900));
  const joined=engine.push(page(100));assert.equal(joined.kind,'appended');assert.equal(joined.recoveredAfter,1);
  assert.equal(engine.push(page(200)).kind,'limit');assert.deepEqual(engine.bitmap(),page(0,540));
  engine.clear();const fresh=engine.push(page(0));assert.equal(fresh.consecutiveRejections,0);assert.equal(fresh.recoveredAfter,undefined);
});

test('a bounded local change at 2560×1600 preserves the complete native-resolution result',()=>{
  const first=page(0,1600,2560),next=patch(page(600,1600,2560),1100,240,24,40),engine=new ScrollCaptureEngine();
  engine.push(first);const result=engine.push(next);assert.equal(result.kind,'appended');assert.equal(result.verification,'localized');assert.equal(result.ignoredPixels,960);
  assert.deepEqual(engine.bitmap(),page(0,2200,2560));
});

test('varied resolutions accept a local change, reject a missing viewport and deduplicate backward revisits',()=>{
  for(let i=0;i<18;i++){
    const width=[128,320,640][i%3],height=[320,440,720][i%3],offset=i*17,step=Math.floor(height*.3),engine=new ScrollCaptureEngine();
    engine.push(page(offset,height,width));
    const frame=patch(page(offset+step,height,width),Math.floor(width*.4),Math.floor((height-step)*.4),3,12);
    assert.equal(engine.push(frame).kind,'appended');const output=engine.bitmap();assert.deepEqual(output,page(offset,height+step,width));
    assert.equal(engine.push(page(offset+height*3,height,width)).kind,'rejected');
    assert.equal(engine.push(page(offset,height,width)).kind,'duplicate');assert.deepEqual(engine.bitmap(),output);
  }
});
