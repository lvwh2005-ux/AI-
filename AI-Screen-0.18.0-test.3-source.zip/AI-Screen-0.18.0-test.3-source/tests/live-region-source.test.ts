import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { NativeImage } from 'electron';
import { LiveRegionSource } from '../src/main/services/live-region-source';
import { longshotControlsBounds, longshotPanelBounds, LONGSHOT_CONTROL_HEIGHT, LONGSHOT_CONTROL_GAP } from '../src/main/longshot-window';
import type { CaptureDisplay } from '../src/shared/geometry';

const display = (): CaptureDisplay => ({ id: 'left', label: '副屏', bounds: { x: -1536, y: -240, width: 1536, height: 864 }, scaleFactor: 1.25 });
const region = { x: 10, y: 20, width: 100, height: 50 };
function bitmap(width: number, height: number) {
  return { isEmpty: () => false, getSize: () => ({ width, height }), crop: (rect: unknown) => ({ rect, size: { width, height } }) } as unknown as NativeImage;
}

describe('live region source', () => {
  it('isolated crops retain source coordinates, retry counters and explicit lifecycle',async()=>{
    let closed=0;
    const source=new LiveRegionSource('left',region,{displays:()=>[display()],nativeSize:()=>({width:1920,height:1080}),
      sources:async()=>assert.fail('parent must not enumerate desktop sources'),remoteRetries:()=>1,close:()=>{closed++;},
      readRegion:async()=>({image:bitmap(126,63),bitmapSize:{width:1920,height:1080}})});
    await source.read(new AbortController().signal);
    assert.deepEqual(source.capturedBitmapSize,{width:1920,height:1080});assert.equal(source.retryCount,1);
    assert.deepEqual(source.globalRectForPixels({x:0,y:0,width:20,height:10}),{x:-1526.4,y:-220,width:16,height:8});
    source.dispose();source.dispose();assert.equal(closed,1);await assert.rejects(source.read(new AbortController().signal),/已结束/);
  });
  it('rejects isolated images with a wrong native or crop size before publishing pixels',async()=>{
    for(const kind of ['native','crop']){
      const source=new LiveRegionSource('left',region,{displays:()=>[display()],nativeSize:()=>({width:1920,height:1080}),sources:async()=>[],
        readRegion:async()=>({image:bitmap(kind==='crop'?125:126,63),bitmapSize:{width:kind==='native'?1921:1920,height:1080}})});
      await assert.rejects(source.read(new AbortController().signal),/原生分辨率|选区尺寸/);assert.equal(source.capturedBitmapSize,undefined);
    }
  });
  it('retries a missing or empty native image once with a fresh source and unchanged pixel request',async()=>{
    for(const kind of ['missing','empty']){
      let reads=0;const sizes:unknown[]=[];
      const source=new LiveRegionSource('left',region,{displays:()=>[display()],nativeSize:()=>({width:1920,height:1080}),sources:async size=>{
        sizes.push(size);reads++;
        if(reads===1)return kind==='missing'?[]:[{display_id:'left',thumbnail:{isEmpty:()=>true} as NativeImage}];
        return[{display_id:'left',thumbnail:bitmap(1920,1080)}];
      }});
      const image=await source.read(new AbortController().signal);
      assert.deepEqual(image,{rect:{x:12,y:25,width:126,height:63},size:{width:1920,height:1080}});
      assert.equal(reads,2);assert.equal(source.retryCount,1);assert.deepEqual(sizes,[{width:1920,height:1080},{width:1920,height:1080}]);
    }
  });
  it('limits empty-source retries and never retries arbitrary errors or resampled pixels',async()=>{
    let reads=0;const dependencies={displays:()=>[display()],sources:async()=>{reads++;return[];}};
    const source=new LiveRegionSource('left',region,dependencies);
    await assert.rejects(source.read(new AbortController().signal),/重新读取后仍/);assert.equal(reads,2);assert.equal(source.retryCount,1);
    reads=0;const failed=new LiveRegionSource('left',region,{...dependencies,sources:async()=>{reads++;throw new Error('synthetic source failure');}});
    await assert.rejects(failed.read(new AbortController().signal),/synthetic source failure/);assert.equal(reads,1);assert.equal(failed.retryCount,0);
    const scaled=new LiveRegionSource('left',region,{...dependencies,nativeSize:()=>({width:1920,height:1080}),sources:async()=>{reads++;return[{display_id:'left',thumbnail:bitmap(960,540)}];}});
    reads=0;await assert.rejects(scaled.read(new AbortController().signal),/原生分辨率/);assert.equal(reads,1);assert.equal(scaled.retryCount,0);
  });
  it('cancels a delayed reread without issuing another native request',async()=>{
    const abort=new AbortController();let reads=0;
    const source=new LiveRegionSource('left',region,{displays:()=>[display()],sources:async()=>{reads++;return[];}});
    const pending=source.read(abort.signal);await new Promise(resolve=>setImmediate(resolve));abort.abort();
    await assert.rejects(pending,{name:'AbortError'});assert.equal(reads,1);assert.equal(source.retryCount,0);
  });
  it('detects display changes during retry delay rather than reading different coordinates',async()=>{
    let monitor=display(),reads=0;
    const source=new LiveRegionSource('left',region,{displays:()=>[monitor],sources:async()=>{reads++;return[];}});
    const pending=source.read(new AbortController().signal);await new Promise(resolve=>setImmediate(resolve));monitor={...monitor,scaleFactor:2};
    await assert.rejects(pending,/缩放已变化/);assert.equal(reads,1);assert.equal(source.retryCount,0);
  });
  it('maps confirmed body pixels back through the actual bitmap with negative origins', async () => {
    const source=new LiveRegionSource('left',region,{displays:()=>[display()],sources:async()=>[{display_id:'left',thumbnail:bitmap(960,540)}]});
    assert.throws(()=>source.globalRectForPixels({x:0,y:0,width:1,height:1}),/尚未/);
    await source.read(new AbortController().signal);
    assert.deepEqual(source.globalRectForPixels({x:3,y:4,width:20,height:10}),{x:-1521.6,y:-214.4,width:32,height:16});
    assert.throws(()=>source.globalRectForPixels({x:60,y:0,width:20,height:10}),/超出/);
  });
  it('captures a fresh source per read and crops actual bitmap pixels with negative display origins', async () => {
    let reads = 0;
    const sizes: unknown[] = [];
    const source = new LiveRegionSource('left', region, {
      displays: () => [display()], sources: async (size) => {
        sizes.push(size); reads++;
        return [{ display_id: 'other', thumbnail: bitmap(1, 1) }, { display_id: 'left', thumbnail: bitmap(960, 540) }];
      },
    });
    assert.equal(source.frameBytes,126*63*4,'reserve physical crop pixels including fractional edge rounding');
    assert.deepEqual(source.globalRect, { ...region, x: -1526, y: -220 });
    const copy = source.globalRect; copy.x = 1;
    assert.equal(source.globalRect.x, -1526);
    for (let i = 0; i < 2; i++) assert.deepEqual(await source.read(new AbortController().signal), { rect: { x: 6, y: 12, width: 63, height: 32 }, size: { width: 960, height: 540 } });
    assert.equal(source.frameBytes,63*32*4,'later reservations follow validated actual bitmap dimensions');
    assert.equal(reads, 2);
    assert.deepEqual(sizes, [{ width: 1920, height: 1080 }, { width: 1920, height: 1080 }]);
  });

  it('rejects empty, non-finite, missing-display and cross-screen regions', () => {
    const dependencies = { displays: () => [display()], sources: async () => [] };
    for (const rect of [{ ...region, x: -1 }, { ...region, width: 0 }, { ...region, x: 1530 }, { ...region, height: Infinity }]) {
      assert.throws(() => new LiveRegionSource('left', rect, dependencies), /完整位于/);
    }
    assert.throws(() => new LiveRegionSource('missing', region, dependencies), /断开/);
  });

  it('does not read an already cancelled source or return an in-flight cancelled image', async () => {
    let reads = 0;
    let release!: (value: { display_id: string; thumbnail: NativeImage }[]) => void;
    const source = new LiveRegionSource('left', region, {
      displays: () => [display()], sources: () => { reads++; return new Promise((resolve) => { release = resolve; }); },
    });
    const cancelled = new AbortController(); cancelled.abort();
    await assert.rejects(source.read(cancelled.signal), { name: 'AbortError' });
    assert.equal(reads, 0);
    const running = new AbortController();
    const pending = source.read(running.signal); running.abort();
    release([{ display_id: 'left', thumbnail: bitmap(1920, 1080) }]);
    await assert.rejects(pending, { name: 'AbortError' });
    assert.equal(reads, 1);
  });

  it('detects display geometry or scale changes before and after enumeration', async () => {
    for (const key of ['x', 'y', 'width', 'height', 'scaleFactor'] as const) {
      let current = display();
      let reads = 0;
      const source = new LiveRegionSource('left', region, { displays: () => [current], sources: async () => { reads++; return []; } });
      if (key === 'scaleFactor') current.scaleFactor = 2;
      else current.bounds[key] += 1;
      await assert.rejects(source.read(new AbortController().signal), /缩放已变化/);
      assert.equal(reads, 0);
    }
    let current = display();
    const source = new LiveRegionSource('left', region, {
      displays: () => [current], sources: async () => {
        current = { ...current, scaleFactor: 2 };
        return [{ display_id: 'left', thumbnail: bitmap(1920, 1080) }];
      },
    });
    await assert.rejects(source.read(new AbortController().signal), /缩放已变化/);
  });

  it('rejects disconnects and empty display sources rather than selecting another screen', async () => {
    let connected = true;
    const source = new LiveRegionSource('left', region, {
      displays: () => connected ? [display()] : [], sources: async () => { connected = false; return []; },
    });
    await assert.rejects(source.read(new AbortController().signal), /断开/);
    const other = new LiveRegionSource('left', region, { displays: () => [display()], sources: async () => [{ display_id: 'other', thumbnail: bitmap(1920, 1080) }] });
    await assert.rejects(other.read(new AbortController().signal), /无法读取/);
  });

  it('stops when native thumbnail resolution changes between frames', async () => {
    let width = 1920;
    const source = new LiveRegionSource('left', region, {
      displays: () => [display()], sources: async () => [{ display_id: 'left', thumbnail: bitmap(width, 1080) }],
    });
    await source.read(new AbortController().signal);
    width = 960;
    await assert.rejects(source.read(new AbortController().signal), /分辨率已变化/);
  });
  it('uses exact native pixels instead of rounded DIPs and rejects resampled sources', async () => {
    const monitor = { ...display(), bounds: { x: 0, y: 0, width: 1707, height: 1067 }, scaleFactor: 1.5 };
    let requested: unknown, returnedWidth = 2560;
    const source = new LiveRegionSource('left', region, {
      displays: () => [monitor], nativeSize: () => ({ width: 2560, height: 1600 }),
      sources: async (size) => { requested = size; return [{ display_id: 'left', thumbnail: bitmap(returnedWidth, 1600) }]; },
    });
    assert.equal(source.frameBytes,151*76*4,'use exact native pixels rather than rounded DIP×scale');
    await source.read(new AbortController().signal);
    assert.deepEqual(requested, { width: 2560, height: 1600 });
    returnedWidth = 2561;
    await assert.rejects(source.read(new AbortController().signal), /原生分辨率/);
    assert.throws(() => new LiveRegionSource('left', region, { displays: () => [monitor], nativeSize: () => undefined, sources: async () => [] }), /原生像素尺寸/);
  });
});

describe('longshot control placement', () => {
  it('keeps a full-screen collection panel visible without covering the scrolling centre', () => {
    const area = { x: -1707, y: -120, width: 1707, height: 1027 };
    const bounds = longshotPanelBounds(area, area);
    assert.ok(bounds.x >= area.x && bounds.y >= area.y);
    assert.ok(bounds.x + bounds.width <= area.x + area.width && bounds.y + bounds.height <= area.y + area.height);
    const centre = { x: area.x + area.width / 2, y: area.y + area.height / 2 };
    assert.ok(centre.x < bounds.x || centre.x >= bounds.x + bounds.width || centre.y < bounds.y || centre.y >= bounds.y + bounds.height);
  });
  it('keeps controls completely outside the captured region and inside a negative-coordinate work area', () => {
    const area = { x: -1536, y: -240, width: 1536, height: 864 };
    for (const target of [
      { x: -1400, y: -200, width: 800, height: 300 },
      { x: -1300, y: 100, width: 800, height: 500 },
      { x: -1536, y: -240, width: 1000, height: 864 },
    ]) {
      const bounds = longshotControlsBounds(target, area);
      assert.ok(bounds);
      assert.ok(bounds.x >= area.x && bounds.y >= area.y);
      assert.ok(bounds.x + bounds.width <= area.x + area.width && bounds.y + bounds.height <= area.y + area.height);
      assert.ok(bounds.x + bounds.width <= target.x || bounds.x >= target.x + target.width || bounds.y + bounds.height <= target.y || bounds.y >= target.y + target.height);
    }
  });

  it('uses compact controls when needed and returns no placement for a full-screen capture', () => {
    // Only the compact width fits, with exactly enough vertical room for the
    // current control height and its clearance below the selected content.
    const target = { x: 0, y: 0, width: 380, height: 150 };
    const area = { x: 0, y: 0, width: 400, height: target.height + LONGSHOT_CONTROL_GAP + LONGSHOT_CONTROL_HEIGHT };
    const compact = longshotControlsBounds(target, area);
    assert.deepEqual(compact, { x: 20, y: target.height + LONGSHOT_CONTROL_GAP, width: 360, height: LONGSHOT_CONTROL_HEIGHT });
    assert.ok(compact.y + compact.height <= area.height && compact.y >= target.height + LONGSHOT_CONTROL_GAP);
    assert.equal(longshotControlsBounds(target, { ...area, height: area.height - 1 }), undefined);
    assert.equal(longshotControlsBounds({ x: 0, y: 0, width: 1920, height: 1080 }, { x: 0, y: 0, width: 1920, height: 1040 }), undefined);
    assert.equal(longshotControlsBounds({ x: 0, y: 0, width: 50, height: 50 }, { x: 0, y: 0, width: 300, height: 300 }), undefined);
  });

  it('can place controls on a separate display without intersecting the target', () => {
    const bounds = longshotControlsBounds({ x: 0, y: 0, width: 1920, height: 1080 }, { x: 2400, y: 0, width: 1280, height: 720 });
    assert.ok(bounds);
    assert.equal(bounds.x, 2400);
    assert.ok(bounds.y >= 0 && bounds.y + bounds.height <= 720);
  });
});
