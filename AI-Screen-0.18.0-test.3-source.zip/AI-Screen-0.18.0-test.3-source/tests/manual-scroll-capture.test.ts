import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ScrollCaptureEngine } from '../src/shared/scroll-capture/engine';
import type { BitmapFrame, PixelRegion } from '../src/shared/scroll-capture/types';

function pixel(x: number, y: number, seed = 0) {
  let n = Math.imul((y + seed + 1) ^ 0x6a09e667, 0x45d9f3b) ^ Math.imul(x + 7, 0x119de1f3);
  n = Math.imul(n ^ n >>> 16, 0x45d9f3b);
  return [n & 255, n >>> 8 & 255, n >>> 16 & 255, 255];
}
const body = {x:96,y:36,width:336,height:328};
function page(offset: number, chrome = false): BitmapFrame {
  const width = 480, height = 420, data = new Uint8Array(width * height * 4);
  for (let y=0;y<height;y++) for (let x=0;x<width;x++) {
    const inside = x>=body.x && x<body.x+body.width && y>=body.y && y<body.y+body.height;
    data.set(chrome && !inside ? pixel(x,y,8000) : pixel(x, chrome ? y-body.y+offset : y+offset), (y*width+x)*4);
  }
  return {width,height,data};
}
function expected(height: number, rect?: PixelRegion,offset=0): BitmapFrame {
  const width = rect?.width ?? 480, data = new Uint8Array(width*height*4);
  for (let y=0;y<height;y++) for (let x=0;x<width;x++) data.set(pixel(x+(rect?.x??0),y+offset), (y*width+x)*4);
  return {width,height,data};
}
test('manual frames with variable continuous increments and pauses stitch every original row in order', () => {
  const engine = new ScrollCaptureEngine();
  for (const offset of [0,21,65,65,132,197,301]) {
    const result = engine.push(page(offset));
    assert.equal(result.kind, offset === 0 ? 'initial' : offset === 65 && result.kind === 'duplicate' ? 'duplicate' : 'appended');
  }
  assert.deepEqual(engine.bitmap(), expected(721));
});
test('sidebar/header/footer requires explicit crop review and retains every body pixel from the first screen', () => {
  const engine = new ScrollCaptureEngine(); engine.push(page(0,true));
  const original = engine.bitmap(), next = page(100,true), candidate = engine.push(next);
  assert.equal(candidate.kind,'review'); assert.deepEqual(candidate.regionCandidate,body);
  assert.deepEqual(engine.bitmap(),original,'Suggestion must not silently alter output');
  next.data.fill(0);
  candidate.regionCandidate!.x=0;
  assert.equal(engine.push(page(130,true)).kind,'review','Review pauses commits');
  const committed = engine.confirmRegion();
  assert.deepEqual(committed.contentRect,body); assert.equal(committed.appendedRows,100);
  assert.deepEqual(engine.bitmap(),expected(428,body),'Pending frame must own its pixels');
  assert.equal(engine.push(page(180,true)).kind,'appended');
  assert.equal(engine.push(page(250,true)).kind,'appended');
  assert.deepEqual(engine.bitmap(),expected(578,body));
  assert.equal(engine.push(page(250,true)).kind,'duplicate');
  assert.equal(engine.push(page(190,true)).kind,'duplicate');
  assert.deepEqual(engine.bitmap(),expected(578,body));
  assert.equal(engine.push(page(280,true)).verifiedTransitions,4);
});

test('upward first movement can propose a body crop and prepend only after explicit confirmation',()=>{
  const engine=new ScrollCaptureEngine();engine.push(page(180,true));const saved=engine.bitmap();
  const proposal=engine.push(page(80,true));assert.equal(proposal.kind,'review');assert.deepEqual(engine.bitmap(),saved);
  const confirmed=engine.confirmRegion();assert.equal(confirmed.addedTop,100);assert.equal(confirmed.coveredTop,-100);
  assert.deepEqual(engine.bitmap(),expected(428,body,80));
  assert.equal(engine.push(page(0,true)).addedTop,80);assert.deepEqual(engine.bitmap(),expected(508,body));
  assert.equal(engine.push(page(120,true)).kind,'duplicate');assert.deepEqual(engine.bitmap(),expected(508,body));
});
test('keeping original scope does not crop or repeatedly ask to discard sidebar', () => {
  const engine = new ScrollCaptureEngine(); engine.push(page(0,true)); const first = engine.bitmap();
  assert.equal(engine.push(page(100,true)).kind,'review');
  assert.equal(engine.keepRegion().kind,'rejected');
  assert.equal(engine.push(page(120,true)).kind,'rejected'); assert.deepEqual(engine.bitmap(),first);
  engine.clear(); engine.push(page(0,true)); assert.equal(engine.push(page(100,true)).kind,'review');
});
test('animated document columns cannot be treated as stationary chrome and silently cropped away', () => {
  const engine = new ScrollCaptureEngine(); engine.push(page(0)); const first = engine.bitmap();
  const animated = page(100);
  for(let y=20;y<220;y++) for(let x=260;x<270;x++) animated.data.set([255,255,255,255],(y*480+x)*4);
  assert.equal(engine.push(animated).kind,'rejected'); assert.deepEqual(engine.bitmap(),first);
  assert.equal(engine.push(page(100)).kind,'appended');
});
test('independent scrolling columns, missing overlap, changed size and low proposal budget are not accepted', () => {
  const engine = new ScrollCaptureEngine(); engine.push(page(0)); const first = engine.bitmap();
  const split = page(100), other = page(150);
  for(let y=0;y<420;y++) split.data.set(other.data.subarray((y*480+240)*4,(y+1)*480*4),(y*480+240)*4);
  assert.equal(engine.push(split).kind,'rejected'); assert.deepEqual(engine.bitmap(),first);
  assert.equal(engine.push(page(380)).kind,'rejected');
  assert.equal(engine.push({width:1,height:1,data:new Uint8Array(4)}).kind,'rejected');
  const budget = new ScrollCaptureEngine({maxBytes:480*420*4*2+4}); budget.push(page(0,true));
  assert.equal(budget.push(page(100,true)).kind,'rejected'); assert.equal(budget.bitmap().height,420);
});
test('confirmation height limit preserves the original snapshot and can be dismissed', () => {
  const engine=new ScrollCaptureEngine({maxHeight:425}); engine.push(page(0,true)); const before=engine.bitmap();
  assert.equal(engine.push(page(100,true)).kind,'review');
  assert.equal(engine.confirmRegion().kind,'limit'); assert.deepEqual(engine.bitmap(),before);
  engine.keepRegion(); assert.equal(engine.push(page(120,true)).kind,'rejected'); assert.deepEqual(engine.bitmap(),before);
});
