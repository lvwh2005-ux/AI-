import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { buildMessages, CompatibleProvider, completionUrl } from '../src/main/providers/compatible';
import { DemoProvider } from '../src/main/providers/demo';
import type { AIRequest } from '../src/main/providers/types';

const request = (): AIRequest => ({ action: 'ask', image: 'data:image/png;base64,fixture', question: '解释图片', language: '简体中文', history: [], signal: new AbortController().signal });
describe('compatible provider', () => {
  it('allows secure remote services and HTTP loopback only', () => {
    assert.equal(completionUrl('https://example.com/v1/'), 'https://example.com/v1/chat/completions');
    assert.ok(completionUrl('http://127.0.0.1:1234/v1').endsWith('/v1/chat/completions'));
    assert.throws(() => completionUrl('http://example.com/v1'));
    assert.throws(() => completionUrl('https://user:secret@example.com/v1'));
    assert.throws(() => completionUrl('https://example.com/v1?key=secret'));
  });
  it('attaches selected image and bounds conversation context', () => {
    const req = request(); req.history = Array.from({ length: 20 }, () => ({ role: 'user', content: 'old' }));
    const messages = buildMessages(req);
    assert.equal(messages.length, 14);
    assert.deepEqual(messages.at(-1)?.content, [{ type: 'text', text: req.question }, { type: 'image_url', image_url: { url: req.image } }]);
  });
  it('sends server-side credentials and rejects redirects', async () => {
    const transport: typeof fetch = async (url, init) => {
      assert.equal(url, 'https://example.com/v1/chat/completions');
      assert.equal(init?.redirect, 'error');
      assert.equal(new Headers(init?.headers).get('Authorization'), 'Bearer test-key');
      return new Response(JSON.stringify({ choices: [{ message: { content: '解释结果' } }] }));
    };
    const provider = new CompatibleProvider({ baseUrl: 'https://example.com/v1', model: 'vision-model', apiKey: 'test-key' }, transport);
    assert.equal(await provider.complete(request()), '解释结果');
  });
  it('does not expose an error body that might contain credentials', async () => {
    const transport: typeof fetch = async () => new Response('echoed-secret', { status: 401 });
    await assert.rejects(new CompatibleProvider({ baseUrl: 'https://example.com/v1', model: 'test', apiKey: '' }, transport).complete(request()), (error: Error) => error.message.includes('HTTP 401') && !error.message.includes('echoed-secret'));
  });
  it('rejects empty responses', async () => {
    const transport: typeof fetch = async () => new Response('{"choices":[]}');
    await assert.rejects(new CompatibleProvider({ baseUrl: 'https://example.com', model: 'test', apiKey: '' }, transport).complete(request()), /有效文本/);
  });
  it('cancels demonstration requests', async () => {
    const controller = new AbortController();
    const pending = new DemoProvider().complete({ ...request(), signal: controller.signal });
    controller.abort();
    await assert.rejects(pending, /已取消/);
  });
});
