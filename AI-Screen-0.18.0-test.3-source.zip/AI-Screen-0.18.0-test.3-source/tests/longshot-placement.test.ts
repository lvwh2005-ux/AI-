import assert from 'node:assert/strict';
import { test } from 'node:test';
import type { Rect } from '../src/shared/contracts';
import { PreviewPlacementManager } from '../src/shared/scroll-capture/preview-placement';
import { intersects, thumbnailBounds } from '../src/shared/scroll-capture/layout';

const manager = new PreviewPlacementManager();
const area = { x: 0, y: 0, width: 1600, height: 1000 };
const elsewhere = { x: -500, y: -100, width: 440, height: 44 };
function inside(bounds: Rect, work: Rect) {
  assert.ok(Object.values(bounds).every(Number.isInteger));
  assert.ok(bounds.width > 0 && bounds.height > 0);
  assert.ok(bounds.x >= work.x && bounds.y >= work.y);
  assert.ok(bounds.x + bounds.width <= work.x + work.width && bounds.y + bounds.height <= work.y + work.height);
}

test('equally readable exterior previews prefer the right and align their bottom with the selection', () => {
  const target = { x: 500, y: 200, width: 500, height: 600 };
  const result = manager.place(target, area, elsewhere);
  assert.equal(result.side, 'right'); assert.equal(result.mode, 'outside');
  assert.ok(result.bounds.x >= 1012); assert.equal(result.bounds.y + result.bounds.height, 800);
  assert.equal(result.bounds.width, 390); assert.equal(result.overlapsFocus, false);
  assert.deepEqual(thumbnailBounds(target, area, elsewhere), result.bounds);
});
test('a readable left preview beats a narrow but technically usable right strip', () => {
  const target = { x: 500, y: 100, width: 800, height: 800 };
  const result = manager.place(target, area, elsewhere);
  assert.equal(result.side, 'left'); assert.equal(result.bounds.width, 390);
  assert.ok(result.spaces.right >= 240 && result.spaces.right < result.spaces.left); assert.equal(result.overlapsFocus, false);
});
test('near the work-area top, side previews retain bottom alignment and reserve native DPI rounding space', () => {
  const work = { x: 0, y: 0, width: 1707, height: 1027 };
  const target = { x: 49, y: 48, width: 600, height: 548 };
  const result = manager.place(target, work, { x: 200, y: 604, width: 440, height: 44 });
  assert.equal(result.side, 'right'); assert.equal(result.bounds.y + result.bounds.height, 596);
  assert.ok(result.bounds.y >= 2); inside(result.bounds, work);
});
test('top space is used when both sides and bottom cannot hold a readable preview', () => {
  const target = { x: 40, y: 450, width: 1520, height: 500 };
  const result = manager.place(target, area, elsewhere);
  assert.equal(result.side, 'top'); assert.equal(result.mode, 'outside');
  assert.ok(result.bounds.y + result.bounds.height <= 438);
  assert.equal(intersects(result.bounds, target), false); inside(result.bounds, area);
});
test('bottom space is used without clipping or covering a toolbar placed above', () => {
  const target = { x: 40, y: 40, width: 1520, height: 450 };
  const toolbar = { x: 1100, y: 0, width: 440, height: 32 };
  const result = manager.place(target, area, toolbar);
  assert.equal(result.side, 'bottom'); assert.equal(result.mode, 'outside');
  assert.ok(result.bounds.y >= 502); assert.equal(result.overlapsToolbar, false);
  assert.equal(intersects(result.bounds, target), false);
});
test('a toolbar crossing a side splits the free space rather than hiding controls under the preview', () => {
  const target = { x: 80, y: 150, width: 900, height: 700 };
  const toolbar = { x: 1020, y: 390, width: 440, height: 44 };
  const result = manager.place(target, area, toolbar);
  assert.equal(result.mode, 'outside'); assert.equal(result.overlapsToolbar, false);
  assert.equal(intersects(result.bounds, target), false); inside(result.bounds, area);
  assert.ok(result.bounds.width >= 240 && result.bounds.height >= 240);
});
test('full-screen protected overlays leave the central scrolling area and toolbar unobstructed', () => {
  const toolbar = { x: 1140, y: 940, width: 440, height: 44 };
  const result = manager.place(area, area, toolbar);
  assert.equal(result.mode, 'overlay'); assert.equal(result.overlapsToolbar, false); assert.equal(result.overlapsFocus, false);
  assert.ok(result.bounds.width >= 240 && result.bounds.height >= 240); inside(result.bounds, area);
  assert.equal(intersects({ ...result.bounds, width: result.bounds.width + 1, height: result.bounds.height + 1 },
    { x: 480, y: 300, width: 640, height: 400 }), false, 'Native outward rounding must not cover the scrolling centre');
});
test('fractional selection edges on a negative-coordinate display are not rounded out of the work area', () => {
  const work = { x: -1706.5, y: -150.5, width: 1706.5, height: 1018.5 };
  const target = { x: -1660.25, y: -100.25, width: 1000.5, height: 760.5 };
  const result = manager.place(target, work, { x: -1100, y: 670, width: 440, height: 44 });
  inside(result.bounds, work); assert.equal(result.overlapsToolbar, false);
  assert.equal(intersects(result.bounds, target), false);
});
test('a toolbar on a second monitor does not pull the preview off the selected monitor', () => {
  const work = { x: -1920, y: 120, width: 1920, height: 1040 };
  const target = { x: -1800, y: 200, width: 1150, height: 800 };
  const result = manager.place(target, work, { x: 200, y: 100, width: 440, height: 44 });
  inside(result.bounds, work); assert.equal(result.side, 'right'); assert.equal(result.mode, 'outside');
});
test('layout leaves selections extending into the taskbar unchanged and reports an impossible fit honestly', () => {
  const work = { x: 0, y: 0, width: 800, height: 600 };
  const target = { x: 0, y: 0, width: 800, height: 640 }, before = { ...target };
  inside(manager.place(target, work, { x: 350, y: 550, width: 440, height: 44 }).bounds, work);
  assert.deepEqual(target, before);
  const tiny = { x: -10, y: -10, width: 30, height: 20 };
  const result = manager.place(tiny, tiny, tiny);
  assert.equal(result.mode, 'constrained'); assert.equal(result.overlapsToolbar, true); inside(result.bounds, tiny);
});
test('invalid geometry is rejected before creating a native window', () => {
  for (const invalid of [{ ...area, x: NaN }, { ...area, height: 0 }, { ...area, width: Infinity }]) {
    assert.throws(() => manager.place(invalid, area, elsewhere), /无效/);
    assert.throws(() => manager.place(area, invalid, elsewhere), /无效/);
    assert.throws(() => manager.place(area, area, invalid), /无效/);
  }
  assert.throws(() => manager.place(area, { x: .2, y: .2, width: .2, height: .2 }, elsewhere), /空间/);
});
test('placement is deterministic, translation-invariant and never mutates caller rectangles', () => {
  const target = { x: 400, y: 100, width: 900, height: 800 };
  const toolbar = { x: 880, y: 910, width: 440, height: 44 };
  const input = JSON.stringify([target, area, toolbar]), first = manager.place(target, area, toolbar);
  for (let i = 0; i < 8; i++) assert.deepEqual(manager.place(target, area, toolbar), first);
  const translate = (r: Rect) => ({ ...r, x: r.x - 2500, y: r.y - 1400 });
  const shifted = manager.place(translate(target), translate(area), translate(toolbar));
  assert.deepEqual(shifted, { ...first, bounds: translate(first.bounds) });
  assert.equal(JSON.stringify([target, area, toolbar]), input);
});
test('varied full and partial selections keep the preview on one monitor, away from toolbar and scrolling centre', () => {
  let count = 0;
  for (const work of [area, { x: -1536, y: -200, width: 1536, height: 864 }, { x: 0, y: 0, width: 853, height: 560 }]) {
    for (const fraction of [1, .9, .65, .35]) for (const px of [0, .5, 1]) for (const py of [0, .5, 1]) {
      const target = { x: work.x + work.width * (1 - fraction) * px, y: work.y + work.height * (1 - fraction) * py,
        width: work.width * fraction, height: work.height * fraction };
      const toolbar = { x: work.x + work.width - 452, y: work.y + work.height - 56, width: 440, height: 44 };
      const result = manager.place(target, work, toolbar);
      inside(result.bounds, work); assert.equal(result.overlapsToolbar, false);
      assert.equal(result.overlapsFocus, false); count++;
    }
  }
  assert.equal(count, 108);
});
