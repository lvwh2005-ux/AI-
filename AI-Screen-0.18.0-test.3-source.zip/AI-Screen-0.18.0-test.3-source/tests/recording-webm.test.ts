import {it} from 'node:test';import assert from 'node:assert/strict';
import {reserveWebmDuration} from '../src/main/services/recording/webm-duration';
import {recordingDisplayPermission} from '../src/shared/recording/permissions';
// Minimal layout produced by the app's Chromium recorder: EBML, unknown Segment, Info, Tracks.
const prefix='1a45dfa3801853806701ffffffffffffff';
it('reserves a Duration field without rewriting or retaining video payload',()=>{
  const input=Buffer.from(prefix+'1549a966872ad7b1830f42401654ae6b801f43b67580','hex'),patch=reserveWebmDuration(input);
  const output=Buffer.concat(patch.parts);assert.equal(patch.addedBytes,11);assert.equal(patch.timestampScale,1000000);
  assert.equal(output.subarray(patch.durationOffset-3,patch.durationOffset).toString('hex'),'448988');
  output.writeDoubleBE(10000,patch.durationOffset);assert.equal(output.readDoubleBE(patch.durationOffset),10000);
  assert.equal(output.subarray(-10).toString('hex'),input.subarray(-10).toString('hex'));
});
it('uses an existing float Duration and respects custom timestamp scale',()=>{
  const input=Buffer.from(prefix+'1549a966922ad7b1831e848044898800000000000000001654ae6b80','hex'),patch=reserveWebmDuration(input);
  assert.equal(patch.addedBytes,0);assert.equal(patch.timestampScale,2000000);assert.equal(patch.floatBytes,8);assert.equal(patch.parts[0],input);
});
it('rejects truncated, foreign or indexed container layouts instead of corrupting offsets',()=>{
  assert.throws(()=>reserveWebmDuration(new Uint8Array([0])));
  assert.throws(()=>reserveWebmDuration(Buffer.from(prefix+'114d9b7480','hex')));
  assert.throws(()=>reserveWebmDuration(Buffer.from(prefix+'1549a966812a','hex')));
});
it('grants only exact local main-frame display requests across runtime permission names',()=>{
  const url='file:///app/media-host.html',details={isMainFrame:true,requestingUrl:url,mediaTypes:[]};
  assert.equal(recordingDisplayPermission('media',details,url),true);
  assert.equal(recordingDisplayPermission('display-capture',{...details,mediaTypes:['video']},url),true);
  for(const types of [undefined,['video'],['audio'],['video','audio']])assert.equal(recordingDisplayPermission('media',{...details,mediaTypes:types},url),false);
  assert.equal(recordingDisplayPermission('display-capture',{...details,mediaTypes:['audio']},url),false);
  assert.equal(recordingDisplayPermission('media',{...details,isMainFrame:false},url),false);
  assert.equal(recordingDisplayPermission('media',{...details,requestingUrl:'file:///other.html'},url),false);
});
