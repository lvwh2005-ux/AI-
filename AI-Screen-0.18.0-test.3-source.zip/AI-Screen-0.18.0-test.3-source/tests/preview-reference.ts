import type {BitmapFrame,PixelRegion} from '../src/shared/scroll-capture/types';
/** Independent, uncapped box integral for the small reduction ratios in tests. */
export function referencePixel(source:BitmapFrame,region:PixelRegion,width:number,height:number,x:number,y:number){
  const left=region.x+x*region.width/width,right=region.x+(x+1)*region.width/width;
  const top=region.y+y*region.height/height,bottom=region.y+(y+1)*region.height/height;
  const sums=[0,0,0,0],area=(right-left)*(bottom-top);
  for(let sy=Math.floor(top);sy<Math.ceil(bottom);sy++)for(let sx=Math.floor(left);sx<Math.ceil(right);sx++){
    const weight=(Math.min(sx+1,right)-Math.max(sx,left))*(Math.min(sy+1,bottom)-Math.max(sy,top));
    for(let c=0;c<4;c++)sums[c]+=source.data[(sy*source.width+sx)*4+c]*weight;
  }
  return Uint8Array.from(sums,value=>Math.round(value/area));
}
