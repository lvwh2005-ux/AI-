import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import {cropFrame} from '../src/shared/scroll-capture/motion-region';
import {StageProfiler,type ProfileSpan} from '../src/shared/scroll-capture/profiler';
import {FRAME_ANALYSIS_LIMITS} from '../src/shared/scroll-capture/analysis-work';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';

// The report's physical ROI, with a narrow text column in a white desktop
// document and a large stationary navigation pane. No rainbow/noise in text.
const body={x:1280,y:100,width:1259,height:1280};
function desktop(offset:number):BitmapFrame {
  const width=2559,height=1543,data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let value=208+((Math.floor(x/7)*13+Math.floor(y/9)*17)%40);
    if(x>=body.x&&x<body.x+body.width&&y>=body.y&&y<body.y+body.height){
      const sx=x-body.x,sy=y-body.y+offset;
      value=255;
      if(sx>=64&&sx<580&&sy%24<16){
        const column=Math.floor((sx-64)/12),line=Math.floor(sy/24);
        let hash=Math.imul(line+17,1597334677)^Math.imul(column+3,0x119de1f3);
        hash=Math.imul(hash^(hash>>>13),1597334677);
        if((sx-64)%12<8&&(hash>>>(sy%16)&1))value=35;
      }
    }
    const at=(y*width+x)*4;data[at]=data[at+1]=data[at+2]=value;data[at+3]=255;
  }
  return{width,height,data};
}

test('near-full-screen white desktop text offers a verified body without a selection-width quota',()=>{
  for(const shift of [120,-120]){
    const spans:ProfileSpan[]=[],engine=new ScrollCaptureEngine({profiler:new StageProfiler(span=>spans.push(span))});
    const first=desktop(480),next=desktop(480+shift);engine.push(first);
    const result=engine.push(next);assert.equal(result.kind,'review');
    assert.deepEqual(engine.bitmap(),first,'A proposal cannot crop before approval');
    const rect=result.regionCandidate!;
    assert.ok(rect.x<=body.x+64&&rect.x+rect.width>=body.x+580);
    assert.equal(rect.y,body.y);assert.equal(rect.height,body.height);
    const a=cropFrame(first,rect),b=cropFrame(next,rect),rows=Math.abs(shift),stride=rect.width*4;
    const data=new Uint8Array(stride*(rect.height+rows));
    if(shift>0){data.set(a.data);data.set(b.data.subarray((rect.height-rows)*stride),a.data.length);}
    else{data.set(b.data.subarray(0,rows*stride));data.set(a.data,rows*stride);}
    assert.equal(engine.confirmRegion().appendedRows,rows);
    assert.deepEqual(engine.bitmap(),{width:rect.width,height:rect.height+rows,data});
    assert.equal(engine.push(first).kind,'duplicate','Reverse revisit must not append a second copy');
    for(const span of spans.filter(span=>span.stage==='frame-analysis-budget')){
      for(const [key,limit] of Object.entries(FRAME_ANALYSIS_LIMITS))assert.ok(Number(span.metrics?.[key])<=limit);
      assert.equal(span.metrics?.exhausted,0);
    }
  }
});

test('large white pages resolve repeated text prefixes using separated original-pixel probes',()=>{
  function textPage(offset:number):BitmapFrame{
    const width=2450,height=1303,data=new Uint8Array(width*height*4).fill(255);
    for(let y=0;y<height;y++){
      const sy=y+offset,line=Math.floor(sy/48),row=sy%48;if(row>=16)continue;
      for(let x=1450;x<1680;x++){
        const suffix=x>=1650;
        let hash=Math.imul((suffix?line:19)+17,1597334677)^Math.imul(Math.floor(x/8)+3,0x119de1f3);
        hash=Math.imul(hash^(hash>>>13),1597334677);
        if(x%8<6&&(!suffix||(hash>>>row&1))){const at=(y*width+x)*4;data[at]=data[at+1]=data[at+2]=35+row*7;}
      }
    }
    return{width,height,data};
  }
  const engine=new ScrollCaptureEngine(),first=textPage(480),next=textPage(660);
  engine.push(first);const result=engine.push(next);
  assert.equal(result.kind,'appended',JSON.stringify(result));assert.equal(result.appendedRows,180);
  const expected=new Uint8Array(first.data.length+2450*180*4);expected.set(first.data);expected.set(next.data.subarray(2450*(1303-180)*4),first.data.length);
  assert.deepEqual(engine.bitmap().data,expected);
  assert.equal(engine.push(first).kind,'duplicate');
});

test('large selection cannot crop away independently moving sidebar content',()=>{
  const engine=new ScrollCaptureEngine(),first=desktop(480),next=desktop(600);engine.push(first);
  // A second changed pane is too broad to qualify as a caret or edge control.
  for(let y=200;y<900;y++)for(let x=150;x<400;x++)next.data[(y*next.width+x)*4]^=255;
  assert.equal(engine.push(next).kind,'rejected');assert.deepEqual(engine.bitmap(),first);
});

test('a large fixed header does not hide the smaller scrolling body below forty percent of the selection',()=>{
  function inset(frame:BitmapFrame):BitmapFrame{
    const height=3000,data=new Uint8Array(frame.width*height*4).fill(220);
    for(let at=3;at<data.length;at+=4)data[at]=255;
    data.set(frame.data,1300*frame.width*4);return{width:frame.width,height,data};
  }
  const engine=new ScrollCaptureEngine(),first=inset(desktop(480)),next=inset(desktop(600));engine.push(first);
  const result=engine.push(next);assert.equal(result.kind,'review');
  assert.equal(result.regionCandidate!.y,1400);assert.equal(result.regionCandidate!.height,1280);
  assert.deepEqual(engine.bitmap(),first);assert.equal(engine.confirmRegion().appendedRows,120);
});
