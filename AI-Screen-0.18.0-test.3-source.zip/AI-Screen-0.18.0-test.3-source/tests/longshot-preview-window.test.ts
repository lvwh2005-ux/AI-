import assert from 'node:assert/strict';
import { test } from 'node:test';
import { randomUUID } from 'node:crypto';
import { PreviewWindowLayout, previewEdges, previewWindowRequestSchema, type PreviewWindowRequest, type PreviewWindowState } from '../src/shared/scroll-capture/preview-window';
import { previewWorkArea } from '../src/shared/scroll-capture/preview-placement';
import { PreviewGesture } from '../src/renderer/longshot/preview-gesture';

const work = { x: -1600, y: -200, width: 1600, height: 1000 };
const target = { x: -1500, y: -100, width: 850, height: 700 };
const toolbar = { x: -1100, y: 620, width: 440, height: 44 };
const create = () => new PreviewWindowLayout(target, work, toolbar);
const point = { x: -400, y: 0 };
test('a click without movement remains automatic; ended gesture tokens cannot move a preview', () => {
  const layout = create(), before = layout.snapshot(), token = randomUUID();
  layout.begin(token, 'move', point); layout.end(token, point);
  assert.deepEqual(layout.snapshot(), before);
  assert.throws(()=>layout.update(token,{x:0,y:0}),/结束/);
});
test('manual movement persists through repeated toolbar updates and snapshots cannot mutate it', () => {
  const layout = create(), token = randomUUID(), before = layout.snapshot().bounds;
  layout.begin(token, 'move', point); layout.update(token,{x:point.x-100,y:point.y+50}); layout.end(token);
  const moved = layout.snapshot(); assert.equal(moved.positionMode,'manual');
  assert.equal(moved.bounds.x,before.x-100); assert.equal(moved.bounds.y,before.y+50);
  for(let i=0;i<10;i++)layout.updateToolbar({...toolbar,x:toolbar.x+i*30});
  assert.deepEqual(layout.snapshot(),moved);
  moved.bounds.x=999; assert.notEqual(layout.snapshot().bounds.x,999);
});
test('dragging clamps to a negative-coordinate monitor without changing the selection or preview size', () => {
  const source={...target},layout=create(),token=randomUUID(),before=layout.snapshot().bounds;
  layout.begin(token,'move',point);layout.update(token,{x:-99999,y:99999});layout.end(token);
  const bounds=layout.snapshot().bounds,area=previewWorkArea(work);
  assert.equal(bounds.x,area.x);assert.equal(bounds.y+bounds.height,area.y+area.height);
  assert.equal(bounds.width,before.width);assert.equal(bounds.height,before.height);assert.deepEqual(target,source);
});
for(const edge of previewEdges.filter(edge=>edge!=='move'))test(`${edge} resizing preserves its opposite edges and enters manual mode`,()=>{
  const layout=create(),token=randomUUID(),before=layout.snapshot().bounds;
  layout.begin(token,edge,point);layout.end(token,{x:point.x+(edge.includes('w')?-25:25),y:point.y+(edge.includes('n')?-25:25)});
  const after=layout.snapshot();assert.equal(after.positionMode,'manual');
  if(edge.includes('w'))assert.equal(after.bounds.x+after.bounds.width,before.x+before.width);
  else assert.equal(after.bounds.x,before.x);
  if(edge.includes('n'))assert.equal(after.bounds.y+after.bounds.height,before.y+before.height);
  else assert.equal(after.bounds.y,before.y);
});
test('resize cannot flip across the opposite edge or escape monitor boundaries',()=>{
  const layout=create(),token=randomUUID();layout.begin(token,'nw',point);layout.end(token,{x:99999,y:99999});
  assert.equal(layout.snapshot().bounds.width,240);assert.equal(layout.snapshot().bounds.height,240);
  const second=randomUUID();layout.begin(second,'se',point);layout.end(second,{x:99999,y:99999});
  const bounds=layout.snapshot().bounds,area=previewWorkArea(work);
  assert.equal(bounds.x+bounds.width,area.x+area.width);assert.equal(bounds.y+bounds.height,area.y+area.height);
});
test('restoring automatic positioning cancels late updates and preserves requested size where it fits',()=>{
  const layout=create(),token=randomUUID();layout.begin(token,'se',point);layout.update(token,{x:point.x+20,y:point.y-100});
  const manual=layout.snapshot();layout.restoreAuto();const automatic=layout.snapshot();
  assert.equal(automatic.positionMode,'auto');assert.equal(automatic.bounds.width,manual.bounds.width);assert.equal(automatic.bounds.height,manual.bounds.height);
  assert.throws(()=>layout.update(token,{x:0,y:0}),/结束/);
  const fresh=create().snapshot();assert.equal(fresh.positionMode,'auto');assert.notEqual(fresh.bounds.height,manual.bounds.height);
});
test('a pending click gesture is not displaced by automatic toolbar updates',()=>{
  const layout=create(),token=randomUUID(),before=layout.snapshot();layout.begin(token,'move',point);
  layout.updateToolbar({...toolbar,x:-500,y:200});assert.deepEqual(layout.snapshot(),before);
  assert.throws(()=>layout.begin(randomUUID(),'se',point),/结束/);layout.end(token);layout.restoreAuto();
  assert.equal(layout.snapshot().positionMode,'auto');
});
test('preview IPC rejects missing/foreign-shaped fields, invalid identities and non-finite coordinates',()=>{
  const id=randomUUID(),token=randomUUID();assert.equal(previewWindowRequestSchema.safeParse({id,op:'begin',edge:'move',point}).success,true);
  for(const input of [{id:'wrong',op:'get'},{id,op:'get',bounds:work},{id,op:'update',token,point:{x:Infinity,y:0}},
    {id,op:'begin',edge:'all',point},{id,op:'end',token:'wrong'},{id,op:'begin',edge:'move',point:{x:100001,y:0}}]){
    assert.equal(previewWindowRequestSchema.safeParse(input).success,false);
  }
});
function deferred<T>() {let resolve!:(value:T)=>void;const promise=new Promise<T>(r=>{resolve=r;});return{promise,resolve};}
const reply=(id:string,token?:string):PreviewWindowState=>({id,token,positionMode:'manual',bounds:{x:0,y:0,width:300,height:400},revision:1});
test('pointer-up before Begin replies sends only the last point, then End',async()=>{
  const id=randomUUID(),token=randomUUID(),gate=deferred<PreviewWindowState>(),calls:PreviewWindowRequest[]=[];
  const gesture=new PreviewGesture(id,'move',{x:0,y:0},async input=>{calls.push(input);return input.op==='begin'?gate.promise:reply(id);},()=>{},error=>assert.fail(String(error)));
  for(let x=1;x<=500;x++)gesture.move({x,y:50});gesture.end({x:600,y:60});
  assert.equal(calls.length,1);gate.resolve(reply(id,token));await gesture.completed;
  assert.deepEqual(calls.map(input=>input.op),['begin','update','end']);
  assert.deepEqual(calls[1],{id,op:'update',token,point:{x:600,y:60}});
});
test('slow Update keeps one request in flight and retains the final resize point',async()=>{
  const id=randomUUID(),token=randomUUID(),gate=deferred<PreviewWindowState>(),calls:PreviewWindowRequest[]=[];
  let updates=0;
  const gesture=new PreviewGesture(id,'se',{x:0,y:0},async input=>{calls.push(input);if(input.op==='begin')return reply(id,token);if(input.op==='update'&&++updates===1)return gate.promise;return reply(id);},()=>{},error=>assert.fail(String(error)));
  await Promise.resolve();gesture.move({x:10,y:10});await Promise.resolve();
  for(let x=20;x<200;x++)gesture.move({x,y:x});gesture.end({x:250,y:300});
  assert.equal(calls.filter(input=>input.op==='update').length,1);gate.resolve(reply(id));await gesture.completed;
  assert.deepEqual(calls.map(input=>input.op),['begin','update','update','end']);
  assert.deepEqual(calls[2],{id,op:'update',token,point:{x:250,y:300}});
});
test('a failed update releases the gesture; repeated End is harmless and no later point is sent',async()=>{
  const id=randomUUID(),token=randomUUID(),calls:PreviewWindowRequest[]=[],errors:unknown[]=[];
  const gesture=new PreviewGesture(id,'move',point,async input=>{calls.push(input);if(input.op==='begin')return reply(id,token);if(input.op==='update')throw new Error('closed');return reply(id);},()=>{},error=>errors.push(error));
  gesture.move({x:0,y:0});await gesture.completed;gesture.end();gesture.move(point);
  assert.equal(errors.length,1);assert.deepEqual(calls.map(input=>input.op),['begin','update','end']);
});
test('Begin failure settles a short gesture without leaking an End for another interaction',async()=>{
  const errors:unknown[]=[],calls:PreviewWindowRequest[]=[];
  const gesture=new PreviewGesture(randomUUID(),'move',point,async input=>{calls.push(input);throw new Error('denied');},()=>{},error=>errors.push(error));
  gesture.end();await gesture.completed;assert.equal(errors.length,1);assert.equal(calls.length,1);
});
