import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {test} from 'node:test';
import {CaptureProcessClient,type CaptureChild} from '../src/main/services/capture-process-client';
import {captureProcessConfigSchema,type CaptureProcessConfig} from '../src/main/services/capture-process-protocol';
const config:CaptureProcessConfig={displayId:'left',display:{id:'left',bounds:{x:-1536,y:-240,width:1536,height:864},scaleFactor:1.25},
  rect:{x:10,y:20,width:100,height:50},nativeSize:{width:1920,height:1080},profiling:false};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
function frame(id:number){return{kind:'frame',id,width:126,height:63,bitmapSize:{width:1920,height:1080},data:new Uint8Array(126*63*4),retries:0,profile:[],timeOrigin:performance.timeOrigin};}
class Child extends EventEmitter{
  pid=123; killed=0; messages:{kind:string;id:number;config?:unknown}[]=[];
  initialBackend?:'gdi-roi'|'electron-snapshot';
  onRead?:(request:{id:number})=>void;
  send(message:{kind:string;id:number},callback?:(error:Error|null)=>void){
    this.messages.push(message);callback?.(null);
    queueMicrotask(()=>{
      if(message.kind==='init')this.emit('message',{kind:'initialized',id:message.id,...(this.initialBackend?{backend:this.initialBackend}:{})});
      else if(this.onRead)this.onRead(message);else this.emit('message',frame(message.id));
    });return true;
  }
  kill(){this.killed++;this.emit('exit',0);return true;}
}
function harness(options:{ready?:boolean;timeoutMs?:number}={}){
  const child=new Child();let launches=0;
  const client=new CaptureProcessClient(config,{timeoutMs:options.timeoutMs??1000,launch:()=>{
    launches++;if(options.ready!==false)queueMicrotask(()=>child.emit('message',{kind:'ready'}));return child as unknown as CaptureChild;
  }});return{child,client,launches:()=>launches};
}
test('capture helper binds once, reads fresh ROI bytes and preserves physical dimensions',async()=>{
  const {client,child,launches}=harness();let reads=0;
  child.onRead=request=>{const reply=frame(request.id);reply.data.fill(++reads);child.emit('message',reply);};
  try{
    const first=await client.read(new AbortController().signal),second=await client.read(new AbortController().signal);
    assert.equal(first.width,126);assert.equal(first.height,63);assert.equal(first.data[0],1);assert.equal(second.data[0],2);
    assert.equal(launches(),1);assert.deepEqual(child.messages.map(request=>request.kind),['init','read','read']);
    assert.deepEqual(child.messages[0].config,config);
  }finally{client.dispose();client.dispose();assert.equal(child.killed,1);}
});
test('pre-aborted read never launches a helper; active cancellation rejects and ignores late pixels',async()=>{
  const first=harness(),pre=new AbortController();pre.abort();
  await assert.rejects(first.client.read(pre.signal),{name:'AbortError'});assert.equal(first.launches(),0);first.client.dispose();
  const {client,child}=harness(),abort=new AbortController();let requestId=0;
  child.onRead=request=>{requestId=request.id;};
  const pending=client.read(abort.signal);await tick();assert.ok(requestId);
  await assert.rejects(client.read(new AbortController().signal),/并发/);
  const rejected=assert.rejects(pending,{name:'AbortError'});abort.abort();await rejected;
  child.emit('message',frame(requestId));assert.equal(child.killed,1);
  await assert.rejects(client.read(new AbortController().signal),/已结束/);
});
test('startup, read timeout, spawn error and process exit reject once and release the child',async()=>{
  for(const kind of ['startup','read','exit']){
    const {client,child}=harness({ready:kind!=='startup',timeoutMs:20});
    child.onRead=()=>{if(kind==='exit')child.emit('exit',1);};
    await assert.rejects(client.read(new AbortController().signal),/超时|退出/);assert.equal(child.killed,1);
  }
  const failed=new CaptureProcessClient(config,{launch:()=>{throw new Error('synthetic launch error');}});
  await assert.rejects(failed.read(new AbortController().signal),/启动/);
});
test('malformed, oversized, changed-native or wrong-crop responses cannot enter the frame queue',async()=>{
  for(const mutation of ['bytes','native','crop','extra']){
    const {client,child}=harness();child.onRead=request=>{
      const reply={...frame(request.id)} as Record<string,unknown>;
      if(mutation==='bytes')reply.data=new Uint8Array(4);
      if(mutation==='native')reply.bitmapSize={width:1921,height:1080};
      if(mutation==='crop')reply.width=127;
      if(mutation==='extra')reply.path='not-allowed';
      child.emit('message',reply);
    };
    await assert.rejects(client.read(new AbortController().signal),/数据无效/);assert.equal(child.killed,1);
  }
});
test('stale request IDs are ignored and retry evidence survives a terminal capture error',async()=>{
  const {client,child}=harness();child.onRead=request=>{
    child.emit('message',frame(request.id-1));child.emit('message',{kind:'error',id:request.id,issue:'empty-source',retries:1});
  };
  await assert.rejects(client.read(new AbortController().signal),/重新读取后仍/);assert.equal(client.retryCount,1);assert.equal(child.killed,1);
});
test('private helper configuration rejects cross-display, excessive buffers and unexpected fields',()=>{
  for(const value of [{...config,displayId:'other'},{...config,rect:{...config.rect,width:2000}},
    {...config,rect:{x:0,y:0,width:1536,height:864},nativeSize:{width:100000,height:100000}},
    {...config,url:'https://invalid.test'}])assert.equal(captureProcessConfigSchema.safeParse(value).success,false);
});

test('capture backend evidence permits startup fallback but rejects changing sources after the first frame',async()=>{
  const {client,child}=harness();child.initialBackend='gdi-roi';let reads=0;
  child.onRead=request=>child.emit('message',{...frame(request.id),backend:++reads===1?'electron-snapshot':'gdi-roi'});
  await client.read(new AbortController().signal);assert.equal(client.backend,'electron-snapshot');
  await assert.rejects(client.read(new AbortController().signal),/数据无效/);assert.equal(child.killed,1);client.dispose();
});
