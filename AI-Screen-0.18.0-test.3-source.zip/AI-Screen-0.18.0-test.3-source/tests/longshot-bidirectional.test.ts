import assert from 'node:assert/strict';
import {test} from 'node:test';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import {StitchDocument} from '../src/shared/scroll-capture/stitch-document';
import {DocumentCoverage} from '../src/shared/scroll-capture/document-coverage';
import {DocumentLocator} from '../src/shared/scroll-capture/document-locator';
import {verifyTranslation} from '../src/shared/scroll-capture/translation-verifier';
import {pixelRow,type BitmapFrame} from '../src/shared/scroll-capture/types';
import {AutoScrollPolicy} from '../src/shared/longshot-auto';
import {CaptureTelemetry} from '../src/shared/scroll-capture/telemetry';

function page(offset:number,height=320,width=128):BitmapFrame {
  const data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return {width,height,data};
}

test('signed coverage plans do not mutate until commit and reject gaps or unsafe coordinates',()=>{
  const coverage=new DocumentCoverage(320),up=coverage.plan(-100)!;
  assert.deepEqual([coverage.top,coverage.bottom,coverage.viewport],[0,320,0]);
  assert.deepEqual([up.addedTop,up.addedBottom,up.overlapTop,up.overlapRows],[100,0,0,220]);coverage.commit(up);
  const down=coverage.plan(100)!;assert.deepEqual([down.addedTop,down.addedBottom],[0,100]);coverage.commit(down);
  const back=coverage.plan(0)!;assert.equal(back.addedTop+back.addedBottom,0);
  assert.equal(coverage.plan(420),undefined);assert.equal(coverage.plan(Number.MAX_SAFE_INTEGER),undefined);
});

test('alternating directions prepend/append uncovered rows and deduplicate revisits pixel for pixel',()=>{
  const engine=new ScrollCaptureEngine();let low=300,high=620;engine.push(page(300));
  for(const offset of [200,400,250,100,200,400,500,250,100,350,500]){
    const previousHeight=high-low,result=engine.push(page(offset));low=Math.min(low,offset);high=Math.max(high,offset+320);
    assert.equal(result.kind,high-low>previousHeight?'appended':'duplicate');
    assert.equal(result.viewportY,offset-300);assert.equal(result.coveredTop,low-300);assert.equal(result.coveredBottom,high-300);
    assert.deepEqual(engine.bitmap(),page(low,high-low));
  }
});

test('both directions preserve stationary header/footer exactly once',()=>{
  const chrome=(offset:number)=>{const first=page(8000,400),body=page(offset);first.data.set(body.data,32*128*4);return first;};
  const engine=new ScrollCaptureEngine();engine.push(chrome(300));
  for(const offset of [180,420,250,100,350,500])assert.ok(['appended','duplicate'].includes(engine.push(chrome(offset)).kind));
  const output=engine.bitmap(),expected=new Uint8Array(800*128*4),original=chrome(300);
  expected.set(original.data.subarray(0,32*128*4));expected.set(page(100,720).data,32*128*4);
  expected.set(original.data.subarray(352*128*4),752*128*4);
  assert.equal(output.height,800);assert.deepEqual(output.data,expected);
});

test('newly revisited historical pixels are checked beyond the adjacent-frame overlap',()=>{
  const engine=new ScrollCaptureEngine();for(const offset of [0,200,400])engine.push(page(offset));const saved=engine.bitmap();
  const changed=page(300);for(let y=20;y<50;y++)changed.data.fill(255,(y*128+40)*4,(y*128+72)*4);
  assert.equal(engine.push(changed).reasonCode,'history-changed');assert.deepEqual(engine.bitmap(),saved);
  const restored=engine.push(page(300));assert.equal(restored.kind,'duplicate');assert.equal(restored.recoveredAfter,1);assert.deepEqual(engine.bitmap(),saved);
});

test('large jumps into fully covered history relocate exactly; jumps across unknown content do not',()=>{
  const engine=new ScrollCaptureEngine();for(let offset=0;offset<=1000;offset+=200)engine.push(page(offset));const saved=engine.bitmap();
  const back=engine.push(page(0));assert.equal(back.kind,'duplicate');assert.equal(back.relocated,true);assert.equal(back.viewportY,0);assert.deepEqual(engine.bitmap(),saved);
  assert.equal(engine.push(page(4000)).kind,'rejected');assert.deepEqual(engine.bitmap(),saved);
  const again=engine.push(page(1000));assert.equal(again.kind,'duplicate');assert.equal(again.relocated,true);
  assert.equal(engine.push(page(1200)).addedBottom,200);assert.deepEqual(engine.bitmap(),page(0,1520));
});

test('locator is exact, bounded and refuses repeated identical viewports',()=>{
  const document=new StitchDocument(),locator=new DocumentLocator(),source=page(0,1600);document.reset(source);
  assert.deepEqual(locator.locate(document.view(0,1600),page(700),document.revision),{kind:'located',top:700});
  const modified=page(700);modified.data[1000]^=255;assert.equal(locator.locate(document.view(0,1600),modified,document.revision),undefined);
  source.data.set(page(0).data,700*128*4);document.reset(source);
  assert.equal(locator.locate(document.view(0,1600),page(0),document.revision)?.kind,'ambiguous');
  locator.clear();document.clear();
});

test('row views, verifier and previews span prepended segments without flattening or changing output',()=>{
  const document=new StitchDocument();document.reset(page(200));document.lockEdges(0,0);document.prepend(page(0),0,200);document.append(page(400),120,200);
  const snapshot=document.bitmap(),view=document.view(100,500);assert.ok(verifyTranslation(view,page(100,500),0));
  for(const y of [0,400,30,499,100]){const row=pixelRow(view,y);assert.deepEqual(row.data.subarray(row.offset,row.offset+128*4),page(100+y,1).data);}
  document.bitmap=()=>assert.fail('preview must not flatten');const preview=document.preview(128,900);assert.deepEqual(preview,snapshot);
});

test('upward capacity failure is atomic and old inputs cannot mutate committed prefix pixels',()=>{
  const engine=new ScrollCaptureEngine({maxHeight:450});engine.push(page(300));const up=page(200);assert.equal(engine.push(up).addedTop,100);up.data.fill(0);
  const saved=engine.bitmap();assert.deepEqual(saved,page(200,420));assert.equal(engine.push(page(100)).kind,'limit');assert.deepEqual(engine.bitmap(),saved);
  engine.clear();assert.equal(engine.push(page(100)).viewportY,0);
});

test('detail preview follows the top, middle and bottom viewport while export stays unchanged',()=>{
  const engine=new ScrollCaptureEngine();for(let offset=0;offset<=1000;offset+=200)engine.push(page(offset));
  const saved=engine.bitmap();engine.push(page(0));const top=engine.previews({width:64,height:120});
  assert.equal(top.detailRegion.y,0);assert.equal(top.detailRegion.height,240);assert.notEqual(top.detail,top.overview);
  engine.push(page(400));const middle=engine.previews({width:64,height:120});assert.equal(middle.detailRegion.y,480);
  engine.push(page(1000));const bottom=engine.previews({width:64,height:120});assert.equal(bottom.detailRegion.y,1080);
  assert.deepEqual(engine.bitmap(),saved);
});

test('mixed-direction walks across sizes preserve a single continuous covered interval',()=>{
  for(let run=0;run<12;run++){
    const width=[128,320,640][run%3],height=[320,440,720][run%3],engine=new ScrollCaptureEngine();
    let position=1000,low=position,high=position+height,seed=run+17;engine.push(page(position,height,width));
    for(let i=0;i<18;i++){
      seed=Math.imul(seed,1664525)+1013904223|0;
      const delta=(Math.abs(seed)%Math.floor(height*.4)+1)*(seed&1?1:-1);position=Math.max(0,position+delta);
      const oldHeight=high-low,result=engine.push(page(position,height,width));low=Math.min(low,position);high=Math.max(high,position+height);
      assert.equal(result.kind,high-low>oldHeight?'appended':'duplicate');assert.deepEqual(engine.bitmap(),page(low,high-low,width));
    }
  }
});

test('2560×1600 reversal across already covered rows adds only the uncovered ends',()=>{
  const engine=new ScrollCaptureEngine();engine.push(page(1000,1600,2560));
  assert.equal(engine.push(page(400,1600,2560)).addedTop,600);
  const down=engine.push(page(1600,1600,2560));assert.equal(down.viewportDelta,1200);assert.equal(down.addedBottom,600);
  assert.equal(engine.push(page(1000,1600,2560)).kind,'duplicate');assert.deepEqual(engine.bitmap(),page(400,2800,2560));
});

test('a full memory budget still allows revisits but cannot prepend another row',()=>{
  const bytes=128*320*4,engine=new ScrollCaptureEngine({maxBytes:bytes*2+100*128*4});engine.push(page(300));engine.push(page(200));
  const saved=engine.bitmap();assert.equal(engine.push(page(199)).kind,'limit');assert.deepEqual(engine.bitmap(),saved);
  assert.equal(engine.push(page(300)).kind,'duplicate');assert.deepEqual(engine.bitmap(),saved);
});

test('history index invalidates after prefix and suffix changes without retaining old coordinates',()=>{
  const document=new StitchDocument(),locator=new DocumentLocator();document.reset(page(500,640));document.lockEdges(0,0);
  assert.deepEqual(locator.locate(document.view(0,640),page(700),document.revision),{kind:'located',top:200});
  document.prepend(page(300),0,200);
  assert.deepEqual(locator.locate(document.view(0,840),page(700),document.revision),{kind:'located',top:400});
  document.append(page(1000),140,180);
  assert.deepEqual(locator.locate(document.view(0,1020),page(1000),document.revision),{kind:'located',top:700});
});

test('directional telemetry counts new pixels and revisits while auto input pauses on reversal',()=>{
  const meter=new CaptureTelemetry(),engine=new ScrollCaptureEngine(),policy=new AutoScrollPolicy();meter.result(engine.push(page(300)));
  const up=engine.push(page(200));meter.result(up);assert.equal(policy.observe(up).kind,'pause');
  meter.result(engine.push(page(400)));meter.result(engine.push(page(300)));
  const stats=meter.snapshot();assert.equal(stats.prependedRows,100);assert.equal(stats.appendedBottomRows,100);assert.equal(stats.revisits,1);
  assert.equal(policy.observe({kind:'duplicate',width:128,height:520,appendedRows:0,relocated:true}).kind,'pause');
});
