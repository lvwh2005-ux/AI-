import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import type { NativeImage } from 'electron';
import { CaptureService } from '../src/main/services/capture';
import { captureDisplayPlan, toolbarPosition, toPixelRect, type CaptureDisplay } from '../src/shared/geometry';

const displays: CaptureDisplay[] = [
  { id: 'left', label: '副屏', bounds: { x: -1920, y: -240, width: 1920, height: 1080 }, scaleFactor: 1 },
  { id: 'main', label: '主屏', bounds: { x: 0, y: 0, width: 1536, height: 864 }, scaleFactor: 1.25 },
  { id: 'right', label: '高分屏', bounds: { x: 1536, y: 0, width: 1920, height: 1080 }, scaleFactor: 2 },
];
function image(id: string, width: number, height: number) {
  return {
    isEmpty: () => false, getSize: () => ({ width, height }),
    toJPEG: () => Buffer.from(`fixture:${id}`),
    crop: (rect: unknown) => ({ id, rect }),
  } as unknown as NativeImage;
}
const preview = (id: string) => `data:image/jpeg;base64,${Buffer.from(`fixture:${id}`).toString('base64')}`;

describe('multi-display capture', () => {
  it('prioritizes the cursor display and requests physical sizes per screen', () => {
    const plan = captureDisplayPlan(displays, 'main');
    assert.deepEqual(plan.map(({ id, pixelSize }) => [id, pixelSize]), [
      ['main', { width: 1920, height: 1080 }], ['left', { width: 1920, height: 1080 }], ['right', { width: 3840, height: 2160 }],
    ]);
    assert.deepEqual(plan[1].bounds, displays[0].bounds);
    assert.equal(displays[0].id, 'left');
  });
  it('crops local coordinates independently of negative desktop origins and mixed DPI', () => {
    const rect = { x: 10, y: 20, width: 100, height: 50 };
    assert.deepEqual(toPixelRect(rect, displays[0].bounds, { width: 1920, height: 1080 }), rect);
    assert.deepEqual(toPixelRect(rect, displays[1].bounds, { width: 1920, height: 1080 }), { x: 12, y: 25, width: 126, height: 63 });
    assert.deepEqual(toPixelRect(rect, displays[2].bounds, { width: 3840, height: 2160 }), { x: 20, y: 40, width: 200, height: 100 });
  });
  it('enumerates the display group once at maximum physical size and maps actual thumbnails by identity', async () => {
    const sizes: { width: number; height: number }[] = [];
    const service = new CaptureService({
      displays: () => displays, preferredDisplay: () => 'main', sources: async (size) => {
        sizes.push(size);
        return [...displays].reverse().map(({ id }) => ({ display_id: id, thumbnail: image(id, 960, 540) }));
      },
    });
    await service.takeAll();
    assert.deepEqual(sizes, [{ width: 3840, height: 2160 }]);
    assert.equal(service.frame()?.image, preview('main'));
    assert.equal(service.frame('left')?.image, preview('left'));
    assert.equal(service.frame('right')?.scaleFactor, 2);
    assert.equal(service.frame('forged'), null);
    assert.throws(() => service.crop({ x: 0, y: 0, width: 10, height: 10 }, 'forged'), /失效/);
    assert.deepEqual(service.crop({ x: 0, y: 0, width: 1536, height: 864 }, 'main'), { id: 'main', rect: { x: 0, y: 0, width: 960, height: 540 } });
    service.clear();
    for (const { id } of displays) assert.equal(service.frame(id), null);
  });
  it('caches the preview per snapshot while cropping only the original bitmap', async () => {
    const qualities: number[] = [];
    const cropRects: unknown[] = [];
    const original = {
      isEmpty: () => false, getSize: () => ({ width: 1920, height: 1080 }),
      toJPEG: (quality: number) => { qualities.push(quality); return Buffer.from('preview'); },
      toDataURL: () => { throw new Error('Full-screen PNG encoding should not run'); },
      crop: (rect: unknown) => { cropRects.push(rect); return 'original cropped pixels'; },
    } as unknown as NativeImage;
    const service = new CaptureService({
      displays: () => [displays[0]], preferredDisplay: () => 'left',
      sources: async () => [{ display_id: 'left', thumbnail: original }],
    });
    await service.takeAll();
    const first = service.frame('left')?.image;
    assert.equal(first, 'data:image/jpeg;base64,cHJldmlldw==');
    assert.equal(service.frame()?.image, first);
    assert.equal(service.frame('left')?.image, first);
    assert.deepEqual(qualities, [95]);
    const rect = { x: 10, y: 20, width: 100, height: 50 };
    assert.equal(service.crop(rect, 'left'), 'original cropped pixels');
    assert.deepEqual(cropRects, [rect]);
    service.clear();
    assert.equal(service.frame('left'), null);
    await service.takeAll();
    assert.equal(service.frame('left')?.image, first);
    assert.deepEqual(qualities, [95, 95]);
  });
  it('does not restore frozen images after cancellation during async loading', async () => {
    let release!: (sources: { display_id: string; thumbnail: NativeImage }[]) => void;
    const service = new CaptureService({
      displays: () => [displays[0]], preferredDisplay: () => 'left',
      sources: () => new Promise((resolve) => { release = resolve; }),
    });
    const taking = service.takeAll();
    service.clear();
    release([{ display_id: 'left', thumbnail: image('left', 1920, 1080) }]);
    await assert.rejects(taking, /取消/);
    assert.equal(service.frame(), null);
  });
  it('does not publish a partially captured display group', async () => {
    let incomplete = false;
    const service = new CaptureService({
      displays: () => displays, preferredDisplay: () => 'main',
      sources: async () => (incomplete ? [displays[1]] : displays).map(({ id }) => ({ display_id: id, thumbnail: image(id, 1920, 1080) })),
    });
    await service.takeAll();
    incomplete = true;
    await assert.rejects(service.takeAll(), /无法读取/);
    for (const { id } of displays) assert.equal(service.frame(id), null);
  });
  it('does not replace a newer snapshot when an older enumeration finishes last', async () => {
    const releases: ((sources: { display_id: string; thumbnail: NativeImage }[]) => void)[] = [];
    const service = new CaptureService({
      displays: () => [displays[1]], preferredDisplay: () => 'main',
      sources: () => new Promise((resolve) => { releases.push(resolve); }),
    });
    const earlier = service.takeAll();
    const cancelled = assert.rejects(earlier, /取消/);
    const latest = service.takeAll();
    releases[1]([{ display_id: 'main', thumbnail: image('latest', 1920, 1080) }]);
    await latest;
    releases[0]([{ display_id: 'main', thumbnail: image('earlier', 1920, 1080) }]);
    await cancelled;
    assert.equal(service.frame('main')?.image, preview('latest'));
  });
  it('honors cancellation before checking an incomplete response', async () => {
    let release!: (sources: { display_id: string; thumbnail: NativeImage }[]) => void;
    const service = new CaptureService({
      displays: () => displays, preferredDisplay: () => 'main',
      sources: () => new Promise((resolve) => { release = resolve; }),
    });
    const taking = service.takeAll();
    service.clear();
    release([]);
    await assert.rejects(taking, /取消/);
    assert.equal(service.frame(), null);
  });
});

it('keeps an expanded measured toolbar inside a short screen at every edge', () => {
  for (const rect of [
    { x: 0, y: 0, width: 720, height: 450 },
    { x: 710, y: 440, width: 10, height: 10 },
    { x: 400, y: 150, width: 100, height: 250 },
  ]) {
    const position = toolbarPosition(rect, { width: 720, height: 450 }, { width: 550, height: 260 });
    assert.ok(position.left >= 8 && position.left + 550 <= 712);
    assert.ok(position.top >= 8 && position.top + 260 <= 442);
  }
});
