import { it } from 'node:test';
import assert from 'node:assert/strict';
import { readCompletionStream } from '../src/main/providers/stream';

const event = (text: string, ending = '\n\n') => `data: ${JSON.stringify({ choices: [{ index: 0, delta: { content: text } }] })}${ending}`;
function response(payload: string, stride = 3) {
  const bytes = new TextEncoder().encode(payload);
  return new Response(new ReadableStream({ start(controller) {
    for (let i = 0; i < bytes.length; i += stride) controller.enqueue(bytes.slice(i, i + stride));
    controller.close();
  } }), { headers: { 'Content-Type': 'text/event-stream' } });
}
it('streams split UTF-8 and CRLF events without corrupting Chinese text', async () => {
  const progress: string[] = [];
  assert.equal(await readCompletionStream(response(': keepalive\r\n\r\n' + event('中文', '\r\n\r\n') + event('解释') + 'data: [DONE]\n\n', 1), (text) => progress.push(text), new AbortController().signal), '中文解释');
  assert.deepEqual(progress, ['中文', '中文解释']);
});
it('rejects a truncated stream instead of marking a partial answer as complete', async () => {
  await assert.rejects(readCompletionStream(response(event('partial')), () => {}, new AbortController().signal), /连接中断/);
});
it('accepts providers that close after finish_reason instead of DONE', async () => {
  assert.equal(await readCompletionStream(response(event('完成') + 'data: {"choices":[{"index":0,"delta":{},"finish_reason":"stop"}]}\n\n'), () => {}, new AbortController().signal), '完成');
});
it('sanitizes stream errors and malformed event payloads', async () => {
  await assert.rejects(readCompletionStream(response('data: {"error":{"message":"secret"}}\n\n'), () => {}, new AbortController().signal), (error: Error) => !error.message.includes('secret'));
  await assert.rejects(readCompletionStream(response('data: not-json\n\n'), () => {}, new AbortController().signal), /无效/);
});
it('cancels a stalled stream promptly', async () => {
  const controller = new AbortController();
  const pending = readCompletionStream(new Response(new ReadableStream({ start() {} })), () => {}, controller.signal);
  controller.abort();
  await assert.rejects(pending, (error: Error) => error.name === 'AbortError');
});
