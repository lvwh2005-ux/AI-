import assert from 'node:assert/strict';
import {test} from 'node:test';
import {StageProfiler,profiled,type ProfileSpan} from '../src/shared/scroll-capture/profiler';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';

test('profiler preserves values, errors, nested spans and snapshots numeric metrics',async()=>{
  let clock=0;const spans:ProfileSpan[]=[],profiler=new StageProfiler(span=>spans.push(span),()=>clock++);
  const metrics={count:1};const value={ok:true};
  assert.equal(profiler.measure('outer',()=>profiler.measure('inner',()=>value,metrics)),value);
  metrics.count=20;
  assert.deepEqual(spans.map(span=>[span.stage,span.durationMs]),[['inner',1],['outer',3]]);
  assert.equal(spans[0].metrics?.count,1);
  const error=new Error('expected');assert.throws(()=>profiler.measure('throw',()=>{throw error;}),e=>e===error);
  await assert.rejects(profiler.measureAsync('reject',async()=>{throw error;}),e=>e===error);
  assert.deepEqual(spans.slice(2).map(span=>span.stage),['throw','reject']);
});
test('disabled profiling and failing debug observers never change application results',async()=>{
  let calls=0;const profiler=new StageProfiler(()=>{throw new Error('debug disk full');});
  assert.equal(profiled(undefined,'disabled',()=>++calls),1);
  assert.equal(profiler.measure('active',()=>++calls),2);
  assert.equal(await profiler.measureAsync('async',async()=>++calls),3);
  profiler.observe([{stage:'worker',startMs:1,durationMs:2}]);
});
function frame(width:number,height:number,offset:number,bodyWidth=width,bodyHeight=height):BitmapFrame{
  const data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const row=x<bodyWidth&&y<bodyHeight?y+offset:y+500000;
    let n=Math.imul(row+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const i=(y*width+x)*4;data[i]=n&255;data[i+1]=n>>>8&255;data[i+2]=n>>>16&255;data[i+3]=255;
  }return{width,height,data};
}
test('profiling is observational across append, revisit, duplicate and rejected motion',()=>{
  for(const [width,height,bodyWidth,bodyHeight] of [[128,320,128,320],[640,320,128,320],[128,720,128,320]]){
    const spans:ProfileSpan[]=[],plain=new ScrollCaptureEngine(),observed=new ScrollCaptureEngine({profiler:new StageProfiler(span=>spans.push(span))});
    for(const offset of [0,96,96,32,160]){
      const input=frame(width,height,offset,bodyWidth,bodyHeight),original=input.data.slice();
      assert.deepEqual(observed.push(input),plain.push(input));
      assert.deepEqual(observed.bitmap(),plain.bitmap());assert.deepEqual(input.data,original);
    }
    assert.ok(spans.some(span=>span.stage==='exact-change-check'));
    assert.ok(spans.some(span=>span.stage==='analysis-sample'&&span.metrics?.actualPixels!<=32_768));
    assert.ok(spans.every(span=>span.durationMs>=0&&Number.isFinite(span.durationMs)));
  }
});
