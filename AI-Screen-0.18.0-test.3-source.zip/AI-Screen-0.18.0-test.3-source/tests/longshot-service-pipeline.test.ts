import assert from 'node:assert/strict';
import {test} from 'node:test';
import type {NativeImage} from 'electron';
import {LongshotService} from '../src/main/services/longshot';
import type {LiveRegionSource} from '../src/main/services/live-region-source';
import type {LongshotWindow} from '../src/main/longshot-window';
import type {ClipboardService} from '../src/main/services/clipboard';
import type {AnnotationCompositor} from '../src/main/services/annotation-compositor';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import type {BitmapFrame, StitchResult} from '../src/shared/scroll-capture/types';
import type {PreviewSize} from '../src/shared/scroll-capture/preview';
import type {ScrollDriver} from '../src/main/services/longshot-scroller';

// No Electron/native capture, keys, clipboard or private pixels in these race tests.
const gate=()=>{let resolve!:()=>void;const promise=new Promise<void>(done=>{resolve=done;});return{promise,resolve};};
const sleep=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms));
async function until(check:()=>boolean,timeout=500){const deadline=Date.now()+timeout;while(Date.now()<deadline&&!check())await sleep(5);assert.ok(check(),'service transition timed out');}
function page(offset:number,height=320):BitmapFrame {
  const width=128,data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}
function harness(read:()=>Promise<BitmapFrame>,engine:ScrollCaptureEngine, hooks:{push?(frame:BitmapFrame):Promise<StitchResult>;previewGate?:Promise<void>;previewStarted?():void;scroller?:ScrollDriver}={}){
  let disposed=false,closed=0;
  const processor={get available(){return !disposed;},push:hooks.push??(async(frame:BitmapFrame)=>engine.push(frame)),
    bitmap:async()=>engine.bitmap(),confirmRegion:async()=>engine.confirmRegion(),keepRegion:async()=>engine.keepRegion(),
    encodePreview:async(frames:BitmapFrame[])=>frames.map(()=>'fixture-preview'),
    preview:async(size:PreviewSize)=>{const value=engine.previews(size);hooks.previewStarted?.();await hooks.previewGate;return value;},viewport:async(request:Parameters<ScrollCaptureEngine['viewport']>[0])=>engine.viewport(request),
    dispose:()=>{disposed=true;engine.clear();}};
  const source={globalRect:{x:0,y:0,width:128,height:320},frameBytes:128*320*4,
    read:async()=>{const frame=await read();return {getSize:()=>({width:frame.width,height:frame.height}),toBitmap:()=>Buffer.from(frame.data)} as NativeImage;}} as unknown as LiveRegionSource;
  const window={close:()=>{closed++;},showControls:async()=>false,overlaysSelection:false,publish:()=>{},publishTelemetry:()=>{},previewSize:()=>({width:128,height:160})} as unknown as LongshotWindow;
  const service=new LongshotService({window,createSource:()=>source,createProcessor:()=>processor,beforeCapture:async()=>undefined,onIdle:()=>{},
    ...(hooks.scroller?{createScroller:()=>hooks.scroller!}:{}),
    clipboard:{} as ClipboardService,compositor:{dispose:()=>{}} as AnnotationCompositor,analyze:async()=>{}});
  const start=(scrollMode:'manual'|'auto'='manual')=>service.start({displayId:'test',rect:source.globalRect,signal:new AbortController().signal,scrollMode});
  return{service,start,closed:()=>closed,disposed:()=>disposed};
}

test('a read failure overtaking a valid worker commit remains an error with a finishable partial image',async()=>{
  const pending=gate(),engine=new ScrollCaptureEngine();let reads=0;
  const {service,start,disposed}=harness(async()=>{if(++reads===1)return page(0);throw new Error('synthetic read failed');},engine,
    {push:async(frame)=>{const result=engine.push(frame);await pending.promise;return result;}});
  try{
    await start();await until(()=>service.state?.status==='error');assert.equal(service.state?.frames,0);
    pending.resolve();await until(()=>service.state?.frames===1);
    assert.equal(service.state?.status,'error','late match must not revive a stopped producer');
    assert.match(service.state!.error!,/synthetic read failed/);assert.equal(service.state?.canFinish,true);
    assert.equal(service.state?.telemetry?.lastIssue,'capture-error');
    assert.equal(service.state?.telemetry?.readErrors,1,'late match cannot double-count or erase the source error');
    await until(()=>service.state?.telemetry?.bufferedFrames===0);assert.equal(reads,2);
  }finally{pending.resolve();await service.cancel();}
  assert.equal(service.state,null);assert.equal(disposed(),true);
});

test('automatic input overlaps a slow commit only after saving each frame and stops at bounded queue capacity',async()=>{
  const held=gate(),engine=new ScrollCaptureEngine();let offset=0,steps=0,pushes=0;
  const scroller:ScrollDriver={bind:async()=>{},validate:async()=>{},resume:async()=>{},dispose:()=>{},step:async()=>{offset+=96;steps++;}};
  const {service,start}=harness(async()=>page(offset),engine,{scroller,push:async frame=>{if(++pushes===2)await held.promise;return engine.push(frame);}});
  try{
    await start('auto');await until(()=>steps>=3,4500);
    assert.equal(pushes,2,'the second worker commit remains blocked');
    assert.equal(engine.bitmap().height,320,'input is independent of the pending full-resolution commit');
    await until(()=>service.state?.telemetry?.bufferedFrames===3,2500);
    await sleep(550);assert.equal(steps,3,'queue capacity prevents uncontrolled scrolling past saved frames');
    held.resolve();await until(()=>(service.state?.appendedRows??0)>=288,2000);
    await service.command(service.state!.id,'pause');
    const image=engine.bitmap();assert.deepEqual(image,page(0,image.height),'ordered intermediate overlaps produce exact continuous output');
    const stopped=steps;await sleep(550);assert.equal(steps,stopped);
  }finally{held.resolve();await service.cancel();}
});
test('asynchronous automatic rejection cancels queued work and prevents later input',async()=>{
  const held=gate(),engine=new ScrollCaptureEngine();let offset=0,steps=0,pushes=0;
  const scroller:ScrollDriver={bind:async()=>{},validate:async()=>{},resume:async()=>{},dispose:()=>{},step:async()=>{offset+=96;steps++;}};
  const {service,start}=harness(async()=>page(offset),engine,{scroller,push:async frame=>{
    if(++pushes===2){await held.promise;return{kind:'rejected',reasonCode:'no-overlap',reason:'synthetic rejection',width:128,height:320,appendedRows:0};}
    return engine.push(frame);
  }});
  try{
    await start('auto');await until(()=>steps>=2,3000);held.resolve();await until(()=>!!service.state?.paused);
    assert.equal(engine.bitmap().height,320);const stopped=steps;
    await sleep(800);assert.equal(steps,stopped);assert.match(service.state!.message,/synthetic rejection/);
    assert.equal(service.state?.telemetry?.bufferedFrames,0);
  }finally{held.resolve();await service.cancel();}
});
test('fractional-notch native controls cannot cause premature automatic completion',async()=>{
  const engine=new ScrollCaptureEngine();let offset=0,accumulated=0;const amounts:number[]=[];
  const scroller:ScrollDriver={bind:async()=>{},validate:async()=>{},resume:async()=>{},dispose:()=>{},step:async(_signal,units=120)=>{
    amounts.push(units);accumulated+=units;
    while(accumulated>=120){offset=Math.min(630,offset+210);accumulated-=120;}
  }};
  const {service,start}=harness(async()=>page(offset),engine,{scroller});
  try{
    await start('auto');await until(()=>(service.state?.appendedRows??0)>=630||service.state?.status==='done'||service.state?.status==='error',15000);
    await service.command(service.state!.id,'pause');
    assert.equal(offset,630);assert.equal(service.state?.appendedRows,630);
    assert.ok(amounts.includes(60)&&amounts.includes(120));
    assert.equal(service.state?.height,950);
    assert.deepEqual(engine.bitmap(),page(0,950));
  }finally{await service.cancel();}
});

test('capacity stops the producer before awaiting an in-flight preview; cancel cannot publish late state',async()=>{
  const preview=gate(),previewStarted=gate(),secondRead=gate();let reads=0;
  const engine=new ScrollCaptureEngine({maxHeight:320});
  const {service,start,disposed}=harness(async()=>{const at=reads++;if(at)await secondRead.promise;return page(at*96);},engine,
    {previewGate:preview.promise,previewStarted:previewStarted.resolve});
  try{
    await start();await previewStarted.promise;secondRead.resolve();
    await until(()=>service.state?.status==='error');assert.equal(service.state?.canFinish,true);
    assert.equal(service.state?.telemetry?.lastIssue,'capacity');
    const stoppedReads=reads;await sleep(35);assert.equal(reads,stoppedReads,'closed queue must not spin/read while preview is blocked');
    await service.cancel();preview.resolve();await sleep(20);
    assert.equal(service.state,null);assert.equal(disposed(),true);
  }finally{secondRead.resolve();preview.resolve();await service.cancel();}
});
