import assert from 'node:assert/strict';
import {test} from 'node:test';
import {mkdtemp,readFile,readdir,rm,writeFile,mkdir} from 'node:fs/promises';
import path from 'node:path';
import {FrameFingerprint} from '../src/main/services/frame-fingerprint';
import {CaptureTelemetry} from '../src/shared/scroll-capture/telemetry';
import {buildDiagnosticReport,diagnosticGuidance} from '../src/shared/scroll-capture/diagnostics';
import {saveLongshotDiagnostics} from '../src/main/services/longshot-file';
import type {LongshotState} from '../src/shared/longshot';
const state=(patch:Partial<LongshotState>={}):LongshotState=>({id:'test',status:'capturing',scrollMode:'manual',frames:1,width:128,height:320,initialHeight:320,appendedRows:0,message:'test',telemetry:new CaptureTelemetry().snapshot(),...patch});
test('adjacent reads detect a one-byte change and dimension changes without retaining mutable source buffers',()=>{
  const meter=new FrameFingerprint(),frame={width:2,height:3,data:new Uint8Array(24).fill(17)};
  assert.equal(meter.observe(frame),'first');assert.equal(meter.observe({...frame,data:frame.data.slice()}),'same');
  frame.data[13]++;assert.equal(meter.observe(frame),'changed');assert.equal(meter.observe(frame),'same');
  assert.equal(meter.observe({...frame,width:3,height:2}),'changed');meter.clear();assert.equal(meter.observe(frame),'first');
});
test('read equality counts stay separate from match results, reject/revisit/duplicates and pause resets',()=>{
  const meter=new CaptureTelemetry();
  for(const [i,change] of ['first','same','same','changed','same','changed'].entries())meter.captured(100+i*100,change as 'first'|'same'|'changed');
  meter.result({kind:'duplicate',width:128,height:320,appendedRows:0,revisited:true});
  const data=meter.snapshot();assert.equal(data.captured,6);assert.equal(data.identicalReads,3);assert.equal(data.changedReads,2);assert.equal(data.duplicates,1);assert.equal(data.identicalReadStreak,0);
  meter.captured(800,'same');meter.captured(900,'same');assert.equal(meter.snapshot().identicalReadStreak,2);
  meter.resetRate();assert.equal(meter.snapshot().identicalReadStreak,0);assert.equal(meter.snapshot().identicalReads,5);
  meter.retried(1);meter.retried(NaN);meter.retried(-1);assert.equal(meter.snapshot().readRetries,1);
});
test('unchanged-read advice records uncertainty and cannot claim input, GPU or browser root cause',()=>{
  const value=state();value.telemetry!.identicalReadStreak=4;
  const advice=diagnosticGuidance(value);assert.equal(advice.code,'unchanged-read');assert.match(advice.action,/不能区分/);
  value.telemetry!.identicalReadStreak=0;value.telemetry!.changedReads=30;
  value.telemetry!.rejectionStreak=3;value.telemetry!.lastIssue='no-overlap';
  assert.equal(diagnosticGuidance(value).code,'overlap-rejected');
});
test('guidance prioritizes stop/review/pause/backpressure and never labels a single-frame result complete',()=>{
  assert.equal(diagnosticGuidance(null).code,'preparing');
  const value=state();value.telemetry!.identicalReadStreak=5;value.telemetry!.waitingForSpace=true;
  assert.equal(diagnosticGuidance(value).code,'backpressure');value.paused=true;assert.equal(diagnosticGuidance(value).code,'paused');
  value.regionCandidate={x:0,y:0,width:10,height:10};assert.equal(diagnosticGuidance(value).code,'body-review');
  value.status='error';value.telemetry!.lastIssue='capacity';assert.equal(diagnosticGuidance(value).code,'capacity');
  value.telemetry!.lastIssue='capture-error';assert.equal(diagnosticGuidance(value).code,'capture-error');
  value.status='done';assert.equal(diagnosticGuidance(value).code,'single-frame');value.appendedRows=100;assert.equal(diagnosticGuidance(value).code,'stitched');
});
test('guidance differentiates changed history, ambiguous content, frame errors, local changes and revisits',()=>{
  const value=state();value.telemetry!.rejectionStreak=1;
  for(const [issue,code] of [['history-changed','history-changed'],['ambiguous-overlap','ambiguous-overlap'],['fixed-region-changed','fixed-region'],['size-changed','frame-invalid']] as const){value.telemetry!.lastIssue=issue;assert.equal(diagnosticGuidance(value).code,code);}
  value.telemetry!.rejectionStreak=0;value.telemetry!.lastResult='duplicate';value.telemetry!.lastVerification='localized';assert.equal(diagnosticGuidance(value).code,'local-change');
  value.telemetry!.lastVerification='strict';value.revisited=true;assert.equal(diagnosticGuidance(value).code,'revisit');
});

test('diagnostics report only an allow-listed actual capture backend',()=>{
  assert.equal(buildDiagnosticReport(state({captureBackend:'gdi-roi'}),1).capture.backend,'gdi-roi');
  assert.equal(buildDiagnosticReport(state({captureBackend:'electron-snapshot'}),1).capture.backend,'electron-snapshot');
  assert.equal(buildDiagnosticReport(state({captureBackend:'private-path' as never}),1).capture.backend,'unknown');
});
test('diagnostic report excludes all free text, images, identifiers, settings, hashes and untrusted extra fields',()=>{
  const secret='PRIVATE-TEST-DO-NOT-EXPORT',value=state({id:secret,message:secret,error:secret,preview:'data:'+secret,livePreview:secret,liveDetailPreview:secret});
  Object.assign(value,{apiKey:secret,settings:{apiKey:secret},windowTitle:secret,sourceURL:secret,hash:secret});
  Object.assign(value.telemetry!,{extra:secret,lastIssue:secret,activity:secret});
  const report=buildDiagnosticReport(value,1200,{appVersion:'0.16.0',systemVersion:'10.0.19045',platform:'win32',displayWidth:2560,displayHeight:1600,scaleFactor:1.5});
  const serialized=JSON.stringify(report);assert.ok(serialized.length<9000);assert.ok(!serialized.includes(secret));assert.ok(!serialized.includes('data:'));
  assert.equal(report.telemetry.lastIssue,null);assert.equal(report.telemetry.activity,'preparing');assert.equal(report.environment.displayWidth,2560);
});
test('reports keep signed document coordinates, finite counters and detached environment/timing values',()=>{
  const value=state({coveredTop:-120,coveredBottom:900,viewportY:-90});value.telemetry!.capture.average=Infinity;value.telemetry!.rejected=NaN;value.telemetry!.peakBytes=-1;
  const env={appVersion:'C:/private/file',systemVersion:'invalid private text',platform:'other',displayWidth:NaN,displayHeight:Infinity,scaleFactor:Infinity};
  const report=buildDiagnosticReport(value,NaN,env);
  assert.equal(report.capture.coveredTop,-120);assert.equal(report.capture.viewportY,-90);assert.equal(report.capture.elapsedMs,0);
  assert.equal(report.telemetry.capture.average,0);assert.equal(report.telemetry.rejected,0);assert.equal(report.telemetry.peakBytes,0);assert.equal(report.environment.appVersion,'unknown');
  assert.ok(!JSON.stringify(report).includes('private'));
  report.telemetry.capture.last=999;report.environment.displayWidth=100;
  assert.equal(value.telemetry!.capture.last,0);assert.ok(Number.isNaN(env.displayWidth));
});
test('diagnostic JSON saves only to a selected path, preserves prior files on cancellation and cleans temporary files',async()=>{
  await mkdir('.runtime',{recursive:true});const directory=await mkdtemp(path.join('.runtime','diagnostic-file-'));
  try{
    const destination=path.join(directory,'诊断.json'),report=buildDiagnosticReport(state(),100);
    await writeFile(destination,'previous');let checks=0;
    await assert.rejects(saveLongshotDiagnostics(destination,report,()=>++checks===1),/取消/);
    assert.equal(await readFile(destination,'utf8'),'previous');assert.deepEqual(await readdir(directory),['诊断.json']);
    await assert.rejects(saveLongshotDiagnostics(path.join(directory,'wrong.png'),report),/json/);
    await saveLongshotDiagnostics(destination,report);
    assert.deepEqual(JSON.parse(await readFile(destination,'utf8')),report);assert.deepEqual(await readdir(directory),['诊断.json']);
  }finally{assert.ok(path.resolve(directory).startsWith(path.resolve('.runtime')+path.sep));await rm(directory,{recursive:true,force:true});}
});
