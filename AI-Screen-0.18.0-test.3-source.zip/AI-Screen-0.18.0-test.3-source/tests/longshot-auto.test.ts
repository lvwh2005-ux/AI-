import { it } from 'node:test';
import assert from 'node:assert/strict';
import { AutoScrollPolicy } from '../src/shared/longshot-auto';
import type { StitchResult } from '../src/shared/longshot-stitcher';

const result = (kind: StitchResult['kind'], reason?: string): StitchResult => ({ kind, width: 160, height: 900, appendedRows: kind === 'appended' ? 120 : 0, reason });
it('requires three wheel attempts with delayed rechecks before completing an already moving page', () => {
  const policy = new AutoScrollPolicy();
  assert.equal(policy.observe(result('initial')).kind, 'scroll'); policy.didScroll();
  assert.equal(policy.observe(result('appended')).kind, 'scroll'); policy.didScroll();
  for (let attempt = 0; attempt < 3; attempt++) {
    assert.deepEqual(policy.observe(result('duplicate')), { kind: 'verify', delayMs: 1200 });
    const decision = policy.observe(result('duplicate'));
    assert.equal(decision.kind, attempt === 2 ? 'finish' : 'scroll');
    if (decision.kind === 'scroll') policy.didScroll();
  }
});
it('never calls a non-scrolling or blocked page complete and preserves manual fallback', () => {
  const policy = new AutoScrollPolicy();
  policy.observe(result('initial')); policy.didScroll();
  for (let attempt = 0; attempt < 3; attempt++) {
    assert.equal(policy.observe(result('duplicate')).kind, 'verify');
    const decision = policy.observe(result('duplicate'));
    assert.equal(decision.kind, attempt === 2 ? 'pause' : 'scroll');
    if (decision.kind === 'scroll') policy.didScroll();
  }
});
it('late loaded content resets no-movement detection instead of dropping new rows', () => {
  const policy = new AutoScrollPolicy();
  policy.observe(result('appended')); policy.didScroll();
  assert.equal(policy.observe(result('duplicate')).kind, 'verify');
  assert.equal(policy.observe(result('appended')).kind, 'scroll'); policy.didScroll();
  for (let i = 0; i < 2; i++) {
    assert.equal(policy.observe(result('duplicate')).kind, 'verify');
    assert.equal(policy.observe(result('duplicate')).kind, 'scroll'); policy.didScroll();
  }
});
it('ambiguous overlap or resource limits pause immediately without another wheel action', () => {
  const policy = new AutoScrollPolicy();
  for (const reason of ['重叠不足', '反向滚动', '动态内容', '固定栏']) {
    assert.deepEqual(policy.observe(result('rejected', reason)), { kind: 'pause', reason });
  }
  assert.deepEqual(policy.observe(result('limit', '像素预算不足')), { kind: 'pause', reason: '像素预算不足' });
});
it('bounds unattended scrolling by both step count and time, including repeated resume', () => {
  let now = 100;
  const policy = new AutoScrollPolicy({ maxSteps: 2, maxDurationMs: 5000, now: () => now });
  policy.observe(result('initial')); policy.didScroll();
  assert.equal(policy.observe(result('appended')).kind, 'scroll');
  now += 5001;
  assert.equal(policy.observe(result('appended')).kind, 'pause');
  policy.resume();
  assert.equal(policy.observe(result('appended')).kind, 'scroll'); policy.didScroll();
  policy.resume();
  assert.equal(policy.observe(result('appended')).kind, 'pause');
});
