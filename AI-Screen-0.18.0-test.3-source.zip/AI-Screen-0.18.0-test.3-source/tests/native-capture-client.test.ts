import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {PassThrough,Writable} from 'node:stream';
import {test} from 'node:test';
import {NativeCaptureClient,type NativeCaptureChild} from '../src/main/services/native-capture-client';
const rect={x:-100,y:20,width:8,height:4},monitor={x:-200,y:0,width:200,height:100};
function reply(value=1){const out=Buffer.alloc(24+8*4*4,value);out.writeUInt32LE(0x31434447,0);out.writeUInt32LE(128,4);out.writeUInt32LE(8,8);out.writeUInt32LE(4,12);out.writeBigInt64LE(2500n,16);return out;}
class Child extends EventEmitter{
  pid=111;stdout=new PassThrough();stderr=new PassThrough();killed=0;requests=0;
  onRead?:()=>void;
  stdin=new Writable({write:(chunk,_encoding,done)=>{assert.deepEqual([...chunk],[114]);this.requests++;queueMicrotask(()=>this.onRead?.());done();}});
  kill(){this.killed++;this.emit('exit',0);return true;}
}
function harness(timeoutMs=1000,frameIntervalMs=0){
  const child=new Child();let launches=0;
  const client=new NativeCaptureClient('unused.exe',rect,monitor,{timeoutMs,frameIntervalMs,launch:()=>{launches++;return child as unknown as NativeCaptureChild;}});
  return {child,client,launches:()=>launches};
}
test('native ROI framing handles arbitrarily split headers/pixels, reuses one worker and owns each frame',async()=>{
  const {client,child,launches}=harness();let index=0;
  child.onRead=()=>{const out=reply(++index);for(let i=0;i<out.length;i+=7)child.stdout.write(out.subarray(i,i+7));};
  try{
    const a=await client.read(new AbortController().signal),b=await client.read(new AbortController().signal);
    assert.equal(a.width,8);assert.equal(a.height,4);assert.equal(a.nativeMs,2.5);assert.equal(a.data[0],1);assert.equal(b.data[0],2);
    b.data.fill(0);assert.equal(a.data[0],1);assert.equal(launches(),1);assert.equal(child.requests,2);
  }finally{client.dispose();client.dispose();assert.equal(child.killed,1);}
});
test('native framing rejects wrong magic, excessive bytes, changed size, invalid timings and trailing data',async()=>{
  for(const kind of ['magic','length','width','height','time','extra']){
    const {client,child}=harness();child.onRead=()=>{
      let out=reply();if(kind==='magic')out.writeUInt32LE(0,0);if(kind==='length')out.writeUInt32LE(0xffffffff,4);
      if(kind==='width')out.writeUInt32LE(9,8);if(kind==='height')out.writeUInt32LE(5,12);if(kind==='time')out.writeBigInt64LE(-1n,16);
      if(kind==='extra')out=Buffer.concat([out,Buffer.from([0])]);child.stdout.write(out);
    };
    await assert.rejects(client.read(new AbortController().signal),/数据|多余/);assert.equal(child.killed,1);
  }
});
test('native cancellation, concurrent pulls, process failures and partial-frame timeouts release the worker',async()=>{
  const {client,child,launches}=harness(),pre=new AbortController();pre.abort();
  await assert.rejects(client.read(pre.signal),{name:'AbortError'});assert.equal(launches(),0);
  const abort=new AbortController(),reading=client.read(abort.signal);
  await assert.rejects(client.read(new AbortController().signal),/并发/);
  const rejected=assert.rejects(reading,{name:'AbortError'});abort.abort();await rejected;assert.equal(child.killed,1);
  for(const kind of ['exit','error','end','partial']){
    const run=harness(20);run.child.onRead=()=>{
      if(kind==='exit')run.child.emit('exit',1);if(kind==='error')run.child.emit('error',new Error('synthetic'));
      if(kind==='end')run.child.stdout.end();if(kind==='partial')run.child.stdout.write(reply().subarray(0,30));
    };
    await assert.rejects(run.client.read(new AbortController().signal),/退出|启动|关闭|超时/);assert.equal(run.child.killed,1);
  }
});
test('pacing holds the single-read guard and cancellation revokes a waiting pull',async()=>{
  const {client,child}=harness(1000,100);child.onRead=()=>child.stdout.write(reply());
  await client.read(new AbortController().signal);const abort=new AbortController(),pending=client.read(abort.signal);
  await assert.rejects(client.read(new AbortController().signal),/并发/);
  const rejected=assert.rejects(pending,{name:'AbortError'});abort.abort();await rejected;
  assert.equal(child.requests,1);assert.equal(child.killed,1);
});
test('native ROI configuration requires integral bounded physical coordinates inside one monitor',()=>{
  for(const invalid of [{...rect,x:-201},{...rect,x:-1},{...rect,width:0},{...rect,width:9000},{...rect,x:1.5},{...rect,y:2147483648}]){
    assert.throws(()=>new NativeCaptureClient('unused.exe',invalid,monitor),/无效/);
  }
});
