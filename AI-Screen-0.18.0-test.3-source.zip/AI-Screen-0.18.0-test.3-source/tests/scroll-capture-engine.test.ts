import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ScrollCaptureEngine, type BitmapFrame } from '../src/shared/scroll-capture/engine';
import { thumbnailBounds, intersects, selectionExterior } from '../src/shared/scroll-capture/layout';

function scene(offset: number, top = 28, bottom = 42): BitmapFrame {
  const width = 120, height = 360, data = new Uint8Array(width * height * 4);
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) {
    const fixed = y < top ? 2000 + y : y >= height - bottom ? 4000 + y - (height - bottom) : y - top + offset;
    const i = (y * width + x) * 4;
    data[i] = (fixed * 59 + x * 11) % 251; data[i+1] = (fixed * 17 + x * 23) % 241;
    data[i+2] = ((fixed * fixed) % 251 + x * 31) % 253; data[i+3] = 255;
  }
  return { width, height, data };
}
function expected(height: number): BitmapFrame {
  const width = 120, first = scene(0), data = new Uint8Array(width * height * 4);
  const bodyHeight = height - 28 - 42;
  data.set(first.data.subarray(0, 28 * width * 4));
  for (let y = 0; y < bodyHeight; y++) {
    const row = scene(y).data.subarray(28 * width * 4, 29 * width * 4);
    data.set(row, (28 + y) * width * 4);
  }
  data.set(first.data.subarray(318 * width * 4), (height - 42) * width * 4);
  return { width, height, data };
}
test('two fixed edge bands stay once while the complete body grows across three frames', () => {
  const engine = new ScrollCaptureEngine();
  assert.equal(engine.push(scene(0)).kind, 'initial');
  const match = engine.push(scene(100));
  assert.equal(match.kind, 'appended'); assert.equal(match.fixedTop, 28); assert.equal(match.fixedBottom, 42);
  assert.equal(engine.push(scene(190)).kind, 'appended');
  assert.deepEqual(engine.bitmap(), expected(550));
  const snapshot = engine.bitmap();
  assert.equal(engine.push(scene(190)).kind, 'duplicate');
  const revisit=engine.push(scene(90));assert.equal(revisit.kind, 'duplicate');assert.equal(revisit.revisited,true);
  assert.deepEqual(engine.bitmap(), snapshot);
  const preview = engine.preview(120, 600);
  assert.deepEqual(preview, snapshot);
});
test('changing fixed bands and mismatched body never mutate the last accepted document', () => {
  const engine = new ScrollCaptureEngine(); engine.push(scene(0)); engine.push(scene(100));
  const output = engine.bitmap();
  for (const bad of [scene(190, 29, 42), scene(190, 28, 41), scene(500)]) {
    assert.equal(engine.push(bad).kind, 'rejected'); assert.deepEqual(engine.bitmap(), output);
  }
  const altered = scene(190); altered.data.fill(0, 32 * 120 * 4, 45 * 120 * 4);
  assert.equal(engine.push(altered).kind, 'rejected'); assert.deepEqual(engine.bitmap(), output);
  assert.equal(engine.push(scene(190)).kind, 'appended');
  assert.deepEqual(engine.bitmap(), expected(550));
});
test('unknown or later appearing fixed regions cannot silently switch the locked document model', () => {
  const engine = new ScrollCaptureEngine(); engine.push(scene(0, 0, 0)); engine.push(scene(100, 0, 0));
  const output = engine.bitmap(); assert.equal(engine.push(scene(200)).kind, 'rejected');
  assert.deepEqual(engine.bitmap(), output);
});
test('thumbnail avoids toolbar, scroll centre and negative-coordinate display edges', () => {
  for (const area of [{x:0,y:0,width:1920,height:1040},{x:-1536,y:-200,width:1536,height:864}]) {
    const target = { ...area }, toolbar = {x:area.x+area.width-440,y:area.y+area.height-112,width:440,height:112};
    const thumb = thumbnailBounds(target, area, toolbar);
    assert.ok(thumb.x >= area.x && thumb.y >= area.y && thumb.x + thumb.width <= area.x+area.width && thumb.y+thumb.height <= area.y+area.height);
    assert.ok(!intersects(thumb, toolbar)); assert.ok(!intersects(thumb, {x:area.x+area.width/2,y:area.y+area.height/2,width:1,height:1}));
  }
});

test('tall preview prefers the right side and aligns with the selection bottom at fractional DPI', () => {
  const area = {x:-1600,y:-120,width:1600,height:1000};
  const target = {x:-1507.5,y:-30.25,width:1008.5,height:750.5};
  const toolbar = {x:-939,y:729,width:440,height:44};
  const preview = thumbnailBounds(target, area, toolbar);
  assert.ok(preview.x >= target.x + target.width + 11);
  assert.ok(Math.abs(preview.y + preview.height - target.y - target.height) <= 1);
  assert.ok(preview.y < target.y && preview.height > preview.width * 2);
  assert.ok(Object.values(preview).every(Number.isInteger));
  assert.ok(!intersects(preview, toolbar) && !intersects(preview, target));
});

test('native mask shape leaves the whole fractional-DPI selection free of drawing and input', () => {
  const display = {x:-1707,y:-120,width:1707,height:1067};
  const target = {x:-1500.5,y:20.25,width:900.5,height:720.25};
  const local = {...target,x:target.x-display.x,y:target.y-display.y};
  const exterior = selectionExterior(target, display);
  assert.equal(exterior.length, 4);
  for (const r of exterior) {
    assert.ok(!intersects(r,local));
    assert.ok(Object.values(r).every(Number.isInteger));
    assert.ok(r.x>=0 && r.y>=0 && r.x+r.width<=display.width && r.y+r.height<=display.height);
  }
  assert.deepEqual(selectionExterior(display,display), [], 'A full-screen selection must not install an empty (rectangular) native shape');
});
