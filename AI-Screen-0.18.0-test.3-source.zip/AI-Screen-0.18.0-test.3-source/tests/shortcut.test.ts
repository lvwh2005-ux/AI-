import { it } from 'node:test';
import assert from 'node:assert/strict';
import { shortcutFromKeyEvent, type ShortcutKeyEvent } from '../src/shared/shortcut';

const event = (code: string, props: Partial<ShortcutKeyEvent> = {}): ShortcutKeyEvent => ({ code, ctrlKey: false, altKey: true, shiftKey: false, metaKey: false, ...props });

it('records letter, digit and function shortcuts from physical key codes', () => {
  assert.equal(shortcutFromKeyEvent(event('KeyA')), 'Alt+A');
  assert.equal(shortcutFromKeyEvent(event('Digit0', { ctrlKey: true, shiftKey: true })), 'Control+Alt+Shift+0');
  assert.equal(shortcutFromKeyEvent(event('F1')), 'Alt+F1');
  assert.equal(shortcutFromKeyEvent(event('F24')), 'Alt+F24');
  assert.equal(shortcutFromKeyEvent(event('KeyZ', { altKey: false, metaKey: true })), 'Super+Z');
});
it('rejects unmodified, modifier-only, repeated, composing and unsupported key events', () => {
  for (const code of ['ControlLeft', 'AltRight', 'ShiftLeft', 'MetaRight', 'Escape', 'F25', 'Unknown', 'Unidentified', 'toString', '__proto__']) assert.equal(shortcutFromKeyEvent(event(code)), null);
  assert.equal(shortcutFromKeyEvent(event('KeyA', { altKey: false })), null);
  assert.equal(shortcutFromKeyEvent(event('KeyA', { repeat: true })), null);
  assert.equal(shortcutFromKeyEvent(event('KeyA', { isComposing: true })), null);
});
it('maps navigation and numpad keys to Electron accelerator names', () => {
  assert.equal(shortcutFromKeyEvent(event('ArrowRight')), 'Alt+Right');
  assert.equal(shortcutFromKeyEvent(event('Space')), 'Alt+Space');
  assert.equal(shortcutFromKeyEvent(event('Numpad0')), 'Alt+num0');
  assert.equal(shortcutFromKeyEvent(event('NumpadAdd')), 'Alt+numadd');
  assert.equal(shortcutFromKeyEvent(event('NumpadDecimal')), 'Alt+numdec');
  assert.equal(shortcutFromKeyEvent(event('Equal')), 'Alt+=');
});
