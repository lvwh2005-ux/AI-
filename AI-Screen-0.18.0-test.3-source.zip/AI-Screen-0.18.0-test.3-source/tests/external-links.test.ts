import { it } from 'node:test';
import assert from 'node:assert/strict';
import { externalLink } from '../src/shared/external-links';
import { ShortcutRecording } from '../src/main/services/shortcut-recording';

it('accepts ordinary web links and rejects executable, credential and control-character URLs', () => {
  assert.equal(externalLink('https://example.com/path?a=1'), 'https://example.com/path?a=1');
  for (const value of ['javascript:alert(1)', 'file:///C:/secret', 'data:text/html,test', 'mailto:a@example.com', 'https://user:secret@example.com/', 'https://example.com/\npath']) assert.throws(() => externalLink(value));
});
it('suspends shortcut recording once and restores once on finish/cleanup', () => {
  let suspended = 0, restored = 0;
  const recording = new ShortcutRecording(() => suspended++, () => restored++);
  recording.begin(); recording.begin();
  assert.equal(suspended, 1); assert.equal(recording.recording, true);
  recording.end(); recording.end();
  assert.equal(restored, 1); assert.equal(recording.recording, false);
});
it('clears ownership even when re-registering a shortcut fails', () => {
  const recording = new ShortcutRecording(() => {}, () => { throw new Error('occupied'); });
  recording.begin(); assert.throws(() => recording.end(), /occupied/); assert.equal(recording.recording, false);
});
