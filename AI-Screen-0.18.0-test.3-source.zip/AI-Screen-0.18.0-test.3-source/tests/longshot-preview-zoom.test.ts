import assert from 'node:assert/strict';
import {test} from 'node:test';
import {randomUUID} from 'node:crypto';
import {ScrollCaptureEngine} from '../src/shared/scroll-capture/engine';
import {previewCssScale,clampPreviewZoom,wheelPreviewZoom,zoomScroll,viewportRegion,type ViewportRequest} from '../src/shared/scroll-capture/preview-viewport';
import {previewWindowRequestSchema,type PreviewWindowState} from '../src/shared/scroll-capture/preview-window';
import {PreviewViewSender} from '../src/renderer/longshot/preview-view-sender';
import type {BitmapFrame} from '../src/shared/scroll-capture/types';
import {referencePixel} from './preview-reference';

const request=(zoom=1,x=0,y=0,follow=false):ViewportRequest=>({sequence:1,pixels:{width:96,height:80},settings:{zoom,x,y,follow,coveredTop:0,viewportDip:{width:64,height:54}}});
const document={width:512,height:1600,coveredTop:-100,fixedTop:20,followTop:500,followBottom:820,preferTop:false};
function pixels(width:number,height:number):BitmapFrame{
  const data=new Uint8Array(width*height*4);let n=17;
  for(let at=0;at<data.length;at+=4){n=Math.imul(n^(n>>>13),1597334677)+12345|0;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;}
  return{width,height,data};
}
const crop=(source:BitmapFrame,y:number,height:number)=>({width:source.width,height,data:source.data.slice(y*source.width*4,(y+height)*source.width*4)});
test('zoom percentages represent physical source pixels at 100/125/150/200 percent display scaling',()=>{
  for(const dpi of [1,1.25,1.5,2])for(const zoom of [.5,.75,1,1.25,4])assert.equal(previewCssScale(zoom,dpi)*dpi,zoom);
  assert.equal(previewCssScale(1,NaN),1);assert.equal(clampPreviewZoom(NaN),1);
  assert.equal(clampPreviewZoom(.1),.25);assert.equal(clampPreviewZoom(8),4);
  assert.ok(wheelPreviewZoom(1,-120)>1);assert.ok(wheelPreviewZoom(1,120)<1);
  assert.equal(wheelPreviewZoom(1,3,1),wheelPreviewZoom(1,48));
  assert.equal(wheelPreviewZoom(1,1,2),wheelPreviewZoom(1,240));
  assert.equal(wheelPreviewZoom(4,-99999),4);assert.equal(wheelPreviewZoom(.25,99999),.25);
});
test('zoom preserves source point under cursor, clamping and centering only at document edges',()=>{
  assert.deepEqual(zoomScroll({width:1000,height:2000},{width:200,height:300},{x:400,y:600},{x:80,y:90},.5),{x:120,y:210});
  assert.deepEqual(zoomScroll({width:100,height:200},{width:400,height:500},{x:50,y:100},{x:200,y:250},1),{x:0,y:0});
  assert.deepEqual(zoomScroll({width:1000,height:2000},{width:200,height:300},{x:999,y:1999},{x:0,y:0},1),{x:800,y:1700});
});
test('ROI bounds, current viewport following and upward insertion use document coordinates',()=>{
  const view=request(1,33,400);view.settings.coveredTop=-100;
  assert.deepEqual(viewportRegion(document,view),{x:33,y:400,width:96,height:80});
  assert.deepEqual(viewportRegion(document,request(.5,99999,99999)),{x:320,y:1440,width:192,height:160});
  assert.equal(viewportRegion(document,request(1,0,0,true)).y,740);
  assert.equal(viewportRegion({...document,preferTop:true},request(1,0,0,true)).y,500);
  assert.equal(viewportRegion(document,request(1,0,400)).y,500,'prepend keeps the same body rows visible');
  assert.equal(viewportRegion(document,request(1,0,10)).y,10,'fixed header is not shifted by prepend');
  assert.deepEqual(viewportRegion({...document,width:30,height:40},request()),{x:0,y:0,width:30,height:40});
  assert.throws(()=>viewportRegion(document,{...request(),pixels:{width:3000,height:1}}),/尺寸/);
  assert.deepEqual(viewportRegion({...document,width:8192,height:30000},{...request(),pixels:{width:2048,height:2048},visiblePixels:{width:2560,height:3000}}),{x:0,y:0,width:2560,height:3000},'sample cap must not leave part of a large viewport empty');
  assert.throws(()=>viewportRegion(document,{...request(),visiblePixels:{width:Infinity,height:10}}),/尺寸/);
});
test('preview IPC rejects unbounded images, forged DPI, invalid sequence and stale-style extra fields',()=>{
  const input={id:randomUUID(),op:'view',sequence:1,view:request().settings};
  assert.equal(previewWindowRequestSchema.safeParse(input).success,true);
  assert.equal(previewWindowRequestSchema.safeParse({...input,view:null}).success,true);
  for(const sequence of [0,-1,NaN,Infinity,Number.MAX_SAFE_INTEGER+1])assert.equal(previewWindowRequestSchema.safeParse({...input,sequence}).success,false);
  for(const value of [{...input.view,zoom:9},{...input.view,x:-1},{...input.view,y:Infinity},{...input.view,dpi:2},{...input.view,viewportDip:{width:100000,height:1}},{...input.view,viewportDip:{width:100,height:100,image:'data:'}}])assert.equal(previewWindowRequestSchema.safeParse({...input,view:value}).success,false);
});
test('100 percent ROI reads exact original pixels across segments without flattening or mutating export',()=>{
  const source=pixels(128,1600),engine=new ScrollCaptureEngine();
  for(const y of [0,130,260,390,520])assert.equal(engine.push(crop(source,y,320)).kind,y?'appended':'initial');
  const original=engine.bitmap();
  const old=engine.bitmap;engine.bitmap=()=>{throw new Error('ROI must not flatten document');};
  for(const zoom of [.5,.75,1,1.25,4]){
    const view=request(zoom,11,510),tile=engine.viewport(view),{region,frame}=tile;
    assert.ok(frame.width<=96&&frame.height<=80&&frame.data.length<=96*80*4);
    for(let y=0;y<frame.height;y++)for(let x=0;x<frame.width;x++){
      const at=(y*frame.width+x)*4,expected=referencePixel(original,region,frame.width,frame.height,x,y);
      for(let c=0;c<4;c++)assert.ok(Math.abs(frame.data[at+c]-expected[c])<=(zoom>=1?0:1));
    }
    if(zoom===1){assert.equal(frame.width,region.width);assert.equal(frame.height,region.height);}
    frame.data.fill(0);
  }
  engine.bitmap=old;assert.deepEqual(engine.bitmap(),original);engine.clear();
});
test('ROI follows upward/top and downward/bottom capture positions while manual panning keeps the same body',()=>{
  const source=pixels(128,2000),engine=new ScrollCaptureEngine();
  for(const [y,kind] of [[600,'initial'],[470,'appended'],[340,'appended'],[470,'duplicate'],[600,'duplicate'],[730,'appended']] as const)assert.equal(engine.push(crop(source,y,320)).kind,kind);
  const tile=engine.viewport(request(1,0,0,true));assert.equal(tile.region.y+tile.region.height,engine.bitmap().height);
  assert.equal(engine.push(crop(source,340,320)).kind,'duplicate');
  assert.equal(engine.push(crop(source,210,320)).kind,'appended');const top=engine.viewport(request(1,0,0,true));assert.equal(top.region.y,0);
  const manual=request(1,0,100);manual.settings.coveredTop=-260;
  assert.equal(engine.viewport(manual).region.y,230);engine.clear();
});
test('a very large preview window shows the entire viewport while sampling within the 2048 pixel cap',()=>{
  const source=pixels(2560,1800),engine=new ScrollCaptureEngine();engine.push(source);
  const tile=engine.viewport({...request(),pixels:{width:2048,height:1200},visiblePixels:{width:2560,height:1400}});
  assert.deepEqual(tile.region,{x:0,y:0,width:2560,height:1400});
  assert.deepEqual({width:tile.frame.width,height:tile.frame.height},{width:2048,height:1120});
  for(let y=0;y<1120;y+=13)for(let x=0;x<2048;x+=17){
    const at=(y*2048+x)*4,expected=referencePixel(source,tile.region,2048,1120,x,y);
    for(let c=0;c<4;c++)assert.ok(Math.abs(tile.frame.data[at+c]-expected[c])<=1);
  }
  engine.clear();
});
test('viewport sender keeps only newest queued pan and handles failures, disposal and late replies',async()=>{
  const id=randomUUID(),value={id,positionMode:'auto',revision:0,bounds:{x:0,y:0,width:200,height:300}} as PreviewWindowState;
  const seen:number[]=[],failures:number[]=[];let release!:(v:PreviewWindowState)=>void;
  const sender=new PreviewViewSender(input=>{seen.push(input.sequence);return input.sequence===1?new Promise(resolve=>{release=resolve;}):input.sequence===4?Promise.reject(new Error('test')):Promise.resolve(value);},input=>failures.push(input.sequence));
  const submit=(sequence:number)=>sender.submit({id,op:'view',sequence,view:request().settings});
  submit(1);submit(2);submit(3);assert.deepEqual(seen,[1]);release(value);await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(seen,[1,3]);
  submit(4);await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(failures,[4]);submit(5);await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(seen,[1,3,4,5]);
  sender.dispose();submit(6);assert.deepEqual(seen,[1,3,4,5]);
});
