import {it}from'node:test';
import assert from'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,utimes,readdir,rm}from'node:fs/promises';
import path from'node:path';import os from'node:os';
import{recordingMime,recordingFormat}from'../src/shared/recording/format';
import{checkRecordingExtension}from'../src/main/services/recording/save-video';
import{removeExpiredRecordings}from'../src/main/services/recording/temp-cleanup';
import{finalizeRecordingMP4,inspectRecordingMP4}from'../src/main/services/recording/mp4-info';

it('selects AAC for MP4 and Opus for WebM without relabeling a container',()=>{
  assert.equal(recordingMime({mimeType:'video/mp4;codecs=avc1.42001E'},true),'video/mp4;codecs=avc1.42001E,mp4a.40.2');
  assert.equal(recordingMime({mimeType:'video/webm;codecs=vp8'},true),'video/webm;codecs=vp8,opus');
  assert.equal(recordingMime({mimeType:'video/mp4;codecs=avc1.42001E'},false),'video/mp4;codecs=avc1.42001E');assert.equal(recordingFormat('video/mp4;codecs=avc1').extension,'mp4');
  assert.doesNotThrow(()=>checkRecordingExtension('clip.MP4','video/mp4'));assert.throws(()=>checkRecordingExtension('clip.webm','video/mp4'),/\.mp4/);assert.throws(()=>checkRecordingExtension('clip','video/webm'),/\.webm/);
});
async function temporary(run:(root:string)=>Promise<void>){const root=await mkdtemp(path.join(os.tmpdir(),'ai-recording-delivery-'));try{await run(root);}finally{const relative=path.relative(os.tmpdir(),root);assert.ok(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative));await rm(root,{recursive:true,force:true});}}
it('expires only old app-owned recordings and leaves recent, unrelated and directory entries',()=>temporary(async root=>{
  const old='recording-00000000-0000-0000-0000-000000000001.partial',fresh='recording-00000000-0000-0000-0000-000000000002.mp4',now=Date.now()+8*86400000;
  await writeFile(path.join(root,old),'old');await writeFile(path.join(root,fresh),'active');await utimes(path.join(root,fresh),new Date(now),new Date(now));await writeFile(path.join(root,'private.mp4'),'unrelated');
  const directory='recording-00000000-0000-0000-0000-000000000003.webm';await mkdir(path.join(root,directory));
  assert.equal(await removeExpiredRecordings(root,now),1);assert.deepEqual((await readdir(root)).sort(),['private.mp4',fresh,directory].sort());assert.equal(await removeExpiredRecordings(path.join(root,'missing'),now),0);
}));
const box=(type:string,...parts:Buffer[])=>{const data=Buffer.concat(parts),header=Buffer.alloc(8);header.writeUInt32BE(data.length+8);header.write(type,4,'ascii');return Buffer.concat([header,data]);};
function mp4(){
  const mvhd=Buffer.alloc(32);mvhd.writeUInt32BE(1000,12);const tkhd=Buffer.alloc(32);tkhd.writeUInt32BE(1,12);const mdhd=Buffer.alloc(24);mdhd.writeUInt32BE(30000,12);const hdlr=Buffer.alloc(16);hdlr.write('vide',8);const stsd=Buffer.concat([Buffer.alloc(4),Buffer.from([0,0,0,1]),box('avc1',Buffer.alloc(78))]);
  const moov=box('moov',box('mvhd',mvhd),box('trak',box('tkhd',tkhd),box('mdia',box('mdhd',mdhd),box('hdlr',hdlr),box('minf',box('stbl',box('stsd',stsd))))));
  const tfhd=Buffer.alloc(12);tfhd.writeUIntBE(8,1,3);tfhd.writeUInt32BE(1,4);tfhd.writeUInt32BE(1000,8);const tfdt=Buffer.alloc(8),trun=Buffer.alloc(8);trun.writeUInt32BE(90,4);
  return Buffer.concat([box('ftyp',Buffer.from('isom0000')),moov,box('moof',box('traf',box('tfhd',tfhd),box('tfdt',tfdt),box('trun',trun))),box('mdat',Buffer.from('preserve compressed media'))]);
}
it('fills MP4 movie, track and media durations from encoded samples while preserving mdat',()=>temporary(async root=>{
  const file=path.join(root,'clip.mp4'),original=mp4();await writeFile(file,original);const info=await finalizeRecordingMP4(file);assert.equal(info.tracks[0].samples,90);assert.equal(info.tracks[0].durationSeconds,3);assert.equal(info.tracks[0].framesPerSecond,30);
  const fixed=await readFile(file);assert.equal(fixed.length,original.length);const marker=original.indexOf('mdat');assert.deepEqual(fixed.subarray(marker),original.subarray(marker));
  const mvhd=fixed.indexOf('mvhd'),tkhd=fixed.indexOf('tkhd'),mdhd=fixed.indexOf('mdhd');assert.equal(fixed.readUInt32BE(mvhd+4+16),3000);assert.equal(fixed.readUInt32BE(tkhd+4+20),3000);assert.equal(fixed.readUInt32BE(mdhd+4+16),90000);assert.deepEqual(await inspectRecordingMP4(file),info);
}));
it('rejects invalid MP4 metadata instead of inventing a successful duration',()=>temporary(async root=>{
  const file=path.join(root,'bad.mp4');for(const data of[Buffer.from('garbage'),box('ftyp',Buffer.from('isom0000')),Buffer.from([0,0,0,4,109,111,111,118])]){await writeFile(file,data);await assert.rejects(finalizeRecordingMP4(file));assert.deepEqual(await readFile(file),data);}
}));
