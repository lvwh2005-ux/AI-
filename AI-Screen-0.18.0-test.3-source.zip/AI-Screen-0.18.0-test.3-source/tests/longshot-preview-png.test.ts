import assert from 'node:assert/strict';
import {test} from 'node:test';
import {inflateSync} from 'node:zlib';
import {previewPNG} from '../src/main/services/preview-png';
function decode(png:Buffer){
  assert.deepEqual([...png.subarray(0,8)],[137,80,78,71,13,10,26,10]);
  const blocks:Buffer[]=[];let width=0,height=0;
  for(let at=8;at<png.length;){
    const size=png.readUInt32BE(at),kind=png.toString('ascii',at+4,at+8),data=png.subarray(at+8,at+8+size);
    // Independently compute CRC, without the encoder's lookup-table path.
    let crc=0xffffffff;for(const byte of png.subarray(at+4,at+8+size)){crc^=byte;for(let bit=0;bit<8;bit++)crc=crc&1?(crc>>>1)^0xedb88320:crc>>>1;}
    assert.equal((crc^0xffffffff)>>>0,png.readUInt32BE(at+8+size));
    if(kind==='IHDR'){width=data.readUInt32BE(0);height=data.readUInt32BE(4);assert.equal(data[8],8);assert.equal(data[9],6);}
    if(kind==='IDAT')blocks.push(data);at+=size+12;
  }return{width,height,rows:inflateSync(Buffer.concat(blocks))};
}
test('background preview PNG preserves BGRA colors and row boundaries with valid CRCs',()=>{
  const decoded=decode(previewPNG({width:2,height:2,data:new Uint8Array([1,2,3,255,10,20,30,255,11,22,33,255,44,55,66,255])}));
  assert.equal(decoded.width,2);assert.equal(decoded.height,2);
  assert.deepEqual([...decoded.rows],[0,3,2,1,255,30,20,10,255,0,33,22,11,255,66,55,44,255]);
});
test('preview encoder unpremultiplies alpha and rejects unbounded or malformed images',()=>{
  const decoded=decode(previewPNG({width:2,height:1,data:new Uint8Array([32,64,96,128,50,60,70,0])}));
  assert.deepEqual([...decoded.rows],[0,191,128,64,128,0,0,0,0]);
  for(const [width,height] of [[0,1],[2049,1],[1,2049],[1,1]])assert.throws(()=>previewPNG({width,height,data:new Uint8Array(0)}));
});
