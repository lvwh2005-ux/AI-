import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { annotationGeometry, annotationSchema, annotationsSchema, normalizeAnnotationPoint, type Annotation } from '../src/shared/annotations';

const pen: Annotation = { id: 'pen1', kind: 'pen', color: '#e34b43', width: 3, points: [{ x: 0.25, y: 0.5 }, { x: 1, y: 1 }] };

describe('annotation coordinates and limits', () => {
  it('keeps a stroke anchored when a selection moves and scales', () => {
    assert.deepEqual(normalizeAnnotationPoint({ x: 250, y: 180 }, { x: 200, y: 130, width: 200, height: 100 }), { x: 0.25, y: 0.5 });
    assert.deepEqual(annotationGeometry(pen, { width: 800, height: 200 }).paths[0], [{ x: 200, y: 100 }, { x: 800, y: 200 }]);
  });
  it('clips outside pointer positions to the selection without admitting invalid numbers', () => {
    assert.deepEqual(normalizeAnnotationPoint({ x: -10, y: 999 }, { x: 0, y: 0, width: 100, height: 50 }), { x: 0, y: 1 });
    assert.throws(() => normalizeAnnotationPoint({ x: NaN, y: 0 }, { x: 0, y: 0, width: 100, height: 50 }));
    assert.throws(() => normalizeAnnotationPoint({ x: 0, y: 0 }, { x: 0, y: 0, width: 0, height: 50 }));
  });
  it('draws arrow heads toward their end and remains finite for a click', () => {
    const arrow: Annotation = { id: 'arrow1', kind: 'arrow', color: '#111111', width: 2, start: { x: 0, y: 0.5 }, end: { x: 1, y: 0.5 } };
    const geometry = annotationGeometry(arrow, { width: 100, height: 50 });
    assert.equal(geometry.paths.length, 2);
    assert.equal(geometry.paths[1][1].x, 100);
    assert.ok(geometry.paths[1][0].x < 100 && geometry.paths[1][2].x < 100);
    assert.deepEqual(annotationGeometry({ ...arrow, end: arrow.start }, { width: 100, height: 50 }), { paths: [], dots: [{ x: 0, y: 25 }] });
  });
  it('normalizes reverse rectangles and preserves multiline text as data', () => {
    const rectangle: Annotation = { id: 'rect1', kind: 'rectangle', color: '#111111', width: 2, start: { x: 1, y: 1 }, end: { x: 0, y: 0 } };
    assert.deepEqual(annotationGeometry(rectangle, { width: 100, height: 50 }).paths[0], [{ x: 100, y: 50 }, { x: 0, y: 50 }, { x: 0, y: 0 }, { x: 100, y: 0 }, { x: 100, y: 50 }]);
    const text: Annotation = { id: 'text1', kind: 'text', color: '#111111', width: 2, position: { x: 0, y: 0 }, text: '<script>\n你好', fontSize: 20 };
    assert.deepEqual(annotationGeometry(text, { width: 100, height: 50 }).text?.lines, ['<script>', '你好']);
  });
  it('rejects excessive paths, duplicate IDs, malformed colors and unexpected fields', () => {
    assert.equal(annotationSchema.safeParse({ ...pen, points: [{ x: 2, y: 0 }] }).success, false);
    assert.equal(annotationSchema.safeParse({ ...pen, color: 'url(remote.svg)' }).success, false);
    assert.equal(annotationSchema.safeParse({ ...pen, width: 0 }).success, false);
    assert.equal(annotationSchema.safeParse({ ...pen, onload: 'bad' }).success, false);
    assert.equal(annotationSchema.safeParse({ ...pen, points: Array.from({ length: 4001 }, () => ({ x: 0, y: 0 })) }).success, false);
    assert.equal(annotationsSchema.safeParse([pen, pen]).success, false);
    const paths = Array.from({ length: 6 }, (_, index) => ({ ...pen, id: `p${index}`, points: Array.from({ length: 4000 }, () => ({ x: 0, y: 0 })) }));
    assert.equal(annotationsSchema.safeParse(paths).success, false);
    assert.equal(annotationsSchema.safeParse(Array.from({ length: 201 }, (_, index) => ({ ...pen, id: `p${index}` }))).success, false);
  });
});
