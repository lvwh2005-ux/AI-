import{it}from'node:test';import assert from'node:assert/strict';import{mkdtemp,writeFile,readFile,readdir,rm}from'node:fs/promises';import path from'node:path';import os from'node:os';
import{saveRecordingAtomic}from'../src/main/services/recording/save-video';import{recordingByteRange,recordingVideoResponse}from'../src/main/services/recording/video-response';import{recordingControlsBounds}from'../src/shared/recording/layout';
import{RecordingService}from'../src/main/services/recording/recording-service';import{recordingOptionsSchema,type RecordingMediaInfo,type RecordingStats}from'../src/shared/recording/contracts';
it('parses bounded single video ranges including suffixes and rejects ambiguous ranges',()=>{
  assert.deepEqual(recordingByteRange(null,100),{start:0,end:99,status:200});assert.deepEqual(recordingByteRange('bytes=0-',100),{start:0,end:99,status:206});assert.deepEqual(recordingByteRange('bytes=-10',100),{start:90,end:99,status:206});
  for(const r of['bytes=100-','bytes=20-10','bytes=0-1,2-3','bytes=-0','bogus'])assert.equal(recordingByteRange(r,100),undefined);
});
it('clamps recording controls to negative-origin and full-screen display work areas',()=>{
  const area={x:-1920,y:0,width:1920,height:1040},r=recordingControlsBounds({x:-1920,y:0,width:1920,height:1080},area);
  assert.ok(r.x>=area.x&&r.y>=area.y&&r.x+r.width<=0&&r.y+r.height<=1040);
  const outside=recordingControlsBounds({x:0,y:0,width:100,height:100},{x:0,y:0,width:1000,height:800});assert.ok(outside.y>=110);
});
async function files(run:(root:string,source:string,target:string)=>Promise<void>){const root=await mkdtemp(path.join(os.tmpdir(),'ai-recording-flow-'));try{const source=path.join(root,'source.webm'),target=path.join(root,'target.webm');await writeFile(source,'recorded video bytes');await writeFile(target,'old target');await run(root,source,target);}finally{const relative=path.relative(os.tmpdir(),root);assert.ok(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative));await rm(root,{recursive:true,force:true});}}
it('saves via target-volume temporary file, preserves source and replaces the chosen target',()=>files(async(root,source,target)=>{
  await saveRecordingAtomic(source,target,()=>{});assert.equal(await readFile(target,'utf8'),'recorded video bytes');assert.equal(await readFile(source,'utf8'),'recorded video bytes');assert.equal((await readdir(root)).length,2);
}));
it('late cancellation and copy failure preserve existing targets and remove temporary copies',()=>files(async(root,source,target)=>{
  let checks=0;await assert.rejects(saveRecordingAtomic(source,target,()=>{if(++checks===2)throw Error('cancelled');}),/cancelled/);assert.equal(await readFile(target,'utf8'),'old target');assert.equal((await readdir(root)).length,2);
  await assert.rejects(saveRecordingAtomic(source,path.join(root,'missing','out.webm'),()=>{}));assert.equal(await readFile(source,'utf8'),'recorded video bytes');
}));
it('streams only the current artifact and enforces range/method/url boundaries',()=>files(async(_root,source)=>{
  const artifact={path:source,mimeType:'video/webm',width:1,height:1,bytes:20,durationMs:1000},url='recording-video://session/current.webm';
  const response=recordingVideoResponse(new Request(url,{headers:{Range:'bytes=2-5'}}),artifact,url);assert.equal(response.status,206);assert.equal(await response.text(),'cord');
  assert.equal(recordingVideoResponse(new Request(url),undefined,url).status,403);assert.equal(recordingVideoResponse(new Request(url+'?other'),artifact,url).status,403);assert.equal(recordingVideoResponse(new Request(url,{method:'POST'}),artifact,url).status,403);
}));
it('preserves ready output after save cancellation or failure, and ignores late chooser on cancel',async()=>{
  const media:RecordingMediaInfo={mimeType:'video/webm',width:10,height:10,sourceWidth:10,sourceHeight:10,sourceFrameRate:30,codecs:{}},stats:RecordingStats={frames:30,chunks:1,bytes:10,pendingPeakBytes:10,pendingPeakChunks:1};let aborts=0;
  const service=new RecordingService({backend:()=>({prepare:async()=>media,start:async()=>{},pause:async()=>{},resume:async()=>{},stop:async()=>stats,dispose:async()=>{}}),sink:async()=>({append:async()=>{},finish:async()=>({path:'missing-source.webm',mimeType:'video/webm',width:10,height:10,bytes:10,durationMs:1000}),abort:async()=>{aborts++;}}),target:()=>({displayId:'x',displayBounds:{x:0,y:0,width:10,height:10},scaleFactor:1,rect:{x:0,y:0,width:10,height:10}})},recordingOptionsSchema.parse({countdownMs:0}));
  await service.start({displayId:'x',rect:{x:0,y:0,width:10,height:10},signal:new AbortController().signal});const id=service.state!.id;await service.command(id,'finish');
  assert.equal(await service.save(id,async()=>undefined),false);assert.equal(service.state?.status,'ready');await assert.rejects(service.save(id,async()=>{throw Error('chooser failed');}));assert.equal(service.state?.error?.code,'save-failed');assert.ok(service.artifact);
  let choose!:(v:string|undefined)=>void;const saving=service.save(id,()=>new Promise(resolve=>{choose=resolve;}));void saving.catch(()=>{});const closing=service.cancel();choose(undefined);await closing;await assert.rejects(saving);assert.equal(service.state?.status,'cancelled');assert.equal(aborts,1);
});
