import { it } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { CompatibleProvider } from '../src/main/providers/compatible';
import type { AIAction } from '../src/shared/contracts';

it('exercises real loopback HTTP requests for OCR, translation, analysis, questions and followups', async () => {
  const requests: { model: string; stream: boolean; messages: { role: string; content: unknown }[] }[] = [];
  const server = createServer(async (req, res) => {
    assert.equal(req.url, '/v1/chat/completions');
    assert.equal(req.headers.authorization, 'Bearer test-only');
    let body = ''; for await (const chunk of req) body += chunk;
    const parsed = JSON.parse(body); requests.push(parsed);
    if (parsed.stream) {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {"choices":[{"index":0,"delta":{"content":"测试"}}]}\n\n');
      res.end('data: {"choices":[{"index":0,"delta":{"content":"成功"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n');
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end('{"choices":[{"message":{"content":"OCR TEXT"}}]}');
    }
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = (server.address() as { port: number }).port;
  const provider = new CompatibleProvider({ baseUrl: `http://127.0.0.1:${port}/v1`, model: 'fixture-model', apiKey: 'test-only' });
  try {
    for (const action of ['ocr', 'translate', 'analyze', 'ask'] as AIAction[]) {
      const progress: string[] = [];
      const text = await provider.complete({ action, image: 'data:image/png;base64,fixture', question: '测试问题', language: '简体中文', history: action === 'ask' ? [{ role: 'user', content: '前文' }, { role: 'assistant', content: '回复' }] : [], signal: new AbortController().signal, onProgress: action === 'ocr' ? undefined : (text) => progress.push(text) });
      assert.equal(text, action === 'ocr' ? 'OCR TEXT' : '测试成功');
      if (action !== 'ocr') assert.deepEqual(progress, ['测试', '测试成功']);
    }
    assert.equal(requests.length, 4);
    assert.equal(requests[3].messages.length, 4);
    assert.match(JSON.stringify(requests[0].messages), /提取图片/);
    assert.match(JSON.stringify(requests[1].messages), /翻译为简体中文/);
    assert.match(JSON.stringify(requests[2].messages), /解释图片/);
    assert.match(JSON.stringify(requests[3].messages), /测试问题/);
  } finally { await new Promise<void>((resolve) => server.close(() => resolve())); }
});
