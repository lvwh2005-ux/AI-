// Standalone, isolated evidence runner; never loaded by the normal application.
import {app, BrowserWindow, desktopCapturer, nativeImage, screen} from 'electron';
import assert from 'node:assert/strict';
import {mkdir, writeFile, readFile} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {setTimeout as delay} from 'node:timers/promises';
import {StageProfiler, type ProfileSpan} from '../shared/scroll-capture/profiler';
import {ScrollCaptureEngine} from '../shared/scroll-capture/engine';
import {cropFrame} from '../shared/scroll-capture/motion-region';
import {verifyTranslation} from '../shared/scroll-capture/translation-verifier';
import type {BitmapFrame, StitchResult} from '../shared/scroll-capture/types';
import {toPixelRect} from '../shared/geometry';
import {LiveRegionSource} from './services/live-region-source';
import {LongshotProcessor} from './services/longshot-processor';
import {FrameFingerprint} from './services/frame-fingerprint';
import {CapturePipeline} from './services/capture-pipeline';
import {WindowDetector} from './services/window-detector';

interface Scenario {id:string;width:number;height:number;bodyWidth:number;bodyHeight:number}
const cases:Scenario[]=[
  {id:'body-small',width:400,height:400,bodyWidth:400,bodyHeight:400},
  {id:'body-half-width',width:800,height:400,bodyWidth:400,bodyHeight:400},
  {id:'body-quarter-width',width:1600,height:400,bodyWidth:400,bodyHeight:400},
  {id:'body-short-in-tall',width:400,height:900,bodyWidth:400,bodyHeight:400},
  {id:'body-small-in-large',width:1600,height:900,bodyWidth:400,bodyHeight:400},
  {id:'full-tall-control',width:400,height:900,bodyWidth:400,bodyHeight:900},
  {id:'full-large-control',width:1600,height:900,bodyWidth:1600,bodyHeight:900},
];
const offset=120, repetitions=5, maxFrames=16, maxRawBytes=96*1024*1024;
const root=path.resolve('.runtime/longshot-roi-stage1');
const replayArgument=process.argv.find(arg=>arg.startsWith('--replay='));
const replayDir=replayArgument ? path.resolve(replayArgument.slice('--replay='.length)) : undefined;
const mode=replayDir?'replay':process.argv.includes('--native')?'native':'synthetic';
const output=path.join(root,`${new Date().toISOString().replace(/[:.]/g,'-')}-${mode}`);
app.setPath('userData',path.join(root,'isolated-user-data'));
app.disableHardwareAcceleration(); // Only this fixture process; reported as a test condition.

// Same deterministic texture in Node and Canvas; no external or private content.
function texture(x:number,y:number){let n=Math.imul(y+17,1597334677)^Math.imul(x+7,0x119de1f3);return Math.imul(n^(n>>>13),1597334677);}
function scene(s:Scenario,shift:number):BitmapFrame{
  const data=new Uint8Array(s.width*s.height*4);
  for(let y=0;y<s.height;y++)for(let x=0;x<s.width;x++){
    const n=texture(x,x<s.bodyWidth&&y<s.bodyHeight?y+shift:y+500000),i=(y*s.width+x)*4;
    data[i]=n&255;data[i+1]=n>>>8&255;data[i+2]=n>>>16&255;data[i+3]=255;
  }return{width:s.width,height:s.height,data};
}
function imageOf(frame:BitmapFrame){return nativeImage.createFromBitmap(Buffer.from(frame.data),{width:frame.width,height:frame.height});}
function bitmap(image:Electron.NativeImage):BitmapFrame{const size=image.getSize();return{...size,data:new Uint8Array(image.toBitmap())};}
function percentile(values:number[],p:number){const sorted=[...values].sort((a,b)=>a-b);return sorted[Math.max(0,Math.ceil(sorted.length*p)-1)];}
function summarize(samples:ProfileSpan[][]){
  const stages=[...new Set(samples.flatMap(spans=>spans.map(span=>span.stage)))];
  return Object.fromEntries(stages.map(stage=>{
    const values=samples.map(spans=>spans.filter(span=>span.stage===stage).reduce((total,span)=>total+span.durationMs,0));
    return[stage,{samples:values.length,p50Ms:percentile(values,.5),p95Ms:percentile(values,.95),maxMs:Math.max(...values)}];
  }));
}
interface SavedCase {scenario:Scenario;frames:{width:number;height:number;raw:string;png:string}[]}
async function run(){
  await mkdir(output,{recursive:true});
  let fixture:BrowserWindow|undefined;
  const spans:ProfileSpan[]=[];
  const profiler=new StageProfiler(span=>{if(spans.length<4096)spans.push(span);else throw new Error('Profile capacity exceeded');});
  const display=screen.getPrimaryDisplay();
  const detector=new WindowDetector();
  let physical:{x:number;y:number;width:number;height:number};
  try{
    await detector.warmup();await detector.snapshot();
    const native=detector.getNativeDisplays().find(item=>item.x===display.nativeOrigin.x&&item.y===display.nativeOrigin.y);
    assert.ok(native,'Native Win32 monitor dimensions unavailable');physical=native;
  }finally{detector.dispose();}
  const monitor={id:String(display.id),label:'controlled-fixture',bounds:display.bounds,scaleFactor:display.scaleFactor};
  let previous: {cases:SavedCase[]}|undefined;
  if(replayDir){
    const relative=path.relative(root,replayDir);
    assert.ok(relative&&!relative.startsWith('..')&&!path.isAbsolute(relative),'Replay must select a recorded directory inside the evidence root');
    previous=JSON.parse(await readFile(path.join(replayDir,'manifest.json'),'utf8'));
    assert.ok(Array.isArray(previous?.cases)&&previous.cases.length<=8);
  }
  const saved:SavedCase[]=[],results:unknown[]=[];
  let writtenFrames=0,writtenBytes=0,readBytes=0;
  try{
    if(mode==='native'){
      const scale=display.scaleFactor;
      const width=Math.ceil(1640/scale),height=Math.ceil(940/scale);
      assert.ok(display.workArea.width>=width+32&&display.workArea.height>=height+32,'Display cannot contain the native fixture');
      fixture=new BrowserWindow({x:display.workArea.x,y:display.workArea.y,width,height,frame:false,useContentSize:true,show:false,
        alwaysOnTop:true,skipTaskbar:true,movable:false,resizable:false,backgroundColor:'#ffffff',
        webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'roi-evidence'}});
      fixture.webContents.setWindowOpenHandler(()=>({action:'deny'}));
      fixture.webContents.on('will-navigate',event=>event.preventDefault());
      fixture.webContents.session.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));
      await fixture.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'"><style>body{margin:0;overflow:hidden}canvas{display:block}#body{position:absolute;top:0;left:0;overflow:hidden}::-webkit-scrollbar{display:none}</style><canvas id="static"></canvas><div id="body"><canvas id="content"></canvas></div><script>
        const texture=${texture.toString()};
        function draw(canvas,width,height,fixed){canvas.width=width;canvas.height=height;canvas.style.width=width/devicePixelRatio+'px';canvas.style.height=height/devicePixelRatio+'px';const ctx=canvas.getContext('2d'),im=ctx.createImageData(width,height);for(let y=0;y<height;y++)for(let x=0;x<width;x++){const n=texture(x,y+(fixed?500000:0)),i=(y*width+x)*4;im.data[i]=n>>>16&255;im.data[i+1]=n>>>8&255;im.data[i+2]=n&255;im.data[i+3]=255;}ctx.putImageData(im,0,0);}
        window.configure=(width,height)=>{draw(document.getElementById('static'),1640,940,true);const body=document.getElementById('body');body.style.width=width/devicePixelRatio+'px';body.style.height=height/devicePixelRatio+'px';draw(document.getElementById('content'),width,height+600,false);body.scrollTop=0;};
        window.shift=value=>{const body=document.getElementById('body');body.scrollTop=value/devicePixelRatio;return body.scrollTop*devicePixelRatio;};
      </script>`)}`);
      fixture.webContents.setZoomFactor(1);fixture.showInactive();fixture.moveTop();await delay(250);
    }
    for(const s of cases){
      const captureSpans:ProfileSpan[][]=[],frames:BitmapFrame[]=[];
      let crop:unknown=null;
      const recorded=previous?.cases.find(entry=>entry.scenario.id===s.id);
      if(replayDir)assert.ok(recorded,'Missing recorded scenario');
      if(fixture)await fixture.webContents.executeJavaScript(`window.configure(${s.bodyWidth},${s.bodyHeight})`);
      for(let index=0;index<2;index++){
        spans.length=0;
        if(recorded&&replayDir){
          const metadata=recorded.frames[index];assert.ok(metadata&&/^[a-z0-9-]+\.bgra$/.test(metadata.raw));
          assert.ok(Number.isSafeInteger(metadata.width)&&metadata.width>0&&metadata.width<=8192&&Number.isSafeInteger(metadata.height)&&metadata.height>0&&metadata.height<=30000);
          const bytes=metadata.width*metadata.height*4;readBytes+=bytes;assert.ok(readBytes<=maxRawBytes);
          const data=await readFile(path.join(replayDir,metadata.raw));assert.equal(data.length,bytes);
          frames.push({width:metadata.width,height:metadata.height,data:new Uint8Array(data)});
        }else if(fixture){
          const actualOffset=await fixture.webContents.executeJavaScript(`window.shift(${index*offset})`);
          assert.ok(Math.abs(actualOffset-index*offset)<.01,'Fixture scroll offset differs from truth');
          await fixture.webContents.executeJavaScript('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');await delay(120);
          const bounds=fixture.getContentBounds();
          // Match the production actual-bitmap mapping; record rounding, never hide it.
          const nativePoint=screen.dipToScreenPoint({x:bounds.x,y:bounds.y});
          // Select within the edge pixels (0.1px inset), so outward rounding
          // gives exactly the requested physical ROI despite rounded display DIPs.
          const rect={x:(nativePoint.x-physical.x+.1)*display.bounds.width/physical.width,
            y:(nativePoint.y-physical.y+.1)*display.bounds.height/physical.height,
            width:(s.width-.2)*display.bounds.width/physical.width,height:(s.height-.2)*display.bounds.height/physical.height};
          crop=toPixelRect(rect,display.bounds,physical);
          const source=new LiveRegionSource(String(display.id),rect,{displays:()=>[monitor],nativeSize:()=>physical,profiler,
            sources:thumbnailSize=>desktopCapturer.getSources({types:['screen'],thumbnailSize})});
          const image=await source.read(new AbortController().signal);
          frames.push(profiler.measure('bitmap-copy',()=>bitmap(image)));
        }else frames.push(scene(s,index*offset));
        const fingerprint=new FrameFingerprint();profiler.measure('fingerprint',()=>fingerprint.observe(frames[index]));
        captureSpans.push([...spans]);
      }
      const [first,second]=frames;
      assert.equal(first.width,second.width);assert.equal(first.height,second.height);
      // Check the same known moving body in both captures before invoking the engine.
      const body={x:0,y:0,width:Math.min(s.bodyWidth,first.width),height:Math.min(s.bodyHeight,first.height)};
      const a=cropFrame(first,body),b=cropFrame(second,body);
      if(!verifyTranslation(a,b,offset,{allowLocalized:false})){
        console.error('RAW_TRUTH_MISMATCH',JSON.stringify({scenario:s,display:monitor,physical,crop,actual:{width:first.width,height:first.height},
          fixtureBounds:fixture?.getContentBounds(),firstPixels:[...first.data.slice(0,24)],secondPixels:[...second.data.slice(0,24)],
          expectedPixels:[...scene(s,0).data.slice(0,24)]}));
        throw new Error('Raw body did not capture the expected 120px translation; failed run is not acceptance evidence');
      }
      let changed=0;for(let i=0;i<first.data.length;i+=4)if(first.data[i]!==second.data[i]||first.data[i+1]!==second.data[i+1]||first.data[i+2]!==second.data[i+2])changed++;
      assert.ok(changed>0);
      const entry:SavedCase={scenario:s,frames:[]};
      for(let index=0;index<2;index++){
        const frame=frames[index],png=imageOf(frame).toPNG(),raw=Buffer.from(frame.data);
        assert.ok(++writtenFrames<=maxFrames&&(writtenBytes+=raw.length+png.length)<=maxRawBytes,'Raw recording budget exceeded');
        const stem=`${s.id}-${index+1}`;
        await writeFile(path.join(output,`${stem}.bgra`),raw,{flag:'wx'});await writeFile(path.join(output,`${stem}.png`),png,{flag:'wx'});
        entry.frames.push({width:frame.width,height:frame.height,raw:`${stem}.bgra`,png:`${stem}.png`});
      }
      saved.push(entry);
      const samples:ProfileSpan[][]=[],outcomes:StitchResult[]=[],timelines:unknown[]=[];
      // One warm-up, then five repetitions on the exact same immutable raw pair.
      const processor=new LongshotProcessor({profiler});
      try{for(let repeat=-1;repeat<repetitions;repeat++){
        spans.length=0;
        const queueEvents:unknown[]=[];
        const fingerprint=new FrameFingerprint();let frameId=0;
        const accepted:StitchResult[]=[];
        const pipeline=new CapturePipeline({maxFrames:3,maxBytes:64*1024*1024,maxFrameBytes:128*1024*1024,
          bytes:(value:{frame:BitmapFrame;id:number;enqueuedAt:number})=>value.frame.data.length,
          consume:async value=>{const started=performance.now();
            queueEvents.push({frameId:value.id,queueWaitMs:started-value.enqueuedAt,startedMs:started});
            accepted.push(await processor.push(value.frame));},
          changed:stats=>queueEvents.push({atMs:performance.now(),...stats}),failed:error=>{throw error;}});
        try{
          // The warm-up uses this same Worker. bitmap() clears its document after each pair.
          for(const frame of frames)await pipeline.capture(frame.data.length,async()=>{
            profiler.measure('fingerprint',()=>fingerprint.observe(frame));
            return{frame,id:++frameId,enqueuedAt:performance.now()};
          });
          pipeline.seal();await pipeline.idle();
          const result=accepted[1];assert.ok(result);
          const previews=await processor.preview({width:240,height:360});
          const previewFrames=[previews.overview,previews.detail];
          const expectedPreview=previewFrames.map(frame=>Buffer.from(frame.data));
          const encoded=await processor.encodePreview(previewFrames);
          for(let index=0;index<encoded.length;index++)assert.deepEqual(nativeImage.createFromDataURL(encoded[index]).toBitmap(),expectedPreview[index]);
          // Verify observational instrumentation against a plain engine, including output pixels.
          const plain=new ScrollCaptureEngine();plain.push(first);const baseline=plain.push(second);
          assert.deepEqual(result,baseline);
          const outputFrame=await processor.bitmap();assert.deepEqual(outputFrame,plain.bitmap());
          if(result.kind==='appended'){assert.equal(result.viewportDelta,offset);assert.equal(result.appendedRows,offset);}
          if(repeat>=0){samples.push([...spans]);outcomes.push(result);timelines.push({repeat,queueEvents});}
        }finally{pipeline.close();}
      }}finally{processor.dispose();}
      assert.ok(outcomes.every(result=>result.kind===outcomes[0].kind));
      const transitionSamples=samples.map(sample=>{
        const requestId=sample.filter(span=>span.stage==='worker-push').at(-1)?.metrics?.requestId;
        assert.ok(requestId!==undefined);return sample.filter(span=>span.metrics?.requestId===requestId);
      });
      const row={scenario:s,actualPixels:{width:first.width,height:first.height},crop,expectedOffset:offset,
        changedPixels:changed,changedPixelRatio:changed/(first.width*first.height),rawBodyTranslationVerified:true,
        outcome:outcomes[0],failures:outcomes.filter(result=>result.kind!=='appended').length,sampleCount:repetitions,
        pairTimings:summarize(samples),transitionTimings:summarize(transitionSamples),captureSamples:captureSpans,timeline:timelines,spans:samples,
        notExecuted:['analysis-downsample','tile-difference','manual-stability-gate','automatic-scroll','renderer-ipc-paint'],
        confidence:null};
      results.push(row);console.log(JSON.stringify({id:s.id,pixels:row.actualPixels,result:row.outcome.kind,reason:row.outcome.reasonCode,
        offset:row.outcome.viewportDelta,rawBodyTranslationVerified:true}));
    }
    const report={schemaVersion:1,mode,baselineVersion:'0.16.0',recordedAt:new Date().toISOString(),
      conditions:{platform:process.platform,os:os.release(),electron:process.versions.electron,node:process.versions.node,cpus:os.cpus()[0]?.model,
        display:{width:physical.width,height:physical.height,scaleFactor:display.scaleFactor},hardwareAcceleration:false,
        fixtureOnly:true,nativeCapture:mode==='native',realApplicationsVerified:false,warmups:1,repetitions,
        rawBudget:{maxFrames,maxRawBytes,writtenFrames,writtenBytes},timingNote:'Nested spans overlap; do not sum inclusive parent and child durations. Five samples are exploratory, not a stable performance benchmark.'},
      cases:results};
    await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2),{flag:'wx'});
    await writeFile(path.join(output,'manifest.json'),JSON.stringify({schemaVersion:1,mode,cases:saved},null,2),{flag:'wx'});
    console.log(`ROI_EVIDENCE_REPORT ${path.join(output,'report.json')}`);
  }finally{fixture?.destroy();}
}
app.whenReady().then(run).then(()=>app.exit(0),error=>{console.error(error);app.exit(1);});
