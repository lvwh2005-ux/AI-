import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { writeFile } from 'node:fs/promises';
import path from 'node:path';
import type { BrowserWindow } from 'electron';
import type { Rect } from '../shared/contracts';
import type { LongshotWindow } from './longshot-window';
import type { LongshotService } from './services/longshot';
import type { PreviewWindowState } from '../shared/scroll-capture/preview-window';

/** Production React → isolated preload → validated main geometry, synthetic
 * pointer events only. Native reads still use the owned fixture underneath. */
export async function verifyPreviewWindow(window: LongshotWindow, service: LongshotService, home: BrowserWindow, area: Rect, scale: number) {
  const preview = window.thumbnailWindow()!, controls = window.get()!, id = service.state!.id;
  const sleep = () => new Promise<void>(resolve=>setTimeout(resolve,30));
  const get = () => preview.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'get'})`) as Promise<PreviewWindowState>;
  async function rendered(mode: 'auto'|'manual') {
    const end=Date.now()+4000;
    while(Date.now()<end){if(await preview.webContents.executeJavaScript(`document.querySelector('.scroll-thumbnail')?.dataset.positionMode===${JSON.stringify(mode)}`))return;await sleep();}
    throw new Error(`Preview window mode did not render: ${mode}`);
  }
  async function gesture(selector: string, dx: number, dy: number) {
    const before=await get(),bounds=preview.getBounds();
    await preview.webContents.executeJavaScript(`(() => {
      Element.prototype.setPointerCapture=function(){};Element.prototype.hasPointerCapture=function(){return false;};
      const node=document.querySelector(${JSON.stringify(selector)});if(!node)throw new Error('Preview handle missing');
      const r=node.getBoundingClientRect(),cx=r.x+r.width/2,cy=r.y+r.height/2;
      const send=(type,x,y)=>node.dispatchEvent(new PointerEvent(type,{bubbles:true,pointerId:19,button:0,screenX:x,screenY:y,clientX:cx,clientY:cy}));
      send('pointerdown',${bounds.x+80},${bounds.y+16});send('pointermove',${bounds.x+80+dx},${bounds.y+16+dy});send('pointerup',${bounds.x+80+dx},${bounds.y+16+dy});
    })()`);
    const end=Date.now()+4000;
    while(Date.now()<end){const value=await get();if(value.revision>before.revision&&value.positionMode==='manual'){await rendered('manual');return value;}await sleep();}
    throw new Error(`Preview gesture did not complete: ${selector}`);
  }
  async function reset() {
    await preview.webContents.executeJavaScript(`document.querySelector('[data-preview-auto]').click();undefined`);
    await rendered('auto'); return get();
  }
  assert.equal((await get()).positionMode,'auto');
  for(const collectingWindow of [preview,controls])assert.equal(await collectingWindow.webContents.executeJavaScript(`document.querySelectorAll('[title]').length`),0,'Collection UI must not spawn unprotected native tooltip windows');
  for(const other of [home,controls])assert.equal(await other.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'get'}).then(()=>false,()=>true)`),true,'Only the current thumbnail may control its layout');
  assert.equal(await preview.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(randomUUID())},op:'auto'}).then(()=>false,()=>true)`),true);
  assert.equal(await preview.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'begin',edge:'move',point:{x:Infinity,y:0}}).then(()=>false,()=>true)`),true);
  await service.command(id,'pause');
  try {
    const before=await get(),widthBefore=service.state!.liveDetailPreview;
    const dx=before.bounds.x>area.x+100?-80:80;
    const dy=before.bounds.y+before.bounds.height+80<area.y+area.height?60:-30;
    const moved=await gesture('[data-preview-drag]',dx,dy);
    assert.equal(moved.bounds.x,before.bounds.x+dx);assert.equal(moved.bounds.y,before.bounds.y+dy);
    const nativeMoved=preview.getBounds();assert.ok(Math.abs(nativeMoved.x-moved.bounds.x)<=1&&Math.abs(nativeMoved.y-moved.bounds.y)<=1);
    const originalToolbar=controls.getBounds();controls.setPosition(originalToolbar.x+4,originalToolbar.y+4);await sleep();
    assert.deepEqual((await get()).bounds,moved.bounds,'Toolbar movement must not reset manual position');
    if(service.state)window.publish(service.state);await sleep();assert.deepEqual((await get()).bounds,moved.bounds);
    const resized=await gesture('[data-preview-resize=se]',60,-40);
    assert.equal(resized.bounds.width,moved.bounds.width+60);assert.equal(resized.bounds.height,moved.bounds.height-40);
    const end=Date.now()+6000;
    while(Date.now()<end){
      const supplied=await preview.webContents.executeJavaScript(`(()=>{const i=document.querySelector('.scroll-thumbnail-sheet img');return i?.complete?{width:i.naturalWidth,display:i.getBoundingClientRect().width}:null;})()`);
      if(service.state?.liveDetailPreview!==widthBefore&&supplied?.width>=Math.floor(supplied.display*scale)-2)break;
      await sleep();
    }
    assert.notEqual(service.state!.liveDetailPreview,widthBefore,'Paused resize must request fresh native-DPI pixels');
    const supplied=await preview.webContents.executeJavaScript(`(()=>{const i=document.querySelector('.scroll-thumbnail-sheet img');return {width:i.naturalWidth,display:i.getBoundingClientRect().width};})()`);
    assert.ok(supplied.width>=Math.floor(supplied.display*scale)-2);
    assert.equal(service.state!.paused,true);
    const auto=await reset();assert.equal(auto.bounds.width,resized.bounds.width);
    for(const edge of ['n','ne','e','se','s','sw','w','nw']){
      await gesture(`[data-preview-resize=${edge}]`,edge.includes('w')?-8:8,edge.includes('n')?-8:8);await reset();
    }
    const token=await preview.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'begin',edge:'move',point:{x:0,y:0}}).then(value=>value.token)`);
    await preview.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'auto'})`);
    assert.equal(await preview.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'update',token:${JSON.stringify(token)},point:{x:100,y:100}}).then(()=>false,()=>true)`),true);
    await gesture('[data-preview-drag]',-9999,9999);
    const bounded=preview.getBounds();assert.ok(bounded.x>=area.x&&bounded.y>=area.y&&bounded.x+bounded.width<=area.x+area.width&&bounded.y+bounded.height<=area.y+area.height);
    await reset();
    assert.ok(preview.isContentProtected()&&!preview.isFocusable());
    const buttonFits=await preview.webContents.executeJavaScript(`(()=>{const parent=document.querySelector('.scroll-thumbnail').getBoundingClientRect();return [...document.querySelectorAll('header button')].every(button=>{const r=button.getBoundingClientRect();return r.right<=parent.right&&r.bottom<=parent.bottom;});})()`);
    assert.equal(buttonFits,true);
    await writeFile(path.join(process.cwd(),'.runtime','longshot-stage3.2-preview.png'),(await preview.webContents.capturePage()).toPNG());
    console.log('LONGSHOT PREVIEW WINDOW PASS: React title drag/eight resize handles change native bounds, manual layout survives toolbar/state updates, paused resizing supplies native-DPI pixels, Reset preserves usable size, stale/foreign/invalid requests are rejected, extreme movement stays on-screen, protection and non-focusability remain.');
  } finally { if(service.state?.id===id&&service.state.paused)await service.command(id,'resume'); }
}
