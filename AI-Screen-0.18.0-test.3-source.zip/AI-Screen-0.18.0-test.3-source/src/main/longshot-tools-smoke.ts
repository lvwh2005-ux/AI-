import assert from 'node:assert/strict';
import {nativeImage,type BrowserWindow} from 'electron';
import {createHash,randomUUID} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import type {LongshotState} from '../shared/longshot';
import type {LongshotService} from './services/longshot';
import type {WindowManager} from './windows';
import {AnnotationCompositor} from './services/annotation-compositor';

const digest=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
async function rendered(win:BrowserWindow,expression:string,label:string) {
  await win.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+6000;const check=()=>{if(${expression})return resolve(true);if(Date.now()>end)return reject(new Error(${JSON.stringify(label)}));setTimeout(check,25);};check();})`);
}
/** Exercise the real editor handlers; only the already verified synthetic source
 * is used. No OS input, external AI, clipboard, messaging app or desktop save. */
export async function verifyLongshotTools(win:BrowserWindow,state:LongshotState,services:{longshot:LongshotService;setSavePath(path:string|undefined):void;copiedDigest():string|undefined},windows:WindowManager) {
  await rendered(win,'document.querySelector(".longshot-original-image")?.complete','original editor image');
  const original=await win.webContents.executeJavaScript(`window.screenAI.getLongshotImage(${JSON.stringify(state.id)})`);
  const baseline=nativeImage.createFromDataURL(original.image);
  assert.deepEqual(baseline.getSize(),{width:state.width,height:state.height});
  assert.equal(await win.webContents.executeJavaScript(`window.screenAI.getLongshotImage(${JSON.stringify(randomUUID())}).then(()=>false,()=>true)`),true);
  assert.equal(await win.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(state.id)},'copy',[{kind:'pen'}]).then(()=>false,()=>true)`),true);
  const click=async(selector:string)=>{await win.webContents.executeJavaScript(`document.querySelector(${JSON.stringify(selector)}).click();undefined`);};
  await rendered(win,`document.querySelector('[data-longshot-original]')?.disabled===false`,'original zoom button enabled');
  await win.webContents.executeJavaScript(`window.longshotPointerCapture=[Element.prototype.setPointerCapture,Element.prototype.hasPointerCapture,Element.prototype.releasePointerCapture];Element.prototype.setPointerCapture=()=>{};Element.prototype.hasPointerCapture=()=>false;Element.prototype.releasePointerCapture=()=>{};
    document.querySelector('[data-longshot-original]').click();undefined`);
  await rendered(win,'Math.abs(parseFloat(document.querySelector(".longshot-original-sheet").style.transform.slice(6))*devicePixelRatio-1)<1e-5','100% physical-pixel zoom');
  await rendered(win,`document.querySelector('.longshot-original-image').naturalWidth===${state.width}&&document.querySelector('.longshot-original-image').naturalHeight===${state.height}`,'full-resolution original image');
  const layout=await win.webContents.executeJavaScript(`(()=>{const controls=document.querySelector('.longshot-edit-controls').getBoundingClientRect(),viewport=document.querySelector('.longshot-edit-viewport').getBoundingClientRect();return {controlsBottom:controls.bottom,viewportTop:viewport.top};})()`);
  assert.ok(layout.viewportTop>=layout.controlsBottom,'Editor controls must not be clipped by the image viewport');
  // Scroll to the last rows before drawing, to catch viewport/zoom offset bugs.
  await win.webContents.executeJavaScript(`const viewport=document.querySelector('.longshot-edit-viewport');viewport.scrollTop=viewport.scrollHeight;undefined`);
  assert.ok(await win.webContents.executeJavaScript('document.querySelector(".longshot-edit-viewport").scrollTop > 0'),'The coordinate test must actually scroll the image');
  for(const [index,tool] of ['pen','arrow','rectangle','text'].entries()) {
    await click(`[data-longshot-tool="${tool}"]`);
    await rendered(win,`document.querySelector('.annotation-layer').dataset.annotationTool === '${tool}'`,'annotation tool selection');
    await win.webContents.executeJavaScript(`(()=>{const canvas=document.querySelector('.annotation-canvas'),viewport=document.querySelector('.longshot-edit-viewport').getBoundingClientRect(),sheet=canvas.getBoundingClientRect();
      const x=Math.max(sheet.left+18,viewport.left+18),y=Math.max(sheet.top+15,viewport.top+25)+${index*20};
      const pointer=(type,px,py)=>canvas.dispatchEvent(new PointerEvent(type,{bubbles:true,pointerId:9,button:0,clientX:px,clientY:py}));
      pointer('pointerdown',x,y);${tool==='text'?'':"pointer('pointermove',x+90,y+15);pointer('pointerup',x+120,y+20);"}return true;})()`);
    if(tool==='text') {
      await rendered(win,'!!document.querySelector(".annotation-text-input")','text draft');
      await win.webContents.executeJavaScript(`(()=>{const input=document.querySelector('.annotation-text-input');Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set.call(input,'长图标注');input.dispatchEvent(new Event('input',{bubbles:true}));})();undefined`);
      await win.webContents.executeJavaScript(`document.querySelector('.annotation-text-input').dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,key:'Enter'}));undefined`);
    }
    await rendered(win,`document.querySelector('.longshot-editor').dataset.annotationCount === '${index+1}'`,'committed annotation');
  }
  await click('[data-longshot-edit="undo"]');await rendered(win,"document.querySelector('.longshot-editor').dataset.annotationCount === '3'",'undo');
  await click('[data-longshot-edit="redo"]');await rendered(win,"document.querySelector('.longshot-editor').dataset.annotationCount === '4'",'redo');
  await click('[data-longshot-edit="clear"]');await rendered(win,"document.querySelector('.longshot-editor').dataset.annotationCount === '0'",'clear');
  await click('[data-longshot-edit="undo"]');await rendered(win,"document.querySelector('.longshot-editor').dataset.annotationCount === '4'",'undo clear');
  const point=await win.webContents.executeJavaScript(`(()=>{const list=document.querySelector('.annotation-canvas polyline').points;const p=list.getItem(1);return {x:Math.round(p.x),y:Math.round(p.y)};})()`);
  const destination=path.join(process.cwd(),'.runtime',`longshot-annotated-${randomUUID()}.png`);
  services.setSavePath(destination);
  await click('[data-longshot-action="share"]');
  await rendered(win,'!!document.querySelector(".longshot-share-menu")','share menu');
  await click('[data-longshot-share="save"]');
  await rendered(win,"document.querySelector('.longshot-footer').textContent.includes('PNG 长截图已保存')",'share PNG export');
  const exported=nativeImage.createFromBuffer(await readFile(destination));
  assert.deepEqual(exported.getSize(),baseline.getSize());
  const pixels=exported.toBitmap(),base=baseline.toBitmap();
  assert.notEqual(digest(pixels),digest(base));
  // The stroke midpoint remains in original coordinates at native zoom after scroll.
  let red=false;
  for(let y=Math.max(0,point.y-2);y<=Math.min(state.height-1,point.y+2);y++)for(let x=Math.max(0,point.x-2);x<=Math.min(state.width-1,point.x+2);x++){
    const i=(y*state.width+x)*4;if(pixels[i+2]>220&&pixels[i+1]<100&&pixels[i]<100)red=true;
  }
  assert.ok(red,'Original-size export contains the red stroke at its correct scrolled/zoomed coordinate');
  assert.deepEqual(pixels.subarray(0,state.width*4),base.subarray(0,state.width*4),'untouched first row stays exact');
  assert.equal(digest(nativeImage.createFromDataURL(services.longshot.original(state.id).image).toBitmap()),digest(base),'annotations never replace the unmodified source');
  await click('[data-longshot-action="share"]');await rendered(win,'!!document.querySelector(".longshot-share-menu")','share copy menu');
  await click('[data-longshot-share="copy"]');await rendered(win,"document.querySelector('.longshot-footer').textContent.includes('长截图已复制')",'share image copy');
  assert.equal(services.copiedDigest(),digest(pixels),'share copies the same marked original pixels as PNG export');
  assert.equal(await win.webContents.executeJavaScript('window.screenAI.getSettings().then(settings=>settings.provider)'),'demo','AI smoke must stay offline before clicking Analyze');
  await click('[data-longshot-action="analyze"]');
  const end=Date.now()+6000;
  while(!windows.get('result')&&Date.now()<end)await new Promise(resolve=>setTimeout(resolve,25));
  const result=windows.get('result');assert.ok(result,'AI opens an independent floating result');
  await rendered(result,'!!document.querySelector(".markdown-answer")','longshot AI result');
  const analysis=await result.webContents.executeJavaScript('window.screenAI.getResult()');
  assert.equal(analysis.action,'analyze');assert.equal(analysis.demo,true);assert.equal(analysis.status,'done');
  assert.equal(digest(nativeImage.createFromDataURL(analysis.image).toBitmap()),digest(pixels),'AI receives the marked full-resolution PNG, not the scaled editor viewport');
  assert.equal(await result.webContents.executeJavaScript(`window.screenAI.getLongshotImage(${JSON.stringify(state.id)}).then(()=>false,()=>true)`),true,'AI window cannot access another window raw image API');
  windows.close('result');
  await rendered(win,"document.querySelector('[data-longshot-action=copy]').disabled === false",'editor remains usable after AI closes');
  await writeFile(path.join(process.cwd(),'.runtime','longshot-tools-editor.png'),(await win.webContents.capturePage()).toPNG());
  const normalBounds=win.getBounds();win.setContentSize(640,560);
  await click('[data-longshot-action="share"]');
  await rendered(win,`(()=>{const menu=document.querySelector('.longshot-share-menu')?.getBoundingClientRect();return menu&&menu.left>=0&&menu.top>=0&&menu.right<=innerWidth&&menu.bottom<=innerHeight;})()`,'compact share menu stays inside the window');
  await new Promise(resolve=>setTimeout(resolve,120));
  await writeFile(path.join(process.cwd(),'.runtime','longshot-tools-compact.png'),(await win.webContents.capturePage()).toPNG());
  await click('[data-longshot-action="share"]');win.setBounds(normalBounds);
  await win.webContents.executeJavaScript(`[Element.prototype.setPointerCapture,Element.prototype.hasPointerCapture,Element.prototype.releasePointerCapture]=window.longshotPointerCapture;undefined`);
  const tallCompositor=new AnnotationCompositor();
  try {
    const width=96,height=20000;
    const tall=nativeImage.createFromBitmap(Buffer.alloc(width*height*4,255),{width,height});
    const marked=await tallCompositor.render(tall,{x:0,y:0,width,height},[{id:'tall-bottom',kind:'pen',color:'#EF4444',width:3,points:[{x:.25,y:.99},{x:.75,y:.99}]}]);
    assert.deepEqual(marked.getSize(),{width,height});
    const data=marked.toBitmap(),index=(19800*width+48)*4;
    assert.ok(data[index+2]>220&&data[index+1]<100&&data[index]<100,'Annotation survives beyond 16384px without cropping or scaling the PNG');
    assert.deepEqual(data.subarray(0,width*4),tall.toBitmap().subarray(0,width*4));
  } finally {tallCompositor.dispose();}
  console.log('LONGSHOT TOOLS PASS: four tools at zoomed/scrolled coordinates, undo/redo/clear, 20000px export, marked PNG/copy equality, demo AI receives the full marked PNG, role isolation, compact share menu and editor cleanup.');
}
