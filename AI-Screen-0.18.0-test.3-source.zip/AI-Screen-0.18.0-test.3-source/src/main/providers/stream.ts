// Incremental SSE parsing: UTF-8 and JSON events may cross arbitrary network chunks.
export async function readCompletionStream(response: Response, onProgress: (text: string) => void, signal: AbortSignal): Promise<string> {
  if (!response.body) throw new Error('AI 服务未返回流式数据');
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '', data: string[] = [], text = '';
  let done = false, finished = false;
  function event() {
    if (!data.length) return;
    const payload = data.join('\n'); data = [];
    if (payload === '[DONE]') { done = true; return; }
    let chunk: { error?: unknown; choices?: { index?: number; delta?: { content?: unknown }; finish_reason?: string | null }[] };
    try { chunk = JSON.parse(payload); } catch { throw new Error('AI 服务返回了无效的流式数据'); }
    if (chunk.error) throw new Error('AI 服务在输出过程中返回错误，请检查模型和服务配置');
    const choice = chunk.choices?.find((item) => (item.index ?? 0) === 0);
    if (choice?.finish_reason) finished = true;
    const delta = choice?.delta?.content;
    if (typeof delta === 'string' && delta) {
      text += delta;
      if (text.length > 2_000_000) throw new Error('AI 回复过长，已停止接收');
      onProgress(text);
    }
  }
  function lines(flush = false) {
    let end: number;
    while (!done && (end = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, end).replace(/\r$/, ''); buffer = buffer.slice(end + 1);
      if (!line) event(); else if (line.startsWith('data:')) data.push(line.slice(5).replace(/^ /, ''));
      if (data.join('').length > 1_000_000) throw new Error('AI 服务返回了过大的数据片段');
    }
    if (buffer.length > 1_000_000) throw new Error('AI 服务返回了过大的数据片段');
    if (flush && !done) {
      if (buffer.startsWith('data:')) data.push(buffer.slice(5).replace(/^ /, '').replace(/\r$/, ''));
      buffer = ''; event();
    }
  }
  const abort = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', abort, { once: true });
  try {
    while (!done) {
      signal.throwIfAborted();
      const chunk = await reader.read();
      signal.throwIfAborted();
      buffer += decoder.decode(chunk.value, { stream: !chunk.done });
      lines(chunk.done);
      if (chunk.done) break;
    }
    if (!done && !finished) throw new Error('AI 回复连接中断，请重试');
    if (!text.trim()) throw new Error('AI 服务未返回有效文本');
    return text;
  } finally { signal.removeEventListener('abort', abort); await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
