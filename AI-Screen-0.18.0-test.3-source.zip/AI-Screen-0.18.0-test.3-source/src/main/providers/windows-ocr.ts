import { spawn } from 'node:child_process';
import path from 'node:path';
import { app, nativeImage } from 'electron';
import type { OCRProvider } from './types';

export class WindowsOCRProvider implements OCRProvider {
  async recognize(image: string, signal: AbortSignal): Promise<string> {
    if (process.platform !== 'win32') throw new Error('本地 OCR 需要 Windows 10/11');
    signal.throwIfAborted();
    let bitmap = nativeImage.createFromDataURL(image);
    if (bitmap.isEmpty()) throw new Error('无法读取选区图片');
    const size = bitmap.getSize();
    const ratio = Math.min(1, 2500 / Math.max(size.width, size.height));
    if (ratio < 1) bitmap = bitmap.resize({ width: Math.max(1, Math.round(size.width * ratio)), height: Math.max(1, Math.round(size.height * ratio)), quality: 'best' });
    const script = app.isPackaged ? path.join(process.resourcesPath, 'windows-ocr.ps1') : path.join(__dirname, 'windows-ocr.ps1');
    const powershell = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const combined = AbortSignal.any([signal, AbortSignal.timeout(30_000)]);
    return new Promise<string>((resolve, reject) => {
      const child = spawn(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], signal: combined });
      let output = '';
      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (chunk: string) => {
        output += chunk;
        if (output.length > 2_000_000) { child.kill(); reject(new Error('OCR 输出过长')); }
      });
      child.stderr.resume();
      child.stdin.on('error', () => { /* close/error reports failure */ });
      child.on('error', () => reject(new Error(signal.aborted ? '已取消' : combined.aborted ? '本地 OCR 超时，请缩小选区后重试' : '无法启动 Windows OCR')));
      child.on('close', () => {
        if (combined.aborted) { reject(new Error(signal.aborted ? '已取消' : '本地 OCR 超时')); return; }
        try {
          const result = JSON.parse(output.replace(/^\uFEFF/, '')) as { ok: boolean; text?: string; code?: string };
          if (!result.ok) throw new Error(result.code === 'language' ? '未安装可用的 Windows OCR 语言包，请在 Windows 设置中安装对应语言，或改用视觉模型识别' : 'Windows OCR 识别失败，请改用视觉模型或重新框选');
          if (typeof result.text !== 'string') throw new Error('OCR 未返回有效结果');
          resolve(result.text);
        } catch (error) { reject(error instanceof SyntaxError ? new Error('Windows OCR 无法启动，请检查系统组件或改用视觉模型') : error); }
      });
      child.stdin.end(JSON.stringify({ image: bitmap.toPNG().toString('base64') }));
    });
  }
}
