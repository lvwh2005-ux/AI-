import type { AIAction, Turn } from '../../shared/contracts';

export interface AIRequest {
  action: AIAction; image: string; question: string; language: string;
  history: Turn[]; signal: AbortSignal;
  onProgress?: (text: string) => void;
  customPrompt?: string;
}
export interface AIProvider { complete(request: AIRequest): Promise<string> }
// Windows OCR / PaddleOCR can implement this without changing UI or capture code.
export interface OCRProvider { recognize(image: string, signal: AbortSignal): Promise<string> }
