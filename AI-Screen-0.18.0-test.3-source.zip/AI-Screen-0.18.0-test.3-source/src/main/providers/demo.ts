import type { AIProvider, AIRequest } from './types';

export class DemoProvider implements AIProvider {
  async complete(request: AIRequest): Promise<string> {
    await new Promise<void>((resolve, reject) => {
      const abort = () => { clearTimeout(timer); reject(new Error('已取消')); };
      const timer = setTimeout(() => { request.signal.removeEventListener('abort', abort); resolve(); }, 450);
      if (request.signal.aborted) abort();
      else request.signal.addEventListener('abort', abort, { once: true });
    });
    return `这是演示结果，不是对截图的真实识别。\n\n选区已经成功送达处理流程。${request.question ? `\n你的问题：${request.question}\n` : ''}\n在「设置」中切换到兼容 API，填写服务地址、支持图片输入的模型和 API Key，即可使用${request.action === 'ocr' ? '文字识别' : request.action === 'translate' ? '翻译' : 'AI 分析与提问'}。\n\n演示模式不会上传截图，也不会把演示文字自动写入剪贴板。`;
  }
}
