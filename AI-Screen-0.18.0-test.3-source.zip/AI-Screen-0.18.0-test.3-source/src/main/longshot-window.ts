import type { BrowserWindow } from 'electron';
import path from 'node:path';
import { release } from 'node:os';
import type { Rect } from '../shared/contracts';
import type { LongshotState } from '../shared/longshot';
import { LongshotSurfaces } from './longshot-surfaces';
import { previewPixelSize } from '../shared/scroll-capture/preview';
import type { TelemetryUpdate } from '../shared/scroll-capture/telemetry';
import type { PreviewWindowRequest } from '../shared/scroll-capture/preview-window';
import type { ViewportRequest } from '../shared/scroll-capture/preview-viewport';

function intersects(a: Rect, b: Rect) {
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}
export const LONGSHOT_CONTROL_HEIGHT = 44;
export const LONGSHOT_CONTROL_GAP = 8;

// Prefer the selection exterior. If it cannot fit, longshotPanelBounds supplies
// a visible capture-excluded overlay instead of silently hiding collection UI.
export function longshotControlsBounds(target: Rect, area: Rect): Rect | undefined {
  const height = LONGSHOT_CONTROL_HEIGHT, gap = LONGSHOT_CONTROL_GAP;
  const clamp = (value: number, minimum: number, maximum: number) => Math.max(minimum, Math.min(value, maximum));
  for (const width of [440, 360]) {
    if (width > area.width || height > area.height) continue;
    const x = clamp(target.x + target.width - width, area.x, area.x + area.width - width);
    const y = clamp(target.y, area.y, area.y + area.height - height);
    const candidates: Rect[] = [
      { x, y: Math.max(target.y + target.height + gap, area.y), width, height },
      { x, y: Math.min(target.y - height - gap, area.y + area.height - height), width, height },
      { x: Math.max(target.x + target.width + gap, area.x), y, width, height },
      { x: Math.min(target.x - width - gap, area.x + area.width - width), y, width, height },
    ];
    const match = candidates.find((candidate) => candidate.x >= area.x && candidate.y >= area.y
      && candidate.x + width <= area.x + area.width && candidate.y + height <= area.y + area.height
      && !intersects(candidate, target));
    if (match) return match;
  }
  return undefined;
}

/** A visible fallback replaces the old silent tray-only mode. Prefer a corner
 * away from the scrolling point; the protected panel is excluded from capture. */
export function longshotPanelBounds(target: Rect, area: Rect): Rect {
  const outside = longshotControlsBounds(target, area);
  if (outside) return outside;
  const width = Math.max(1, Math.min(360, area.width - 24)), height = Math.max(1, Math.min(LONGSHOT_CONTROL_HEIGHT, area.height - 24));
  const left = area.x + (area.width - width) / 2, top = area.y + (area.height - height) / 2;
  const candidates = [
    { x: area.x + area.width - width - 12, y: area.y + 12, width, height },
    { x: area.x + 12, y: area.y + 12, width, height },
    { x: area.x + area.width - width - 12, y: area.y + area.height - height - 12, width, height },
    { x: area.x + 12, y: area.y + area.height - height - 12, width, height },
  ];
  const centre = { x: target.x + target.width / 2, y: target.y + target.height / 2 };
  return candidates.find((item) => centre.x < item.x || centre.x >= item.x + item.width || centre.y < item.y || centre.y >= item.y + item.height)
    ?? { x: left, y: top, width, height };
}

export class LongshotWindow {
  private win?: BrowserWindow;
  private loaded?: Promise<void>;
  private state?: LongshotState;
  private target?: Rect;
  private backdrop?: string;
  private control = false;
  private surfaces: LongshotSurfaces;
  overlaysSelection = false;
  onPreviewResize?: () => void;

  constructor(private readonly onClosed: () => void) { this.surfaces = new LongshotSurfaces(onClosed, () => this.onPreviewResize?.()); }

  get(): BrowserWindow | undefined { return this.win && !this.win.isDestroyed() ? this.win : undefined; }
  roleOf(senderId: number): 'longshot' | undefined { return this.get()?.webContents.id === senderId ? 'longshot' : this.surfaces.roleOf(senderId); }
  collectionWindows(): BrowserWindow[] { return this.surfaces.windows(); }
  thumbnailWindow() { return this.surfaces.thumbnailWindow(); }
  previewWindow(senderId: number, input: PreviewWindowRequest) {
    if (this.thumbnailWindow()?.webContents.id !== senderId) throw new Error('只有当前预览窗口可以调整自身布局');
    return this.surfaces.previewCommand(input);
  }
  previewSize() {
    const { screen } = require('electron') as typeof import('electron');
    const bounds = this.thumbnailWindow()?.getBounds() ?? {x:0,y:0,width:390,height:800};
    return previewPixelSize(bounds, screen.getDisplayMatching(bounds).scaleFactor);
  }
  previewRequest(): {sequence:number;view?:ViewportRequest} {
    const request=this.surfaces.previewView();
    if(!request.view)return{sequence:request.sequence};
    const {screen}=require('electron') as typeof import('electron');
    const bounds=this.thumbnailWindow()!.getBounds(),scale=screen.getDisplayMatching(bounds).scaleFactor,size=this.previewSize();
    const visiblePixels={width:Math.max(1,Math.ceil(Math.min(request.view.viewportDip.width,bounds.width-2)*scale)),
      height:Math.max(1,Math.ceil(Math.min(request.view.viewportDip.height,bounds.height-118)*scale))};
    return {sequence:request.sequence,view:{sequence:request.sequence,settings:request.view,visiblePixels,pixels:{
      width:Math.min(size.width,visiblePixels.width),height:Math.min(size.height,visiblePixels.height)}}};
  }
  protectedControlHandles(): string[] {
    const win = this.get();
    if (!win || !this.control) return [];
    return [win, ...this.surfaces.windows()].filter(surface => surface.isContentProtected()).map(surface => {
      const handle = surface.getNativeWindowHandle();
      return handle.length === 8 ? handle.readBigUInt64LE().toString() : String(handle.readUInt32LE());
    });
  }

  private async ensure(): Promise<BrowserWindow> {
    const current = this.get();
    if (current) { await this.loaded; return current; }
    const { BrowserWindow } = require('electron') as typeof import('electron');
    const win = new BrowserWindow({
      width: 440, height: LONGSHOT_CONTROL_HEIGHT, useContentSize: true, frame: false, show: false,
      title: 'AI Screen · 长截图', backgroundColor: '#f5f5f5',
      icon: path.join(__dirname, 'icon.ico'),
      autoHideMenuBar: true, resizable: false, movable: false,
      minimizable: false, maximizable: false, alwaysOnTop: true, skipTaskbar: true,
      webPreferences: {
        preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false,
        contextIsolation: true, sandbox: true, webSecurity: true,
      },
    });
    // Record ownership before loading: preload/initial-page IPC can arrive while
    // loadFile is pending and must already resolve to the longshot role.
    this.win = win;
    win.on('move', () => { if (this.control) this.surfaces.reposition(win.getBounds()); });
    win.setContentProtection(true);
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', (event) => event.preventDefault());
    win.webContents.on('render-process-gone', () => { if (!win.isDestroyed()) win.destroy(); });
    win.on('closed', () => {
      if (this.win !== win) return;
      this.win = undefined;
      this.loaded = undefined;
      this.state = undefined;
      this.surfaces.close();
      this.onClosed();
    });
    this.loaded = (async () => {
      const devUrl = process.defaultApp ? process.env.AI_SCREEN_DEV_URL : undefined;
      if (devUrl === 'http://127.0.0.1:5173') await win.loadURL(`${devUrl}/#longshot`);
      else await win.loadFile(path.join(__dirname, '../renderer/index.html'), { hash: 'longshot' });
      if (win.isDestroyed() || this.win !== win) throw new Error('长截图窗口已关闭');
      if (this.state) win.webContents.send('longshot:changed', this.state);
    })();
    try { await this.loaded; return win; }
    catch (error) { if (!win.isDestroyed()) win.destroy(); throw error; }
  }

  async showControls(targetGlobalRect: Rect, backdrop?: string): Promise<boolean> {
    const { screen } = require('electron') as typeof import('electron');
    this.target = { ...targetGlobalRect };
    if (backdrop) this.backdrop = backdrop;
    const preferred = screen.getDisplayMatching(targetGlobalRect);
    const displays = [preferred, ...screen.getAllDisplays().filter((display) => display.id !== preferred.id)];
    const bounds = displays.map((display) => longshotControlsBounds(targetGlobalRect, display.workArea)).find((candidate) => !!candidate);
    const win = await this.ensure();
    const proposed = bounds ?? longshotPanelBounds(targetGlobalRect, preferred.workArea);
    const placement = {x:Math.round(proposed.x),y:Math.round(proposed.y),width:Math.round(proposed.width),height:Math.round(proposed.height)};
    this.overlaysSelection = intersects(placement, targetGlobalRect); this.control = true;
    win.setContentProtection(true);
    win.setResizable(false);
    const supportsExclusion = process.platform === 'win32' && Number(release().split('.')[2]) >= 19041;
    win.setMovable(supportsExclusion);
    win.setBounds(placement);
    win.showInactive();
    if (this.overlaysSelection && !supportsExclusion) throw new Error('当前系统无法将悬浮面板从采集中排除，请缩小选区为控制面板留出空间');
    if (supportsExclusion) await this.surfaces.show(targetGlobalRect, preferred, win.getBounds(), this.backdrop);
    if (this.get() !== win) return false;
    if (this.state) this.surfaces.publish(this.state);
    win.moveTop();
    return true;
  }

  async showPreview(): Promise<void> {
    this.surfaces.close();
    this.backdrop = undefined;
    const { screen } = require('electron') as typeof import('electron');
    const win = await this.ensure();
    this.control = false;
    win.setContentProtection(false);
    win.setSkipTaskbar(false);
    const area = screen.getDisplayMatching(this.target ?? win.getBounds()).workArea;
    const width = Math.min(900, area.width), height = Math.min(720, area.height);
    win.setResizable(true);
    win.setMinimumSize(Math.min(620,area.width),Math.min(480,area.height));
    win.setMovable(true);
    win.setBounds({ x: area.x + Math.round((area.width - width) / 2), y: area.y + Math.round((area.height - height) / 2), width, height });
    if (win.isMinimized()) win.restore();
    win.show(); win.focus();
  }

  publish(state: LongshotState): void {
    this.state = state;
    const win = this.get();
    this.surfaces.publish(state);
    if (win?.isVisible() && this.control) win.moveTop();
    if (win && !win.webContents.isLoadingMainFrame()) win.webContents.send('longshot:changed', state);
  }
  publishTelemetry(update: TelemetryUpdate): void {
    if (this.state?.id === update.id) this.state={...this.state,telemetry:update.telemetry};
    this.surfaces.publishTelemetry(update);
    const win=this.get();
    if(win&&!win.webContents.isLoadingMainFrame())win.webContents.send('longshot:telemetry',update);
  }

  close(): void {
    const win = this.get();
    this.win = undefined; this.loaded = undefined; this.state = undefined;
    this.control = false; this.overlaysSelection = false;
    this.backdrop = undefined;
    this.surfaces.close();
    // A programmatic close belongs to the service's lifecycle. It must not
    // feed an old native closed event back into a newly started session.
    // Give an initiating command IPC time to deliver its reply before its
    // renderer is destroyed. Ownership is already revoked synchronously.
    if (win && !win.isDestroyed()) {
      win.hide();
      setTimeout(() => { if (!win.isDestroyed()) win.destroy(); }, 50);
    }
  }
}
