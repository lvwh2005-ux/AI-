import { BrowserWindow, screen, type Rectangle } from 'electron';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import type { PinCommand, PinState } from '../shared/pin';

interface PinEntry {
  win: BrowserWindow;
  state: PinState;
  original: { width: number; height: number };
}

const MIN_ZOOM = 0.25;
const MAX_ZOOM = 3;
const MIN_SIZE = 64;

/** Pinned images deliberately have no capture-window parent or capture session. */
export class PinWindowManager {
  private entries = new Map<number, PinEntry>();
  private disposed = false;

  roleOf(senderId: number): 'pin' | undefined {
    const entry = this.entries.get(senderId);
    return entry && !entry.win.isDestroyed() ? 'pin' : undefined;
  }

  getForSender(senderId: number): PinState | null {
    const entry = this.entries.get(senderId);
    return entry && !entry.win.isDestroyed() ? { ...entry.state } : null;
  }

  getAll() {
    return [...this.entries.values()].filter(({ win }) => !win.isDestroyed()).map(({ win, state }) => ({
      win, state: { ...state },
    }));
  }

  async create(image: string, bounds: Rectangle, isCurrent: () => boolean = () => true): Promise<void> {
    if (this.disposed) throw new Error('应用正在退出');
    if (!isCurrent()) throw new Error('截图已取消');
    if (!image.startsWith('data:image/png;base64,') || !Object.values(bounds).every(Number.isFinite) || bounds.width <= 0 || bounds.height <= 0) {
      throw new Error('贴图内容无效，请重新截图');
    }
    if (this.entries.size >= 12) throw new Error('贴图已达到 12 张，请先关闭一些贴图');
    const fitted = this.fit(bounds, 1, bounds);
    const win = new BrowserWindow({
      ...fitted.bounds, minWidth: MIN_SIZE, minHeight: MIN_SIZE,
      title: 'AI Screen · 贴图', frame: false, alwaysOnTop: true, skipTaskbar: true,
      show: false, backgroundColor: '#f5f5f5', autoHideMenuBar: true,
      movable: true, resizable: true, minimizable: false, maximizable: false,
      fullscreenable: false, icon: path.join(__dirname, 'icon.ico'),
      webPreferences: {
        preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false,
        contextIsolation: true, sandbox: true, webSecurity: true, backgroundThrottling: false,
      },
    });
    const senderId = win.webContents.id;
    const entry: PinEntry = {
      win, original: { width: bounds.width, height: bounds.height },
      state: { id: randomUUID(), image, zoom: fitted.zoom, originalSize: { width: bounds.width, height: bounds.height } },
    };
    // Register before loading so only this window can read its own image over IPC.
    this.entries.set(senderId, entry);
    win.setAspectRatio(bounds.width / bounds.height);
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', (event) => event.preventDefault());
    win.webContents.on('render-process-gone', () => { if (!win.isDestroyed()) win.destroy(); });
    win.on('closed', () => {
      entry.state.image = '';
      this.entries.delete(senderId);
    });
    win.on('resized', () => {
      if (win.isDestroyed()) return;
      const current = win.getBounds();
      const zoom = Math.min(current.width / entry.original.width, current.height / entry.original.height);
      this.resize(entry, zoom, current);
    });
    win.on('moved', () => {
      if (win.isDestroyed()) return;
      const current = win.getBounds();
      const fit = this.fit(entry.original, entry.state.zoom, current);
      if (this.boundsDiffer(fit.bounds, current)) {
        entry.state.zoom = fit.zoom;
        win.setBounds(fit.bounds);
      }
    });
    try {
      const devUrl = process.defaultApp ? process.env.AI_SCREEN_DEV_URL : undefined;
      if (devUrl === 'http://127.0.0.1:5173') await win.loadURL(`${devUrl}/#pin`);
      else await win.loadFile(path.join(__dirname, '../renderer/index.html'), { hash: 'pin' });
      if (win.isDestroyed() || this.disposed || !isCurrent()) throw new Error('贴图创建已取消');
      // Wait for this new renderer's own image, rather than flashing an empty window.
      await win.webContents.executeJavaScript(`new Promise((resolve, reject) => {
        const end = Date.now() + 4000;
        const check = () => {
          const image = document.querySelector('.pin-image');
          if (image && image.complete && image.naturalWidth > 0) return resolve(true);
          if (Date.now() >= end) return reject(new Error('贴图画面未能加载'));
          setTimeout(check, 20);
        };
        check();
      })`);
      if (win.isDestroyed() || this.disposed || !isCurrent()) throw new Error('贴图创建已取消');
      if (!process.argv.includes('--smoke-test')) win.show();
    } catch (error) {
      if (!win.isDestroyed()) win.destroy();
      throw error;
    }
  }

  control(senderId: number, command: PinCommand): PinState | null {
    const entry = this.entries.get(senderId);
    if (!entry || entry.win.isDestroyed()) return null;
    if (command === 'close') { entry.win.close(); return null; }
    if (!['zoom-in', 'zoom-out', 'reset'].includes(command)) throw new Error('不支持的贴图操作');
    const zoom = command === 'reset' ? 1 : entry.state.zoom * (command === 'zoom-in' ? 1.2 : 1 / 1.2);
    this.resize(entry, zoom, entry.win.getBounds());
    return { ...entry.state };
  }

  dispose() {
    this.disposed = true;
    const entries = [...this.entries.values()];
    this.entries.clear();
    for (const entry of entries) {
      entry.state.image = '';
      if (!entry.win.isDestroyed()) entry.win.destroy();
    }
  }

  private resize(entry: PinEntry, zoom: number, anchor: Rectangle) {
    const fitted = this.fit(entry.original, zoom, anchor);
    entry.state.zoom = fitted.zoom;
    const previous = entry.win.getBounds();
    if (this.boundsDiffer(fitted.bounds, previous)) {
      entry.win.setBounds(fitted.bounds);
    }
  }

  private boundsDiffer(next: Rectangle, previous: Rectangle) {
    // Windows may round a DIP edge outward by one pixel at fractional scaling.
    return (['x', 'y', 'width', 'height'] as const).some((key) => Math.abs(next[key] - previous[key]) > 1);
  }

  private fit(original: { width: number; height: number }, requestedZoom: number, anchor: Rectangle) {
    const area = screen.getDisplayMatching(anchor).workArea;
    const maxFit = Math.min(area.width / original.width, area.height / original.height, MAX_ZOOM);
    const zoom = Math.max(0.01, Math.min(Math.max(requestedZoom, MIN_ZOOM), maxFit));
    // Tiny snippets retain their image ratio with object-fit, while leaving a usable close target.
    const width = Math.min(area.width, Math.max(MIN_SIZE, Math.round(original.width * zoom)));
    const height = Math.min(area.height, Math.max(MIN_SIZE, Math.round(original.height * zoom)));
    const x = Math.round(Math.max(area.x, Math.min(anchor.x, area.x + area.width - width)));
    const y = Math.round(Math.max(area.y, Math.min(anchor.y, area.y + area.height - height)));
    return { zoom, bounds: { x, y, width, height } };
  }
}
