import assert from 'node:assert/strict';
import {Worker,isMainThread,parentPort} from 'node:worker_threads';
import {writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {LongshotProcessor} from './services/longshot-processor';
import {LongshotPreviewEncoder} from './services/longshot-preview-encoder';
import {ScrollCaptureEngine} from '../shared/scroll-capture/engine';
import type {BitmapFrame} from '../shared/scroll-capture/types';
const width=1600,height=1000,size={width:2048,height:2048};
const view={sequence:1,settings:{zoom:1,follow:true,x:0,y:0,coveredTop:0,viewportDip:size},pixels:size};
function page(offset:number,rows=height):BitmapFrame{
  const data=new Uint8Array(width*rows*4);
  for(let y=0;y<rows;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height:rows,data};
}
if(!isMainThread){
  const engine=new ScrollCaptureEngine();
  parentPort!.on('message',({id,operation,frame})=>{
    if(operation==='push')parentPort!.postMessage({id,result:engine.push(frame)});
    else if(operation==='bitmap'){const result=engine.bitmap();parentPort!.postMessage({id,result},[result.data.buffer as ArrayBuffer]);}
    else{const result=engine.previews(size,view);parentPort!.postMessage({id,result},[...new Set([result.overview.data.buffer as ArrayBuffer,result.detail.data.buffer as ArrayBuffer,result.viewport!.frame.data.buffer as ArrayBuffer])]);}
  });
}else{
  void(async()=>{
    const input=Array.from({length:9},(_,i)=>page(i*120)),results=[],digests:string[][]=[];
    for(const mode of ['shared-sampling-worker','isolated-preview-worker']){
      const processor=new LongshotProcessor(),encoder=new LongshotPreviewEncoder(),worker=mode==='shared-sampling-worker'?new Worker(__filename):undefined;
      let nextId=0;const pending=new Map<number,(value:any)=>void>();
      worker?.on('message',({id,result})=>{pending.get(id)!(result);pending.delete(id);});
      const request=(operation:string,frame?:BitmapFrame):Promise<any>=>new Promise(resolve=>{const id=++nextId;pending.set(id,resolve);worker!.postMessage({id,operation,frame});});
      const push=(frame:BitmapFrame)=>worker?request('push',frame):processor.push(frame);
      const latency:number[]=[],previewLatency:number[]=[],images:string[]=[];
      const render=async()=>{
        const bundle=await(worker?request('preview'):processor.preview(size,view));
        const frames=[bundle.overview,...(bundle.detail===bundle.overview?[]:[bundle.detail]),bundle.viewport!.frame];
        return worker?encoder.encode(frames):processor.encodePreview(frames);
      };
      try{
        await push(input[0]);
        const warmStarted=performance.now();await render();const firstPreviewMs=performance.now()-warmStarted;
        for(const frame of input.slice(1)){
          const started=performance.now();
          const preview=render().then(png=>{
            images.push(createHash('sha256').update(png.join('|')).digest('hex'));previewLatency.push(performance.now()-started);
          });
          assert.equal((await push(frame)).kind,'appended');latency.push(performance.now()-started);await preview;
        }
        const output=worker?await request('bitmap'):await processor.bitmap();assert.deepEqual(output,page(0,height+960));
        const percentile=(a:number[],p:number)=>[...a].sort((a,b)=>a-b)[Math.ceil(a.length*p)-1];
        results.push({mode,transitions:8,outputPixelCorrect:true,firstPreviewMs,matchingWhilePreview:{p50Ms:percentile(latency,.5),p95Ms:percentile(latency,.95)},preview:{p50Ms:percentile(previewLatency,.5),p95Ms:percentile(previewLatency,.95)}});
        digests.push(images);
      }finally{processor.dispose();encoder.dispose();await worker?.terminate();}
    }
    assert.deepEqual(digests[0],digests[1],'previews from the same committed revision differ');
    const report={conditions:{width,height,preview:size,transitionsPerMode:8,syntheticOnly:true,nativeCapture:false,sameMatcher:true,samePNGWorker:true},previewsPixelCorrect:true,results};
    await writeFile('.runtime/longshot-stage234-preview-bench.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report));
  })().catch(error=>{console.error(error);process.exitCode=1;});
}
