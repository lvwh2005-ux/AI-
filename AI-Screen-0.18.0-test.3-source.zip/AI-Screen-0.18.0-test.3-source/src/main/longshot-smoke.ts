import assert from 'node:assert/strict';
import { BrowserWindow, Menu, nativeImage, screen, type NativeImage } from 'electron';
import { randomUUID } from 'node:crypto';
import { mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import type { Rect } from '../shared/contracts';
import type { LongshotState } from '../shared/longshot';
import type { WindowManager } from './windows';
import { LONGSHOT_CONTROL_HEIGHT, type LongshotWindow } from './longshot-window';
import type { LongshotService } from './services/longshot';
import { activateSmokeWindow, probeSmokeWindow } from './smoke-window-input';
import {verifyLongshotTools} from './longshot-tools-smoke';
import { verifyPreviewPlacement } from './longshot-placement-smoke';
import { verifyPreviewWindow } from './longshot-preview-window-smoke';
import { verifyPreviewZoom,verifyPreviewFollow } from './longshot-preview-zoom-smoke';
import {verifyDiagnosticExport,verifyDiagnosticCancel,verifyDiagnosticResult} from './longshot-diagnostics-smoke';
import {previewFilterAxis} from '../shared/scroll-capture/preview-filter';

interface Services {
  longshot: LongshotService;
  longshotWindow: LongshotWindow;
  copiedSize(): { width: number; height: number } | undefined;
  copiedDigest(): string|undefined;
  setSavePath(value: string | undefined): void;
  setDiagnosticChooser(choose:()=>Promise<string|undefined>):void;
}
const sleep = (milliseconds: number) => new Promise<void>((resolve) => setTimeout(resolve, milliseconds));
const intersects = (a: Rect, b: Rect) => a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;

/** Native screen reads from a real scrolling, synthetic-only browser fixture. */
export async function runLongshotSmoke(windows: WindowManager, home: BrowserWindow, services: Services) {
  const { longshot, longshotWindow } = services;
  const uiOnly = process.argv.includes('--longshot-ui-only');
  const display = screen.getPrimaryDisplay(), area = display.workArea, scale = display.scaleFactor;
  assert.ok(area.width >= 800 && area.height >= 650, 'Native longshot smoke requires an unobscured display work area of at least 800×650 DIP');
  const largeROI=process.argv.includes('--longshot-large-roi');
  const width = Math.floor((largeROI?area.width-64:Math.min(760, area.width - 64)) / 8) * 8;
  const height = Math.floor((largeROI?area.height-64:Math.min(640, area.height - 200)) / 8) * 8;
  const fixture = new BrowserWindow({
    x: area.x + 32, y: area.y + 32, width, height, frame: false, useContentSize: true,
    show: false, backgroundColor: '#ffffff', alwaysOnTop: true, skipTaskbar: true,
    movable: false, resizable: false, autoHideMenuBar: true,
    webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true, backgroundThrottling: false, partition: 'longshot-native-smoke' },
  });
  fixture.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  fixture.webContents.on('will-navigate', (event) => event.preventDefault());
  fixture.webContents.session.setPermissionCheckHandler(() => false);
  fixture.webContents.session.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
  let currentOverlay: BrowserWindow | undefined;
  let focusFixture: BrowserWindow | undefined;

  async function stateWhen(predicate: (state: LongshotState) => boolean, label: string, timeout = 12_000): Promise<LongshotState> {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      const state = longshot.state;
      if (state && predicate(state)) return state;
      if (state?.status === 'error') throw new Error(`Native longshot smoke ${label}: ${state.error || state.message}`);
      await sleep(40);
    }
    const state = longshot.state;
    throw new Error(`Native longshot smoke timed out: ${label}; status=${state?.status ?? 'none'}, frames=${state?.frames ?? 0}, height=${state?.height ?? 0}; ${state?.message ?? ''}`);
  }
  async function painted() {
    await fixture.webContents.executeJavaScript('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)))');
    await sleep(90);
  }

  try {
    // One long canvas is drawn once. Subsequent frames come from real document
    // scrolling, never swapped images or webContents.capturePage substitutes.
    const html = `<!doctype html><html><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:"><style>*{box-sizing:border-box}html{scroll-behavior:auto;overflow-anchor:none}body{margin:0;background:#fff;overflow-x:hidden}::-webkit-scrollbar{display:none}canvas{display:block;image-rendering:pixelated;forced-color-adjust:none}</style></head><body><canvas id="scene"></canvas><script>
      const canvas=document.getElementById('scene'), ratio=devicePixelRatio, cssWidth=innerWidth;
      window.smokeWheel={trusted:0,untrusted:0,positions:[],deltas:[],nativeDefault:false}; window.smokeScrollStep=120; window.smokeWhitePage=${largeROI};
      // This inert page has no keyboard actions. Do not let a space or a
      // navigation key page the canvas while native focus is being exercised.
      window.addEventListener('keydown',event=>event.preventDefault());
      window.setSmokeSceneHeight=(cssHeight,scrollStep=120)=>{
      window.smokeScrollStep=scrollStep; window.smokeWheel={trusted:0,untrusted:0,positions:[],deltas:[],nativeDefault:false};
      canvas.width=Math.round(cssWidth*ratio); canvas.height=Math.round(cssHeight*ratio);
      canvas.style.width=cssWidth+'px'; canvas.style.height=cssHeight+'px';
      const ctx=canvas.getContext('2d'), bitmap=ctx.createImageData(canvas.width,canvas.height);
      for(let y=0;y<canvas.height;y++) for(let x=0;x<canvas.width;x++) {
        const row=Math.floor(y/12),column=Math.floor(x/24),i=(y*canvas.width+x)*4;
        bitmap.data[i]=(row*37+column*19)%180+40; bitmap.data[i+1]=(row*59+column*23)%180+40; bitmap.data[i+2]=(row*83+column*31)%180+40; bitmap.data[i+3]=255;
      }
      ctx.putImageData(bitmap,0,0); ctx.font=Math.round(17*ratio)+'px sans-serif';
      for(let y=48*ratio;y<canvas.height;y+=64*ratio){ctx.fillStyle='#ffffff';ctx.fillRect(Math.round(canvas.width*.35),Math.round(y-22*ratio),Math.round(canvas.width*.56),Math.round(30*ratio));ctx.fillStyle='#222222';ctx.fillText('Synthetic scrolling row '+Math.round(y/ratio)+' / '+Math.round(y*y),Math.round(canvas.width*.37),Math.round(y));}
      if(window.smokeWhitePage){ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.fillStyle='#222222';
        for(let y=48*ratio;y<canvas.height;y+=32*ratio)ctx.fillText('Desktop text row '+Math.round(y/ratio)+' / '+Math.round(y*y),Math.round(canvas.width*.56),Math.round(y));}
      window.scrollTo(0,0);
      };
      window.addEventListener('wheel',event=>{
        if(!event.isTrusted){event.preventDefault();window.smokeWheel.untrusted++;return;}
        window.smokeWheel.trusted++;
        window.smokeWheel.deltas.push(event.deltaY);
        if(window.smokeWheel.nativeDefault){window.smokeWheel.positions.push(scrollY);return;}
        event.preventDefault();
        if(event.deltaY) window.scrollBy({top:Math.sign(event.deltaY)*window.smokeScrollStep,left:0,behavior:'instant'});
        window.smokeWheel.positions.push(scrollY);
      },{passive:false});
      window.setSmokeSceneHeight(2600);
    </script></body></html>`;
    await fixture.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(html)}`);
    fixture.webContents.setZoomFactor(1);
    fixture.showInactive(); fixture.moveTop();
    await painted();
    const ratio: number = await fixture.webContents.executeJavaScript('devicePixelRatio');
    assert.ok(Math.abs(ratio - scale) < .00001, 'Fixture must use the primary display native DPI');
    const bounds = fixture.getContentBounds();
    const targetGlobal: Rect = { x: bounds.x + 16, y: bounds.y + 16, width: largeROI?bounds.width-48:Math.min(bounds.width - 48, Math.floor(900 / scale / 8) * 8), height: bounds.height - 96 };
    const rect: Rect = { ...targetGlobal, x: targetGlobal.x - display.bounds.x, y: targetGlobal.y - display.bounds.y };
    assert.ok(targetGlobal.x >= area.x && targetGlobal.y >= area.y && targetGlobal.x + targetGlobal.width <= area.x + area.width && targetGlobal.y + targetGlobal.height <= area.y + area.height);
    assert.ok(targetGlobal.height > 280 && targetGlobal.width > 300);
    let step = 120;
    while (step <= 160 && Math.abs(step * scale - Math.round(step * scale)) > .00001) step++;
    assert.ok(step <= 160 && step < targetGlobal.height / 2, 'Need an integer-physical-pixel scroll step below half the region height');
    const physicalStep = Math.round(step * scale);
    const expectedWidth = Math.round(rect.width * scale), expectedHeight = Math.round(rect.height * scale);
    async function start(scrollMode?: 'manual' | 'auto') {
      if (scrollMode === 'auto') { fixture.show(); fixture.focus(); }
      else fixture.showInactive();
      fixture.moveTop();
      await painted();
      if (!uiOnly) await activateSmokeWindow(fixture);
      await home.webContents.executeJavaScript('window.screenAI.startCapture()');
      const overlay = windows.getCaptures().find((entry) => entry.displayId === String(display.id))?.win;
      assert.ok(overlay, 'Primary display must have an active capture overlay');
      currentOverlay = overlay;
      assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.getLongshot().then(() => false, () => true)'), true);
      if (scrollMode === 'auto') {
        // Keep the experimental automatic backend independently covered. The
        // normal manual entry must exercise the actual mode + selection UI.
        await overlay.webContents.executeJavaScript(`window.screenAI.startCaptureMode('longshot', ${JSON.stringify(rect)}, 'auto')`);
      } else {
        await overlay.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+5000;const poll=()=>{const button=document.querySelector('.mode-toolbar [data-mode="longshot"]');if(button){button.click();resolve(true);}else if(Date.now()>end)reject(new Error('Longshot mode did not render'));else setTimeout(poll,20);};poll();})`);
        await overlay.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+3000;const poll=()=>{if(document.querySelector('.capture')?.dataset.mode==='longshot')resolve(true);else if(Date.now()>end)reject(new Error('Longshot mode not selected'));else setTimeout(poll,20);};poll();})`);
        await overlay.webContents.executeJavaScript(`(() => {
          Element.prototype.setPointerCapture=function(){};
          Element.prototype.hasPointerCapture=function(){return false;};
          const node=document.querySelector('.capture');
          const send=(type,x,y)=>node.dispatchEvent(new PointerEvent(type,{bubbles:true,pointerId:7,button:0,clientX:x,clientY:y}));
          send('pointerdown',${rect.x},${rect.y});send('pointermove',${rect.x+rect.width},${rect.y+rect.height});send('pointerup',${rect.x+rect.width},${rect.y+rect.height});
          if(document.querySelector('.reserved-mode,.longshot-selection-hint,.longshot-start-actions'))throw new Error('Legacy longshot start card must be removed');
        })()`);
        const started=Date.now()+12_000;
        while (windows.getCaptures().length || longshot.state?.controlsInTray === undefined) {
          if(Date.now()>started)throw new Error('Selecting a longshot region must automatically open live capture controls');
          await sleep(25);
        }
      }
      assert.equal(windows.getCaptures().length, 0, 'Frozen overlays must leave before native live sampling');
      const controls = longshotWindow.get();
      assert.ok(controls, 'Longshot owns its own control renderer');
      assert.equal(longshotWindow.collectionWindows().length, 2, 'Collection owns a mask and independent thumbnail');
      assert.ok(longshotWindow.collectionWindows().every(win => win.isVisible() && win.isContentProtected() && !win.isFocusable()));
      assert.equal(controls.getContentBounds().height, LONGSHOT_CONTROL_HEIGHT, 'Live collection uses the installed single-row toolbar');
      const toolbarLayout = await controls.webContents.executeJavaScript(`(() => {
        const bounds=document.querySelector('.scroll-toolbar').getBoundingClientRect();
        return {legacy:!!document.querySelector('.layout-stage,.scroll-toolbar-status'), unavailable:document.querySelectorAll('.scroll-unavailable:disabled').length,
          fits:[...document.querySelectorAll('.scroll-toolbar button')].every(el=>{const r=el.getBoundingClientRect();return r.right<=bounds.right && r.bottom<=bounds.bottom;})};
      })()`);
      assert.equal(toolbarLayout.legacy, false);
      assert.equal(toolbarLayout.unavailable, 0);
      assert.equal(toolbarLayout.fits, true);
      const thumbnailBounds = longshotWindow.thumbnailWindow()!.getBounds();
      if (targetGlobal.x + targetGlobal.width + 12 + thumbnailBounds.width <= area.x + area.width) {
        assert.ok(thumbnailBounds.x >= targetGlobal.x + targetGlobal.width, 'Live preview prefers the right of the actual selection');
        assert.ok(Math.abs(thumbnailBounds.y + thumbnailBounds.height - targetGlobal.y - targetGlobal.height) <= 2, `Live preview and selection bottom align: ${JSON.stringify({thumbnailBounds,targetGlobal,area})}`);
      }
      if (!longshot.state?.panelOverlay) {
        assert.equal(intersects(controls.getBounds(), targetGlobal), false, 'Visible controls must be outside sampled content');
        controls.showInactive();
      }
      if (scrollMode === 'auto' && process.argv.includes('--longshot-panel-overlay')) {
        // Deliberately cover a window-guard sample point while keeping the
        // actual scroll cursor clear. The production guard must look through
        // only this owned, capture-excluded panel, never an unrelated window.
        controls.setBounds({ x: Math.round(targetGlobal.x + targetGlobal.width - 230), y: Math.round(targetGlobal.y + targetGlobal.height / 2 - 90), width: 240, height: 180 });
      }
      return controls;
    }
    async function manualStageB() {
      await fixture.webContents.executeJavaScript('window.smokeWhitePage=false;window.setSmokeSceneHeight(4000); undefined'); await painted();
      const controls = await start();
      const initial = await stateWhen(state => state.frames >= 1, 'manual default first viewport');
      assert.equal(initial.scrollMode,'manual'); assert.equal(initial.scrollSteps,0);
      await probeSmokeWindow(fixture,{x:Math.round(targetGlobal.x+targetGlobal.width/2),y:Math.round(targetGlobal.y+targetGlobal.height/2)});
      const quantum = [1,2,3,4,5,6,7,8].find(q=>Math.abs(q*scale-Math.round(q*scale))<.00001)!;
      const travel = step*6;
      await fixture.webContents.executeJavaScript(`window.manualSweep={active:true}; window.manualTimer=setInterval(()=>{const remaining=${travel}-scrollY;if(remaining<=0){clearInterval(window.manualTimer);window.manualSweep.active=false;return;}window.scrollBy({top:Math.min(remaining,${quantum*3+.5/scale}),behavior:'instant'});},25); undefined`);
      const during = await stateWhen(state => state.height > initial.height+physicalStep, 'manual continuous scrolling adds frames', 15_000);
      assert.equal(await fixture.webContents.executeJavaScript('window.manualSweep.active'),true,'Capture must append while the page is still moving');
      const deadline=Date.now()+15_000;
      while(Date.now()<deadline && await fixture.webContents.executeJavaScript('window.manualSweep.active')) await sleep(30);
      assert.equal(await fixture.webContents.executeJavaScript('scrollY'),travel);
      // Deliberately finish immediately after one last viewport change.
      const tail = quantum*10;
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${tail},behavior:'instant'}); undefined`);
      await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(initial.id)},'finish')`);
      const done = await stateWhen(state=>state.status==='done','manual final viewport catch-up');
      assert.equal(done.height,initial.height+Math.round((travel+tail)*scale)); assert.ok(done.frames>during.frames);
      const pipeline=done.telemetry!;
      assert.equal(pipeline.bufferedFrames,0);assert.equal(pipeline.bufferedBytes,0);assert.equal(pipeline.queuedFrames,0,'Done must drain all queued frames before flattening');
      assert.ok(pipeline.peakFrames>=1&&pipeline.peakFrames<=3);
      assert.ok(pipeline.peakBytes<=Math.max(64*1024*1024,initial.width*initial.height*4));
      console.log('LONGSHOT PIPELINE METRICS '+JSON.stringify({width:initial.width,height:initial.height,captured:pipeline.captured,processed:pipeline.processed,appended:pipeline.appended,rejected:pipeline.rejected,discarded:pipeline.discarded,captureFps:pipeline.captureFps,captureMs:pipeline.capture.average,matchMs:pipeline.match.average,previewMs:pipeline.preview.average,peakFrames:pipeline.peakFrames,peakBytes:pipeline.peakBytes,backpressureWaits:pipeline.backpressureWaits}));
      let canvas = nativeImage.createFromDataURL(await fixture.webContents.executeJavaScript('document.querySelector("canvas").toDataURL()'));
      const output = nativeImage.createFromDataURL(longshot.original(done.id).image); verifyCanvas(output,canvas);
      services.setSavePath(path.join(process.cwd(),'.runtime','manual-continuous-b.png'));
      await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)},'save')`);
      verifyCanvas(nativeImage.createFromBuffer(await readFile(path.join(process.cwd(),'.runtime','manual-continuous-b.png'))),canvas);
      await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)},'copy')`);
      assert.deepEqual(services.copiedSize(),{width:done.width,height:done.height});
      await verifyDiagnosticResult(longshotWindow,longshot,services.setDiagnosticChooser);
      await longshot.command(done.id,'close'); await sleep(80);
      console.log('MANUAL CONTINUOUS PASS: default manual mode captures during uninterrupted real document motion, deduplicates pauses, includes the final viewport immediately before Done, and every original pixel matches the synthetic canvas.');

      await fixture.webContents.executeJavaScript('window.scrollTo(0,0);undefined');await painted();
      const diagnosticControls=await start();
      const baseline=await stateWhen(value=>value.frames>0&&!!value.livePreview,'diagnostic manual first frame');
      await verifyDiagnosticExport(longshotWindow,longshot,home,fixture,services.setDiagnosticChooser,services.copiedDigest);
      const diagnosticThumbnail=longshotWindow.thumbnailWindow()!;
      await diagnosticThumbnail.webContents.executeJavaScript(`window.diagnosticUpdates=[];window.screenAI.onLongshotTelemetry(value=>{window.diagnosticUpdates.push({id:value.id,keys:Object.keys(value).sort(),bytes:JSON.stringify(value).length});if(window.diagnosticUpdates.length>8)window.diagnosticUpdates.shift();});undefined`);
      async function clickControl(action:'pause'|'resume'){
        await diagnosticControls.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000;const poll=()=>{const button=document.querySelector('[data-longshot-action=${action}]');if(button&&!button.disabled){button.click();resolve(true);}else if(Date.now()>end)reject(new Error('Manual ${action} button unavailable'));else setTimeout(poll,25);};poll();})`);
        await diagnosticControls.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000;const poll=()=>{const button=document.querySelector('[data-longshot-action=${action==='pause'?'resume':'pause'}]');if(button&&!button.disabled)resolve(true);else if(Date.now()>end)reject(new Error('Manual ${action} command did not complete'));else setTimeout(poll,25);};poll();})`);
      }
      await clickControl('pause');const paused=longshot.state!;assert.equal(paused.paused,true);
      assert.equal(paused.telemetry?.queuedFrames,0,'Pause must clear prefetched frames before acknowledging');
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},behavior:'instant'});undefined`);await painted();await sleep(550);
      assert.equal(longshot.state?.height,paused.height);assert.equal(longshot.state?.frames,paused.frames);assert.equal(longshot.state?.telemetry?.processed,paused.telemetry?.processed,'No worker commits after Pause has acknowledged');
      await clickControl('resume');
      const resumed=await stateWhen(value=>value.height===baseline.height+physicalStep,'manual resumes capture at a connected position');
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step*8});undefined`);await painted();
      const rejection=await stateWhen(value=>(value.telemetry?.rejected??0)>0&&['no-overlap','overlap-rejected'].includes(value.telemetry?.lastIssue??''),'unseen viewport without overlap must be rejected');
      assert.equal(rejection.height,resumed.height);assert.ok(rejection.telemetry!.captured>=rejection.telemetry!.processed);
      assert.ok(rejection.telemetry!.capture.count>0&&rejection.telemetry!.match.count>0);
      await stateWhen(value=>(value.consecutiveRejections??0)>=3&&value.telemetry?.activity==='seeking-overlap','visible reconnect state without changing output');
      await diagnosticThumbnail.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000;const poll=()=>{const button=document.querySelector('[data-longshot-diagnostics=toggle]');if(button){button.click();resolve(true);}else if(Date.now()>end)reject(new Error('Diagnostic toggle unavailable'));else setTimeout(poll,25);};poll();})`);
      await diagnosticThumbnail.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000;const poll=()=>{if(document.querySelector('[data-diagnostic-issue]')?.textContent===${JSON.stringify(rejection.telemetry!.lastIssue)}&&window.diagnosticUpdates.length)resolve(true);else if(Date.now()>end)reject(new Error('Diagnostic issue not shown'));else setTimeout(poll,25);};poll();})`);
      const updates:{id:string;keys:string[];bytes:number}[]=await diagnosticThumbnail.webContents.executeJavaScript('window.diagnosticUpdates');
      for(const update of updates){assert.equal(update.id,baseline.id);assert.deepEqual(update.keys,['id','telemetry']);assert.ok(update.bytes<3000,'Diagnostic events must not resend PNG images');}
      const diagnosticBounds=await diagnosticThumbnail.webContents.executeJavaScript(`new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>{const panel=document.querySelector('.scroll-diagnostics').getBoundingClientRect();resolve({x:panel.x,y:panel.y,right:panel.right,bottom:panel.bottom,width:innerWidth,height:innerHeight});})))`);
      assert.ok(diagnosticBounds.x>=0&&diagnosticBounds.y>=0&&diagnosticBounds.right<=diagnosticBounds.width&&diagnosticBounds.bottom<=diagnosticBounds.height,'Diagnostic panel must remain visible inside the preview');
      await sleep(100);
      await mkdir(path.join(process.cwd(),'.runtime'),{recursive:true});
      await writeFile(path.join(process.cwd(),'.runtime','longshot-stage2.3-diagnostics.png'),(await diagnosticThumbnail.webContents.capturePage()).toPNG());
      const recoveries=longshot.state!.telemetry!.recoveries;
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step});undefined`);await painted();
      const reconnected=await stateWhen(value=>(value.telemetry?.recoveries??0)>recoveries&&value.consecutiveRejections===0&&value.telemetry?.lastIssue===undefined,'return to last accepted viewport deduplicates and clears rejection');
      assert.equal(reconnected.height,resumed.height);assert.equal(reconnected.frames,resumed.frames);
      const localized=reconnected.telemetry!.localizedFrames;
      const caretX=targetGlobal.x-bounds.x+Math.floor(targetGlobal.width*.4),caretY=targetGlobal.y-bounds.y+Math.floor(targetGlobal.height*.4);
      // Keep this patch above the unchanged strict-change allowance on a large
      // viewport while remaining within the localized verifier's source cap.
      await fixture.webContents.executeJavaScript(`(()=>{const caret=document.createElement('div');caret.id='smoke-caret';caret.style.cssText='position:fixed;z-index:5;pointer-events:none;background:#020202;left:${caretX}px;top:${caretY}px;width:${largeROI?12:6}px;height:${largeROI?32:24}px';document.body.appendChild(caret);})()`);await painted();
      const blinking=await stateWhen(value=>(value.telemetry?.localizedFrames??0)>localized,'local change in a stationary viewport is deduplicated');
      assert.equal(blinking.height,reconnected.height);assert.equal(blinking.frames,reconnected.frames);
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step*2});undefined`);await painted();
      const localAppend=await stateWhen(value=>value.height===baseline.height+physicalStep*2,'manual scroll with a small changing overlay still appends');
      assert.equal(localAppend.frames,reconnected.frames+1);
      const qualityDeadline=Date.now()+3000;
      while(Date.now()<qualityDeadline&&!await diagnosticThumbnail.webContents.executeJavaScript(`document.querySelector('[data-diagnostic-localized]')?.textContent.includes('/ 1')`))await sleep(25);
      assert.ok(await diagnosticThumbnail.webContents.executeJavaScript(`!!document.querySelector('[data-diagnostic-localized]')?.textContent.includes('/ 1')`),'Renderer must display reconnect count');
      await fixture.webContents.executeJavaScript(`document.getElementById('smoke-caret').remove();undefined`);await painted();
      await clickControl('pause');const pausedFinish=longshot.state!;
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step*3},behavior:'instant'});undefined`);await painted();
      await diagnosticControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(baseline.id)},'finish')`);
      const pausedDone=await stateWhen(value=>value.status==='done','finish accumulated content while paused');
      assert.equal(pausedDone.height,pausedFinish.height);assert.equal(pausedDone.frames,pausedFinish.frames,'Paused Done must not capture the page scrolled during pause');
      assert.equal(pausedDone.telemetry?.activity,'completed');
      const reference=nativeImage.createFromDataURL(await fixture.webContents.executeJavaScript('document.querySelector("canvas").toDataURL()'));
      verifyCanvas(nativeImage.createFromDataURL(longshot.original(pausedDone.id).image),reference);
      console.log('LONGSHOT ROBUST RECOVERY PASS: repeated rejection renders reconnect state, returning to the accepted viewport deduplicates, bounded local changes do not grow stationary output, scrolling with the overlay appends, telemetry renders, and the entire original image matches the clean canvas.');
      await longshot.command(baseline.id,'close');await sleep(80);assert.equal(longshotWindow.collectionWindows().length,0);
      console.log('LONGSHOT CONTROL PASS: manual pause drains worker commits, resume continues matching, captured/rejected/timing counters and missing-overlap code render, numeric telemetry excludes PNG data, paused Finish does not acquire later content, and collection cleanup completes.');

      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step*4});undefined`);await painted();
      const bidirectionalControls=await start();
      const middleStart=await stateWhen(value=>value.frames>0&&!!value.livePreview,'bidirectional capture starts mid-document');
      await verifyPreviewFollow(longshotWindow,longshot,'enable');
      for(let position=5;position<=12;position++){
        await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step}*${position});undefined`);await painted();
        await stateWhen(value=>value.height===middleStart.height+(position-4)*physicalStep,'downward body expansion before historical revisit');
      }
      const full=longshot.state!,relocations=full.telemetry?.relocations??0;
      await verifyPreviewFollow(longshotWindow,longshot,'bottom');
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step*4});undefined`);await painted();
      const revisited=await stateWhen(value=>(value.telemetry?.relocations??0)>relocations&&value.viewportY===0,'large covered jump relocalizes without adding a repeated page');
      assert.equal(revisited.height,full.height);assert.equal(revisited.frames,full.frames);
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step*3});undefined`);await painted();
      const topState=await stateWhen(value=>value.height===full.height+physicalStep&&value.coveredTop===-physicalStep&&value.viewportY===-physicalStep&&value.liveDetailRegion?.y===0&&value.livePreviewRegion?.height===value.height,'upward scroll prepends and refreshes top detail');
      assert.equal(topState.telemetry?.prependedRows,physicalStep);
      const topDetail=nativeImage.createFromDataURL(topState.liveDetailPreview!);
      verifyThumbnail(topDetail,canvas,topState.liveDetailRegion!.width,topState.liveDetailRegion!.height,{x:0,y:physicalStep*3});
      const bidirectionalThumbnail=longshotWindow.thumbnailWindow()!;
      await verifyPreviewFollow(longshotWindow,longshot,'top',(image,width,height,offset)=>verifyThumbnail(image,canvas,width,height,{x:offset.x,y:offset.y+physicalStep*3}));
      await bidirectionalThumbnail.webContents.executeJavaScript(`document.querySelector('button[data-preview-mode=detail]').click();undefined`);
      await bidirectionalThumbnail.webContents.executeJavaScript('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');await sleep(100);
      const topLabel=topState.liveDetailRegion!.height<topState.height?'显示顶部':'按宽度显示';
      assert.ok(await bidirectionalThumbnail.webContents.executeJavaScript(`document.querySelector('footer')?.textContent.includes(${JSON.stringify(topLabel)})`));
      await writeFile(path.join(process.cwd(),'.runtime','longshot-stage2.3-top-preview.png'),(await bidirectionalThumbnail.webContents.capturePage()).toPNG());
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,${step*5});undefined`);await painted();
      const within=await stateWhen(value=>value.viewportY===physicalStep,'forward revisit updates the viewport without growing');
      assert.equal(within.height,topState.height);assert.equal(within.frames,topState.frames);
      await bidirectionalControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(middleStart.id)},'finish')`);
      const bidirectionalDone=await stateWhen(value=>value.status==='done','bidirectional original output');
      const bidirectionalOutput=nativeImage.createFromDataURL(longshot.original(bidirectionalDone.id).image);
      verifyCanvas(bidirectionalOutput,canvas,{x:0,y:physicalStep*3});
      services.setSavePath(path.join(process.cwd(),'.runtime','manual-bidirectional.png'));
      await longshot.command(bidirectionalDone.id,'save');
      verifyCanvas(nativeImage.createFromBuffer(await readFile(path.join(process.cwd(),'.runtime','manual-bidirectional.png'))),canvas,{x:0,y:physicalStep*3});
      await longshot.command(bidirectionalDone.id,'copy');assert.deepEqual(services.copiedSize(),{width:bidirectionalDone.width,height:bidirectionalDone.height});
      await longshot.command(bidirectionalDone.id,'close');assert.equal(longshotWindow.collectionWindows().length,0);
      console.log('LONGSHOT BIDIRECTIONAL PASS: mid-page start, downward growth, distant exact history revisit, upward prefix, top detail pixels, forward deduplication, original/copy/PNG row order and collection cleanup.');

      const localBottom = targetGlobal.y-bounds.y+targetGlobal.height;
      if(largeROI){
        await fixture.webContents.executeJavaScript('window.smokeWhitePage=true;window.setSmokeSceneHeight(4000);undefined');
        canvas=nativeImage.createFromDataURL(await fixture.webContents.executeJavaScript('document.querySelector("canvas").toDataURL()'));
      }
      const edgeControl=process.argv.includes('--longshot-edge-control');
      const right = targetGlobal.x-bounds.x+targetGlobal.width-(edgeControl?12:64);
      await fixture.webContents.executeJavaScript(`window.scrollTo(0,0);for(const [name,style] of [['left','left:0;top:0;width:${largeROI?Math.floor(bounds.width*.5):128}px;height:100%'],['right','left:${right}px;top:0;right:0;height:100%'],['top','left:0;top:0;width:100%;height:72px'],['bottom','left:0;top:${localBottom-80}px;width:100%;bottom:0']]){const e=document.createElement('div');e.dataset.chrome=name;e.style.cssText='position:fixed;z-index:2;background:repeating-linear-gradient(15deg,#dce4ec 0px,#dce4ec 5px,#697785 5px,#697785 9px);'+style;if(${edgeControl}&&name==='right'){e.style.background='#f5f5f5';const thumb=document.createElement('div');thumb.style.cssText='position:absolute;left:0;right:0;height:48px;background:#7d7d7d';e.appendChild(thumb);window.edgeThumbUpdate=()=>thumb.style.top=Math.round(100+scrollY*.2)+'px';window.addEventListener('scroll',window.edgeThumbUpdate);window.edgeThumbUpdate();}document.body.appendChild(e);}undefined`);
      await painted();
      const sidebarControls = await start();
      const original = await stateWhen(state=>state.frames>=1,'fixed sidebar first viewport');
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},behavior:'instant'}); undefined`);
      const review = await stateWhen(state=>!!state.regionCandidate,'detected scrolling body review',20_000);
      assert.equal(review.height,original.height); assert.equal(review.width,original.width); assert.equal(review.frames,1);
      const region=review.regionCandidate!;
      assert.ok(region.x>0 && region.y>0 && region.x+region.width<original.width && region.y+region.height<original.height);
      const renderDeadline=Date.now()+3000;
      while(Date.now()<renderDeadline && !await sidebarControls.webContents.executeJavaScript('!!document.querySelector("[data-longshot-action=confirm-region]")')) await sleep(20);
      assert.ok(await sidebarControls.webContents.executeJavaScript('!!document.querySelector("[data-longshot-action=confirm-region]")'),'Actual confirmation button must render');
      const reviewThumbnail=longshotWindow.thumbnailWindow()!;
      reviewThumbnail.setBounds({...reviewThumbnail.getBounds(),width:320,height:170});
      // Toolbar and thumbnail render independently; a numeric review state is
      // not evidence that the first PNG/blue-box DOM has reached the thumbnail.
      await reviewThumbnail.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+6000;const poll=()=>{const image=document.querySelector('.scroll-thumbnail-sheet img'),box=document.querySelector('.scroll-region-candidate');if(image?.complete&&image.naturalWidth&&box&&box.getBoundingClientRect().width>0&&image.getBoundingClientRect().height>0)resolve(true);else if(Date.now()>end)reject(new Error('Sidebar thumbnail pixels/blue region did not render'));else setTimeout(poll,25);};poll();})`);
      const geometry: {img:{x:number;y:number;width:number;height:number};box:{x:number;y:number;width:number;height:number}} = await reviewThumbnail.webContents.executeJavaScript(`(()=>{const img=document.querySelector('.scroll-thumbnail-sheet img').getBoundingClientRect(),box=document.querySelector('.scroll-region-candidate').getBoundingClientRect();return {img:{x:img.x,y:img.y,width:img.width,height:img.height},box:{x:box.x,y:box.y,width:box.width,height:box.height}}})()`);
      assert.ok(Math.abs(geometry.box.x-geometry.img.x-region.x/original.width*geometry.img.width)<1.5);
      assert.ok(Math.abs(geometry.box.y-geometry.img.y-region.y/original.height*geometry.img.height)<1.5);
      assert.ok(Math.abs(geometry.box.width-region.width/original.width*geometry.img.width)<1.5);
      assert.ok(Math.abs(geometry.box.height-region.height/original.height*geometry.img.height)<1.5);
      const reviewToolbarImage=await sidebarControls.webContents.capturePage(),reviewThumbnailImage=await reviewThumbnail.webContents.capturePage();
      await sidebarControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(review.id)},'confirm-region')`);
      const accepted=await stateWhen(state=>!!state.contentRect&&!state.paused,'confirmed body collection');
      assert.equal(accepted.width,region.width); assert.equal(accepted.initialHeight,region.height); assert.equal(accepted.height,region.height+physicalStep);
      await probeSmokeWindow(fixture,{x:Math.round(targetGlobal.x+(region.x+region.width/2)/original.width*targetGlobal.width),y:Math.round(targetGlobal.y+(region.y+region.height/2)/original.height*targetGlobal.height)});
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},behavior:'instant'}); undefined`);
      await stateWhen(state=>state.height>=region.height+2*physicalStep,'body continues after confirmation');
      await sidebarControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(review.id)},'finish')`);
      const bodyDone=await stateWhen(state=>state.status==='done','fixed sidebar body output');
      assert.equal(bodyDone.height,region.height+2*physicalStep); assert.ok((bodyDone.verifiedTransitions??0)>=2);
      const bodyOutput=nativeImage.createFromDataURL(longshot.original(bodyDone.id).image); verifyCanvas(bodyOutput,canvas,region);
      await writeFile(path.join(process.cwd(),'.runtime','manual-b-region-toolbar.png'),reviewToolbarImage.toPNG());
      await writeFile(path.join(process.cwd(),'.runtime','manual-b-region-thumbnail.png'),reviewThumbnailImage.toPNG());
      services.setSavePath(path.join(process.cwd(),'.runtime','manual-sidebar-b.png'));
      await sidebarControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(review.id)},'save')`);
      verifyCanvas(nativeImage.createFromBuffer(await readFile(path.join(process.cwd(),'.runtime','manual-sidebar-b.png'))),canvas,region);
      await sidebarControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(review.id)},'copy')`);
      assert.deepEqual(services.copiedSize(),{width:bodyDone.width,height:bodyDone.height});
      await longshot.command(bodyDone.id,'close'); await sleep(80);
      assert.equal(longshotWindow.collectionWindows().length,0);
      await fixture.webContents.executeJavaScript('window.scrollTo(0,0);undefined');await painted();
      const keepControls=await start();const keepFirst=await stateWhen(state=>state.frames>=1,'keep original first frame');
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},behavior:'instant'});undefined`);
      await stateWhen(state=>!!state.regionCandidate,'keep original review');
      await keepControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(keepFirst.id)},'keep-region')`);
      const kept=await stateWhen(state=>!state.regionCandidate&&!state.paused,'original area is retained');
      assert.equal(kept.width,keepFirst.width);assert.equal(kept.height,keepFirst.height);assert.equal(kept.contentRect,undefined);
      await keepControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(kept.id)},'cancel')`);await sleep(80);
      assert.equal(longshot.state,null);assert.equal(longshotWindow.collectionWindows().length,0);
      await fixture.webContents.executeJavaScript('if(window.edgeThumbUpdate){window.removeEventListener("scroll",window.edgeThumbUpdate);delete window.edgeThumbUpdate;}document.querySelectorAll("[data-chrome]").forEach(e=>e.remove());window.scrollTo(0,0); undefined');
      console.log('MANUAL SIDEBAR PASS: real screen capture detects body between fixed title/footer/sidebars; no crop before explicit IPC/UI confirmation; output retains the entire body from its first viewport, verified pixel-by-pixel; full image copy/save and collection cleanup pass.');
      if(edgeControl)console.log('MANUAL EDGE CONTROL PASS: an independently moving narrow outer thumb permits explicit body review; confirmed output, original/copy/PNG pixels, keeping the original scope and cancellation all verify.');
      await start();await stateWhen(value=>value.frames>0,'diagnostic cancellation first frame');
      await verifyDiagnosticCancel(longshotWindow,longshot,services.setDiagnosticChooser);
    }
    const controls = await start();
    if (uiOnly) {
      longshot.suspendSampling(true);
      await verifyPreviewPlacement(longshotWindow, area, targetGlobal, () => { if (longshot.state) longshotWindow.publish(longshot.state); });
      // Trigger the production full-screen fallback, but only ever sample the
      // owned synthetic canvas region. No full/private desktop image is saved.
      await longshotWindow.showControls(display.bounds);
      assert.equal(longshotWindow.overlaysSelection, true);
      assert.equal(controls.isVisible(), true, 'Large selections must not silently hide collection UI');
      assert.equal(controls.isContentProtected(), true);
      // Put the mask border AND dark exterior inside the sampled fixture, so
      // the pixel comparison proves exclusion instead of a transparent centre.
      await longshotWindow.showControls({ x: targetGlobal.x + 20, y: targetGlobal.y + 20, width: targetGlobal.width - 40, height: targetGlobal.height - 40 });
      controls.setBounds({ x: Math.round(targetGlobal.x + targetGlobal.width - 360), y: Math.round(targetGlobal.y + 30), width: 360, height: LONGSHOT_CONTROL_HEIGHT });
      await painted();
      longshot.suspendSampling(false);
      const firstUI = await stateWhen((value) => value.frames >= 1 && !!value.livePreview, 'live first-screen thumbnail');
      assert.equal(firstUI.appendedRows, 0);
      const referenceCanvas = nativeImage.createFromDataURL(await fixture.webContents.executeJavaScript('document.querySelector("canvas").toDataURL()'));
      verifyThumbnail(nativeImage.createFromDataURL(firstUI.livePreview!), referenceCanvas, firstUI.width, firstUI.height);
      const thumbnail = longshotWindow.thumbnailWindow();
      assert.ok(thumbnail);
      await painted();
      async function thumbnailMode(mode:'overview'|'detail') {
        return thumbnail!.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000;const poll=()=>{const view=document.querySelector('.scroll-thumbnail'),image=view?.querySelector('img');if(view?.dataset.previewMode===${JSON.stringify(mode)}&&image?.complete&&image.naturalWidth){const r=image.getBoundingClientRect();resolve({width:r.width,height:r.height,naturalWidth:image.naturalWidth,naturalHeight:image.naturalHeight,dpi:devicePixelRatio});}else if(Date.now()>end)reject(new Error('Thumbnail mode did not render'));else setTimeout(poll,25);};poll();})`) as Promise<{width:number;height:number;naturalWidth:number;naturalHeight:number;dpi:number}>;
      }
      const firstDetail=await thumbnailMode('detail');
      assert.ok(firstDetail.naturalWidth>=Math.floor(firstDetail.width*firstDetail.dpi)-2,'Live preview must supply the actual physical pixels used by the native-DPI window');
      assert.ok(firstDetail.naturalHeight>=Math.floor(firstDetail.height*firstDetail.dpi)-2);
      assert.ok(firstDetail.naturalWidth>240||firstDetail.naturalHeight>360,'Native thumbnail must exceed the old 240×360 sampling cap on this display');
      await thumbnail.webContents.executeJavaScript(`document.querySelector('button[data-preview-mode="overview"]').click();undefined`);
      await thumbnailMode('overview');
      assert.equal(await thumbnail.webContents.executeJavaScript(`window.screenAI.getLongshot().then(value=>document.querySelector('.scroll-thumbnail-sheet img').getAttribute('src')===value.livePreview)`),true);
      await thumbnail.webContents.executeJavaScript(`document.querySelector('button[data-preview-mode="detail"]').click();undefined`);
      await thumbnailMode('detail');
      await verifyPreviewWindow(longshotWindow, longshot, home, area, scale);
      await verifyPreviewZoom(longshotWindow,longshot,(image,width,height,offset)=>verifyThumbnail(image,referenceCanvas,width,height,offset));
      await mkdir(path.join(process.cwd(), '.runtime'), { recursive: true });
      await writeFile(path.join(process.cwd(), '.runtime', 'longshot-installed-toolbar.png'), (await controls.webContents.capturePage()).toPNG());
      await writeFile(path.join(process.cwd(), '.runtime', 'longshot-installed-thumbnail.png'), (await thumbnail.webContents.capturePage()).toPNG());
      // Exercise the visual-only preview over sampled content as well. Both
      // auxiliary surfaces must be excluded by the production screen source.
      thumbnail.setBounds({ x: Math.round(targetGlobal.x + 12), y: Math.round(targetGlobal.y + 12), width: 220, height: 310 });
      await painted();
      const controlImage = await controls.webContents.capturePage();
      const thumbnailImage = await thumbnail.webContents.capturePage();
      assert.equal(await fixture.webContents.executeJavaScript('scrollY'), 0, 'First frame fixture must remain at the origin');
      await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},behavior:'instant'}); undefined`);
      assert.equal(await fixture.webContents.executeJavaScript('scrollY'), step, 'Fixture advances one known step');
      await painted();
      // Resizing can refresh the old overview before the next frame commits.
      // Wait for preview geometry matching the committed document, not merely
      // a different PNG URL or a numeric telemetry update between those steps.
      const extended = await stateWhen((value) => (value.appendedRows ?? 0) > 0 && !!value.livePreview && value.livePreview !== firstUI.livePreview
        && value.livePreviewRegion?.height===value.height && !!value.liveDetailRegion && value.liveDetailRegion.y+value.liveDetailRegion.height===value.height, 'growing stitched live thumbnail');
      assert.equal(extended.height, firstUI.height + physicalStep);
      assert.ok(extended.liveDetailRegion && extended.livePreviewRegion);
      assert.equal(extended.livePreviewRegion.height,extended.height);
      assert.equal(extended.liveDetailRegion.y+extended.liveDetailRegion.height,extended.height,'Clear preview follows the latest committed row, not an older source frame');
      assert.equal(extended.liveDetailRegion.width,extended.width);
      await thumbnailMode('detail');
      await writeFile(path.join(process.cwd(),'.runtime','longshot-clear-live-preview.png'),(await thumbnail.webContents.capturePage()).toPNG());
      await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(extended.id)}, 'finish')`);
      const doneUI = await stateWhen((value) => value.status === 'done', 'visible stitched result');
      assert.equal(await controls.webContents.executeJavaScript(`window.screenAI.previewWindow({id:${JSON.stringify(doneUI.id)},op:'get'}).then(()=>false,()=>true)`),true,'Finished editor cannot access a closed collection layout');
      assert.equal(controls.isVisible(), true);
      assert.equal(controls.isContentProtected(), false);
      assert.equal(longshotWindow.collectionWindows().length, 0, 'Final output closes all collection-only surfaces');
      assert.equal(doneUI.appendedRows, physicalStep);
      const output = nativeImage.createFromDataURL(longshot.original(doneUI.id).image);
      assert.deepEqual(output.getSize(), { width: doneUI.width, height: doneUI.height });
      const canvas = nativeImage.createFromDataURL(await fixture.webContents.executeJavaScript('document.querySelector("canvas").toDataURL()'));
      verifyCanvas(output, canvas);
      await mkdir(path.join(process.cwd(), '.runtime'), { recursive: true });
      await writeFile(path.join(process.cwd(), '.runtime', 'longshot-ui-controls.png'), controlImage.toPNG());
      await writeFile(path.join(process.cwd(), '.runtime', 'longshot-ui-thumbnail.png'), thumbnailImage.toPNG());
      await writeFile(path.join(process.cwd(), '.runtime', 'longshot-ui-preview.png'), (await controls.webContents.capturePage()).toPNG());
      services.setSavePath(path.join(process.cwd(), '.runtime', 'longshot-ui-smoke.png'));
      await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(doneUI.id)}, 'save')`);
      await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(doneUI.id)}, 'copy')`);
      assert.deepEqual(services.copiedSize(), { width: doneUI.width, height: doneUI.height });
      await verifyLongshotTools(controls, doneUI, services, windows);
      await longshot.command(doneUI.id, 'close'); await sleep(80);
      await fixture.webContents.executeJavaScript('window.scrollTo(0,0); undefined'); await painted();
      const singleControls = await start();
      const single = await stateWhen((value) => value.frames >= 1 && !!value.livePreview, 'single-screen result setup');
      await singleControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(single.id)}, 'finish')`);
      const singleDone = await stateWhen((value) => value.status === 'done', 'explicit non-stitched result');
      assert.equal(singleDone.appendedRows, 0); assert.match(singleDone.error ?? '', /没有拼接出长图/);
      const rendererDeadline = Date.now() + 3000;
      while (Date.now() < rendererDeadline && !await singleControls.webContents.executeJavaScript('document.querySelector(".longshot-brand")?.textContent.includes("首屏截图")')) await sleep(30);
      assert.equal(await singleControls.webContents.executeJavaScript('document.querySelector("[data-longshot-action=copy]").textContent'), '复制首屏');
      await verifyDiagnosticResult(longshotWindow,longshot,services.setDiagnosticChooser);
      await longshot.command(singleDone.id, 'close'); await sleep(80);
      assert.equal(longshotWindow.get(), undefined); assert.equal(longshot.state, null);
      assert.equal(longshotWindow.collectionWindows().length, 0);
      // Exercise the actual toolbar download button, not a synthetic finish
      // followed by a separate save request. The picker is injected by smoke.
      for (const saveToFile of [true, false]) {
        const saveControls = await start();
        const saveState = await stateWhen(value => value.frames > 0 && !!value.livePreview, 'live save first screen');
        const savePath = path.join(process.cwd(), '.runtime', `longshot-live-save-${randomUUID()}.png`);
        services.setSavePath(saveToFile ? savePath : undefined);
        const enabledDeadline = Date.now() + 3000;
        while (Date.now() < enabledDeadline && !await saveControls.webContents.executeJavaScript('document.querySelector("[data-longshot-action=save]")?.disabled === false')) await sleep(30);
        assert.equal(await saveControls.webContents.executeJavaScript('document.querySelector("[data-longshot-action=save]").disabled'), false);
        await saveControls.webContents.executeJavaScript('document.querySelector("[data-longshot-action=save]").click(); undefined');
        const saveDone = await stateWhen(value => value.status === 'done', 'live save completes source session');
        assert.equal(saveDone.id, saveState.id);
        const expectedNotice = saveToFile ? 'PNG 长截图已保存' : '已取消保存';
        const noticeDeadline = Date.now() + 5000;
        while (Date.now() < noticeDeadline && !await saveControls.webContents.executeJavaScript(`document.querySelector('.longshot-footer')?.textContent.includes(${JSON.stringify(expectedNotice)})`)) await sleep(30);
        assert.equal(await saveControls.webContents.executeJavaScript(`document.querySelector('.longshot-footer').textContent.includes(${JSON.stringify(expectedNotice)})`), true);
        if (saveToFile) verifyCanvas(nativeImage.createFromBuffer(await readFile(savePath)), referenceCanvas);
        assert.equal(longshotWindow.collectionWindows().length, 0);
        await longshot.command(saveDone.id, 'close'); await sleep(80);
      }
      // The collection pen/share icons finish the current source and open the
      // corresponding real result pane, rather than dead placeholder buttons.
      for (const pane of ['edit','share']) {
        const paneControls=await start();
        const paneState=await stateWhen(value=>value.frames>0&&!!value.livePreview,'collection tool first frame');
        const ready=Date.now()+3000;
        while(Date.now()<ready&&!await paneControls.webContents.executeJavaScript(`document.querySelector('[data-longshot-action=${pane}]')?.disabled===false`))await sleep(30);
        await paneControls.webContents.executeJavaScript(`document.querySelector('[data-longshot-action=${pane}]').click();undefined`);
        await stateWhen(value=>value.status==='done','collection tool result');
        const expression=pane==='edit'?`document.querySelector('.annotation-layer')?.dataset.annotationTool==='pen'`:`!!document.querySelector('.longshot-share-menu')`;
        await paneControls.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000;const poll=()=>{if(${expression})resolve(true);else if(Date.now()>end)reject(new Error('Collection tool pane did not open'));else setTimeout(poll,25);};poll();})`);
        await longshot.command(paneState.id,'close');await sleep(80);
      }
      const finalCancelControls=await start();
      const cancelState = await stateWhen(value => value.frames >= 1, 'active cancellation');
      const collectionSurfaces = longshotWindow.collectionWindows();
      await finalCancelControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(cancelState.id)}, 'cancel')`);
      await sleep(80);
      assert.equal(longshotWindow.get(), undefined); assert.equal(longshot.state, null);
      assert.ok(collectionSurfaces.every(win => win.isDestroyed()), 'Cancel destroys the mask and thumbnail');
      assert.equal(longshotWindow.collectionWindows().length, 0);
      if (process.argv.includes('--longshot-manual-b')) await manualStageB();
      console.log('LONGSHOT UI PASS: native-DPI overview/detail previews with real mode buttons, sharp pixel supply and latest-row metadata; compact toolbar and independent thumbnail visible; overlapping mask exterior, border and panels absent from every verified canvas pixel; live stitched thumbnail grows; final original copies/saves; single-screen output identified; completion/cancellation clear every collection surface.');
      return;
    }
    // Use a real native menu over the synthetic target while sampling is
    // suspended, following the same popup/callback path as the tray controls.
    const preparing = longshot.state!;
    longshot.suspendSampling(true, preparing.id);
    const popup = Menu.buildFromTemplate([{ label: 'Synthetic capture control', enabled: false }]);
    let menuClosed = false;
    popup.popup({ x: Math.round(targetGlobal.x + 60), y: Math.round(targetGlobal.y + 60), callback: () => { longshot.suspendSampling(false, preparing.id); menuClosed = true; } });
    try {
      await sleep(900);
      assert.equal(longshot.state?.frames, 0, 'A pending source read must not become a first frame while our menu is open');
    } finally { popup.closePopup(); }
    const menuDeadline = Date.now() + 3000;
    while (!menuClosed && Date.now() < menuDeadline) await sleep(20);
    assert.ok(menuClosed, 'Native menu callback must resume collection');
    const first = await stateWhen((state) => state.frames >= 1 && state.canFinish === true, 'first stable frame');
    assert.equal(first.scrollMode, 'manual');
    assert.equal(await fixture.webContents.executeJavaScript('scrollY'), 0, 'The manual fixture must still be at its initial document position');
    // Native window DIP rounding plus outward crop can retain one extra edge
    // pixel. Verify the real dimensions instead of assuming scale multiplication.
    assert.ok(Math.abs(first.width - expectedWidth) <= 2);
    assert.ok(Math.abs(first.height - expectedHeight) <= 2);
    const initialHeight = first.height;
    assert.equal(first.frames, 1);
    console.log('LONGSHOT MENU PASS: native popup suspends sampling, discards pending reads, and resumes before accepting its first clean frame.');
    assert.equal(await home.webContents.executeJavaScript('window.screenAI.getLongshot().then(() => false, () => true)'), true);
    assert.equal(await home.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(first.id)}, 'finish').then(() => false, () => true)`), true);
    assert.equal(await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(randomUUID())}, 'finish').then(() => false, () => true)`), true);

    await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},left:0,behavior:'instant'}); undefined`);
    await painted();
    assert.equal(await fixture.webContents.executeJavaScript('scrollY'), step);
    const second = await stateWhen((state) => state.height > first.height, 'first downward append');
    assert.equal(second.height, initialHeight + physicalStep);
    assert.equal(second.frames, 2);
    await sleep(1800);
    assert.equal(longshot.state?.height, second.height, 'A stationary document must not grow');
    assert.equal(longshot.state?.frames, second.frames, 'Duplicate stable frames must not be appended');
    await fixture.webContents.executeJavaScript(`window.scrollBy({top:${step},left:0,behavior:'instant'}); undefined`);
    await painted();
    assert.equal(await fixture.webContents.executeJavaScript('scrollY'), step * 2);
    const third = await stateWhen((state) => state.height > second.height, 'second downward append');
    assert.equal(third.height, initialHeight + physicalStep * 2);
    assert.equal(third.frames, 3);
    assert.equal(longshot.active, true);
    await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(first.id)}, 'finish')`);
    const done = await stateWhen((state) => state.status === 'done', 'finished PNG');
    assert.equal(longshot.active, false);
    assert.equal(done.width, first.width); assert.equal(done.height, initialHeight + physicalStep * 2);
    assert.ok(done.preview?.startsWith('data:image/png;base64,'));
    const preview = nativeImage.createFromDataURL(done.preview!);
    // This fixture fits the preview limit, so PNG pixel comparisons remain exact.
    assert.deepEqual(preview.getSize(), { width: done.width, height: done.height });
    const pngBytes = preview.toBitmap();
    const checks: { x: number; y: number; rgb: number[] }[] = [];
    let canvasOrigin: { x: number; y: number } | undefined;
    for (let dy = -3; dy <= 3 && !checks.length; dy++) for (let dx = -3; dx <= 3 && !checks.length; dx++) {
      const canvasX = Math.round(16 * scale) + dx, canvasY = Math.round(16 * scale) + dy;
      const candidates: typeof checks = [];
      for (const anchor of [12, initialHeight - 25, initialHeight + Math.floor(physicalStep / 2), done.height - 20]) {
        let y = Math.max(0, Math.min(done.height - 1, anchor));
        while ((canvasY + y) % 12 < 3 || (canvasY + y) % 12 > 8) y++;
        let x = 30;
        while ((canvasX + x) % 24 < 7 || (canvasX + x) % 24 > 16) x++;
        const row = Math.floor((canvasY + y) / 12), column = Math.floor((canvasX + x) / 24);
        const rgb = [(row * 37 + column * 19) % 180 + 40, (row * 59 + column * 23) % 180 + 40, (row * 83 + column * 31) % 180 + 40];
        const i = (y * done.width + x) * 4, actual = [pngBytes[i + 2], pngBytes[i + 1], pngBytes[i]];
        if (!actual.every((value, channel) => Math.abs(value - rgb[channel]) <= 2)) break;
        candidates.push({ x, y, rgb });
      }
      if (candidates.length === 4) { checks.push(...candidates); canvasOrigin = { x: canvasX, y: canvasY }; }
    }
    assert.equal(checks.length, 4, 'All known synthetic document positions must survive real native capture and stitching');
    console.log('LONGSHOT NATIVE PASS: desktop sampling of a real scrolling canvas, two downward appends, stationary deduplication and known color rows in order; controls stay outside the target.');

    const destination = path.join(process.cwd(), '.runtime', 'longshot-smoke.png');
    const beforeCancelledSave = await stat(destination).then((value) => value.mtimeMs, () => undefined);
    services.setSavePath(undefined);
    const cancelledSave = await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)}, 'save')`);
    assert.equal(cancelledSave.cancelled, true);
    assert.equal(await stat(destination).then((value) => value.mtimeMs, () => undefined), beforeCancelledSave);
    // Only after verifying the in-memory image is our synthetic document may it
    // be persisted. No unverified screen or window image is ever written here.
    await mkdir(path.dirname(destination), { recursive: true });
    services.setSavePath(destination);
    const save = await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)}, 'save')`);
    assert.match(save.message, /保存/);
    const saved = nativeImage.createFromBuffer(await readFile(destination));
    assert.deepEqual(saved.getSize(), { width: done.width, height: done.height });
    const savedBytes = saved.toBitmap();
    for (const { x, y, rgb } of checks) {
      const i = (y * done.width + x) * 4;
      assert.ok([savedBytes[i + 2], savedBytes[i + 1], savedBytes[i]].every((value, channel) => Math.abs(value - rgb[channel]) <= 2));
    }
    await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)}, 'copy')`);
    assert.deepEqual(services.copiedSize(), { width: done.width, height: done.height });
    await controls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)}, 'close')`).catch((error) => { if (!controls.isDestroyed()) throw error; });
    await sleep(80);
    assert.equal(longshot.state, null); assert.equal(longshot.active, false); assert.equal(longshotWindow.get(), undefined);
    console.log('LONGSHOT OUTPUT PASS: raw PNG dimensions and known rows survive save; cancelled save writes nothing; injected clipboard gets the complete image; stale and foreign roles are rejected; close releases state.');

    await fixture.webContents.executeJavaScript('window.scrollTo(0,0); undefined');
    await painted();
    const nextControls = await start();
    const next = await stateWhen((state) => !!state.id, 'fresh session');
    assert.notEqual(next.id, done.id);
    await nextControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(done.id)}, 'cancel').then(() => false, () => true)`).then((rejected) => assert.equal(rejected, true));
    await nextControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(next.id)}, 'cancel')`).catch((error) => { if (!nextControls.isDestroyed()) throw error; });
    await sleep(80);
    assert.equal(longshot.state, null); assert.equal(longshot.active, false); assert.equal(longshotWindow.get(), undefined);
    assert.equal(windows.getCaptures().length, 0);
    console.log('LONGSHOT CANCEL PASS: new session has a fresh identity and cancelling releases collector, processor, control window and capture overlays.');

    // The fixture normalizes only real wheel input to a deterministic document
    // displacement. No executeJavaScript scrollBy drives this automatic run.
    const automaticTravel = step * 4;
    await fixture.webContents.executeJavaScript(`window.setSmokeSceneHeight(innerHeight + ${automaticTravel}, ${step}); undefined`);
    await painted();
    const autoStarted=performance.now();
    const autoControls = await start('auto');
    const autoFirst = await stateWhen((state) => state.frames >= 1, 'automatic first stable frame');
    assert.equal(autoFirst.scrollMode, 'auto');
    const autoDone = await stateWhen((state) => state.status === 'done', 'automatic completion at document bottom', 45_000);
    assert.match(autoDone.message, /连续滚动后画面不再变化/);
    assert.equal(autoDone.scrollMode, 'auto');
    assert.ok((autoDone.scrollSteps ?? 0) >= 2, 'Automatic capture must send multiple native scrolling steps');
    assert.ok(autoDone.frames >= 3 && autoDone.height > first.height, 'Automatic native input must append several document sections');
    assert.equal(longshot.active, false);
    const autoInput: { trusted: number; untrusted: number; positions: number[]; deltas:number[];scrollY: number } = await fixture.webContents.executeJavaScript('({...window.smokeWheel,scrollY})');
    assert.equal(autoInput.untrusted, 0, 'Automatic scrolling must not dispatch fabricated wheel events');
    assert.ok(autoInput.trusted >= 2, 'Windows SendInput must reach the real fixture as trusted wheel events');
    assert.ok(new Set(autoInput.deltas.map(value=>Math.round(value*100))).size>=2,'Verified displacement must adapt actual native wheel magnitude');
    console.log('LONGSHOT AUTO METRICS '+JSON.stringify({elapsedMs:performance.now()-autoStarted,addedRows:autoDone.appendedRows,steps:autoDone.scrollSteps,wheelDeltas:autoInput.deltas}));
    assert.ok(new Set(autoInput.positions.filter((position) => position > 0)).size >= 2, 'Native input must produce more than one document position');
    assert.equal(autoInput.scrollY, automaticTravel, 'Automatic capture must actually reach this known short document bottom');
    assert.equal(autoDone.height, first.height + Math.round(automaticTravel * scale));
    assert.equal(autoDone.width, first.width);
    assert.ok(autoDone.preview?.startsWith('data:image/png;base64,'));
    const autoPreview = nativeImage.createFromDataURL(autoDone.preview!);
    assert.deepEqual(autoPreview.getSize(), { width: autoDone.width, height: autoDone.height });
    const autoBytes = autoPreview.toBitmap();
    assert.ok(canvasOrigin, 'Manual verification must establish the actual native crop origin');
    const autoChecks: typeof checks = [];
    for (const anchor of [12, first.height - 25, first.height + Math.floor(physicalStep / 2), autoDone.height - 20]) {
      let y = Math.max(0, Math.min(autoDone.height - 1, anchor)), x = 30;
      while ((canvasOrigin.y + y) % 12 < 3 || (canvasOrigin.y + y) % 12 > 8) y++;
      while ((canvasOrigin.x + x) % 24 < 7 || (canvasOrigin.x + x) % 24 > 16) x++;
      const row = Math.floor((canvasOrigin.y + y) / 12), column = Math.floor((canvasOrigin.x + x) / 24);
      const rgb = [(row * 37 + column * 19) % 180 + 40, (row * 59 + column * 23) % 180 + 40, (row * 83 + column * 31) % 180 + 40];
      const i = (y * autoDone.width + x) * 4;
      assert.ok([autoBytes[i + 2], autoBytes[i + 1], autoBytes[i]].every((value, channel) => Math.abs(value - rgb[channel]) <= 2), `Automatic PNG synthetic document pixel must survive at (${x}, ${y})`);
      autoChecks.push({ x, y, rgb });
    }
    // Persist only the verified synthetic crop, using the injected destination
    // and clipboard writer already isolated by the outer smoke harness.
    const autoDestination = path.join(process.cwd(), '.runtime', 'longshot-auto-smoke.png');
    services.setSavePath(autoDestination);
    await autoControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(autoDone.id)}, 'save')`);
    const autoSaved = nativeImage.createFromBuffer(await readFile(autoDestination));
    assert.deepEqual(autoSaved.getSize(), { width: autoDone.width, height: autoDone.height });
    const autoSavedBytes = autoSaved.toBitmap();
    for (const { x, y, rgb } of autoChecks) {
      const i = (y * autoDone.width + x) * 4;
      assert.ok([autoSavedBytes[i + 2], autoSavedBytes[i + 1], autoSavedBytes[i]].every((value, channel) => Math.abs(value - rgb[channel]) <= 2));
    }
    await autoControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(autoDone.id)}, 'copy')`);
    assert.deepEqual(services.copiedSize(), { width: autoDone.width, height: autoDone.height });
    const autoWheelsAtDone = autoInput.trusted;
    await sleep(900);
    assert.equal(await fixture.webContents.executeJavaScript('window.smokeWheel.trusted'), autoWheelsAtDone, 'Automatic completion must stop all subsequent native wheel input');
    await autoControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(autoDone.id)}, 'close')`).catch((error) => { if (!autoControls.isDestroyed()) throw error; });
    assert.equal(longshot.state, null);
    console.log('LONGSHOT AUTO PASS: native trusted Windows wheel input advances several real document positions, stitches known first/last color rows, stops at unchanged bottom, and copies/saves only the verified synthetic PNG.');

    await fixture.webContents.executeJavaScript(`window.setSmokeSceneHeight(innerHeight + ${step * 24}, ${step}); undefined`);
    await painted();
    const pauseControls = await start('auto');
    const running = await stateWhen((state) => state.frames >= 2 && (state.scrollSteps ?? 0) >= 1, 'automatic capture before pause', 20_000);
    await longshot.command(running.id, 'pause');
    const pausedState = await stateWhen((state) => state.paused === true, 'explicit automatic pause');
    // Drain an input already dispatched before pause, then verify no new one.
    await sleep(500);
    const pausedInput: { trusted: number; scrollY: number } = await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})');
    const pausedHeight = pausedState.height;
    await sleep(1000);
    assert.deepEqual(await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})'), pausedInput);
    assert.equal((await stateWhen((state) => state.paused === true, 'automatic pause remains active')).height, pausedHeight);
    await pauseControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(running.id)}, 'resume')`);
    await stateWhen((state) => !state.paused && state.height > pausedHeight, 'automatic capture resumes native input', 20_000);
    // A wheel already delivered just before pause can leave one uncollected
    // frame. Its append is not proof that the resumed driver sent a new input;
    // wait for the next trusted native wheel independently of the state event.
    const resumedInputDeadline = Date.now() + 5000;
    while (Date.now() < resumedInputDeadline && await fixture.webContents.executeJavaScript('window.smokeWheel.trusted') <= pausedInput.trusted) await sleep(40);
    assert.ok(await fixture.webContents.executeJavaScript('window.smokeWheel.trusted') > pausedInput.trusted);

    focusFixture = new BrowserWindow({
      x: Math.round(targetGlobal.x+targetGlobal.width/2-110), y: Math.round(targetGlobal.y+targetGlobal.height/2-70), width: 220, height: 140,
      show: false, frame: false, alwaysOnTop: true, skipTaskbar: true, backgroundColor: '#eeeeee',
      webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true, partition: 'longshot-focus-smoke' },
    });
    focusFixture.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    focusFixture.webContents.on('will-navigate', (event) => event.preventDefault());
    await focusFixture.loadURL('data:text/html;charset=UTF-8,%3C!doctype%20html%3E%3Cmeta%20http-equiv%3D%22Content-Security-Policy%22%20content%3D%22default-src%20%27none%27%22%3E%3Cp%3ESynthetic%20focus%20target%3C%2Fp%3E');
    // Raise this owned foreign-focus fixture above collection surfaces before
    // the guarded native activation click; keep the hit-test protection intact.
    focusFixture.setAlwaysOnTop(true,'screen-saver',1);
    focusFixture.show(); focusFixture.moveTop(); focusFixture.focus();
    await focusFixture.webContents.executeJavaScript('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');
    await sleep(100);
    await activateSmokeWindow(focusFixture);
    const focusPaused = await stateWhen((state) => state.paused === true, 'another native window pauses automatic input');
    assert.match(`${focusPaused.error ?? ''} ${focusPaused.message}`, /失焦|前台|遮挡|焦点|目标|窗口|鼠标/);
    await sleep(500);
    const focusInput: { trusted: number; scrollY: number } = await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})');
    await sleep(1000);
    assert.deepEqual(await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})'), focusInput, 'A different focused window must not receive or trigger continuing automatic input');
    focusFixture.destroy(); focusFixture = undefined;
    // Closing the owned foreign window may activate the home window above the
    // canvas. Return visibly to the owned target before explicit Resume; the
    // production driver must continue rejecting genuinely obscured targets.
    fixture.show();fixture.moveTop();fixture.focus();await painted();
    await activateSmokeWindow(fixture);
    await pauseControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(running.id)}, 'resume')`);
    await stateWhen((state) => !state.paused && state.height > focusPaused.height, 'resume reactivates the original native target', 20_000);
    await pauseControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(running.id)}, 'manual')`);
    await stateWhen((state) => state.scrollMode === 'manual', 'switch automatic capture to manual');
    await sleep(500);
    const manualWheels = await fixture.webContents.executeJavaScript('window.smokeWheel.trusted');
    await sleep(900);
    assert.equal(await fixture.webContents.executeJavaScript('window.smokeWheel.trusted'), manualWheels, 'Manual fallback must release the automatic wheel driver');
    await pauseControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(running.id)}, 'cancel')`).catch((error) => { if (!pauseControls.isDestroyed()) throw error; });
    const cancelledInput = await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})');
    await sleep(1000);
    assert.equal(longshot.state, null); assert.equal(longshot.active, false); assert.equal(longshotWindow.get(), undefined);
    assert.deepEqual(await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})'), cancelledInput, 'Cancellation must leave no native wheel input or collector active');
    await fixture.webContents.executeJavaScript(`window.setSmokeSceneHeight(innerHeight + ${step * 24}, ${step}); undefined`);
    await painted();
    const cancelAutoControls = await start('auto');
    const cancelRunning = await stateWhen((state) => state.frames >= 2 && (state.scrollSteps ?? 0) >= 1, 'live automatic session before cancel', 20_000);
    assert.equal(cancelRunning.scrollMode, 'auto');
    await cancelAutoControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(cancelRunning.id)}, 'cancel')`).catch((error) => { if (!cancelAutoControls.isDestroyed()) throw error; });
    await sleep(500);
    const autoCancelledInput = await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})');
    await sleep(1000);
    assert.equal(longshot.state, null); assert.equal(longshot.active, false); assert.equal(longshotWindow.get(), undefined);
    assert.deepEqual(await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})'), autoCancelledInput, 'Cancelling a live automatic session must stop its real wheel driver');
    assert.equal(windows.getCaptures().length, 0);
    console.log('LONGSHOT AUTO CONTROL PASS: pause/resume stop and restore native scrolling, foreign-window focus pauses safely, resume returns to the original target, manual fallback stops injected wheel input, and cancelling a live automatic session clears its driver and state.');

    // Exercise Chromium's ordinary default wheel handling separately. This
    // listener records trusted input only; it neither cancels nor translates it
    // into scrollBy, and this run's desktop image is never written to disk.
    await fixture.webContents.executeJavaScript(`window.setSmokeSceneHeight(innerHeight + ${step * 24}, ${step}); window.smokeWheel.nativeDefault=true; undefined`);
    await painted();
    const defaultControls = await start('auto');
    const defaultFirst = await stateWhen((state) => state.frames >= 1 && state.height > 0, 'default browser wheel initial frame');
    const defaultGrown = await stateWhen((state) => state.frames >= 4 && state.height > first.height && (state.scrollSteps ?? 0) >= 3, 'default browser wheel appends several adaptive native frames', 25_000);
    assert.equal(defaultGrown.id, defaultFirst.id);
    assert.equal(defaultGrown.scrollMode, 'auto');
    assert.ok(defaultGrown.width > 0 && defaultGrown.height > first.height && defaultGrown.canFinish === true);
    const defaultInput: { trusted: number; untrusted: number; scrollY: number; nativeDefault: boolean } = await fixture.webContents.executeJavaScript('({...window.smokeWheel,scrollY})');
    assert.equal(defaultInput.nativeDefault, true);
    assert.equal(defaultInput.untrusted, 0);
    assert.ok(defaultInput.trusted > 0 && defaultInput.scrollY > 0, 'Unmodified Chromium wheel handling must scroll the real document');
    await longshot.command(defaultGrown.id, 'pause');
    const defaultPaused = await stateWhen((state) => state.paused === true, 'pause default browser wheel mode');
    assert.equal(defaultPaused.id, defaultGrown.id);
    await sleep(500);
    const defaultPausedInput = await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})');
    await sleep(1000);
    assert.deepEqual(await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})'), defaultPausedInput, 'Paused automatic capture must stop ordinary browser wheel input too');
    await defaultControls.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(defaultGrown.id)}, 'cancel')`).catch((error) => { if (!defaultControls.isDestroyed()) throw error; });
    await sleep(700);
    assert.equal(longshot.state, null); assert.equal(longshot.active, false); assert.equal(longshotWindow.get(), undefined);
    assert.deepEqual(await fixture.webContents.executeJavaScript('({trusted:window.smokeWheel.trusted,scrollY})'), defaultPausedInput);
    console.log('LONGSHOT DEFAULT WHEEL PASS: trusted native input uses Chromium default scrolling without preventDefault/scrollBy, appends a complete frame, and pause/cancel stop input; no image from this segment is saved.');
  } finally {
    services.setSavePath(undefined);
    services.setDiagnosticChooser(async()=>undefined);
    await longshot.cancel();
    if (currentOverlay && !currentOverlay.isDestroyed() && windows.getCaptures().length) await currentOverlay.webContents.executeJavaScript('window.screenAI.cancelCapture()').catch(() => {});
    if (focusFixture && !focusFixture.isDestroyed()) focusFixture.destroy();
    if (!fixture.isDestroyed()) fixture.destroy();
  }
}

/** Verify all output RGB pixels against our known canvas before persisting any
 * native image. Small origin rounding is resolved without saving diagnostic frames. */
function verifyCanvas(image: NativeImage, canvas: NativeImage, offset?: {x:number;y:number}) {
  const size = image.getSize(), source = canvas.getSize(), actual = image.toBitmap(), expected = canvas.toBitmap();
  const scale = screen.getPrimaryDisplay().scaleFactor;
  for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
    const left = Math.round(16 * scale) + (offset?.x??0) + dx, top = Math.round(16 * scale) + (offset?.y??0) + dy;
    if (left < 0 || top < 0 || left + size.width > source.width || top + size.height > source.height) continue;
    let matches = true;
    for (let y = 0; y < size.height && matches; y++) for (let x = 0; x < size.width && matches; x++) {
      const at = (y * size.width + x) * 4, from = ((top + y) * source.width + left + x) * 4;
      for (let channel = 0; channel < 3; channel++) if (Math.abs(actual[at + channel] - expected[from + channel]) > 2) { matches = false; break; }
    }
    if (matches) return;
  }
  assert.fail('Native image differs from the synthetic canvas; refusing to persist a contaminated or resampled frame');
}

function verifyThumbnail(image: NativeImage, canvas: NativeImage, width: number, height: number,offset?:{x:number;y:number}) {
  const size = image.getSize(), source = canvas.getSize(), actual = image.toBitmap(), expected = canvas.toBitmap();
  const scale = screen.getPrimaryDisplay().scaleFactor;
  let best = Infinity;
  for (let dy = -3; dy <= 3; dy++) for (let dx = -3; dx <= 3; dx++) {
    const left=Math.round(16*scale)+(offset?.x??0)+dx,top=Math.round(16*scale)+(offset?.y??0)+dy;
    if(left<0||top<0||left+width>source.width||top+height>source.height)continue;
    // Native integration checks encoding, coordinates and capture exclusion;
    // independent area-integral/filter-quality checks live in the unit suite.
    const columns=previewFilterAxis(left,width,size.width),rows=previewFilterAxis(top,height,size.height);
    let mismatches = 0;
    scan:for (let y = 0; y < size.height; y++) for (let x = 0; x < size.width; x++) {
      const at = (y * size.width + x) * 4;
      for(let c=0;c<3;c++){
        let sum=0;
        for(const row of rows[y])for(const column of columns[x])sum+=expected[(row.index*source.width+column.index)*4+c]*row.weight*column.weight;
        if(Math.abs(actual[at+c]-Math.round(sum))>2){mismatches++;if(mismatches>=16)break scan;break;}
      }
    }
    best = Math.min(best, mismatches);
    if(!mismatches)return;
  }
  assert.equal(best, 0, `First-frame thumbnail must contain only the synthetic canvas (${best}/${size.width*size.height} mismatched pixels)`);
}
