import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {nativeImage,type NativeImage} from 'electron';
import type {LongshotWindow} from './longshot-window';
import type {LongshotService} from './services/longshot';
import type {PreviewWindowState} from '../shared/scroll-capture/preview-window';

export async function verifyPreviewFollow(window:LongshotWindow,service:LongshotService,edge:'enable'|'top'|'bottom',verify?:(image:NativeImage,width:number,height:number,offset:{x:number;y:number})=>void){
  const thumbnail=window.thumbnailWindow()!;
  if(edge==='enable'){
    await thumbnail.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000,poll=()=>{const e=document.querySelector('[data-preview-zoom=menu]');if(e&&!e.disabled){e.click();resolve();}else if(Date.now()>end)reject(new Error('Zoom controls did not render'));else setTimeout(poll,25);};poll();})`);
    await thumbnail.webContents.executeJavaScript(`new Promise((resolve,reject)=>{const end=Date.now()+4000,poll=()=>{const e=document.querySelector('[data-preview-zoom-preset="1"]');if(e){e.click();resolve();}else if(Date.now()>end)reject(new Error('Zoom menu did not open'));else setTimeout(poll,25);};poll();})`);
  }
  const end=Date.now()+6000;
  while(Date.now()<end){
    const state=service.state!,tile=state.liveViewport;
    if(tile?.zoom===1&&tile.follow&&tile.documentHeight===state.height&&tile.coveredTop===state.coveredTop
      &&(edge==='enable'||edge==='top'&&tile.region.y===0||edge==='bottom'&&tile.region.y+tile.region.height===state.height)
      &&await thumbnail.webContents.executeJavaScript(`!document.querySelector('.scroll-preview-loading')`)){
      verify?.(nativeImage.createFromDataURL(tile.image),tile.region.width,tile.region.height,{x:tile.region.x,y:tile.region.y});
      if(edge==='top')console.log('LONGSHOT ZOOM FOLLOW PASS: 100% ROI stays current during downward extension and upward prepend, original ROI pixels verified, source PNG remains unchanged.');
      return;
    }
    await new Promise(resolve=>setTimeout(resolve,30));
  }
  throw new Error(`Live zoom did not follow ${edge}`);
}

/** Synthetic DOM input and owned-canvas pixels; never sends global wheel input. */
export async function verifyPreviewZoom(window:LongshotWindow,service:LongshotService,verify:(image:NativeImage,width:number,height:number,offset:{x:number;y:number})=>void){
  const preview=window.thumbnailWindow()!,id=service.state!.id;
  const js=<T=unknown>(code:string)=>preview.webContents.executeJavaScript(code) as Promise<T>;
  const get=()=>js<PreviewWindowState>(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'get'})`);
  const click=(selector:string)=>js(`(()=>{const e=document.querySelector(${JSON.stringify(selector)});if(!e)throw new Error('Zoom control absent');e.click();})()`);
  async function until(check:()=>Promise<boolean>,label:string){const end=Date.now()+6000;while(Date.now()<end){if(await check())return;await new Promise(resolve=>setTimeout(resolve,30));}throw new Error(`Preview zoom timed out: ${label}; ${JSON.stringify(service.state?.liveViewport) .slice(0,220)}`);}
  async function ready(zoom:number){
    await until(()=>js<boolean>(`(()=>{const s=document.querySelector('.scroll-thumbnail'),i=document.querySelector('[data-preview-tile]');return s?.dataset.previewScale==='${zoom}'&&i?.complete&&i.naturalWidth>0&&!document.querySelector('.scroll-preview-loading');})()`),`${zoom*100}% pixels`);
    assert.equal(service.state?.liveViewport?.zoom,zoom);
  }
  async function choose(zoom:number){await click('[data-preview-zoom=menu]');await click(`[data-preview-zoom-preset="${zoom}"]`);await ready(zoom);}
  const paused=!!service.state?.paused;
  if(!paused)await service.command(id,'pause');
  try{
    service.refreshPreview();
    await until(async()=>{
      const state=service.state!,size=window.previewSize();
      const height=Math.min(state.height,Math.max(1,Math.floor(state.width*size.height/size.width)));
      if(state.liveDetailRegion?.height!==height||!state.liveDetailPreview||!state.livePreview)return false;
      // On a wide first screen, several window sizes share the same detail
      // region. Region metadata alone does not mean a pending resize settled.
      const ratio=Math.min(1,size.width/state.width,size.height/state.height);
      const actual=nativeImage.createFromDataURL(state.livePreview).getSize();
      return actual.width===Math.max(1,Math.floor(state.width*ratio))&&actual.height===Math.max(1,Math.floor(state.height*ratio));
    },'previous resize supplies its final baseline');
    const geometry=await get(),base=service.state!.livePreview,detail=service.state!.liveDetailPreview;
    await click('[data-preview-zoom=original]');await ready(1);
    assert.equal(await js(`document.querySelector('[data-preview-tile]').style.imageRendering`),'pixelated');
    assert.equal(await js(`document.querySelector('[data-preview-zoom=original]').getAttribute('aria-pressed')`),'true');
    for(const zoom of [.5,.75,1,1.25]){
      await choose(zoom);
      const tile=service.state!.liveViewport!;
      verify(nativeImage.createFromDataURL(tile.image),tile.region.width,tile.region.height,{x:tile.region.x,y:tile.region.y});
      const metrics=await js<{w:number;h:number;nw:number;nh:number;dpi:number}>(`(()=>{const i=document.querySelector('[data-preview-tile]'),r=i.getBoundingClientRect();return{w:r.width,h:r.height,nw:i.naturalWidth,nh:i.naturalHeight,dpi:devicePixelRatio};})()`);
      assert.ok(Math.abs(metrics.w*metrics.dpi-tile.region.width*zoom)<.2);
      assert.ok(Math.abs(metrics.h*metrics.dpi-tile.region.height*zoom)<.2);
      if(zoom===1){assert.equal(metrics.nw,tile.region.width);assert.equal(metrics.nh,tile.region.height);}
      assert.deepEqual((await get()).bounds,geometry.bounds,'Zoom must not resize or reposition the preview window');
    }
    assert.ok(service.state!.livePreview===base,'Zoom-only requests reuse cached overview');
    assert.ok(service.state!.liveDetailPreview===detail,'Zoom-only requests reuse cached detail');
    // Move away from an edge so a cursor anchor can remain exact.
    await choose(1);
    await js(`(()=>{const v=document.querySelector('.scroll-thumbnail-image');v.scrollLeft=120;v.scrollTop=100;v.dispatchEvent(new Event('scroll'));})()`);
    await until(async()=>!service.state?.liveViewport?.follow&&!(await js<boolean>(`!!document.querySelector('.scroll-preview-loading')`)),'manual pan');
    const before=await js<{x:number;y:number;cancelled?:boolean}>(`(()=>{const v=document.querySelector('.scroll-thumbnail-image'),r=v.getBoundingClientRect(),s=document.querySelector('[data-preview-sheet]').getBoundingClientRect();window.zoomAnchor={x:r.left+v.clientWidth*.45,y:r.top+v.clientHeight*.45};const p=window.zoomAnchor;return{x:(p.x-s.left)*devicePixelRatio,y:(p.y-s.top)*devicePixelRatio};})()`);
    assert.equal(await js<boolean>(`(()=>{const v=document.querySelector('.scroll-thumbnail-image'),p=window.zoomAnchor,e=new WheelEvent('wheel',{bubbles:true,cancelable:true,ctrlKey:true,deltaY:-60,clientX:p.x,clientY:p.y});v.dispatchEvent(e);return e.defaultPrevented;})()`),true);
    const expected=Math.round(Math.exp(.12)*1000)/1000;await ready(expected);
    const after=await js<{x:number;y:number}>(`(()=>{const s=document.querySelector('[data-preview-sheet]').getBoundingClientRect(),p=window.zoomAnchor;return{x:(p.x-s.left)*devicePixelRatio/${expected},y:(p.y-s.top)*devicePixelRatio/${expected}};})()`);
    assert.ok(Math.abs(after.x-before.x)<2&&Math.abs(after.y-before.y)<2,`Ctrl-wheel must retain cursor anchor: ${JSON.stringify({before,after})}`);
    assert.equal(preview.webContents.getZoomFactor(),1,'Ctrl-wheel must zoom the image, not the app page');
    await click('[data-preview-zoom=follow]');
    await until(async()=>!!service.state?.liveViewport?.follow&&!(await js<boolean>(`!!document.querySelector('.scroll-preview-loading')`)),'resume follow');
    const current=service.state!.liveViewport!;
    await js(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'view',sequence:${Math.max(1,current.sequence-1)},view:null})`);
    await new Promise(resolve=>setTimeout(resolve,300));
    assert.equal(service.state?.liveViewport?.sequence,current.sequence,'Older viewport requests cannot overwrite newer view');
    assert.equal(await js(`window.screenAI.previewWindow({id:${JSON.stringify(id)},op:'view',sequence:999,view:{zoom:99}}).then(()=>false,()=>true)`),true);
    assert.equal(await js(`document.querySelectorAll('[title],select').length`),0,'Zoom menu remains inside the protected window');
    await writeFile(path.join(process.cwd(),'.runtime','longshot-stage3.3-preview.png'),(await preview.webContents.capturePage()).toPNG());
    await click('[data-preview-zoom=fit]');
    await until(()=>js<boolean>(`document.querySelector('.scroll-thumbnail')?.dataset.previewMode==='overview'`),'fit');
    await until(async()=>!service.state?.liveViewport,'fit clears ROI');
    await click('button[data-preview-mode=detail]');
    console.log('LONGSHOT PREVIEW ZOOM PASS: all four presets source-sampled pixel comparison, 100% physical pixels, Ctrl-wheel cursor anchor without page zoom, pan/follow, old/invalid request rejection, cached overview/detail, unchanged geometry, fit and protected in-window menu.');
  }finally{if(!paused&&service.state?.id===id&&service.state.paused)await service.command(id,'resume');}
}
