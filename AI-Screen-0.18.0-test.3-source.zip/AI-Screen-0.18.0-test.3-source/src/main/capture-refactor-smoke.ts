import assert from 'node:assert/strict';
import { nativeImage, BrowserWindow } from 'electron';
import type { Rect, PixelSample } from '../shared/contracts';
import type { WindowManager } from './windows';
import type { CaptureService } from './services/capture';
import type { AnnotationCompositor } from './services/annotation-compositor';
import type { PinWindowManager } from './pin-window';

interface RefactorServices {
  pins: PinWindowManager;
  compositor: AnnotationCompositor;
  copiedSize(): { width: number; height: number } | undefined;
}
const pause = () => new Promise<void>((resolve) => setTimeout(resolve, 30));

async function until(predicate: () => boolean, label: string, milliseconds = 6000) {
  const end = Date.now() + milliseconds;
  while (!predicate()) {
    if (Date.now() > end) throw new Error(`Capture refactor smoke timed out: ${label}`);
    await pause();
  }
}

async function rendered(win: BrowserWindow, expression: string, label: string, milliseconds = 5000) {
  await win.webContents.executeJavaScript(`new Promise((resolve, reject) => {
    const end = Date.now() + ${milliseconds};
    const check = () => {
      if (${expression}) return resolve(true);
      if (Date.now() > end) return reject(new Error(${JSON.stringify(`Capture refactor smoke: ${label}`)}));
      setTimeout(check, 20);
    }; check();
  })`);
}

async function selectionRect(win: BrowserWindow): Promise<Rect> {
  return win.webContents.executeJavaScript(`(() => { const s = document.querySelector('.selection').style; return { x: parseFloat(s.left), y: parseFloat(s.top), width: parseFloat(s.width), height: parseFloat(s.height) }; })()`);
}

// Exercises the production IPC/renderer path. Desktop pixels remain only in memory;
// clipboard writes use the smoke-only writer injected by main/index.ts.
export async function runCaptureRefactorSmoke(windows: WindowManager, capture: CaptureService, services: RefactorServices, home: BrowserWindow) {
  const observed = new Set<number>();
  async function start() {
    await home.webContents.executeJavaScript('window.screenAI.startCapture()');
    const win = windows.get('capture');
    assert.ok(win, 'production startCapture must create a capture group');
    await rendered(win, `document.querySelector('.screen-image')?.complete && !!document.querySelector('.mode-toolbar')`, 'initial mode toolbar');
    await win.webContents.executeJavaScript(`(() => {
      // Synthetic PointerEvents have no OS pointer ID; preserve real React handlers.
      Element.prototype.setPointerCapture = function() {};
      Element.prototype.hasPointerCapture = function() { return false; };
      window.refactorPointer = (target, type, x, y) => target.dispatchEvent(new PointerEvent(type, { bubbles: true, pointerId: 7, button: 0, clientX: x, clientY: y }));
    })()`);
    if (!observed.has(win.webContents.id)) {
      // Retain only session identity. Never retain a duplicate screenshot in the fixture.
      await win.webContents.executeJavaScript(`window.screenAI.onCapture(session => { window.refactorSessionId = session?.sessionId ?? ''; }); undefined`);
      observed.add(win.webContents.id);
    }
    return win;
  }
  async function draw(win: BrowserWindow) {
    await win.webContents.executeJavaScript(`(() => { const node = document.querySelector('.capture'); refactorPointer(node, 'pointerdown', 80, 160); refactorPointer(node, 'pointermove', 360, 340); refactorPointer(node, 'pointerup', 360, 340); })()`);
    await rendered(win, `!!document.querySelector('.selection') && !!document.querySelector('.capture-tools')`, 'drawn selection');
    assert.deepEqual(await selectionRect(win), { x: 80, y: 160, width: 280, height: 180 });
  }
  async function click(win: BrowserWindow, selector: string) {
    await rendered(win, `!!document.querySelector(${JSON.stringify(selector)})`, selector);
    await win.webContents.executeJavaScript(`document.querySelector(${JSON.stringify(selector)}).click()`);
    await pause();
  }
  async function rightClick(win: BrowserWindow) {
    await win.webContents.executeJavaScript(`document.querySelector('.capture').dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, button: 2, clientX: 200, clientY: 220 }))`);
    await pause();
  }
  async function cancel(win: BrowserWindow) {
    await win.webContents.executeJavaScript('window.screenAI.cancelCapture()');
    await until(() => windows.getCaptures().length === 0, 'capture cancellation');
  }

  // Exercise the four actual workspace buttons through the preload and validated IPC.
  await home.webContents.executeJavaScript('document.querySelector("[data-home-page=overview]").click()');
  await pause();
  for (const mode of ['screenshot', 'longshot', 'record', 'ai-screen']) {
    await home.webContents.executeJavaScript(`document.querySelector('[data-launch-mode="${mode}"]').click()`);
    await until(() => !!windows.get('capture'), `workspace ${mode} entry`);
    const entry = windows.get('capture')!;
    await rendered(entry, `document.querySelector('.capture')?.dataset.mode === ${JSON.stringify(mode)} && !!document.querySelector('.mode-toolbar')`, `workspace ${mode} mode`);
    await cancel(entry);
    await rendered(home, `!document.querySelector('[data-launch-mode="${mode}"]').disabled`, 'workspace launch unlocked');
  }
  console.log('WORKSPACE ENTRIES PASS: four cards launch their selected mode, cancel restores the workspace, and launch locks are released.');

  let overlay = await start();
  const modes = await overlay.webContents.executeJavaScript(`Array.from(document.querySelectorAll('.mode-toolbar [data-mode]')).map(node => node.dataset.mode)`);
  assert.deepEqual(modes, ['screenshot', 'longshot', 'record', 'ai-screen']);
  assert.equal(await overlay.webContents.executeJavaScript(`document.querySelector('.capture').dataset.mode`), 'screenshot');
  await overlay.webContents.executeJavaScript(`refactorPointer(document.querySelector('.capture'), 'pointermove', 320, 280)`);
  await pause();
  await rendered(overlay, `!!document.querySelector('.window-candidate')`, 'hover candidate');
  const candidate: Rect = await overlay.webContents.executeJavaScript(`(() => { const s = document.querySelector('.window-candidate').style; return { x: parseFloat(s.left), y: parseFloat(s.top), width: parseFloat(s.width), height: parseFloat(s.height) }; })()`);
  assert.ok(candidate.width >= 4 && candidate.height >= 4);
  await overlay.webContents.executeJavaScript(`(() => { const node = document.querySelector('.capture'); refactorPointer(node, 'pointerdown', 320, 280); refactorPointer(node, 'pointerup', 320, 280); })()`);
  await rendered(overlay, `!!document.querySelector('.selection')`, 'click selects hover candidate');
  assert.deepEqual(await selectionRect(overlay), candidate);
  assert.equal(await overlay.webContents.executeJavaScript(`document.querySelectorAll('[data-resize]').length`), 8);
  await rightClick(overlay);
  await rendered(overlay, `!document.querySelector('.selection') && !!document.querySelector('.mode-toolbar')`, 'first right click resets');
  assert.ok(windows.get('capture'), 'first right click retains screenshot mode');
  await rightClick(overlay);
  await until(() => windows.getCaptures().length === 0, 'second right click exits');
  console.log('QQ SELECTION PASS: four mode entries, hover candidate, click whole candidate, eight handles, right-click reset then exit.');

  overlay = await start();
  const sessionId: string = await overlay.webContents.executeJavaScript('window.refactorSessionId');
  assert.ok(sessionId, 'session subscription must receive fresh identity on warm reuse');
  const samplePoint = { x: 120, y: 120 };
  const sampled: PixelSample | null = await overlay.webContents.executeJavaScript(`window.screenAI.samplePixel(${JSON.stringify(sessionId)}, ${JSON.stringify(samplePoint)})`);
  assert.ok(sampled);
  assert.match(sampled.hex, /^#[0-9A-F]{6}$/);
  assert.deepEqual(nativeImage.createFromDataURL(sampled.image).getSize(), { width: 15, height: 15 });
  const displayId = windows.captureDisplayOf(overlay.webContents.id)!;
  const frame = capture.frame(displayId)!;
  const original = capture.crop({ x: 0, y: 0, width: frame.width, height: frame.height }, displayId);
  const originalSize = original.getSize();
  const originalX = Math.floor(samplePoint.x * originalSize.width / frame.width), originalY = Math.floor(samplePoint.y * originalSize.height / frame.height);
  const originalBytes = original.toBitmap();
  const offset = (originalY * originalSize.width + originalX) * 4;
  assert.deepEqual(sampled.rgb, [originalBytes[offset + 2], originalBytes[offset + 1], originalBytes[offset]]);
  assert.equal(sampled.hex, `#${sampled.rgb.map((channel) => channel.toString(16).padStart(2, '0')).join('').toUpperCase()}`);
  assert.equal(await overlay.webContents.executeJavaScript(`window.screenAI.samplePixel('stale-session', {x:120,y:120})`), null);
  assert.equal(await home.webContents.executeJavaScript(`window.screenAI.samplePixel('untrusted', {x:120,y:120}).then(() => false, () => true)`), true);
  await overlay.webContents.executeJavaScript(`refactorPointer(document.querySelector('.capture'), 'pointermove', 120, 120)`);
  await rendered(overlay, `!!document.querySelector('.magnifier-overlay') && document.querySelector('.magnifier-pixels img').naturalWidth === 15`, 'original-pixel magnifier');
  await draw(overlay);
  await rendered(overlay, `!document.querySelector('.magnifier-overlay')`, 'magnifier hides for selected toolbar');

  await click(overlay, '[data-action="annotate"]');
  await rendered(overlay, `document.querySelector('.capture').dataset.phase === 'annotating' && !!document.querySelector('.annotation-toolbar')`, 'annotation state');
  for (const [index, tool] of ['pen', 'arrow', 'rectangle'].entries()) {
    await click(overlay, `[data-tool="${tool}"]`);
    await rendered(overlay, `document.querySelector('.annotation-layer').dataset.annotationTool === ${JSON.stringify(tool)}`, `annotation tool ${tool}`);
    await overlay.webContents.executeJavaScript(`(() => { const svg = document.querySelector('.annotation-canvas'); refactorPointer(svg, 'pointerdown', 110, 195); refactorPointer(svg, 'pointermove', 230, 260); refactorPointer(svg, 'pointerup', 260, 280); })()`);
    await rendered(overlay, `document.querySelectorAll('.annotation-canvas > g').length === ${index + 1}`, `commit ${tool}`);
  }
  await click(overlay, '[data-tool="text"]');
  await rendered(overlay, `document.querySelector('.annotation-layer').dataset.annotationTool === 'text'`, 'text annotation tool');
  await overlay.webContents.executeJavaScript(`refactorPointer(document.querySelector('.annotation-canvas'), 'pointerdown', 130, 205)`);
  await rendered(overlay, `!!document.querySelector('.annotation-text-input')`, 'annotation text editor');
  await overlay.webContents.executeJavaScript(`(() => { const input = document.querySelector('.annotation-text-input'); Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(input, '标注测试'); input.dispatchEvent(new Event('input', {bubbles:true})); })()`);
  await pause();
  await overlay.webContents.executeJavaScript(`document.querySelector('.annotation-text-input').dispatchEvent(new KeyboardEvent('keydown', {bubbles:true,key:'Enter'}))`);
  await rendered(overlay, `document.querySelectorAll('.annotation-canvas > g').length === 4 && document.querySelector('.annotation-canvas text')?.textContent === '标注测试'`, 'text annotation commit');
  await click(overlay, '[data-tool="undo"]');
  await rendered(overlay, `document.querySelectorAll('.annotation-canvas > g').length === 3`, 'annotation undo');
  await click(overlay, '[data-tool="clear"]');
  await rendered(overlay, `document.querySelectorAll('.annotation-canvas > g').length === 0`, 'annotation clear');
  await click(overlay, '[data-action="annotate"]');
  await rendered(overlay, `document.querySelector('.capture').dataset.phase === 'selected' && document.querySelectorAll('[data-resize]').length === 8`, 'return to editable selection');
  await overlay.webContents.executeJavaScript(`(() => { const node = document.querySelector('.selection'); refactorPointer(node, 'pointerdown', 120, 200); refactorPointer(node, 'pointermove', 135, 210); refactorPointer(node, 'pointerup', 135, 210); })()`);
  await rendered(overlay, `document.querySelector('.selection').style.left === '95px' && document.querySelector('.selection').style.top === '170px'`, 'selection move after annotation');
  await cancel(overlay);
  assert.equal(await overlay.webContents.executeJavaScript(`window.screenAI.samplePixel(${JSON.stringify(sessionId)}, {x:120,y:120})`), null);
  console.log('QQ EDIT PASS: original bitmap pixel sampling, stale/foreign sender guards, magnifier visibility, four annotation tools, undo/clear and selection move.');

  const base = nativeImage.createFromBitmap(Buffer.alloc(100 * 80 * 4, 255), { width: 100, height: 80 });
  const composed = await services.compositor.render(base, { x: 0, y: 0, width: 50, height: 40 }, [
    { id: 'smoke-pen', kind: 'pen', color: '#ff0000', width: 3, points: [{ x: .1, y: .25 }, { x: .9, y: .25 }] },
    { id: 'smoke-rect', kind: 'rectangle', color: '#00ff00', width: 2, start: { x: .1, y: .5 }, end: { x: .5, y: .9 } },
    { id: 'smoke-arrow', kind: 'arrow', color: '#0000ff', width: 2, start: { x: .65, y: .5 }, end: { x: .9, y: .9 } },
    { id: 'smoke-text', kind: 'text', color: '#111111', width: 2, position: { x: .55, y: .01 }, text: 'T<script>', fontSize: 12 },
  ]);
  assert.deepEqual(composed.getSize(), { width: 100, height: 80 });
  const composedBytes = composed.toBitmap();
  const pixel = (x: number, y: number) => [...composedBytes.subarray((y * 100 + x) * 4, (y * 100 + x) * 4 + 4)];
  assert.deepEqual(pixel(50, 20), [0, 0, 255, 255]);
  assert.deepEqual(pixel(10, 50), [0, 255, 0, 255]);
  assert.deepEqual(pixel(0, 0), [255, 255, 255, 255]);
  assert.deepEqual(pixel(50, 23), [255, 255, 255, 255]);
  console.log('QQ COMPOSITOR PASS: synthetic PNG retains untouched pixels and exports annotations with 2x DPI line width.');
  const countBeforeCancelledPin = services.pins.getAll().length;
  let pinCreationCurrent = true;
  const cancelledPin = services.pins.create(base.toDataURL(), { x: 10, y: 10, width: 100, height: 80 }, () => pinCreationCurrent);
  pinCreationCurrent = false;
  await assert.rejects(cancelledPin, /取消/);
  assert.equal(services.pins.getAll().length, countBeforeCancelledPin);

  // Hold a real production pin request at its async boundary, then right-click.
  // The first right click must keep the overlay and invalidate the pending output.
  overlay = await start(); await draw(overlay);
  const originalCreate = services.pins.create.bind(services.pins);
  let releasePin!: () => void;
  const pinGate = new Promise<void>((resolve) => { releasePin = resolve; });
  services.pins.create = async (image, bounds, isCurrent) => { await pinGate; return originalCreate(image, bounds, isCurrent); };
  try {
    await overlay.webContents.executeJavaScript(`document.querySelector('[data-action="pin"]').click()`);
    await rendered(overlay, `document.querySelector('.capture').dataset.phase === 'ai-processing'`, 'pending pin state');
    await rightClick(overlay);
    await rendered(overlay, `document.querySelector('.capture').dataset.phase === 'window-hover' && !document.querySelector('.selection')`, 'right click cancels action and reselects');
    assert.ok(windows.get('capture'));
    releasePin(); await new Promise((resolve) => setTimeout(resolve, 70));
    assert.equal(services.pins.getAll().length, countBeforeCancelledPin);
    assert.equal(await overlay.webContents.executeJavaScript(`!!document.querySelector('[role="alert"]')`), false);
  } finally { releasePin(); services.pins.create = originalCreate; }
  await cancel(overlay);
  console.log('QQ RESET PASS: right click cancels pending pin output, clears selection, retains screenshot mode, ignores the late failure.');

  overlay = await start(); await draw(overlay);
  const initialPins = new Set(services.pins.getAll().map(({ win }) => win.webContents.id));
  await click(overlay, '[data-action="pin"]');
  await until(() => windows.getCaptures().length === 0 && services.pins.getAll().some(({ win }) => !initialPins.has(win.webContents.id)), 'independent pinned image');
  const pinned = services.pins.getAll().find(({ win }) => !initialPins.has(win.webContents.id))!;
  assert.equal(pinned.win.getParentWindow(), null);
  assert.equal(pinned.win.isAlwaysOnTop(), true);
  await rendered(pinned.win, `document.querySelector('.pin-image')?.complete && document.querySelector('.pin-image').naturalWidth > 0`, 'pin image loaded');
  assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.getPin().then(() => false, () => true)'), true);
  const originalZoom: number = await pinned.win.webContents.executeJavaScript('window.screenAI.getPin().then(value => value.zoom)');
  const enlargedZoom: number = await pinned.win.webContents.executeJavaScript(`window.screenAI.controlPin('zoom-in').then(value => value.zoom)`);
  assert.ok(enlargedZoom > originalZoom);
  await pinned.win.webContents.executeJavaScript(`document.querySelector('.pin-close').click()`).catch((error) => { if (!pinned.win.isDestroyed()) throw error; });
  await until(() => !services.pins.getAll().some(({ win }) => !initialPins.has(win.webContents.id)), 'pin close');
  console.log('QQ PIN PASS: selection creates a parentless topmost image, capture closure preserves it, zoom and close work.');

  overlay = await start(); await draw(overlay);
  const copyRect = await selectionRect(overlay);
  const expectedCopy = capture.crop(copyRect, windows.captureDisplayOf(overlay.webContents.id)).getSize();
  await overlay.webContents.executeJavaScript(`document.querySelector('.selection').dispatchEvent(new MouseEvent('dblclick', {bubbles:true,button:0,detail:2,clientX:160,clientY:230}))`);
  await until(() => windows.getCaptures().length === 0, 'double click copy');
  assert.deepEqual(services.copiedSize(), expectedCopy);
  console.log('QQ QUICK COPY PASS: selection double click uses production crop/action and injected clipboard writer, then closes capture.');

  overlay = await start();
  await click(overlay, '.mode-toolbar [data-mode="ai-screen"]');
  await rendered(overlay, `document.querySelector('.capture').dataset.mode === 'ai-screen' && !!document.querySelector('.recognize-actions')`, 'AI screen mode');
  await click(overlay, '.recognize-actions button');
  await until(() => windows.getCaptures().length === 0 && !!windows.get('result'), 'AI screen floating result');
  const result = windows.get('result')!;
  await rendered(result, `!!document.querySelector('.markdown-answer')`, 'AI screen rendered result');
  const demoState = await result.webContents.executeJavaScript(`window.screenAI.getResult().then(state => ({ action: state?.action, status: state?.status, demo: state?.demo, hasText: !!state?.text }))`);
  assert.deepEqual(demoState, { action: 'analyze', status: 'done', demo: true, hasText: true });
  assert.equal(result.isAlwaysOnTop(), true);
  const resultClosed = new Promise<void>((resolve) => result.once('closed', () => resolve()));
  windows.close('result'); await resultClosed;
  console.log('QQ AI SCREEN PASS: recognize current window runs the existing demo analysis route and opens a topmost floating result.');

  for (const mode of ['record']) {
    overlay = await start();
    await click(overlay, `.mode-toolbar [data-mode="${mode}"]`);
    assert.equal(await overlay.webContents.executeJavaScript(`document.querySelector('.capture').dataset.mode`), mode);
    await overlay.webContents.executeJavaScript(`(() => { const node = document.querySelector('.capture'); refactorPointer(node, 'pointerdown', 80, 160); refactorPointer(node, 'pointermove', 360, 340); refactorPointer(node, 'pointerup', 360, 340); })()`);
    let host:BrowserWindow|undefined;
    await until(()=>{host=BrowserWindow.getAllWindows().find(win=>win.webContents.getURL().endsWith('/recording/media-host.html'));return !!host;},'recording preparation host');
    await rendered(host!,`!!document.querySelector('#prepare') && !document.querySelector('#prepare').disabled`,'compact recording preparation');
    assert.equal(await host!.webContents.executeJavaScript(`!!document.querySelector('[data-record-audio="system"]') && !document.body.textContent.includes('返回普通截图')`),true);
    await click(host!, '[data-control="reselect"]');
    await rendered(overlay, `document.querySelector('.capture')?.dataset.mode === 'record' && !!document.querySelector('.mode-toolbar')`, `${mode} reselect keeps recording mode`);
    await cancel(overlay);
  }
  console.log('QQ EXTENSION MODES PASS: record opens compact preparation automatically; reselect stays in recording mode without a return-to-screenshot action.');
}
