import { spawn } from 'node:child_process';
import path from 'node:path';
import { screen, session, type BrowserWindow } from 'electron';

// This is a test gesture against our own inert fixtures, never a production
// activation fallback. Data is passed as JSON, not interpolated executable code.
const activationScript = String.raw`
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8
try {
    $request = [Console]::ReadLine() | ConvertFrom-Json
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Threading;

public static class SmokeFixtureInput {
    [StructLayout(LayoutKind.Sequential)] private struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)] private struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public UIntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Explicit)] private struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; }
    [StructLayout(LayoutKind.Sequential)] private struct INPUT { public uint type; public INPUTUNION data; }
    [DllImport("user32.dll")] private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")] private static extern IntPtr WindowFromPoint(POINT point);
    [DllImport("user32.dll")] private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);
    [DllImport("user32.dll")] private static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool GetClientRect(IntPtr hwnd, out RECT bounds);
    [DllImport("user32.dll")] private static extern bool ClientToScreen(IntPtr hwnd, ref POINT point);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out POINT point);
    [DllImport("user32.dll")] private static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, INPUT[] inputs, int size);

    private static IntPtr Root(IntPtr hwnd) { return hwnd == IntPtr.Zero ? IntPtr.Zero : GetAncestor(hwnd, 2); }
    private static void Validate(IntPtr target, uint ownerPid, POINT point) {
        uint actualPid;
        if (!IsWindow(target) || !IsWindowVisible(target) || IsIconic(target) || Root(target) != target
            || GetWindowThreadProcessId(target, out actualPid) == 0 || actualPid != ownerPid) throw new InvalidOperationException("Smoke fixture is no longer an owned visible root window");
        RECT client; POINT origin = new POINT();
        if (!GetClientRect(target, out client) || !ClientToScreen(target, ref origin)
            || point.X < origin.X + 4 || point.Y < origin.Y + 4
            || point.X >= origin.X + client.Right - 4 || point.Y >= origin.Y + client.Bottom - 4) throw new InvalidOperationException("Smoke click point is outside the fixture client area");
        IntPtr hit = WindowFromPoint(point);
        if (Root(hit) != target) throw new InvalidOperationException("Smoke fixture is obscured; refusing to click another window");
    }
    private static INPUT Mouse(uint flags) { INPUT input = new INPUT(); input.type = 0; input.data.mi.dwFlags = flags; return input; }
    public static void Probe(long handle, uint ownerPid, int x, int y) {
        IntPtr previous = SetThreadDpiAwarenessContext(new IntPtr(-4));
        if (previous == IntPtr.Zero) throw new InvalidOperationException("Smoke probe requires per-monitor physical coordinates");
        try { Validate(new IntPtr(handle), ownerPid, new POINT { X = x, Y = y }); }
        finally { SetThreadDpiAwarenessContext(previous); }
    }
    public static void Activate(long handle, uint ownerPid, int x, int y) {
        IntPtr previous = SetThreadDpiAwarenessContext(new IntPtr(-4));
        if (previous == IntPtr.Zero) throw new InvalidOperationException("Smoke input requires per-monitor physical coordinates");
        POINT original = new POINT(), point = new POINT { X = x, Y = y };
        bool haveOriginal = false, moved = false, releaseLeft = false;
        try {
            IntPtr target = new IntPtr(handle);
            Validate(target, ownerPid, point);
            bool released = false;
            for (int attempt = 0; attempt < 80 && !released; attempt++) {
                released = true;
                foreach (int key in new int[] { 0x01, 0x02, 0x04, 0x05, 0x06, 0x10, 0x11, 0x12, 0x5B, 0x5C }) {
                    if ((GetAsyncKeyState(key) & 0x8000) != 0) { released = false; break; }
                }
                if (!released) Thread.Sleep(25);
            }
            if (!released) throw new InvalidOperationException("Smoke fixture activation requires released mouse buttons and modifiers");
            Validate(target, ownerPid, point);
            haveOriginal = GetCursorPos(out original);
            if (!haveOriginal) throw new InvalidOperationException("Cannot preserve the original smoke cursor position");
            if (!SetCursorPos(x, y)) throw new InvalidOperationException("Cannot position the smoke fixture cursor");
            moved = true;
            Validate(target, ownerPid, point);
            POINT current;
            if (!GetCursorPos(out current) || current.X != x || current.Y != y) throw new InvalidOperationException("User moved the cursor; smoke click cancelled");
            releaseLeft = true;
            uint sent = SendInput(2, new INPUT[] { Mouse(0x0002), Mouse(0x0004) }, Marshal.SizeOf(typeof(INPUT)));
            if (sent != 2) throw new InvalidOperationException("Windows did not accept both fixture mouse events");
            releaseLeft = false;
            for (int attempt = 0; attempt < 16; attempt++) {
                if (Root(GetForegroundWindow()) == target) return;
                Thread.Sleep(25);
            }
            throw new InvalidOperationException("Owned smoke fixture did not become the native foreground window");
        } finally {
            // A partially accepted batch must never leave our button down.
            if (releaseLeft) SendInput(1, new INPUT[] { Mouse(0x0004) }, Marshal.SizeOf(typeof(INPUT)));
            if (moved && haveOriginal) {
                POINT current;
                if (GetCursorPos(out current) && current.X == x && current.Y == y) SetCursorPos(original.X, original.Y);
            }
            SetThreadDpiAwarenessContext(previous);
        }
    }
}
'@
    if ($request.probeOnly) {
        [SmokeFixtureInput]::Probe([Int64]::Parse([string]$request.hwnd, [Globalization.CultureInfo]::InvariantCulture), [uint32]$request.pid, [int]$request.x, [int]$request.y)
    } else {
        [SmokeFixtureInput]::Activate([Int64]::Parse([string]$request.hwnd, [Globalization.CultureInfo]::InvariantCulture), [uint32]$request.pid, [int]$request.x, [int]$request.y)
    }
    [Console]::WriteLine('{"ok":true}')
} catch {
    $failure = $_.Exception
    while ($null -ne $failure.InnerException) { $failure = $failure.InnerException }
    $message = 'Smoke fixture input failed'
    if ($failure -is [System.InvalidOperationException]) { $message = $failure.Message }
    [Console]::WriteLine((@{ ok = $false; error = $message } | ConvertTo-Json -Compress))
    exit 1
}
`;

/** A single real left click inside an explicitly synthetic, owned smoke fixture. */
export async function activateSmokeWindow(win: BrowserWindow): Promise<void> {
  return ownedFixtureInput(win, false);
}
/** Read-only WindowFromPoint probe: never moves the cursor or injects input. */
export async function probeSmokeWindow(win: BrowserWindow, point: {x:number;y:number}): Promise<void> {
  return ownedFixtureInput(win, true, point);
}
async function ownedFixtureInput(win: BrowserWindow, probeOnly: boolean, suppliedPoint?: {x:number;y:number}): Promise<void> {
  if (!process.argv.includes('--smoke-test') || process.platform !== 'win32') throw new Error('Native fixture activation is available only in Windows smoke tests');
  if (win.isDestroyed() || !win.isVisible() || win.isMinimized()) throw new Error('Smoke fixture must already be visible');
  if (!win.webContents.getURL().startsWith('data:text/html;charset=UTF-8,')
    || !['longshot-native-smoke', 'longshot-focus-smoke'].some((partition) => win.webContents.session === session.fromPartition(partition))) {
    throw new Error('Native fixture input is restricted to our synthetic canvas and focus windows');
  }
  const bounds = win.getContentBounds();
  if (bounds.width < 64 || bounds.height < 64) throw new Error('Smoke fixture is too small for a safe client click');
  const point = screen.dipToScreenPoint(suppliedPoint ?? { x: Math.round(bounds.x + 16), y: Math.round(bounds.y + 16) });
  const handle = win.getNativeWindowHandle();
  const hwnd = handle.length === 8 ? handle.readBigUInt64LE().toString() : String(handle.readUInt32LE());
  const payload = JSON.stringify({ hwnd, pid: process.pid, x: point.x, y: point.y, probeOnly });
  const powershell = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
  await new Promise<void>((resolve, reject) => {
    const child = spawn(powershell, ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(activationScript, 'utf16le').toString('base64')], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    let output = '', settled = false;
    const timer = setTimeout(() => { child.kill(); finish(new Error('Smoke fixture activation timed out')); }, 8000);
    function finish(error?: Error) {
      if (settled) return;
      settled = true; clearTimeout(timer);
      if (error) reject(error); else resolve();
    }
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk: string) => {
      output += chunk;
      if (output.length > 16_384) { child.kill(); finish(new Error('Smoke fixture activation returned excessive output')); }
    });
    child.stderr.resume();
    child.stdin.on('error', () => { /* Process close/error supplies the result. */ });
    child.on('error', () => finish(new Error('Cannot launch native smoke fixture input')));
    child.on('close', () => {
      try {
        const reply = JSON.parse(output.replace(/^\uFEFF/, '').trim()) as { ok?: boolean; error?: string };
        if (!reply.ok) throw new Error(typeof reply.error === 'string' ? reply.error : 'Smoke fixture activation failed');
        finish();
      } catch (error) { finish(error instanceof Error && !(error instanceof SyntaxError) ? error : new Error('Native smoke fixture activation returned an invalid response')); }
    });
    child.stdin.end(`${payload}\n`);
  });
}
