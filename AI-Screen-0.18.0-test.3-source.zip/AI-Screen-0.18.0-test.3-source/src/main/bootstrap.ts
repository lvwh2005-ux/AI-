// Route the private helper before importing UI/settings/single-instance setup.
import {CAPTURE_HELPER_FLAG} from './services/capture-process-protocol';
if(process.argv.includes(CAPTURE_HELPER_FLAG)){
  void import('./services/capture-process-helper').then(module=>module.runCaptureHelper()).catch(()=>{
    (require('electron') as typeof import('electron')).app.exit(1);
  });
}else if(process.argv.includes('--recording-spike')){
  void import('./recording-smoke');
}else if(process.argv.includes('--recording-stress')){
  void import('./recording-stress');
}else{void import('./index');}
