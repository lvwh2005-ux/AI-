import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { nativeImage, safeStorage } from 'electron';
import type { WindowManager } from './windows';
import type { TaskService } from './services/tasks';
import type { CaptureService } from './services/capture';
import { WindowsOCRProvider } from './providers/windows-ocr';
import { createServer } from 'node:http';
import { IPC } from '../shared/contracts';
import type { PinWindowManager } from './pin-window';
import type { AnnotationCompositor } from './services/annotation-compositor';
import { runCaptureRefactorSmoke } from './capture-refactor-smoke';
import { runLongshotSmoke } from './longshot-smoke';
import type { LongshotService } from './services/longshot';
import type { LongshotWindow } from './longshot-window';

// Real Electron smoke test: no API calls, no credentials, no desktop images persisted.
export async function runSmoke(windows: WindowManager, tasks: TaskService, capture: CaptureService, services: { pins: PinWindowManager; compositor: AnnotationCompositor; copiedSize: () => { width: number; height: number } | undefined; copiedDigest():string|undefined; longshot: LongshotService; longshotWindow: LongshotWindow; setSavePath(value: string | undefined): void;setDiagnosticChooser(choose:()=>Promise<string|undefined>):void }) {
  const home = await windows.show('home');
  const failures: string[] = [];
  home.webContents.on('console-message', (details) => { if (details.level === 'error') failures.push(details.message); });
  await home.webContents.executeJavaScript(`new Promise((resolve, reject) => {
    const end = Date.now() + 5000;
    const poll = () => document.querySelector('form') ? resolve(true) : Date.now() > end ? reject(new Error('Home did not render')) : setTimeout(poll, 25);
    poll();
  })`);
  if (process.argv.includes('--longshot-only')) {
    await runLongshotSmoke(windows, home, services);
    windows.disposeCaptures(); windows.close('home');
    console.log('LONGSHOT ISOLATED SMOKE PASS'); return;
  }
  const settings = { ...await home.webContents.executeJavaScript('window.screenAI.getSettings()'), shortcut: 'Control+Alt+Shift+F11' };
  assert.equal(settings.provider, 'demo');
  assert.equal(settings.hasApiKey, false);
  assert.equal(settings.ocr, 'vision');
  assert.equal(settings.stream, true);
  assert.equal(await home.webContents.executeJavaScript('typeof window.require'), 'undefined');
  assert.equal(await home.webContents.executeJavaScript('window.screenAI.getCapture().then(() => false, () => true)'), true);
  assert.equal(await home.webContents.executeJavaScript('window.screenAI.startCapture("invalid-mode").then(() => false, () => true)'), true);
  const customActions = [
    { id: 'smoke-summary', label: '总结要点', prompt: '用{{language}}总结图片。', enabled: true },
    { id: 'smoke-question', label: '按需解释', prompt: '用{{language}}回答：{{question}}', enabled: true },
    { id: 'smoke-disabled', label: '已停用动作', prompt: '不会执行', enabled: false },
  ];
  await home.webContents.executeJavaScript(`window.screenAI.saveSettings(${JSON.stringify({ ...settings, shortcut: 'Control+Alt+Shift+F11', customActions })})`);
  await home.webContents.executeJavaScript('document.querySelector("[data-home-page=preferences]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  await home.webContents.executeJavaScript('document.querySelector("#shortcut-recorder").click()');
  await new Promise((resolve) => setTimeout(resolve, 100));
  assert.equal(await home.webContents.executeJavaScript('window.screenAI.getSettings().then(value => value.shortcutActive)'), false);
  assert.equal(await home.webContents.executeJavaScript(`window.screenAI.saveSettings(${JSON.stringify(settings)}).then(() => false, () => true)`), true);
  await home.webContents.executeJavaScript(`(() => { const button = document.querySelector('#shortcut-recorder'); button.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'F10', code: 'F10', ctrlKey: true, altKey: true, shiftKey: true })); button.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'F10', code: 'F10' })); })()`);
  await new Promise((resolve) => setTimeout(resolve, 100));
  assert.equal(await home.webContents.executeJavaScript('window.screenAI.getSettings().then(value => value.shortcutActive)'), true);
  assert.match(await home.webContents.executeJavaScript('document.querySelector("#shortcut-recorder").textContent'), /F10/);
  await home.webContents.executeJavaScript('window.screenAI.setShortcutRecording(true)');
  home.emit('blur');
  assert.equal(await home.webContents.executeJavaScript('window.screenAI.getSettings().then(value => value.shortcutActive)'), true);
  assert.equal(await home.webContents.executeJavaScript('window.screenAI.openExternal("https://example.com").then(() => false, () => true)'), true);
  console.log('SHORTCUT PASS: UI recording suspends registration, key release/blur restore it; save guarded.');
  // Reload the home preview from saved test settings, avoiding stale registration UI.
  const homeReloaded = new Promise<void>((resolve) => home.webContents.once('did-finish-load', () => resolve()));
  home.webContents.reload();
  await homeReloaded;
  await home.webContents.executeJavaScript(`new Promise((resolve, reject) => {
    const end = Date.now() + 5000;
    const poll = () => document.querySelector('form') ? resolve(true) : Date.now() > end ? reject(new Error('Home reload did not render')) : setTimeout(poll, 25);
    poll();
  })`);
  assert.equal(await home.webContents.executeJavaScript('getComputedStyle(document.documentElement).colorScheme'), 'light');
  assert.equal(await home.webContents.executeJavaScript('document.documentElement.scrollWidth <= innerWidth'), true);
  const saveBar = await home.webContents.executeJavaScript('(() => { const b = document.querySelector(".home-save-bar").getBoundingClientRect(); return { top: b.top, bottom: b.bottom, height: innerHeight }; })()');
  assert.ok(saveBar.top >= 0 && saveBar.bottom <= saveBar.height);
  const normalSize = home.getSize();
  home.setSize(800, 560);
  await new Promise((resolve) => setTimeout(resolve, 100));
  assert.equal(await home.webContents.executeJavaScript('(() => { const m = document.querySelector(".home-main"); const b = document.querySelector(".home-save-bar").getBoundingClientRect(); return m.scrollWidth <= m.clientWidth && b.top >= 0 && b.bottom <= innerHeight; })()'), true);
  await writeFile(path.join(process.cwd(), '.runtime', 'smoke-home-narrow.png'), (await home.webContents.capturePage(undefined, { stayHidden: true, stayAwake: true })).toPNG());
  home.setSize(normalSize[0], normalSize[1]);
  await new Promise((resolve) => setTimeout(resolve, 100));
  // A hidden window may not yet have a compositor frame when React first mounts.
  await new Promise((resolve) => setTimeout(resolve, 350));
  const screenshot = await home.webContents.capturePage(undefined, { stayHidden: true, stayAwake: true });
  await mkdir(path.join(process.cwd(), '.runtime'), { recursive: true });
  await writeFile(path.join(process.cwd(), '.runtime', 'smoke-home.png'), screenshot.toPNG());
  assert.equal(await home.webContents.executeJavaScript('Array.from(document.querySelectorAll("[data-launch-mode]")).every(e => { const r = e.getBoundingClientRect(); return r.top >= 0 && r.bottom <= document.querySelector(".home-save-bar").getBoundingClientRect().top; })'), true, 'all four mode entries must fit the default window');
  await home.webContents.executeJavaScript('document.querySelector("[data-home-page=service]").click()');
  await new Promise((resolve) => setTimeout(resolve, 75));
  await writeFile(path.join(process.cwd(), '.runtime', 'smoke-service.png'), (await home.webContents.capturePage(undefined, { stayHidden: true, stayAwake: true })).toPNG());
  await home.webContents.executeJavaScript('document.querySelector("[data-home-page=actions]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  await home.webContents.executeJavaScript(`(() => { document.querySelector('.custom-actions-editor').open = true; document.querySelector('.add-custom-action').click(); })()`);
  await new Promise((resolve) => setTimeout(resolve, 100));
  assert.ok(await home.webContents.executeJavaScript('document.querySelectorAll(".custom-action-item").length > 0'));
  await home.webContents.executeJavaScript('document.querySelector("[data-home-page=preferences]").click()');
  await new Promise((resolve) => setTimeout(resolve, 100));
  await writeFile(path.join(process.cwd(), '.runtime', 'smoke-settings.png'), (await home.webContents.capturePage(undefined, { stayHidden: true, stayAwake: true })).toPNG());
  // Navigation preserves unsaved form state; save stays outside the scroll area.
  await home.webContents.executeJavaScript('document.querySelector("[data-home-page=actions]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.ok(await home.webContents.executeJavaScript('document.querySelectorAll(".custom-action-item").length > 0'));
  assert.equal(await safeStorage.isAsyncEncryptionAvailable(), true);
  const encrypted = await safeStorage.encryptStringAsync('smoke-test-only');
  assert.equal((await safeStorage.decryptStringAsync(encrypted)).result, 'smoke-test-only');
  const ocrFixture = await home.webContents.executeJavaScript(`(() => {
    const canvas = document.createElement('canvas'); canvas.width = 800; canvas.height = 180;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = 'white'; ctx.fillRect(0, 0, 800, 180);
    ctx.fillStyle = 'black'; ctx.font = '52px Segoe UI'; ctx.fillText('SCREEN TEST 123', 30, 100);
    return canvas.toDataURL('image/png');
  })()`);
  const ocrText = await new WindowsOCRProvider().recognize(ocrFixture, new AbortController().signal);
  assert.match(ocrText, /SCREEN\s*TEST\s*123/i);
  console.log('LOCAL OCR PASS: known text recognized by Windows engine.');
  const service = createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += chunk;
    const input = JSON.parse(body);
    assert.equal(req.url, '/v1/chat/completions');
    assert.equal(input.model, 'smoke-vision');
    assert.equal(input.messages.at(-1).content[1].type, 'image_url');
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    res.end('data: {"choices":[{"index":0,"delta":{"content":"测试服务成功"},"finish_reason":"stop"}]}\n\ndata: [DONE]\n\n');
  });
  await new Promise<void>((resolve) => service.listen(0, '127.0.0.1', resolve));
  try {
    const port = (service.address() as { port: number }).port;
    const test = await home.webContents.executeJavaScript(`window.screenAI.testService(${JSON.stringify({ ...settings, provider: 'compatible', model: 'smoke-vision', baseUrl: `http://127.0.0.1:${port}/v1` })})`);
    assert.match(test.message, /成功/);
    assert.equal(await home.webContents.executeJavaScript('window.screenAI.getSettings().then(value => value.provider)'), 'demo');
    console.log('SERVICE TEST PASS: IPC → loopback HTTP → SSE, without changing saved settings.');
  } finally { await new Promise<void>((resolve) => service.close(() => resolve())); }
  const coldCaptureStart = Date.now();
  const displays = await capture.takeAll();
  const coldReadMs = Date.now() - coldCaptureStart;
  const bounds = displays[0].bounds;
  assert.ok(bounds.width > 0 && bounds.height > 0);
  assert.ok(!capture.crop({ x: 0, y: 0, width: 8, height: 8 }).isEmpty());
  const overlays = await windows.showCaptures(displays);
  const overlay = windows.get('capture')!;
  const warmWindowId = overlay.webContents.id;
  const coldCaptureMs = Date.now() - coldCaptureStart;
  assert.equal(await overlay.webContents.executeJavaScript('document.querySelector(".screen-image").complete && document.querySelector(".screen-image").naturalWidth > 0 && !document.querySelector(".screen-shade")'), true);
  assert.equal(overlays.length, displays.length);
  for (const { displayId, win } of overlays) {
    const frame = await win.webContents.executeJavaScript('window.screenAI.getCapture({ displayId: "untrusted" }).then(frame => ({ displayId: frame.displayId, width: frame.width, height: frame.height }))');
    const display = displays.find((item) => item.id === displayId)!;
    assert.equal(windows.captureDisplayOf(win.webContents.id), displayId);
    assert.deepEqual(frame, { displayId, width: display.bounds.width, height: display.bounds.height });
  }
  assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.getCapture().then(frame => frame.width)'), bounds.width);
  assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.saveSettings({}).then(() => false, () => true)'), true);
  assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.runAction({ action: "ask", question: "wrong role" }).then(() => false, () => true)'), true);
  await overlay.webContents.executeJavaScript(`new Promise((resolve, reject) => {
    const until = Date.now() + 3000;
    const poll = () => document.querySelector('.screen-image') ? resolve(true) : Date.now() > until ? reject(new Error('Capture did not render')) : setTimeout(poll, 20);
    poll();
  })`);
  // Native pointer capture requires OS pointer ids; test the React drag handlers directly.
  await overlay.webContents.executeJavaScript(`(() => {
    const node = document.querySelector('.capture'); node.setPointerCapture = () => {}; node.hasPointerCapture = () => false;
    window.smokePointer = (target, type, x, y) => target.dispatchEvent(new PointerEvent(type, { bubbles: true, pointerId: 1, button: 0, clientX: x, clientY: y }));
    smokePointer(node, 'pointerdown', 80, 160); smokePointer(node, 'pointermove', 300, 320); smokePointer(node, 'pointerup', 300, 320);
  })()`);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.deepEqual(await overlay.webContents.executeJavaScript(`(() => { const s = document.querySelector('.selection').style; return [s.left, s.top, s.width, s.height]; })()`), ['80px', '160px', '220px', '160px']);
  await overlay.webContents.executeJavaScript(`(() => { const s = document.querySelector('.selection'); smokePointer(s, 'pointerdown', 100, 180); smokePointer(s, 'pointermove', 160, 200); smokePointer(s, 'pointerup', 160, 200); })()`);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.deepEqual(await overlay.webContents.executeJavaScript(`(() => { const s = document.querySelector('.selection').style; return [s.left, s.top]; })()`), ['140px', '180px']);
  await overlay.webContents.executeJavaScript(`(() => { const h = document.querySelector('[data-resize="se"]'); smokePointer(h, 'pointerdown', 360, 340); smokePointer(h, 'pointermove', 420, 390); smokePointer(h, 'pointerup', 420, 390); })()`);
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.deepEqual(await overlay.webContents.executeJavaScript(`(() => { const s = document.querySelector('.selection').style; return [s.width, s.height]; })()`), ['280px', '210px']);
  await overlay.webContents.executeJavaScript('document.querySelector("[data-action=more]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(await overlay.webContents.executeJavaScript('document.querySelectorAll(".custom-toolbar button").length'), 2);
  await overlay.webContents.executeJavaScript('document.querySelector("[data-action=more]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  // Capture only our toolbar on a neutral background, with all desktop pixels hidden.
  await overlay.webContents.executeJavaScript(`(async () => {
    const image = document.querySelector('.screen-image');
    window.toolbarPreviewSource = image.src;
    const canvas = document.createElement('canvas'); canvas.width = 16; canvas.height = 16;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = '#eeeeef'; ctx.fillRect(0, 0, 16, 16);
    image.src = canvas.toDataURL(); await image.decode();
    image.style.visibility = 'hidden';
    document.querySelector('.selection').style.visibility = 'hidden';
    document.querySelector('.capture').style.background = '#eeeeef';
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
  })()`);
  const compactToolbar = await overlay.webContents.executeJavaScript(`(() => { const b = document.querySelector('.capture-tools').getBoundingClientRect(); return { x: Math.floor(b.x) - 10, y: Math.floor(b.y) - 10, width: Math.ceil(b.width) + 20, height: Math.ceil(b.height) + 20 }; })()`);
  assert.ok(compactToolbar.height <= 66);
  assert.equal(await overlay.webContents.executeJavaScript('document.querySelectorAll(".toolbar svg").length === 8 && !document.querySelector(".capture-status")'), true);
  await writeFile(path.join(process.cwd(), '.runtime', 'smoke-toolbar.png'), (await overlay.webContents.capturePage(compactToolbar, { stayHidden: true, stayAwake: true })).toPNG());
  await overlay.webContents.executeJavaScript(`(async () => {
    const image = document.querySelector('.screen-image'); image.src = window.toolbarPreviewSource;
    delete window.toolbarPreviewSource; await image.decode(); image.style.visibility = '';
    document.querySelector('.selection').style.visibility = '';
    document.querySelector('.capture').style.background = '';
  })()`);
  await overlay.webContents.executeJavaScript('document.querySelector("[data-action=more]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  await overlay.webContents.executeJavaScript('document.querySelectorAll(".custom-toolbar button")[1].click()');
  await new Promise((resolve) => setTimeout(resolve, 100));
  assert.match(await overlay.webContents.executeJavaScript('document.querySelector(".question-bar input").placeholder'), /按需解释/);
  assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.setShortcutRecording(true).then(() => false, () => true)'), true);
  const toolbarBounds = await overlay.webContents.executeJavaScript('(() => { const b = document.querySelector(".capture-tools").getBoundingClientRect(); return { left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: innerWidth, height: innerHeight }; })()');
  assert.ok(toolbarBounds.left >= 0 && toolbarBounds.top >= 0 && toolbarBounds.right <= toolbarBounds.width && toolbarBounds.bottom <= toolbarBounds.height);
  console.log('SELECTION UI PASS: create, move, resize, compact icon toolbar, question panel, measured bounds.');
  await overlay.webContents.executeJavaScript('window.screenAI.cancelCapture()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(windows.getCaptures().length, 0);
  assert.equal(await overlay.webContents.executeJavaScript('!document.querySelector(".screen-image") && !document.querySelector(".selection")'), true);
  assert.equal(await overlay.webContents.executeJavaScript('window.screenAI.getCapture()'), null);
  for (const { win } of overlays) assert.equal(win.isVisible(), false);
  for (const display of displays) assert.equal(capture.frame(display.id), null);
  console.log(`DISPLAY GROUP PASS: ${displays.length} display(s), sender-bound frames, cancel releases the group.`);
  assert.equal(capture.frame(), null);
  // Exercise the custom toolbar through the real crop/close/result route too.
  const warmCaptureStart = Date.now();
  const warmDisplays = await capture.takeAll();
  const warmReadMs = Date.now() - warmCaptureStart;
  await windows.showCaptures(warmDisplays);
  const warmCaptureMs = Date.now() - warmCaptureStart;
  const customOverlay = windows.get('capture')!;
  assert.equal(customOverlay.webContents.id, warmWindowId);
  assert.equal(await customOverlay.webContents.executeJavaScript('!document.querySelector(".selection") && !document.querySelector(".question-bar")'), true);
  console.log(`CAPTURE STARTUP: cold=${coldCaptureMs}ms (screen read ${coldReadMs}ms), reused=${warmCaptureMs}ms (screen read ${warmReadMs}ms); decoded frame before readiness, no initial full-screen shade.`);
  await customOverlay.webContents.executeJavaScript(`new Promise((resolve, reject) => {
    const until = Date.now() + 3000;
    const poll = () => document.querySelector('.screen-image') ? resolve(true) : Date.now() > until ? reject(new Error('Custom capture did not render')) : setTimeout(poll, 20);
    poll();
  })`);
  await customOverlay.webContents.executeJavaScript(`(() => {
    const node = document.querySelector('.capture'); node.setPointerCapture = () => {}; node.hasPointerCapture = () => false;
    for (const [type, x, y] of [['pointerdown', 40, 80], ['pointermove', 180, 160], ['pointerup', 180, 160]]) node.dispatchEvent(new PointerEvent(type, { bubbles: true, pointerId: 1, button: 0, clientX: x, clientY: y }));
  })()`);
  await new Promise((resolve) => setTimeout(resolve, 100));
  await customOverlay.webContents.executeJavaScript('document.querySelector("[data-action=more]").click()');
  await new Promise((resolve) => setTimeout(resolve, 50));
  await customOverlay.webContents.executeJavaScript('document.querySelector(".custom-toolbar button").click()');
  await new Promise((resolve) => setTimeout(resolve, 650));
  assert.equal(windows.getCaptures().length, 0);
  assert.equal(tasks.state?.actionLabel, '总结要点');
  assert.equal(tasks.state?.status, 'done');
  const fixture = nativeImage.createFromBitmap(Buffer.alloc(32 * 32 * 4, 200), { width: 32, height: 32 }).toDataURL();
  await tasks.run('analyze', fixture, '', false);
  assert.equal(tasks.state?.status, 'done');
  assert.equal(tasks.state?.demo, true);
  const result = await windows.show('result');
  assert.equal(await result.webContents.executeJavaScript('window.screenAI.openExternal("file:///C:/Windows").then(() => false, () => true)'), true);
  assert.equal(await result.webContents.executeJavaScript('window.screenAI.runAction({ action: "custom", customActionId: "smoke-disabled" }).then(() => false, () => true)'), true);
  await result.webContents.executeJavaScript('window.screenAI.runAction({ action: "custom", customActionId: "smoke-summary" })');
  await new Promise((resolve) => setTimeout(resolve, 650));
  assert.equal(tasks.state?.actionLabel, '总结要点');
  assert.equal(tasks.state?.customActionId, 'smoke-summary');
  assert.match(tasks.state!.history.at(-2)!.content, /简体中文/);
  // Render only synthetic content; never save images from capture overlays.
  const markdownFixture = '# 示例结果\n\n|项目|状态|\n|---|---|\n|自定义动作|成功|\n\n```typescript\nconst value = 42;\n```\n\n[说明](https://example.com)\n\n![remote](https://example.com/image.png)';
  tasks.state = { ...tasks.state!, text: markdownFixture };
  result.webContents.send(IPC.resultChanged, tasks.state);
  await new Promise((resolve) => setTimeout(resolve, 150));
  assert.equal(await result.webContents.executeJavaScript('!!document.querySelector(".markdown-answer table") && !!document.querySelector(".hljs-keyword") && document.querySelector(".markdown-link").getAttribute("href") === null && !document.querySelector(".markdown-answer img")'), true);
  await writeFile(path.join(process.cwd(), '.runtime', 'smoke-result.png'), (await result.webContents.capturePage(undefined, { stayHidden: true, stayAwake: true })).toPNG());
  console.log('CUSTOM/MARKDOWN PASS: saved actions, prompt expansion, question UI, GFM table, code highlighting, restricted links.');
  await tasks.run('analyze', fixture, '', false);
  assert.equal(await result.webContents.executeJavaScript('window.screenAI.runAction({ action: "analyze", rect: { x: 0, y: 0, width: 8, height: 8 } }).then(() => false, () => true)'), true);
  await result.webContents.executeJavaScript('window.screenAI.runAction({ action: "ask", question: "这是测试追问" })');
  await new Promise((resolve) => setTimeout(resolve, 650));
  assert.equal(tasks.state?.history.length, 4);
  await result.webContents.executeJavaScript('window.screenAI.runAction({ action: "ask", question: "取消测试" })');
  await result.webContents.executeJavaScript('window.screenAI.cancelRequest()');
  assert.equal(tasks.state?.status, 'cancelled');
  assert.deepEqual(failures, []);
  await result.webContents.executeJavaScript('window.screenAI.runAction({ action: "ask", question: "关闭窗口测试" })');
  const closed = new Promise<void>((resolve) => result.once('closed', () => resolve()));
  windows.close('result');
  await closed;
  assert.equal(tasks.state, null);
  await home.webContents.executeJavaScript(`window.screenAI.saveSettings(${JSON.stringify(settings)})`);
  // A slow decode must not reveal the window; a stale readiness signal must not
  // release the current session. Cancellation must unblock the caller and reuse.
  await overlay.webContents.executeJavaScript(`(() => {
    window.originalDecode = HTMLImageElement.prototype.decode;
    HTMLImageElement.prototype.decode = function() { return new Promise(resolve => setTimeout(resolve, 3000)).then(() => originalDecode.call(this)); };
  })()`);
  await home.webContents.executeJavaScript('window.captureStatus = "starting"; window.pendingCapture = window.screenAI.startCapture().then(() => { window.captureStatus = "finished"; }); undefined');
  const pendingUntil = Date.now() + 4000;
  while (!windows.get('capture') && Date.now() < pendingUntil) await new Promise((resolve) => setTimeout(resolve, 10));
  const pendingOverlay = windows.get('capture')!;
  assert.ok(pendingOverlay);
  assert.equal(pendingOverlay.isVisible(), false);
  windows.captureReady(pendingOverlay.webContents.id, 'stale-session', true);
  assert.equal(await home.webContents.executeJavaScript('window.captureStatus'), 'starting');
  await pendingOverlay.webContents.executeJavaScript('window.screenAI.cancelCapture()');
  await home.webContents.executeJavaScript('window.pendingCapture');
  assert.equal(windows.getCaptures().length, 0);
  await overlay.webContents.executeJavaScript('HTMLImageElement.prototype.decode = window.originalDecode; undefined');
  console.log('CAPTURE READINESS PASS: no reveal before decode, stale signals ignored, cancellation while preparing unblocks and clears.');
  // Exercise the actual shortcut/IPC path after warming, without saving desktop images.
  const startupSamples: number[] = [];
  for (let i = 0; i < 3; i++) {
    const started = Date.now();
    await home.webContents.executeJavaScript('window.screenAI.startCapture()');
    startupSamples.push(Date.now() - started);
    const warmed = windows.get('capture')!;
    assert.equal(warmed.webContents.id, warmWindowId);
    assert.equal(await warmed.webContents.executeJavaScript('document.querySelector(".screen-image").complete && document.querySelector(".screen-image").naturalWidth > 0 && !document.querySelector(".screen-shade") && !document.querySelector(".selection")'), true);
    await warmed.webContents.executeJavaScript('window.screenAI.cancelCapture()');
  }
  console.log(`CAPTURE IPC PASS: repeated warm starts ${startupSamples.join('/')}ms; same window, current frame, cleared selection.`);
  await runCaptureRefactorSmoke(windows, capture, services, home);
  await runLongshotSmoke(windows, home, services);
  windows.disposeCaptures();
  windows.close('home');
  console.log('SMOKE PASS: home/capture/result renderers, preload isolation, IPC authorization, native screen/crop, encrypted storage, demo, follow-up, cancellation.');
}
