import{BrowserWindow,screen}from'electron';
import assert from'node:assert/strict';
import{mkdir,writeFile,readFile,stat,readdir}from'node:fs/promises';
import path from'node:path';
import{setTimeout as delay}from'node:timers/promises';
import type{WindowManager}from'./windows';
import type{RecordingService}from'./services/recording/recording-service';
import type{RecordingWindow}from'./recording-window';
import type{ElectronMediaHost}from'./services/recording/media-host';
import{ElectronMediaHost as AudioProbeHost}from'./services/recording/media-host';
import{randomUUID}from'node:crypto';
import{recordingOptionsSchema,type RecordingTarget}from'../shared/recording/contracts';
import{recordingFormat}from'../shared/recording/format';

interface Services{service:RecordingService;result:RecordingWindow;host():ElectronMediaHost|undefined;setSave(choose:()=>Promise<string|undefined>):void;setAudioFrame(frame:Electron.WebFrameMain|undefined):void;setVideoTarget(target:RecordingTarget|undefined):void;denyMicrophone(value:boolean):void}
async function until(predicate:()=>boolean|Promise<boolean>,label:string,ms=15000){const end=performance.now()+ms;while(!await predicate()){if(performance.now()>end)throw Error(`Recording UI timeout: ${label}`);await delay(35);}}
async function click(win:BrowserWindow,selector:string,trusted=false){
  await until(()=>win.webContents.executeJavaScript(`(()=>{const e=document.querySelector(${JSON.stringify(selector)}),r=e?.getBoundingClientRect();return !!e&&!e.disabled&&r.width>0&&r.height>0})()`).catch(()=>false),selector);
  if(!trusted){await win.webContents.executeJavaScript(`document.querySelector(${JSON.stringify(selector)}).click()`);return;}
  win.show();win.focus();const point=await win.webContents.executeJavaScript(`(()=>{const r=document.querySelector(${JSON.stringify(selector)}).getBoundingClientRect();return{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)}})()`);
  win.webContents.sendInputEvent({type:'mouseDown',button:'left',clickCount:1,...point});win.webContents.sendInputEvent({type:'mouseUp',button:'left',clickCount:1,...point});
}
export async function runRecordingUI(windows:WindowManager,services:Services){
  const selectedFormat=process.argv.includes('--recording-mp4')?'mp4':'webm';
  const output=path.resolve('.runtime/recording-ui',new Date().toISOString().replace(/[:.]/g,'-'));await mkdir(output,{recursive:true});
  const evidence:{environment:unknown;cases:unknown[];failure?:string}={environment:{electron:process.versions.electron,windows:process.getSystemVersion(),videoSource:'isolated WebFrameMain controlled fixture (not desktop pixels)',fakeMicrophone:process.argv.includes('--use-fake-device-for-media-stream'),systemAudio:process.argv.includes('--recording-loopback-only')?'Windows loopback numeric-only probe':'isolated WebFrameMain 440Hz fixture, not desktop loopback',display:screen.getPrimaryDisplay().bounds,scaleFactor:screen.getPrimaryDisplay().scaleFactor},cases:[]};
  const home=await windows.show('home');const display=screen.getPrimaryDisplay(),area=display.workArea;
  const fixture=new BrowserWindow({x:area.x+30,y:area.y+30,width:560,height:380,frame:false,show:false,alwaysOnTop:true,resizable:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'recording-ui-fixture'}});
  await fixture.loadURL(`data:text/html,${encodeURIComponent(`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';script-src 'unsafe-inline';style-src 'unsafe-inline'"><style>body{margin:0}canvas{display:block}</style><canvas></canvas><script>
  const c=document.querySelector('canvas'),ctx=c.getContext('2d'),dpr=devicePixelRatio;c.width=innerWidth*dpr;c.height=innerHeight*dpr;c.style.width=innerWidth+'px';c.style.height=innerHeight+'px';ctx.scale(dpr,dpr);window.phase='before';
  window.audioContext=new AudioContext({sampleRate:48000});window.osc=audioContext.createOscillator();window.gain=audioContext.createGain();gain.gain.value=0;osc.frequency.value=440;osc.connect(gain).connect(audioContext.destination);osc.start();
  function draw(){ctx.fillStyle='#555';ctx.fillRect(0,0,innerWidth,innerHeight);ctx.save();ctx.translate(40,60);ctx.fillStyle=phase==='paused'?'#ff00ff':phase==='after'?'#2255dd':'#22aa55';ctx.fillRect(0,0,400,240);
  for(const[x,y,color]of [[0,0,'#ee2222'],[380,0,'#22dd22'],[0,220,'#2233ee'],[380,220,'#dddd22']]){ctx.fillStyle=color;ctx.fillRect(x,y,20,20);}
  const n=Math.floor(performance.now()/100)%256;for(let i=0;i<8;i++){ctx.fillStyle=(n>>i)&1?'white':'black';ctx.fillRect(20+i*20,200,14,14);}ctx.restore();requestAnimationFrame(draw);}draw();</script>`)}`);
  fixture.showInactive();await fixture.webContents.executeJavaScript('audioContext.resume()',true);services.setAudioFrame(fixture.webContents.mainFrame);
  const bounds=fixture.getContentBounds(),rect={x:bounds.x-display.bounds.x+40,y:bounds.y-display.bounds.y+60,width:400,height:240};
  const viewport=await fixture.webContents.executeJavaScript('({width:innerWidth,height:innerHeight})');services.setVideoTarget({displayId:String(display.id),displayBounds:{x:0,y:0,...viewport},scaleFactor:display.scaleFactor,rect:{x:40,y:60,width:400,height:240}});
  fixture.hide();
  async function selectRange(capture:BrowserWindow){
    await capture.webContents.executeJavaScript(`(()=>{Element.prototype.setPointerCapture=function(){};Element.prototype.hasPointerCapture=function(){return false};const e=document.querySelector('.capture'),r=${JSON.stringify(rect)};for(const[type,x,y]of [['pointerdown',r.x,r.y],['pointermove',r.x+r.width,r.y+r.height],['pointerup',r.x+r.width,r.y+r.height]])e.dispatchEvent(new PointerEvent(type,{bubbles:true,pointerId:7,button:0,clientX:x,clientY:y}));})()`);
  }
  async function enter(systemAudio=false,microphone=false,prepareOnly=false){
    await fixture.webContents.executeJavaScript(`phase='before';osc.frequency.value=440;gain.gain.value=${systemAudio?.12:0}`);
    await home.webContents.executeJavaScript('window.screenAI.startCapture()');const capture=windows.get('capture')!;
    await until(()=>capture.webContents.executeJavaScript(`!!document.querySelector('[data-mode="record"]')`).catch(()=>false),'capture ready');
    await click(capture,'[data-mode="record"]');
    await selectRange(capture);
    await until(()=>!!services.host()?.window&&!services.host()!.window!.isDestroyed(),'media controls');
    const host=services.host()!,win=host.window!;
    await until(()=>win.webContents.executeJavaScript(`!!document.querySelector('[data-record-format]')&&!document.querySelector('[data-record-format]').disabled`).catch(()=>false),'preparation ready');
    await win.webContents.executeJavaScript(`(()=>{const e=document.querySelector('[data-record-format]');e.value=${JSON.stringify(selectedFormat)};e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
    if(systemAudio)await click(win,'[data-record-audio="system"]');if(microphone){await click(win,'[data-record-audio="microphone"]');await until(()=>win.webContents.executeJavaScript(`!document.querySelector('#prepare').disabled`),'microphone ready');}
    if(prepareOnly)return{host,win,id:services.service.state!.id};
    await click(win,'#prepare',true);
    await until(()=>['countdown','recording','error'].includes(services.service.state?.status??''),'media preparation',20000);
    assert.notEqual(services.service.state?.status,'error',services.service.state?.error?.message);
    assert.equal(windows.getCaptures().length,0);
    await until(()=>services.service.state?.status==='recording','countdown',12000);assert.ok(win.isContentProtected());
    await until(()=>win.webContents.executeJavaScript(`document.body.dataset.phase==='recording'`).catch(()=>false),'recording controls state');
    const layout=await win.webContents.executeJavaScript(`Array.from(document.querySelector('#record-controls').children,e=>{const r=e.getBoundingClientRect();return{right:r.right,bottom:r.bottom}}).every(r=>r.right<=innerWidth&&r.bottom<=innerHeight)`);assert.equal(layout,true,'recording buttons must fit the control strip');return{host,win,id:services.service.state!.id};
  }
  async function dragToolbar(win:BrowserWindow,dx:number,dy:number){
    const before=win.getBounds();win.show();win.focus();win.webContents.sendInputEvent({type:'mouseDown',button:'left',clickCount:1,x:20,y:20,globalX:before.x+20,globalY:before.y+20});await delay(80);win.webContents.sendInputEvent({type:'mouseMove',modifiers:['leftbuttondown'],x:20+dx,y:20+dy,globalX:before.x+20+dx,globalY:before.y+20+dy});
    try{await until(()=>win.getBounds().x!==before.x||win.getBounds().y!==before.y,'toolbar drag');}finally{win.webContents.sendInputEvent({type:'mouseUp',button:'left',clickCount:1,x:20,y:20,globalX:before.x+20+dx,globalY:before.y+20+dy});}
    const after=win.getBounds();assert.ok(Math.abs(after.x-before.x-dx)<=1);assert.ok(Math.abs(after.y-before.y-dy)<=1);return after;
  }
  async function finish(win:BrowserWindow,name:string){
    await click(win,'[data-control="finish"]');await until(()=>services.service.state?.status==='ready','recording ready');
    await until(()=>!!services.result.get(),'result window');const result=services.result.get()!;
    try{await until(()=>result.webContents.executeJavaScript(`document.querySelector('video')?.readyState>=1`).catch(()=>false),'video metadata');}
    catch(error){console.error('RECORDING VIDEO DEBUG',await result.webContents.executeJavaScript(`(()=>{const v=document.querySelector('video');return{body:document.body.textContent,source:v?.currentSrc,ready:v?.readyState,error:v?.error?.message}})()`));throw error;}
    await result.webContents.executeJavaScript(`document.querySelector('video').play()`,true);
    try{await until(()=>result.webContents.executeJavaScript(`document.querySelector('video').currentTime>.1`),'preview advances',6000);}catch(error){console.error('PLAYBACK DEBUG',await result.webContents.executeJavaScript(`(()=>{const v=document.querySelector('video');return{time:v.currentTime,duration:v.duration,ready:v.readyState,paused:v.paused,error:v.error?.message}})()`));if(services.service.artifact)await writeFile(path.join(output,`playback-failure.${selectedFormat}`),await readFile(services.service.artifact.path));throw error;}await result.webContents.executeJavaScript(`document.querySelector('video').pause()`);
    const artifact=services.service.artifact!;const file=path.join(output,`${name}.${recordingFormat(artifact.mimeType).extension}`);assert.equal(recordingFormat(artifact.mimeType).extension,selectedFormat);services.setSave(async()=>file);await click(result,'[data-recording="save"]');
    await until(()=>!!services.service.state?.savedName,'save result');assert.equal((await stat(file)).size,artifact.bytes);
    return{result,file,artifact,state:services.service.state!};
  }
  async function decodeVideo(result:BrowserWindow,times:number[]){return result.webContents.executeJavaScript(`(async()=>{const v=document.querySelector('video'),canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;const ctx=canvas.getContext('2d'),samples=[];
    for(const t of ${JSON.stringify(times)}){await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('seek timeout')),7000);v.addEventListener('seeked',()=>{clearTimeout(timer);resolve();},{once:true});v.currentTime=t;});await new Promise(r=>setTimeout(r,60));ctx.drawImage(v,0,0);const px=(x,y)=>Array.from(ctx.getImageData(Math.round(x),Math.round(y),1,1).data).slice(0,3);let counter=0;for(let i=0;i<8;i++)if(px((27+i*20)*canvas.width/400,207*canvas.height/240)[0]>128)counter|=1<<i;samples.push({time:v.currentTime,counter,center:px(Math.floor(canvas.width/2),Math.floor(canvas.height/2)),corner:px(8,8)});}
    return{duration:v.duration,width:v.videoWidth,height:v.videoHeight,samples};})()`);}
  async function audioOf(file:string,windowsAt:number[]){
    const bytes=await readFile(file);assert.ok(bytes.length<16*1024*1024);
    return fixture.webContents.executeJavaScript(`(async()=>{const raw=Uint8Array.from(atob(${JSON.stringify(bytes.toString('base64'))}),c=>c.charCodeAt(0));const context=new AudioContext({sampleRate:48000});try{const decoded=await context.decodeAudioData(raw.buffer),data=decoded.getChannelData(0),rate=decoded.sampleRate;
    const samples=${JSON.stringify(windowsAt)}.map(time=>{const start=Math.floor(time*rate),n=Math.min(Math.floor(rate*.2),data.length-start);let energy=0;for(let i=0;i<n;i++)energy+=data[start+i]*data[start+i];
      const spectrum=Object.fromEntries([440,660,880].map(f=>{let re=0,im=0;for(let i=0;i<n;i++){re+=data[start+i]*Math.cos(2*Math.PI*f*i/rate);im+=data[start+i]*Math.sin(2*Math.PI*f*i/rate);}return[f,2*Math.hypot(re,im)/n];}));return{time,rms:Math.sqrt(energy/n),spectrum};});return{duration:decoded.duration,channels:decoded.numberOfChannels,sampleRate:rate,samples};}finally{await context.close();}})()`);
  }
  async function close(result:BrowserWindow){await click(result,'[data-recording="close"]');await until(()=>services.service.state?.status==='cancelled','result cleanup');assert.equal(services.result.get(),undefined);await fixture.webContents.executeJavaScript('gain.gain.value=0');}
  async function loopbackProbe(){
    console.log('RECORDING UI START Windows loopback numeric probe (no recording)');
    const probe=new AudioProbeHost(),controller=new AbortController();
    try{
      await fixture.webContents.executeJavaScript('gain.gain.value=.12;osc.frequency.value=440');fixture.webContents.setAudioMuted(false);
      const prepared=probe.prepare({id:randomUUID(),target:{displayId:String(display.id),displayBounds:display.bounds,scaleFactor:display.scaleFactor,rect},options:recordingOptionsSchema.parse({systemAudio:true,countdownMs:0}),ui:'experiment'},{chunk:async()=>{throw Error('Probe must never persist chunks');},failed:error=>{console.error('LOOPBACK PROBE',error);}},controller.signal);
      void prepared.catch(()=>{});await until(()=>!!probe.window&&!probe.window.isDestroyed(),'loopback window');await click(probe.window!,'#prepare',true);const media=await prepared;assert.equal(media.audio?.systemAvailable,true);await delay(1500);
      await probe.probeAudio();await delay(1000);const metrics=await probe.probeAudio();console.log('LOOPBACK METRICS',JSON.stringify(metrics));console.log('LOOPBACK DIAGNOSTICS',JSON.stringify({fixture:await fixture.webContents.executeJavaScript('({state:audioContext.state,rate:audioContext.sampleRate,volume:gain.gain.value})'),audible:fixture.webContents.isCurrentlyAudible(),muted:fixture.webContents.isAudioMuted(),tracks:await probe.window!.webContents.executeJavaScript(`document.querySelector('video').srcObject.getAudioTracks().map(t=>({state:t.readyState,muted:t.muted,enabled:t.enabled,settings:t.getSettings()}))`)}));assert.ok(metrics.rms>.001&&metrics.amplitude440>.001,JSON.stringify(metrics));evidence.cases.push({name:'windows-loopback-numeric-only',status:'passed',metrics,source:probe.evidence});
    }finally{await probe.dispose();await fixture.webContents.executeJavaScript('gain.gain.value=0');}
  }
  try{
    if(process.argv.includes('--recording-loopback-only')){await loopbackProbe();console.log('RECORDING LOOPBACK PASS');return;}
    if(process.argv.includes('--recording-microphone-probe')){
      const probe=await enter(false,true,true);await click(probe.win,'[data-menu="audio"]');
      const devices=await probe.win.webContents.executeJavaScript(`Array.from(document.querySelector('#microphone-device').options,o=>({id:o.value,label:o.text}))`);
      const chosen=devices.find((item:{id:string;label:string})=>item.id!=='default'&&/Senary/i.test(item.label))??devices.find((item:{id:string})=>item.id!=='default');
      assert.ok(chosen,'physical microphone must be enumerated');
      await probe.win.webContents.executeJavaScript(`(()=>{const e=document.querySelector('#microphone-device');e.value=${JSON.stringify(chosen.id)};e.dispatchEvent(new Event('change',{bubbles:true}));})()`);
      await until(()=>probe.win.webContents.executeJavaScript(`!document.querySelector('#prepare').disabled`),'physical microphone selected');
      const samples:number[]=[];for(let i=0;i<15;i++){samples.push(await probe.win.webContents.executeJavaScript(`document.querySelector('#microphone-meter').value`));await delay(100);}
      evidence.cases.push({name:'physical-microphone-selected-and-meter-no-recording',status:'passed',device:chosen.label,peak:Math.max(...samples),mediaStarted:services.service.state?.status!=='preparing'});assert.equal(services.service.state?.status,'preparing');
      console.log('RECORDING MICROPHONE PROBE PASS',JSON.stringify(evidence.cases));return;
    }
    console.log('RECORDING UI START compact preparation, drag and reselect');
    let prep=await enter(false,false,true);assert.ok(Math.abs(prep.win.getBounds().width-424)<=1);assert.ok(Math.abs(prep.win.getBounds().height-56)<=1);
    assert.equal(await prep.win.webContents.executeJavaScript(`document.body.textContent.includes('返回普通截图')`),false);
    await click(prep.win,'[data-menu="audio"]');await until(()=>prep.win.getBounds().height>100,'device panel expands');await click(prep.win,'[data-menu="audio"]');await until(()=>prep.win.getBounds().height<58,'panel collapses');
    const originalPosition=prep.win.getBounds();await prep.win.webContents.executeJavaScript(`window.recordingHost.layout(${JSON.stringify(prep.id)},{x:100000,y:-100000})`);const clamped=prep.win.getBounds(),clampArea=screen.getDisplayMatching(clamped).workArea;
    assert.ok(clamped.x>=clampArea.x&&clamped.y>=clampArea.y&&clamped.x+clamped.width<=clampArea.x+clampArea.width+1&&clamped.y+clamped.height<=clampArea.y+clampArea.height+1);await prep.win.webContents.executeJavaScript(`window.recordingHost.layout(${JSON.stringify(prep.id)},{x:${originalPosition.x},y:${originalPosition.y}})`);
    await writeFile(path.join(output,'preparation-controls.png'),(await prep.win.webContents.capturePage()).toPNG());
    await dragToolbar(prep.win,35,20);await click(prep.win,'[data-control="reselect"]');await until(()=>!!windows.get('capture'),'reselect capture');
    const reselect=windows.get('capture')!;await until(()=>reselect.webContents.executeJavaScript(`!!document.querySelector('.mode-toolbar [data-mode="record"][aria-pressed="true"]')`).catch(()=>false),'reselect stays recording');
    await selectRange(reselect);await until(()=>services.host()!==prep.host&&!!services.host()?.window,'new preparation host');await services.service.cancel();evidence.cases.push({name:'compact-prepare-drag-reselect',status:'passed'});
    console.log('RECORDING UI START explicit microphone device and meter');
    prep=await enter(false,true,true);await click(prep.win,'[data-menu="audio"]');
    await until(()=>prep.win.webContents.executeJavaScript(`Array.from(document.querySelector('#microphone-device').options).some(o=>o.value!=='default'&&/fake/i.test(o.text))`),'device labels');
    await prep.win.webContents.executeJavaScript(`(()=>{const select=document.querySelector('#microphone-device');select.value=Array.from(select.options).find(o=>o.value!=='default').value;select.dispatchEvent(new Event('change',{bubbles:true}));})()`);
    await until(()=>prep.win.webContents.executeJavaScript(`!document.querySelector('#prepare').disabled&&document.querySelector('#microphone-meter').value>.01`),'selected microphone meter');
    await writeFile(path.join(output,'microphone-settings.png'),(await prep.win.webContents.capturePage()).toPNG());
    assert.notEqual(prep.host.configuration().options.microphoneDeviceId,'default');await services.service.cancel();evidence.cases.push({name:'microphone-device-selection-local-meter',status:'passed'});
    console.log('RECORDING UI START 30s normal entry');
    let session=await enter();
    await assert.rejects(session.win.webContents.executeJavaScript(`window.recordingHost.configure(${JSON.stringify(session.id)},${JSON.stringify(recordingOptionsSchema.parse({}))})`),/不能更改/);
    const moved=await dragToolbar(session.win,25,15);assert.ok(Math.abs(session.win.getBounds().width-328)<=1);assert.ok(Math.abs(session.win.getBounds().height-56)<=1);
    await click(session.win,'[data-control="pause"]');await until(()=>services.service.state?.status==='paused','layout pause');assert.equal(session.win.getBounds().x,moved.x);assert.equal(session.win.getBounds().y,moved.y);await click(session.win,'[data-control="pause"]');await until(()=>services.service.state?.status==='recording','layout resume');
    await writeFile(path.join(output,'recording-controls.png'),(await session.win.webContents.capturePage()).toPNG());
    // Deliberately overlap the test ROI to check actual capture exclusion.
    session.win.setPosition(Math.round(bounds.x+60),Math.round(bounds.y+100));
    const quick=process.argv.includes('--recording-quick'),normalName=quick?'normal-1.5s-quick':'normal-30s';await delay(quick?1500:30000);let done=await finish(session.win,normalName);const normal=await decodeVideo(done.result,quick?[.2,.6,1]:[1,15,29]);
    assert.ok(normal.duration>=(quick?1:29)&&normal.duration<(quick?4:32));assert.ok(new Set(normal.samples.map((s:{counter:number})=>s.counter)).size>1,'fixture video must keep advancing');for(const sample of normal.samples){assert.ok(sample.center[1]>100&&sample.center[0]<70,'control strip must not replace fixture pixels');assert.ok(sample.corner[0]>180&&sample.corner[1]<80);}
    await delay(400);await writeFile(path.join(output,'result-preview.png'),(await done.result.webContents.capturePage()).toPNG());evidence.cases.push({name:normalName,status:'passed',video:normal,state:done.state,source:session.host.evidence});await close(done.result);
    if(quick){console.log('RECORDING QUICK UI PASS');return;}
    console.log('RECORDING UI START pause 5 seconds with mixed audio');
    session=await enter(true,true);await delay(2000);await click(session.win,'[data-control="pause"]');await until(()=>services.service.state?.status==='paused','pause ack');const pausedAt=services.service.state!.elapsedMs;
    await fixture.webContents.executeJavaScript(`phase='paused';osc.frequency.value=880`);await delay(5000);assert.equal(services.service.state!.elapsedMs,pausedAt);
    await fixture.webContents.executeJavaScript(`phase='after';osc.frequency.value=440`);await click(session.win,'[data-control="pause"]');await until(()=>services.service.state?.status==='recording','resume ack');await delay(2000);
    done=await finish(session.win,'pause-mixed');const paused=await decodeVideo(done.result,[.5,1.5,2.8,3.7]);assert.ok(paused.duration<5.2,`paused duration ${paused.duration}`);
    for(const s of paused.samples)assert.ok(!(s.center[0]>170&&s.center[2]>170&&s.center[1]<70),'paused magenta frame must be absent');
    for(const s of paused.samples.slice(2))assert.ok(s.center[2]>150&&s.center[1]<120,'resumed blue frames must be present');
    const pauseAudio=await audioOf(done.file,[.5,2.8]);assert.ok(pauseAudio.duration<5.3);for(const s of pauseAudio.samples)assert.ok(s.spectrum['880']<.003,'paused 880Hz sound must be absent');evidence.cases.push({name:'pause-5s-mixed-audio',status:'passed',video:paused,audio:pauseAudio,state:done.state});await close(done.result);
    for(const[name,system,microphone]of[['system',true,false],['microphone',false,true],['mixed',true,true]]as const){
      console.log(`RECORDING UI START audio ${name}`);session=await enter(system,microphone);
      if(name==='mixed'){
        await delay(1000);await click(session.win,'[data-audio="system"]');await delay(1000);await click(session.win,'[data-audio="microphone"]');await delay(1000);await click(session.win,'[data-audio="system"]');await delay(1000);
      }else await delay(2500);
      done=await finish(session.win,`audio-${name}`);const audio=await audioOf(done.file,name==='mixed'?[.4,1.4,2.4,3.4]:[.7,1.7]);
      console.log(`RECORDING AUDIO ${name} ${JSON.stringify(audio)}`);
      if(name==='system')assert.ok(audio.samples[0].spectrum['440']>.01);
      if(name==='microphone')assert.ok(audio.samples[0].spectrum['660']>.005);
      if(name==='mixed'){assert.ok(audio.samples[0].spectrum['440']>.005&&audio.samples[0].spectrum['660']>.003);assert.ok(audio.samples[2].rms<.005,'both sources muted must be silent');assert.ok(audio.samples[3].spectrum['440']>.01);}
      evidence.cases.push({name:`audio-${name}`,status:'passed',audio,state:done.state});await close(done.result);
    }
    console.log('RECORDING UI START save retry and source interruption');
    session=await enter();await delay(1200);
    await session.win.webContents.executeJavaScript(`document.querySelector('video').srcObject.getVideoTracks()[0].dispatchEvent(new Event('ended'))`);
    await until(()=>services.service.state?.status==='ready','source interrupted finish');const result=services.result.get()!;await until(()=>result.webContents.executeJavaScript(`!!document.querySelector('[data-recording="save"]')`).catch(()=>false),'result save');
    services.setSave(async()=>undefined);await click(result,'[data-recording="save"]');await delay(100);assert.equal(services.service.state?.status,'ready');
    services.setSave(async()=>path.join(output,'missing-folder',`out.${selectedFormat}`));await click(result,'[data-recording="save"]');await until(()=>services.service.state?.error?.code==='save-failed','save error');assert.ok(services.service.artifact);assert.match(services.service.state!.error!.message,/ENOENT/);
    const retryName=`retried.${selectedFormat}`,retry=path.join(output,retryName);await writeFile(retry,'prior target');services.setSave(async()=>retry);await click(result,'[data-recording="save"]');await until(()=>services.service.state?.savedName===retryName,'save retry');
    assert.ok((await stat(retry)).size>1000);assert.ok(services.service.state?.message?.includes('保存'));evidence.cases.push({name:'source-ended-save-cancel-failure-retry',status:'passed'});await close(result);
    console.log('RECORDING UI START microphone permission rejection');
    services.denyMicrophone(true);prep=await enter(false,false,true);await click(prep.win,'[data-audio="microphone"]');await until(()=>prep.win.webContents.executeJavaScript(`document.querySelector('#microphone-hint').textContent.includes('权限被拒绝')`),'microphone permission hint');assert.equal(services.service.state?.status,'preparing');
    assert.equal(await prep.win.webContents.executeJavaScript(`document.querySelector('#prepare').disabled`),true);await click(prep.win,'[data-audio="microphone"]');await click(prep.win,'#prepare',true);await until(()=>services.service.state?.status==='recording','continue without microphone');await delay(1200);const recovered=await finish(prep.win,'microphone-denied-recovered');await close(recovered.result);services.denyMicrophone(false);evidence.cases.push({name:'microphone-permission-denied-recovery',status:'passed'});
    assert.equal((await readdir(output)).some(file=>file.endsWith('.tmp')),false);
    console.log('RECORDING UI PASS: normal entry, 30s, capture exclusion, pause, four audio choices, mute, source end, preview/range, save and retry.');
  }catch(error){evidence.failure=error instanceof Error?error.stack:String(error);throw error;}
  finally{await services.service.cancel();services.result.close();services.setAudioFrame(undefined);services.setVideoTarget(undefined);services.denyMicrophone(false);fixture.destroy();windows.disposeCaptures();windows.close('home');await writeFile(path.join(output,'report.json'),JSON.stringify(evidence,null,2));console.log(`RECORDING UI REPORT ${output}`);}
}
