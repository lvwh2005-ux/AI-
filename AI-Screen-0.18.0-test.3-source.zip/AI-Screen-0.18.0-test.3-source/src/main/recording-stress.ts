// Dedicated controlled-fixture test. Never writes pixels outside this window.
import {app,BrowserWindow,screen,session} from 'electron';
import assert from 'node:assert/strict';
import {mkdir,writeFile,copyFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {RecordingService} from './services/recording/recording-service';
import {ElectronMediaHost} from './services/recording/media-host';
import {LocalVideoFileSink} from './services/recording/video-file-sink';
import {inspectRecordingMP4} from './services/recording/mp4-info';
import {recordingOptionsSchema,type RecordingTarget} from '../shared/recording/contracts';

const root=path.resolve('.runtime/recording-stress'),output=path.join(root,new Date().toISOString().replace(/[:.]/g,'-'));
app.setPath('userData',path.join(root,'isolated-user-data'));app.on('window-all-closed',()=>{});
const report:{environment?:unknown;cases:any[];failure?:string}={cases:[]};
async function until(predicate:()=>boolean|Promise<boolean>,label:string,ms=20000){const end=performance.now()+ms;while(!await predicate()){if(performance.now()>end)throw Error(`Recording stress timeout: ${label}`);await delay(40);}}
function metrics(){const processes=app.getAppMetrics().map(p=>({pid:p.pid,type:p.type,cpu:p.cpu.percentCPUUsage,workingSetKiB:p.memory.workingSetSize,privateKiB:p.memory.privateBytes??0}));return{at:Date.now(),workingSetMiB:processes.reduce((a,p)=>a+p.workingSetKiB,0)/1024,privateMiB:processes.reduce((a,p)=>a+p.privateKiB,0)/1024,cpu:processes.reduce((a,p)=>a+p.cpu,0),processes};}
const fixtureHTML=`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';script-src 'unsafe-inline';style-src 'unsafe-inline'"><style>body{margin:0;overflow:hidden}canvas{display:block}</style><canvas></canvas><script>
const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d'),dpr=devicePixelRatio;canvas.width=Math.round(innerWidth*dpr);canvas.height=Math.round(innerHeight*dpr);canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px';ctx.scale(dpr,dpr);window.roi={width:400,height:240};window.scene='animation';
window.ac=new AudioContext({sampleRate:48000});const osc=ac.createOscillator(),gain=ac.createGain();gain.gain.value=.12;osc.frequency.value=440;osc.connect(gain).connect(ac.destination);osc.start();
function draw(){const r=roi,t=performance.now(),s=scene==='cycle'?['static','scroll','animation'][Math.floor(t/10000)%3]:scene;ctx.fillStyle='#f6f7f9';ctx.fillRect(0,0,innerWidth,innerHeight);ctx.fillStyle='#22aa55';ctx.fillRect(0,0,r.width,r.height);
if(s==='static'||s==='scroll'){ctx.fillStyle='#17202a';ctx.font='18px Segoe UI';for(let i=0;i<Math.ceil(r.height/28)+2;i++){const y=s==='scroll'?(i*28-t*.08)%(r.height+28):i*28;ctx.fillText('AI Screen controlled text line '+i+' · 0123456789',36,y);}}
if(s==='animation'){ctx.fillStyle='hsl('+t/30%360+',70%,50%)';ctx.fillRect(40,45,r.width-80,r.height-100);ctx.fillStyle='white';ctx.fillRect(45+(t/10)%(Math.max(1,r.width-130)),70,45,80);}
for(const[x,y,c]of [[0,0,'#ee2222'],[r.width-20,0,'#22dd22'],[0,r.height-20,'#2233ee'],[r.width-20,r.height-20,'#dddd22']]){ctx.fillStyle=c;ctx.fillRect(x,y,20,20);}
const n=Math.floor(t/100)%65536;for(let i=0;i<16;i++){ctx.fillStyle=(n>>i)&1?'white':'black';ctx.fillRect(32+i*12,r.height-34,8,12);}requestAnimationFrame(draw);}draw();</script>`;
async function run(){
  await mkdir(output,{recursive:true});session.defaultSession.setPermissionCheckHandler(()=>false);session.defaultSession.setPermissionRequestHandler((_w,_p,c)=>c(false));
  const display=screen.getPrimaryDisplay(),work=display.workArea;
  report.environment={electron:process.versions.electron,windows:process.getSystemVersion(),display:display.bounds,workArea:work,scaleFactor:display.scaleFactor,video:'isolated WebFrameMain fixture, independent of desktop occlusion',fakeMicrophone:true,audio:'isolated 440Hz WebFrameMain plus 660Hz fake microphone',gpu:app.getGPUFeatureStatus()};
  const fixture=new BrowserWindow({x:work.x,y:work.y,width:work.width,height:work.height,frame:false,show:false,alwaysOnTop:true,resizable:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'recording-stress-fixture'}});
  let current:RecordingService|undefined,sourceWidth=Math.round(display.bounds.width*display.scaleFactor),sourceHeight=Math.round(display.bounds.height*display.scaleFactor);
  try{
    await fixture.loadURL(`data:text/html,${encodeURIComponent(fixtureHTML)}`);fixture.showInactive();await fixture.webContents.executeJavaScript('ac.resume()',true);
    const physicalBounds=fixture.getContentBounds();assert.equal(physicalBounds.x,display.bounds.x);assert.equal(physicalBounds.y,display.bounds.y);
    const viewport=await fixture.webContents.executeJavaScript('({width:innerWidth,height:innerHeight})'),bounds={...physicalBounds,...viewport},virtualDisplay={...display.bounds,...viewport};sourceWidth=Math.round(viewport.width*display.scaleFactor);sourceHeight=Math.round(viewport.height*display.scaleFactor);fixture.hide();
    async function record(name:string,width:number,height:number,ms:number,scene:string,audio=false){
      const rect={x:0,y:0,width:(width-.01)*virtualDisplay.width/sourceWidth,height:(height-.01)*virtualDisplay.height/sourceHeight};assert.ok(rect.width<=bounds.width&&rect.height<=bounds.height,'Fixture must fully cover the recording region');
      await fixture.webContents.executeJavaScript(`roi=${JSON.stringify({width:rect.width,height:rect.height})};scene=${JSON.stringify(scene)}`);await delay(100);
      const target:RecordingTarget={displayId:String(display.id),displayBounds:virtualDisplay,scaleFactor:display.scaleFactor,rect},host=new ElectronMediaHost({testAudioFrame:()=>fixture.webContents.mainFrame,testVideoFrame:()=>fixture.webContents.mainFrame});
      const service=current=new RecordingService({backend:()=>host,sink:(id,o)=>LocalVideoFileSink.create(path.join(output,'temporary'),id,o.mimeType),target:()=>target},recordingOptionsSchema.parse({countdownMs:0,mimeType:'video/mp4;codecs=avc1.42001E',systemAudio:audio,microphone:audio}));
      const samples:ReturnType<typeof metrics>[]=[];let timer:ReturnType<typeof setInterval>|undefined;
      try{
        console.log(`STRESS START ${name} ${width}x${height} ${ms/1000}s`);const starting=service.start({displayId:target.displayId,rect,signal:new AbortController().signal});void starting.catch(()=>{});
        await until(()=>!!host.window&&!host.window.isDestroyed()&&host.window.webContents.executeJavaScript(`!!document.querySelector('#prepare')&&!document.querySelector('#prepare').disabled`).catch(()=>false),'media host');
        const win=host.window!;win.show();win.focus();const point=await win.webContents.executeJavaScript(`(()=>{const r=document.querySelector('#prepare').getBoundingClientRect();return{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)}})()`);win.webContents.sendInputEvent({type:'mouseDown',button:'left',clickCount:1,...point});win.webContents.sendInputEvent({type:'mouseUp',button:'left',clickCount:1,...point});await starting;win.hide();
        const media=service.state!.media!;sourceWidth=media.sourceWidth;sourceHeight=media.sourceHeight;assert.equal(media.width,width);assert.equal(media.height,height);
        const start=performance.now();samples.push(metrics());timer=setInterval(()=>{const m=metrics();samples.push(m);console.log(`STRESS PROGRESS ${name} ${Math.round((performance.now()-start)/1000)}s private=${Math.round(m.privateMiB)}MiB rss=${Math.round(m.workingSetMiB)}MiB cpu=${m.cpu.toFixed(1)}%`);},30000);
        for(let elapsed=0;elapsed<ms;){await delay(Math.min(1000,ms-elapsed));elapsed=performance.now()-start;assert.equal(service.state?.status,'recording',service.state?.error?.message);}
        clearInterval(timer);timer=undefined;samples.push(metrics());const stopAt=performance.now();await service.command(service.state!.id,'finish');const stopMs=performance.now()-stopAt,artifact=service.artifact!,state=service.state!;
        const file=path.join(output,`${name}.mp4`);await copyFile(artifact.path,file);const container=await inspectRecordingMP4(file),video=container.tracks.find(t=>t.kind==='vide')!,sound=container.tracks.find(t=>t.kind==='soun');
        const evidence:any={name,status:'checking',media,durationMs:artifact.durationMs,bytes:artifact.bytes,stopMs,stats:state.stats,container,resources:samples};report.cases.push(evidence);
        assert.equal(video.codec,'avc1');assert.ok(video.samples>0);assert.ok(Math.abs(video.durationSeconds-ms/1000)<1.5);if(audio){assert.equal(sound?.codec,'mp4a');assert.ok(Math.abs(sound!.endSeconds-video.endSeconds)<.25,'audio/video tail drift');}
        const decoded=await inspect(file,[.2,ms/2000,ms/1000-.2]);assert.ok(new Set(decoded.samples.map((s:any)=>s.counter)).size>1);assert.equal(decoded.width,width);assert.equal(decoded.height,height);
        evidence.decoded=decoded;assert.ok(video.framesPerSecond>=27,`${name}: encoded frame rate ${video.framesPerSecond}`);
        for(const sample of decoded.samples.slice(1)){const expected=(sample.time-decoded.samples[0].time)*10,actual=(sample.counter-decoded.samples[0].counter+65536)%65536;assert.ok(Math.abs(actual-expected)<10,'fixture counter must track media time');}
        for(const s of decoded.samples)for(let i=0;i<4;i++)for(let c=0;c<3;c++)assert.ok(Math.abs(s.corners[i][c]-[[238,34,34],[34,221,34],[34,51,238],[221,221,34]][i][c])<50,'ROI corner changed');
        let memoryGrowthMiB:number|undefined;if(ms>=1800000&&samples.length>=10){const stable=samples.filter(s=>s.at-samples[0].at>=90000),first=stable.slice(0,5),last=stable.slice(-5),mean=(a:typeof stable)=>a.reduce((n,s)=>n+s.privateMiB,0)/a.length;memoryGrowthMiB=mean(last)-mean(first);assert.ok(memoryGrowthMiB<192,`private memory grew ${memoryGrowthMiB} MiB after warmup`);}
        evidence.status='passed';evidence.memoryGrowthMiB=memoryGrowthMiB;await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));console.log(`STRESS PASS ${name} actual=${video.framesPerSecond.toFixed(2)}fps stop=${stopMs.toFixed(1)}ms bytes=${artifact.bytes}`);
      }finally{if(timer)clearInterval(timer);await service.cancel();current=undefined;assert.equal(service.active,false);assert.equal(BrowserWindow.getAllWindows().length,1,'only fixture should remain after cleanup');assert.equal((await readdir(path.join(output,'temporary'))).length,0,'session temporary output must be deleted');}
    }
    for(let i=1;i<=10;i++)await record(`repeat-${i}`,600,360,1500,'animation',i%2===0);
    for(const scene of ['static','scroll','animation'])await record(`1080p-${scene}`,1920,1080,10000,scene,true);
    const maxWidth=Math.floor(sourceWidth/2)*2,maxHeight=Math.floor(sourceHeight/2)*2;
    await record('large-region',maxWidth,maxHeight,10000,'animation',false);
    if(!process.argv.includes('--recording-stress-quick'))await record('1080p-30min',1920,1080,30*60*1000,'cycle',true);
    console.log('RECORDING STRESS PASS');
  }finally{await current?.cancel();fixture.destroy();}
}
async function inspect(file:string,times:number[]){
  const player=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'recording-stress-playback'}});
  try{const page=path.join(path.dirname(file),'playback.html');await writeFile(page,`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';media-src 'self'"><video muted preload="metadata" src="./${path.basename(file)}"></video>`);await player.loadFile(page);return await player.webContents.executeJavaScript(`(async()=>{const v=document.querySelector('video');const wait=(event,action)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error(event+' timeout')),12000);v.addEventListener(event,()=>{clearTimeout(timer);resolve();},{once:true});v.addEventListener('error',()=>reject(Error('decode failed')),{once:true});action?.();});if(v.readyState<1)await wait('loadedmetadata');const canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;const ctx=canvas.getContext('2d'),samples=[];for(const t of ${JSON.stringify(times)}){await wait('seeked',()=>{v.currentTime=t;});await new Promise(r=>setTimeout(r,80));ctx.drawImage(v,0,0);const pixel=(x,y)=>Array.from(ctx.getImageData(Math.round(x),Math.round(y),1,1).data).slice(0,3),corners=[pixel(8,8),pixel(canvas.width-9,8),pixel(8,canvas.height-9),pixel(canvas.width-9,canvas.height-9)];let counter=0;for(let i=0;i<16;i++)if(pixel((36+i*12)*${screen.getPrimaryDisplay().scaleFactor},canvas.height-28*${screen.getPrimaryDisplay().scaleFactor})[0]>128)counter|=1<<i;samples.push({time:v.currentTime,counter,corners});}return{width:v.videoWidth,height:v.videoHeight,duration:v.duration,samples};})()`);}finally{player.destroy();}
}
void app.whenReady().then(run).then(async()=>{await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));console.log(`RECORDING STRESS REPORT ${output}`);app.exit(0);}).catch(async error=>{report.failure=error instanceof Error?error.stack:String(error);console.error(error);await mkdir(output,{recursive:true});await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));console.log(`RECORDING STRESS REPORT ${output}`);app.exit(1);});
