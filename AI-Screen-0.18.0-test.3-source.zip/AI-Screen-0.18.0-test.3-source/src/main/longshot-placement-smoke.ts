import assert from 'node:assert/strict';
import type { Rect } from '../shared/contracts';
import { intersects } from '../shared/scroll-capture/layout';
import type { LongshotWindow } from './longshot-window';

/** Layout-only native evidence. Sampling is suspended by the caller; no global
 * input, desktop images, clipboard writes or configuration changes occur here. */
export async function verifyPreviewPlacement(window: LongshotWindow, area: Rect, original: Rect, publish: () => void) {
  const sleep = () => new Promise<void>(resolve => setTimeout(resolve, 30));
  const rect = (x: number, y: number, width: number, height: number) => ({
    x: area.x + Math.round(area.width * x), y: area.y + Math.round(area.height * y),
    width: Math.round(area.width * width), height: Math.round(area.height * height),
  });
  const cases = [
    { side: 'right', target: rect(.02, .18, .42, .58) },
    { side: 'left', target: rect(.48, .18, .50, .58) },
    { side: 'top', target: rect(.02, .50, .96, .46) },
    { side: 'bottom', target: rect(.02, .02, .96, .46) },
    { side: 'inset', target: { ...area } },
  ];
  const within = (bounds: Rect) => {
    assert.ok(bounds.x >= area.x && bounds.y >= area.y);
    assert.ok(bounds.x + bounds.width <= area.x + area.width && bounds.y + bounds.height <= area.y + area.height, JSON.stringify({ bounds, area }));
  };
  try {
    for (const { side, target } of cases) {
      await window.showControls(target);
      const preview = window.thumbnailWindow()!, bounds = preview.getBounds(), toolbar = window.get()!.getBounds();
      within(bounds); assert.equal(intersects(bounds, toolbar), false, `${side}: controls must remain reachable`);
      assert.ok(preview.isVisible() && preview.isContentProtected() && !preview.isFocusable());
      if (side === 'right') assert.ok(bounds.x >= target.x + target.width);
      else if (side === 'left') assert.ok(bounds.x + bounds.width <= target.x);
      else if (side === 'top') assert.ok(bounds.y + bounds.height <= target.y);
      else if (side === 'bottom') assert.ok(bounds.y >= target.y + target.height);
      else assert.equal(intersects(bounds, { x: target.x + target.width * .3, y: target.y + target.height * .3, width: target.width * .4, height: target.height * .4 }), false, JSON.stringify({ bounds, target }));
      publish(); await sleep(); assert.deepEqual(preview.getBounds(), bounds, 'State publication must not reset native placement');
    }
    await window.showControls(cases[0].target);
    const preview = window.thumbnailWindow()!, before = preview.getBounds(), toolbar = window.get()!;
    const control = toolbar.getBounds();
    toolbar.setBounds({ ...control, x: Math.min(before.x, area.x + area.width - control.width), y: before.y + Math.floor(before.height / 2) });
    const end = Date.now() + 3000;
    while (intersects(preview.getBounds(), toolbar.getBounds()) && Date.now() < end) await sleep();
    assert.equal(intersects(preview.getBounds(), toolbar.getBounds()), false, 'Moving the actual toolbar must trigger preview avoidance');
    assert.notDeepEqual(preview.getBounds(), before); within(preview.getBounds());
    console.log('LONGSHOT PLACEMENT PASS: real protected non-focusable windows fit right/left/top/bottom/full-selection cases, remain on the chosen monitor, preserve scrolling centre, avoid a moved toolbar, and do not move on state publication.');
  } finally { await window.showControls(original); }
}
