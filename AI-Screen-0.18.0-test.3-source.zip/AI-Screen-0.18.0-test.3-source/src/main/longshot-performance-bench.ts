// CPU pipeline benchmark. Native capture and user applications are separately measured.
import {performance} from 'node:perf_hooks';
import {writeFile,mkdir} from 'node:fs/promises';
import {ScrollCaptureEngine} from '../shared/scroll-capture/engine';
import {StageProfiler,type ProfileSpan} from '../shared/scroll-capture/profiler';
import type {BitmapFrame} from '../shared/scroll-capture/types';
const dimensions=[[400,400],[800,400],[1200,400],[1600,400],[400,800],[800,800],[1200,800],[1600,800],[800,1000],[1200,1000],[1600,1000],[400,500],[1500,900]];
function scene(width:number,height:number,offset:number):BitmapFrame{
  const data=new Uint8Array(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    let n=Math.imul(y+offset+17,1597334677)^Math.imul(x+7,0x119de1f3);n=Math.imul(n^(n>>>13),1597334677);
    const at=(y*width+x)*4;data[at]=n&255;data[at+1]=n>>>8&255;data[at+2]=n>>>16&255;data[at+3]=255;
  }return{width,height,data};
}
const percentile=(values:number[],p:number)=>[...values].sort((a,b)=>a-b)[Math.max(0,Math.ceil(values.length*p)-1)];
async function run(){
  const output=process.argv[2];if(!output)throw new Error('Specify benchmark report path');
  const results=[];
  for(const [width,height] of dimensions){
    const frames=Array.from({length:17},(_,i)=>scene(width,height,i*120));
    const samples:ProfileSpan[][]=[],latencies:number[]=[],rss:number[]=[];let pixelCorrect=true,accepted=0;
    // Warm the same functions before collecting two independent sessions.
    const warm=new ScrollCaptureEngine();for(const frame of frames.slice(0,4))warm.push(frame);warm.clear();
    const cpuStart=process.cpuUsage(),started=performance.now();
    for(let repeat=0;repeat<2;repeat++){
      const spans:ProfileSpan[]=[],engine=new ScrollCaptureEngine({profiler:new StageProfiler(span=>spans.push(span))});engine.push(frames[0]);
      for(const frame of frames.slice(1)){
        spans.length=0;const start=performance.now(),result=engine.push(frame);latencies.push(performance.now()-start);
        if(result.kind==='appended'&&result.viewportDelta===120)accepted++;else pixelCorrect=false;
        samples.push([...spans]);rss.push(process.memoryUsage().rss);
      }
      const expected=scene(width,height+16*120,0),actual=engine.bitmap();
      pixelCorrect&&=actual.width===expected.width&&actual.height===expected.height&&Buffer.from(actual.data).equals(Buffer.from(expected.data));engine.clear();
    }
    const wall=performance.now()-started,cpu=process.cpuUsage(cpuStart);
    const stages=Object.fromEntries([...new Set(samples.flatMap(sample=>sample.map(span=>span.stage)))].map(stage=>{
      const ms=samples.map(sample=>sample.filter(span=>span.stage===stage).reduce((sum,span)=>sum+span.durationMs,0));
      return[stage,{p50Ms:percentile(ms,.5),p95Ms:percentile(ms,.95),maxMs:Math.max(...ms)}];
    }));
    results.push({width,height,pixels:width*height,transitions:32,accepted,pixelCorrect,
      analysisBudgetPeak:Object.fromEntries(['samples','probes','verifications','matches','exhausted'].map(key=>[key,Math.max(0,...samples.flatMap(sample=>sample.filter(span=>span.stage==='frame-analysis-budget').map(span=>span.metrics?.[key]??0)))])),
      processingLatency:{p50Ms:percentile(latencies,.5),p95Ms:percentile(latencies,.95)},
      processingOnlyNewRowsPerSecond:32*120/(latencies.reduce((a,b)=>a+b,0)/1000),stages,
      mainProcessCpuMs:(cpu.user+cpu.system)/1000,wallIncludingOutputTruthMs:wall,observedRssMaxBytes:Math.max(...rss)});
    console.log(JSON.stringify(results.at(-1),(_,value)=>typeof value==='number'?Math.round(value*100)/100:value));
    if(!pixelCorrect)throw new Error(`Pixel validation failed at ${width}x${height}`);
  }
  await mkdir('.runtime',{recursive:true});
  await writeFile(output,JSON.stringify({recordedAt:new Date().toISOString(),node:process.versions.node,
    conditions:{mode:'synthetic-cpu',nativeCapture:false,scrollInput:false,preview:false,realApps:false,
      note:'Processing-only rows/sec is not measured page scrolling speed; RSS includes generated input corpus and runtime heap.'},results},null,2));
}
run().catch(error=>{console.error(error);process.exitCode=1;});
