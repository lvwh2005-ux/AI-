import {BrowserWindow,screen,session,protocol}from 'electron';
import path from 'node:path';
import type{RecordingArtifact,RecordingState,RecordingTarget}from '../shared/recording/contracts';
import {recordingVideoResponse}from './services/recording/video-response';
import{recordingFormat}from'../shared/recording/format';

// Executed before app.ready. Each result session serves only its current artifact.
protocol.registerSchemesAsPrivileged([{scheme:'recording-video',privileges:{standard:true,secure:true,stream:true,supportFetchAPI:true,corsEnabled:true}}]);
export interface RecordingView{state:RecordingState;videoURL?:string}
export class RecordingWindow{
  private win?:BrowserWindow;private border?:BrowserWindow;private state?:RecordingState;private videoURL?:string;private opening?:Promise<void>;
  constructor(private deps:{artifact():RecordingArtifact|undefined;closed():void}){}
  get(){return this.win&&!this.win.isDestroyed()?this.win:undefined;}
  roleOf(id:number){return this.get()?.webContents.id===id?'recording' as const:undefined;}
  view():RecordingView|undefined{return this.state?{state:structuredClone(this.state),videoURL:this.videoURL}:undefined;}
  async showBorder(target:RecordingTarget){
    this.closeBorder();const rect=target.rect,b=target.displayBounds;
    const win=this.border=new BrowserWindow({x:Math.floor(b.x+rect.x)-2,y:Math.floor(b.y+rect.y)-2,width:Math.ceil(rect.width)+4,height:Math.ceil(rect.height)+4,transparent:true,frame:false,show:false,alwaysOnTop:true,skipTaskbar:true,focusable:false,resizable:false,movable:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
    win.setContentProtection(true);win.setIgnoreMouseEvents(true);
    const size=win.getBounds();win.setShape([{x:0,y:0,width:size.width,height:2},{x:0,y:size.height-2,width:size.width,height:2},{x:0,y:2,width:2,height:size.height-4},{x:size.width-2,y:2,width:2,height:size.height-4}]);
    await win.loadURL('data:text/html,<meta http-equiv="Content-Security-Policy" content="default-src %27none%27;style-src %27unsafe-inline%27"><style>html{box-sizing:border-box;border:2px solid %23ed4b52;width:100%;height:100%;background:transparent}</style>');
    if(this.border===win&&!win.isDestroyed())win.showInactive();
  }
  closeBorder(){const win=this.border;this.border=undefined;if(win&&!win.isDestroyed())win.destroy();}
  publish(state:RecordingState){
    this.state=structuredClone(state);
    if(['ready','error','cancelled'].includes(state.status))this.closeBorder();
    if(state.status==='cancelled'){this.close();return;}
    if(state.status==='ready'||state.status==='error')void this.ensure().catch(()=>{});
    this.get()?.webContents.send('recording:changed',this.view());
  }
  private async ensure(){
    if(this.opening)return this.opening;if(this.get())return;
    const state=this.state;if(!state)return;
    this.opening=(async()=>{
      const ses=session.fromPartition(`recording-result-${state.id}`,{cache:false});
      this.videoURL=`recording-video://${state.id}/current.${recordingFormat(state.media?.mimeType??'video/mp4').extension}`;
      ses.protocol.handle('recording-video',request=>{const response=recordingVideoResponse(request,this.state?.id===state.id?this.deps.artifact():undefined,this.videoURL!);if(process.argv.includes('--recording-only'))console.log('RECORDING VIDEO REQUEST',request.url,request.headers.get('Range'),response.status);return response;});
      ses.setPermissionCheckHandler(()=>false);ses.setPermissionRequestHandler((_c,_p,callback)=>callback(false));
      const area=screen.getPrimaryDisplay().workArea,width=Math.min(700,area.width),height=Math.min(560,area.height);
      const win=this.win=new BrowserWindow({width,height,minWidth:Math.min(440,width),minHeight:Math.min(380,height),show:false,title:'AI Screen · 录像预览',autoHideMenuBar:true,backgroundColor:'#f6f8fc',webPreferences:{preload:path.join(__dirname,'preload.cjs'),session:ses,sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true}});
      if(process.argv.includes('--recording-only'))win.webContents.on('console-message',details=>{if(details.level==='error')console.error('RECORDING RESULT RENDERER',details.message);});
      win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',event=>event.preventDefault());
      win.on('close',event=>{if(this.win===win){event.preventDefault();this.deps.closed();}});
      win.on('closed',()=>{if(this.win===win){this.win=undefined;this.deps.closed();}});
      const devURL=process.defaultApp?process.env.AI_SCREEN_DEV_URL:undefined;
      if(devURL==='http://127.0.0.1:5173')await win.loadURL(`${devURL}/#recording`);else await win.loadFile(path.join(__dirname,'../renderer/index.html'),{hash:'recording'});
      if(this.win===win&&!win.isDestroyed()){win.webContents.send('recording:changed',this.view());win.show();}
    })();
    try{await this.opening;}finally{this.opening=undefined;}
  }
  close(){this.closeBorder();const win=this.win;this.win=undefined;this.state=undefined;this.videoURL=undefined;if(win&&!win.isDestroyed())win.destroy();}
}
