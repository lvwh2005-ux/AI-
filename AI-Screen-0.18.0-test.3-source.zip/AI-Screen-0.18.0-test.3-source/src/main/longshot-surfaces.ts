import type { BrowserWindow } from 'electron';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import type { Rect } from '../shared/contracts';
import type { LongshotState } from '../shared/longshot';
import { selectionExterior } from '../shared/scroll-capture/layout';
import { PreviewWindowLayout, type PreviewWindowRequest, type PreviewWindowState } from '../shared/scroll-capture/preview-window';
import type { TelemetryUpdate } from '../shared/scroll-capture/telemetry';
import type { PreviewViewRequest } from '../shared/scroll-capture/preview-viewport';

/** Collection-only surfaces. The shaped mask has no preload and a native hole.
 * The thumbnail has the same isolated session bridge as the toolbar. Neither
 * owns source pixels. Both are destroyed before the output editor is shown. */
export class LongshotSurfaces {
  private mask?: BrowserWindow;
  private thumbnail?: BrowserWindow;
  private generation = 0;
  private state?: LongshotState;
  private layout?: PreviewWindowLayout;
  private requestedSize?: { width: number; height: number };
  private view: PreviewViewRequest = { sequence: 0, view: null };
  previewView(): PreviewViewRequest { return this.view; }
  constructor(private onUnexpectedClose: () => void, private onPreviewResize: () => void = () => {}) {}
  windows() { return [this.mask, this.thumbnail].filter((w): w is BrowserWindow => !!w && !w.isDestroyed()); }
  thumbnailWindow() { return this.thumbnail && !this.thumbnail.isDestroyed() ? this.thumbnail : undefined; }
  roleOf(senderId: number) { return this.thumbnailWindow()?.webContents.id === senderId ? 'longshot' as const : undefined; }
  async show(target: Rect, display: { bounds: Rect; workArea: Rect; scaleFactor?: number }, toolbar: Rect, backdrop?: string) {
    this.close();
    const generation = this.generation;
    const { BrowserWindow } = require('electron') as typeof import('electron');
    const common = { frame: false, show: false, alwaysOnTop: true, skipTaskbar: true, resizable: false, movable: false, minimizable: false, maximizable: false };
    const mask = new BrowserWindow({ ...common, ...display.bounds, backgroundColor: '#555555', focusable: false, hasShadow: false,
      webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true } });
    this.mask = mask;
    const exterior = selectionExterior(target, display.bounds);
    if (exterior.length) mask.setShape(exterior);
    mask.setContentProtection(true);
    this.layout = new PreviewWindowLayout({ ...target }, { ...display.workArea }, { ...toolbar });
    const previewBounds = this.layout.snapshot().bounds;
    this.requestedSize = { width: previewBounds.width, height: previewBounds.height };
    const thumbnail = new BrowserWindow({ ...common, ...previewBounds, backgroundColor: '#ffffff', focusable: false,
      webPreferences: { preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false, contextIsolation: true, sandbox: true, webSecurity: true } });
    this.thumbnail = thumbnail;
    // Opaque protected windows avoid the observed layered click-through window
    // capture issue. The mask's native hole passes input without layered styles.
    thumbnail.setContentProtection(true);
    for (const win of [mask, thumbnail]) {
      win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
      win.webContents.on('will-navigate', event => event.preventDefault());
      win.webContents.on('render-process-gone', () => { if (generation === this.generation) this.onUnexpectedClose(); });
      win.on('closed', () => { if (generation === this.generation) this.onUnexpectedClose(); });
    }
    const x = target.x - display.bounds.x, y = target.y - display.bounds.y;
    // Geometry is numeric and comes from the validated main-process selection.
    const pixelWidth = Math.round(target.width * (display.scaleFactor ?? 1));
    const pixelHeight = Math.round(target.height * (display.scaleFactor ?? 1));
    const html = `<!doctype html><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#555}body{background-size:100% 100%}body:before{content:'';position:absolute;inset:0;background:#0009}#region{position:absolute;outline:1px solid #45b8ee;left:${x}px;top:${y}px;width:${target.width}px;height:${target.height}px}.label{position:absolute;left:${Math.max(0,x)}px;top:${Math.max(0,y-34)}px;padding:5px 14px;background:#fff;border:1px solid #ddd;border-radius:7px;color:#333;font:13px 'Segoe UI','Microsoft YaHei',sans-serif;font-variant-numeric:tabular-nums}</style><div id="region"></div><div class="label">${pixelWidth} × ${pixelHeight}</div>`;
    try {
      const dev = process.defaultApp && process.env.AI_SCREEN_DEV_URL === 'http://127.0.0.1:5173';
      await Promise.all([mask.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(html)}`),
        dev ? thumbnail.loadURL('http://127.0.0.1:5173/#longshot-thumbnail') : thumbnail.loadFile(path.join(__dirname, '../renderer/index.html'), { hash: 'longshot-thumbnail' })]);
      if (generation !== this.generation) return;
      // Windows can add non-client padding to the initial frameless size at
      // fractional DPI. Apply screen rectangles explicitly, like the toolbar.
      mask.setBounds(display.bounds);
      thumbnail.setBounds(previewBounds);
      if (backdrop?.startsWith('data:image/jpeg;base64,')) await mask.webContents.executeJavaScript(`document.body.style.backgroundImage=${JSON.stringify(`url("${backdrop}")`)}; undefined`);
      if (generation !== this.generation) return;
      // An empty shape means rectangular in Electron, so keep a full-screen
      // selection's mask hidden rather than accidentally covering the hole.
      if (exterior.length) mask.showInactive();
      thumbnail.showInactive();
      if (this.state) this.publish(this.state);
    } catch (error) { if (generation === this.generation) this.close(); throw error; }
  }
  reposition(toolbar: Rect) {
    const win = this.thumbnailWindow(), layout = this.layout;
    if (!win || !layout) return;
    const previous = layout.snapshot();
    const next = layout.updateToolbar(toolbar);
    if (next.revision !== previous.revision) this.applyLayout(this.state?.id);
  }
  previewCommand(input: PreviewWindowRequest): PreviewWindowState {
    const layout = this.layout;
    if (!layout || !this.thumbnailWindow()) throw new Error('预览窗口已关闭');
    let token: string | undefined;
    if (input.op === 'auto') layout.restoreAuto();
    else if (input.op === 'begin') { token = randomUUID(); layout.begin(token, input.edge, input.point); }
    else if (input.op === 'update') layout.update(input.token, input.point);
    else if (input.op === 'end') layout.end(input.token, input.point);
    else if(input.op==='view'&&input.sequence>this.view.sequence){this.view={sequence:input.sequence,view:input.view};this.onPreviewResize();}
    if (input.op === 'auto' || input.op === 'update' || input.op === 'end') this.applyLayout(input.id);
    return { id: input.id, ...layout.snapshot(), ...(token ? { token } : {}) };
  }
  private applyLayout(id?: string) {
    const win = this.thumbnailWindow(), layout = this.layout;
    if (!win || !layout) return;
    const state = layout.snapshot(), next = state.bounds, current = win.getBounds();
    if ((['x', 'y', 'width', 'height'] as const).some(key => next[key] !== current[key])) win.setBounds(next);
    const resized = this.requestedSize?.width !== next.width || this.requestedSize.height !== next.height;
    this.requestedSize = { width: next.width, height: next.height };
    if (id && !win.webContents.isLoadingMainFrame()) win.webContents.send('longshot:preview-window-changed', { id, ...state });
    if (resized) this.onPreviewResize();
  }
  publish(state: LongshotState) {
    this.state = state;
    const win = this.thumbnailWindow();
    if (win && !win.webContents.isLoadingMainFrame()) win.webContents.send('longshot:changed', state);
    // Reassert order only on publication; never take keyboard focus.
    for (const surface of this.windows()) if (surface.isVisible()) surface.moveTop();
  }
  publishTelemetry(update: TelemetryUpdate) {
    if(this.state?.id===update.id)this.state={...this.state,telemetry:update.telemetry};
    const win=this.thumbnailWindow();
    if(win&&!win.webContents.isLoadingMainFrame())win.webContents.send('longshot:telemetry',update);
  }
  close() {
    this.generation++;
    const windows = this.windows(); this.mask = undefined; this.thumbnail = undefined; this.state = undefined;
    this.layout = undefined;
    this.requestedSize = undefined;
    this.view = { sequence: 0, view: null };
    for (const win of windows) { win.hide(); win.destroy(); }
  }
}
