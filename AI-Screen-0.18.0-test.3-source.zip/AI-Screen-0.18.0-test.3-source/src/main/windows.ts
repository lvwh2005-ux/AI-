import { BrowserWindow, screen, type BrowserWindowConstructorOptions } from 'electron';
import path from 'node:path';
import type { CaptureDisplay } from '../shared/geometry';
import { IPC, type CaptureSession } from '../shared/contracts';
import { captureReadiness } from './capture-readiness';

interface CaptureWindow {
  win: BrowserWindow;
  boot: ReturnType<typeof captureReadiness>;
  prepared: Promise<void>;
  pending?: { sessionId: string; signal: ReturnType<typeof captureReadiness> };
}

export type WindowRole = 'home' | 'capture' | 'result' | 'pin' | 'longshot'|'recording';
export class WindowManager {
  private windows = new Map<WindowRole, BrowserWindow>();
  private captures = new Map<string, BrowserWindow>();
  private capturePool = new Map<string, CaptureWindow>();
  private captureGeneration = 0;
  constructor(private onClosed?: (role: WindowRole) => void, private captureContent?: (displayId: string) => Omit<CaptureSession, 'sessionId' | 'frame'> & { frame: CaptureSession['frame'] | null }) {}
  get(role: WindowRole) { return role === 'capture' ? this.captures.values().next().value : this.windows.get(role); }
  captureDisplayOf(id: number) { return [...this.captures.entries()].find(([, win]) => !win.isDestroyed() && win.webContents.id === id)?.[0]; }
  getCaptures() { return [...this.captures.entries()].map(([displayId, win]) => ({ displayId, win })); }
  captureHandles() { return [...this.capturePool.values()].filter(({ win }) => !win.isDestroyed()).map(({ win }) => { const handle = win.getNativeWindowHandle(); return handle.length === 8 ? handle.readBigUInt64LE().toString() : String(handle.readUInt32LE()); }); }
  isCaptureSession(senderId: number, sessionId: string) {
    const displayId = this.captureDisplayOf(senderId);
    return displayId !== undefined && this.capturePool.get(displayId)?.pending?.sessionId === sessionId;
  }
  async showFloatingResult(target: { x: number; y: number; width: number; height: number }) {
    const area = screen.getDisplayMatching(target).workArea;
    const width = Math.min(500, area.width), height = Math.min(660, area.height);
    const right = target.x + target.width + 14;
    const x = Math.max(area.x, Math.min(right + width <= area.x + area.width ? right : target.x - width - 14, area.x + area.width - width));
    const y = Math.max(area.y, Math.min(target.y, area.y + area.height - height));
    const win = await this.show('result', { x, y, width, height, minWidth: Math.min(380, width), minHeight: Math.min(400, height), alwaysOnTop: true });
    win.setBounds({ x, y, width, height }); win.setAlwaysOnTop(true);
    return win;
  }
  roleOf(id: number) {
    if ([...this.capturePool.values()].some(({ win }) => !win.isDestroyed() && win.webContents.id === id)) return 'capture' as const;
    return [...this.windows.entries()].find(([, win]) => !win.isDestroyed() && win.webContents.id === id)?.[0];
  }
  private create(role: WindowRole, options: BrowserWindowConstructorOptions = {}) {
    const win = new BrowserWindow({
      width: role === 'result' ? 540 : 1040, height: 760, minWidth: role === 'result' ? 420 : 800,
      minHeight: 560, title: 'AI Screen · 屏幕助手', backgroundColor: '#f6f8fc', show: false,
      icon: path.join(__dirname, 'icon.ico'),
      autoHideMenuBar: true, ...options,
      webPreferences: {
        preload: path.join(__dirname, 'preload.cjs'), nodeIntegration: false,
        contextIsolation: true, sandbox: true, webSecurity: true,
        backgroundThrottling: role !== 'capture',
      },
    });
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', (event) => event.preventDefault());
    return win;
  }
  private async load(win: BrowserWindow, role: WindowRole) {
    const devUrl = !process.defaultApp ? undefined : process.env.AI_SCREEN_DEV_URL;
    if (devUrl === 'http://127.0.0.1:5173') await win.loadURL(`${devUrl}/#${role}`);
    else await win.loadFile(path.join(__dirname, '../renderer/index.html'), { hash: role });
    if (win.isDestroyed()) throw new Error('窗口已关闭，请重试');
  }
  async show(role: WindowRole, options: BrowserWindowConstructorOptions = {}) {
    const existing = this.get(role);
    if (existing && !existing.isDestroyed()) { existing.show(); existing.focus(); return existing; }
    if (role === 'capture') {
      const display = screen.getDisplayMatching({ x: options.x ?? 0, y: options.y ?? 0, width: options.width ?? 1, height: options.height ?? 1 });
      return (await this.showCaptures([{ id: String(display.id), label: display.label, bounds: display.bounds, scaleFactor: display.scaleFactor }], options))[0].win;
    }
    const win = this.create(role, options);
    this.windows.set(role, win);
    win.on('closed', () => {
      if (this.windows.get(role) === win) {
        this.windows.delete(role);
        this.onClosed?.(role);
      }
    });
    try {
      await this.load(win, role);
      if (!process.argv.includes('--smoke-test')) { win.show(); win.focus(); }
      return win;
    } catch (error) { if (!win.isDestroyed()) win.destroy(); throw error; }
  }
  async showCaptures(displays: readonly CaptureDisplay[], options: BrowserWindowConstructorOptions = {}) {
    if (this.captures.size) throw new Error('截图窗口已打开');
    const generation = ++this.captureGeneration;
    const entries: { displayId: string; bounds: CaptureDisplay['bounds']; win: BrowserWindow }[] = [];
    try {
      await this.prepareCaptures(displays, options);
      if (generation !== this.captureGeneration) throw new Error('截图已取消，请重新截图');
      for (const display of displays) {
        const entry = this.capturePool.get(display.id)!;
        const win = entry.win;
        this.captures.set(display.id, win);
        win.setBounds(display.bounds);
        const content = this.captureContent?.(display.id);
        if (!content?.frame) throw new Error('选区已失效，请重新截图');
        const sessionId = String(generation);
        entry.pending = { sessionId, signal: captureReadiness() };
        win.webContents.send(IPC.captureChanged, { sessionId, ...content });
        entries.push({ displayId: display.id, bounds: display.bounds, win });
      }
      const loaded = await Promise.allSettled(entries.map(({ displayId }) => this.capturePool.get(displayId)!.pending!.signal.promise));
      const failure = loaded.find((result) => result.status === 'rejected');
      if (failure?.status === 'rejected') throw failure.reason;
      if (generation !== this.captureGeneration) throw new Error('截图已取消，请重新截图');
      // A 1px paint probe forces a compositor frame without copying the screen
      // again. Hidden-window rAF may be throttled; the probe is never persisted.
      await Promise.all(entries.map(({ win }) => win.webContents.capturePage({ x: 0, y: 0, width: 1, height: 1 }, { stayHidden: true, stayAwake: true }).then(() => {})));
      if (generation !== this.captureGeneration) throw new Error('截图已取消，请重新截图');
      if (!process.argv.includes('--smoke-test')) {
        entries.slice(1).forEach(({ win }) => win.showInactive());
        entries[0]?.win.show(); entries[0]?.win.focus();
      }
      return entries;
    } catch (error) {
      if (generation === this.captureGeneration) this.closeCaptures(false);
      throw error;
    }
  }
  // Keep the React page warm, but never retain a desktop image between sessions.
  async prepareCaptures(displays: readonly CaptureDisplay[], options: BrowserWindowConstructorOptions = {}) {
    await Promise.all(displays.map((display) => {
      const existing = this.capturePool.get(display.id);
      if (existing && !existing.win.isDestroyed()) return existing.prepared;
      const win = this.create('capture', {
        ...options, ...display.bounds, minWidth: 1, minHeight: 1, frame: false, resizable: false,
        movable: false, alwaysOnTop: true, skipTaskbar: true, enableLargerThanScreen: true,
        transparent: true, backgroundColor: '#00000000',
      });
      const boot = captureReadiness();
      const entry: CaptureWindow = { win, boot, prepared: Promise.resolve() };
      this.capturePool.set(display.id, entry);
      win.on('closed', () => {
        boot.finish(new Error('截图窗口已关闭'));
        entry.pending?.signal.finish(new Error('截图已取消'));
        if (this.capturePool.get(display.id) === entry) this.capturePool.delete(display.id);
        if (this.captures.get(display.id) === win) this.closeCaptures();
      });
      win.webContents.on('render-process-gone', () => { if (!win.isDestroyed()) win.destroy(); });
      entry.prepared = this.load(win, 'capture').then(() => boot.promise).catch((error) => {
        if (!win.isDestroyed()) win.destroy();
        throw error;
      });
      return entry.prepared;
    }));
  }
  capturePrepared(senderId: number) {
    const entry = [...this.capturePool.values()].find(({ win }) => !win.isDestroyed() && win.webContents.id === senderId);
    entry?.boot.finish();
  }
  captureReady(senderId: number, sessionId: string, ready: boolean) {
    const displayId = this.captureDisplayOf(senderId);
    const entry = displayId === undefined ? undefined : this.capturePool.get(displayId);
    if (!entry?.pending || entry.pending.sessionId !== sessionId) return;
    entry.pending.signal.finish(ready ? undefined : new Error('截图画面无法加载，请重新截图'));
  }
  disposeCaptures() {
    this.closeCaptures();
    const entries = [...this.capturePool.values()];
    this.capturePool.clear();
    entries.forEach(({ win }) => { if (!win.isDestroyed()) win.destroy(); });
  }
  private closeCaptures(notify = true) {
    this.captureGeneration++;
    const windows = [...this.captures.values()];
    this.captures.clear();
    // Release active display identities immediately; warm pages retain only handshake access.
    windows.forEach((win) => {
      if (win.isDestroyed()) return;
      win.hide();
      const entry = [...this.capturePool.values()].find((entry) => entry.win === win);
      entry?.pending?.signal.finish(new Error('截图已取消'));
      if (entry) entry.pending = undefined;
      win.webContents.send(IPC.captureChanged, null);
    });
    if (notify && windows.length) this.onClosed?.('capture');
  }
  close(role: WindowRole) { if (role === 'capture') this.closeCaptures(); else this.get(role)?.close(); }
}
