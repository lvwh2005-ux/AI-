// A bounded handshake prevents showing an unpainted or stale capture window.
export function captureReadiness() {
  let resolve!: () => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<void>((yes, no) => { resolve = yes; reject = no; });
  const timeout = setTimeout(() => reject(new Error('截图界面准备超时，请重新截图')), 5000);
  const finish = (error?: Error) => { clearTimeout(timeout); if (error) reject(error); else resolve(); };
  // The window can close before a caller awaits its readiness.
  void promise.catch(() => {});
  return { promise, finish };
}
