import { app, BrowserWindow, desktopCapturer, dialog, globalShortcut, ipcMain, Menu, nativeImage, nativeTheme, screen, session, shell, Tray,powerMonitor, type IpcMainInvokeEvent } from 'electron';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {writeFile} from 'node:fs/promises';
import {monitorEventLoopDelay} from 'node:perf_hooks';
import { z } from 'zod';
import { IPC, settingsInputSchema, rectSchema, type Reply, type SettingsInput } from '../shared/contracts';
import { WindowManager, type WindowRole } from './windows';
import { SettingsStore } from './services/settings';
import { CaptureService } from './services/capture';
import { TaskService } from './services/tasks';
import { parseActionInput } from './action-input';
import { WindowsOCRProvider } from './providers/windows-ocr';
import { CompatibleProvider } from './providers/compatible';
import { customAction } from '../shared/custom-actions';
import { externalLink } from '../shared/external-links';
import { ShortcutRecording } from './services/shortcut-recording';
import { WindowDetector } from './services/window-detector';
import { clipWindowToDisplay, pickWindow, type DetectedWindow } from '../shared/window-candidates';
import { CaptureModeRegistry } from './services/capture-modes';
import { captureModes, type CaptureMode } from '../shared/capture-modes';
import { ClipboardService } from './services/clipboard';
import { annotationsSchema } from '../shared/annotations';
import { AnnotationCompositor } from './services/annotation-compositor';
import { PinWindowManager } from './pin-window';
import { LongshotWindow } from './longshot-window';
import { previewWindowRequestSchema } from '../shared/scroll-capture/preview-window';
import { LongshotService } from './services/longshot';
import { LiveRegionSource } from './services/live-region-source';
import {isolatedRegionSource} from './services/isolated-region-source';
import { WindowsLongshotScroller } from './services/longshot-scroller';
import {LongshotProcessor} from './services/longshot-processor';
import {StageProfiler,type ProfileSpan} from '../shared/scroll-capture/profiler';
import {RecordingService} from './services/recording/recording-service';
import {ElectronMediaHost} from './services/recording/media-host';
import {LocalVideoFileSink} from './services/recording/video-file-sink';
import{RecordingWindow}from'./recording-window';
import{recordingOptionsSchema,type RecordingTarget,type RecordingAudio,type RecordingCommand}from'../shared/recording/contracts';
import{recordingFormat}from'../shared/recording/format';
import{removeExpiredRecordings}from'./services/recording/temp-cleanup';

const smoke = process.argv.includes('--smoke-test');
const performanceSpans:ProfileSpan[]=[];
const longshotProfiler=smoke&&process.argv.includes('--longshot-performance-profile')
  ?new StageProfiler(span=>{if(performanceSpans.length<20000)performanceSpans.push(span);}):undefined;
const performanceLoop=longshotProfiler?monitorEventLoopDelay({resolution:10}):undefined;
performanceLoop?.enable();
if (smoke) app.setPath('userData', path.join(process.cwd(), '.runtime', 'smoke'));
const detector = new WindowDetector();
const compositor = new AnnotationCompositor();
const longshotCompositor = new AnnotationCompositor();
const pins = new PinWindowManager();
const modes = new CaptureModeRegistry();
const longshotWindow = new LongshotWindow(() => { void longshot?.cancel(); });
let longshot: LongshotService;
let videoRecording: RecordingService;
let recordingHost:ElectronMediaHost|undefined;
let recordingTarget:RecordingTarget|undefined;
const recordingWindow=new RecordingWindow({artifact:()=>videoRecording?.artifact,closed:()=>{const state=videoRecording?.state;if(state)void closeRecording(state.id).catch(showError);}});
let smokeRecordingSave:()=>Promise<string|undefined>=async()=>undefined;
let smokeRecordingAudioFrame:Electron.WebFrameMain|undefined;
let smokeVideoTarget:RecordingTarget|undefined;
let smokeMicrophoneDenied=false;
let captureInitialMode:CaptureMode='screenshot';
const recordingShortcuts=new Set<string>();
let recordingShortcutWarning:string|undefined;
let recordingPublishedStatus='',recordingPublishedSecond=-1;
function captureActivityBusy() { return !!longshot?.active || !!videoRecording?.active; }
const longshotShortcuts = new Set<string>();
let smokeSavePath: string | undefined;
let smokeDiagnosticChooser:()=>Promise<string|undefined>=async()=>undefined;
let detectedWindows: DetectedWindow[] = [];
let smokeCopiedSize: { width: number; height: number } | undefined;
let smokeCopiedDigest: string | undefined;
const clipboardService = new ClipboardService(smoke ? async (image) => { smokeCopiedSize = image.getSize(); smokeCopiedDigest=createHash('sha256').update(image.toBitmap()).digest('hex'); } : undefined);
const windows = new WindowManager((role) => {
  if (role === 'home') restoreShortcut();
  if (role === 'result') tasks?.clear();
  if (role === 'capture') {
    captureVersion++;
    capture.clear();
    detectedWindows = [];
    if (!captureCommitted && !quitting) restoreCaptureWindows();
  }
}, (displayId) => {
  const display = screen.getAllDisplays().find((item) => String(item.id) === displayId);
  const cursor = screen.getCursorScreenPoint();
  return { frame: capture.frame(displayId), settings: publicSettings(), capabilities: modes.capabilities(),initialMode:captureInitialMode,
    candidates: display ? detectedWindows.map((item) => clipWindowToDisplay(item, display.bounds, screen.dipToScreenRect(null, display.bounds))).filter((item): item is DetectedWindow => !!item) : [],
    cursor: display ? { x: cursor.x - display.bounds.x, y: cursor.y - display.bounds.y } : undefined };
});
function captureDisplays() {
  return screen.getAllDisplays().map((display, index) => ({
    id: String(display.id), label: display.label || `显示器 ${index + 1}`,
    bounds: { ...display.bounds }, scaleFactor: display.scaleFactor,
  }));
}
const capture = new CaptureService({
  displays: captureDisplays,
  preferredDisplay: () => String(screen.getDisplayNearestPoint(screen.getCursorScreenPoint()).id),
  sources: (thumbnailSize) => desktopCapturer.getSources({ types: ['screen'], thumbnailSize }),
});
let settings: SettingsStore;
let tasks: TaskService;
let tray: Tray | undefined;
let trayMenu: Menu | undefined;
let capturing = false;
let saving = false;
let shortcut = '';
let restoreHome = false;
let restoreResult = false;
let captureVersion = 0;
let captureCommitted = false;
let captureActionPending: symbol | undefined;
let quitting = false;
let modeAbort = new AbortController();
const recording = new ShortcutRecording(
  () => { if (shortcut) globalShortcut.unregister(shortcut); },
  () => { if (shortcut && !quitting) registerShortcut(shortcut); },
);
function restoreShortcut() { try { recording.end(); } catch (error) { showError(error); } }
app.on('browser-window-created', (_event, win) => {
  const restore = () => { if (windows.roleOf(win.webContents.id) === 'home') restoreShortcut(); };
  win.on('blur', restore);
  win.webContents.on('render-process-gone', restore);
});

function restoreCaptureWindows() {
  if (restoreHome) windows.get('home')?.show();
  if (restoreResult) windows.get('result')?.show();
}

const showError = (error: unknown) => dialog.showErrorBox('AI Screen', error instanceof Error ? error.message : '操作失败');
async function startCapture(initialMode:CaptureMode='screenshot') {
  if (longshot?.active) throw new Error('请先完成或取消正在进行的长截图');
  if (videoRecording?.active) throw new Error('请先完成或取消正在进行的录屏');
  if (recording.recording) throw new Error('请先完成快捷键录制');
  if (capturing || windows.get('capture')) return;
  capturing = true;
  captureInitialMode=initialMode;
  const version = ++captureVersion;
  captureCommitted = false;
  tasks.cancel();
  restoreHome = windows.get('home')?.isVisible() ?? false;
  restoreResult = windows.get('result')?.isVisible() ?? false;
  windows.get('home')?.hide();
  windows.get('result')?.hide();
  try {
    const [displays, , candidates] = await Promise.all([
      (async () => {
        // Only a visible app window needs time to leave the compositor.
        if (restoreHome || restoreResult) await new Promise((resolve) => setTimeout(resolve, 32));
        if (version !== captureVersion) throw new Error('截图已取消');
        return capture.takeAll();
      })(),
      windows.prepareCaptures(captureDisplays()),
      detector.snapshot(windows.captureHandles()),
    ]);
    if (version !== captureVersion) { capture.clear(); return; }
    detectedWindows = candidates;
    await windows.showCaptures(displays);
  } catch (error) {
    if (version === captureVersion) {
      cancelCapture();
      throw error;
    }
  } finally { capturing = false; }
}
function cancelCapture() {
  captureVersion++;
  modeAbort.abort(); modeAbort = new AbortController();
  if (captureActionPending) { compositor.dispose(); if (!quitting) void compositor.warmup().catch(() => {}); }
  captureActionPending = undefined;
  windows.close('capture'); capture.clear();
  detectedWindows = [];
  restoreCaptureWindows();
}
function registerShortcut(next: string) {
  if (next === shortcut && globalShortcut.isRegistered(next)) return;
  if (!globalShortcut.register(next, () => { if (!captureActivityBusy()) void startCapture().catch(showError); })) throw new Error(`快捷键 ${next} 已被占用，请更换组合键`);
  if (shortcut && shortcut !== next) globalShortcut.unregister(shortcut);
  shortcut = next;
}
function publicSettings() { return { ...settings.value, hasApiKey: settings.hasApiKey, shortcutActive: !!shortcut && globalShortcut.isRegistered(shortcut) }; }
async function saveSettings(input: SettingsInput) {
  if (recording.recording) throw new Error('请先完成快捷键录制');
  if (saving) throw new Error('设置正在保存，请稍候');
  saving = true;
  const oldShortcut = shortcut;
  try {
    registerShortcut(input.shortcut);
    await settings.save(input);
    return publicSettings();
  } catch (error) {
    if (shortcut !== oldShortcut) {
      globalShortcut.unregister(shortcut); shortcut = '';
      if (oldShortcut) registerShortcut(oldShortcut);
    }
    throw error;
  } finally { saving = false; }
}

function handle(channel: string, roles: WindowRole[], callback: (value: unknown, role: WindowRole, senderId: number) => unknown) {
  ipcMain.handle(channel, async (event: IpcMainInvokeEvent, value: unknown): Promise<Reply<unknown>> => {
    try {
      const role = windows.roleOf(event.sender.id) ?? pins.roleOf(event.sender.id) ?? longshotWindow.roleOf(event.sender.id)??recordingWindow.roleOf(event.sender.id);
      if (!role || !roles.includes(role) || event.senderFrame !== event.sender.mainFrame) throw new Error('无权限调用此操作');
      return { ok: true, value: await callback(value, role, event.sender.id) };
    } catch (error) {
      return { ok: false, error: error instanceof z.ZodError ? '输入格式不正确' : error instanceof Error ? error.message : '操作失败' };
    }
  });
}
function setupIPC() {
  handle(IPC.getLongshot, ['longshot'], () => longshot.state);
  handle(IPC.previewWindow, ['longshot'], (value, _role, senderId) => {
    const input = previewWindowRequestSchema.parse(value), state = longshot.state;
    if (!state || state.id !== input.id || !['preparing', 'capturing', 'error'].includes(state.status)) throw new Error('长截图会话已结束');
    return longshotWindow.previewWindow(senderId, input);
  });
  handle(IPC.getLongshotImage, ['longshot'], value => longshot.original(z.object({id:z.string().uuid()}).strict().parse(value).id));
  handle(IPC.commandLongshot, ['longshot'], (value) => {
    const input = z.object({ id: z.string().uuid(), command: z.enum(['finish', 'cancel', 'copy', 'save', 'analyze', 'close', 'pause', 'resume', 'manual', 'confirm-region', 'keep-region','export-diagnostics']), annotations:annotationsSchema.optional() }).strict().parse(value);
    return longshot.command(input.id, input.command, input.annotations);
  });
  handle(IPC.capturePrepared, ['capture'], (_value, _role, senderId) => windows.capturePrepared(senderId));
  handle(IPC.captureReady, ['capture'], (value, _role, senderId) => {
    const input = z.object({ sessionId: z.string().max(80), ready: z.boolean() }).parse(value);
    windows.captureReady(senderId, input.sessionId, input.ready);
  });
  handle(IPC.setShortcutRecording, ['home'], (value) => {
    if (z.boolean().parse(value)) {
      if (saving || capturing || windows.get('capture')) throw new Error('请等待当前操作完成');
      if (!smoke && !windows.get('home')?.isFocused()) throw new Error('请在设置窗口中录制快捷键');
      recording.begin();
    } else recording.end();
  });
  handle(IPC.openExternal, ['result'], (value) => shell.openExternal(externalLink(z.string().parse(value))));
  handle(IPC.getSettings, ['home', 'result', 'capture', 'longshot'], () => publicSettings());
  handle(IPC.saveSettings, ['home'], (value) => saveSettings(settingsInputSchema.parse(value)));
  handle(IPC.testService, ['home'], async (value) => {
    const input = settingsInputSchema.parse(value);
    if (input.provider !== 'compatible') throw new Error('请先选择兼容 API 服务');
    const apiKey = input.apiKey?.trim() || (input.clearApiKey ? '' : await settings.apiKey());
    const fixture = nativeImage.createFromBitmap(Buffer.alloc(64 * 64 * 4, 255), { width: 64, height: 64 }).toDataURL();
    const start = Date.now();
    await new CompatibleProvider({ ...input, apiKey }).complete({ action: 'ask', image: fixture, question: '这是一张连接测试用的小图片。请简短回答你能否接收图片。', language: input.language, history: [], signal: AbortSignal.timeout(20_000), onProgress: input.stream ? () => {} : undefined });
    return { message: '服务请求成功，已收到图片请求的回复。图片理解质量请用实际选区确认。', elapsedMs: Date.now() - start };
  });
  handle(IPC.startCapture, ['home', 'result'], (value)=>startCapture(z.enum(captureModes).default('screenshot').parse(value)));
  handle(IPC.getCapture, ['capture'], (_value, _role, senderId) => {
    const displayId = windows.captureDisplayOf(senderId);
    if (displayId === undefined) return null;
    return capture.frame(displayId);
  });
  handle(IPC.cancelCapture, ['capture'], cancelCapture);
  handle(IPC.resetCaptureAction, ['capture'], (_value, _role, senderId) => {
    if (windows.captureDisplayOf(senderId) === undefined) throw new Error('截图窗口已关闭');
    captureVersion++; modeAbort.abort(); modeAbort = new AbortController();
    captureActionPending = undefined;
    compositor.dispose();
    void compositor.warmup().catch(() => {});
  });
  handle(IPC.startCaptureMode, ['capture'], async (value, _role, senderId) => {
    const input = z.object({ mode: z.enum(['longshot', 'record']), rect: rectSchema, scrollMode: z.enum(['auto', 'manual']).optional(),recordingOptions:recordingOptionsSchema.optional() }).parse(value);
    const displayId = windows.captureDisplayOf(senderId);
    if (displayId === undefined) throw new Error('截图窗口已关闭');
    // Validate that the target can be cropped before handing it to an extension.
    capture.crop(input.rect, displayId);
    const display = screen.getAllDisplays().find((item) => String(item.id) === displayId);
    const targetWindowId = display ? pickWindow(detectedWindows, screen.dipToScreenPoint({
      x: Math.round(display.bounds.x + input.rect.x + input.rect.width / 2),
      y: Math.round(display.bounds.y + input.rect.y + input.rect.height / 2),
    }))?.id : undefined;
    if (input.mode === 'longshot' && input.scrollMode !== 'manual' && !targetWindowId) {
      throw new Error('无法可靠识别原目标窗口，请重新框选或选择手动滚动采集');
    }
    if (captureActionPending) throw new Error('选区正在处理，请稍候');
    const actionToken = Symbol(); captureActionPending = actionToken;
    try { await modes.start(input.mode, { displayId, rect: input.rect, signal: modeAbort.signal, scrollMode: input.scrollMode, targetWindowId,recordingOptions:input.recordingOptions }); }
    finally { if (captureActionPending === actionToken) captureActionPending = undefined; }
  });
  handle(IPC.getRecording,['recording'],()=>recordingWindow.view()??null);
  handle(IPC.saveRecording,['recording'],value=>saveRecording(z.object({id:z.string().uuid()}).strict().parse(value).id));
  handle(IPC.closeRecording,['recording'],value=>closeRecording(z.object({id:z.string().uuid()}).strict().parse(value).id));
  handle(IPC.samplePixel, ['capture'], (value, _role, senderId) => {
    const input = z.object({ sessionId: z.string().max(80), point: z.object({ x: z.number().finite().nonnegative(), y: z.number().finite().nonnegative() }) }).parse(value);
    const displayId = windows.captureDisplayOf(senderId);
    if (displayId === undefined || !windows.isCaptureSession(senderId, input.sessionId)) return null;
    return capture.sample(input.point, displayId);
  });
  handle(IPC.getPin, ['pin'], (_value, _role, senderId) => pins.getForSender(senderId));
  handle(IPC.controlPin, ['pin'], (value, _role, senderId) => pins.control(senderId, z.enum(['close', 'zoom-in', 'zoom-out', 'reset']).parse(value)));
  handle(IPC.pinSelection, ['capture'], async (value, _role, senderId) => {
    const input = z.object({ rect: rectSchema, annotations: annotationsSchema.optional() }).parse(value);
    if (captureActionPending) throw new Error('选区正在处理，请稍候');
    const displayId = windows.captureDisplayOf(senderId), version = captureVersion;
    const display = screen.getAllDisplays().find((item) => String(item.id) === displayId);
    if (!display) throw new Error('截图窗口已关闭');
    const actionToken = Symbol(); captureActionPending = actionToken;
    try {
      const image = await compositor.render(capture.crop(input.rect, displayId), input.rect, input.annotations ?? []);
      if (version !== captureVersion || windows.captureDisplayOf(senderId) !== displayId) return;
      await pins.create(image.toDataURL(), { ...input.rect, x: display.bounds.x + input.rect.x, y: display.bounds.y + input.rect.y }, () => version === captureVersion && windows.captureDisplayOf(senderId) === displayId);
      if (version === captureVersion) { captureCommitted = true; cancelCapture(); }
    } finally { if (captureActionPending === actionToken) captureActionPending = undefined; }
  });
  handle(IPC.openSettings, ['result'], async () => { await windows.show('home'); });
  handle(IPC.getResult, ['result'], () => tasks.state);
  handle(IPC.cancelRequest, ['result'], () => tasks.cancel());
  handle(IPC.copyText, ['result'], (value) => clipboardService.writeText(z.string().max(2_000_000).parse(value)));
  handle(IPC.runAction, ['capture', 'result'], async (value, role, senderId) => {
    const input = parseActionInput(value, role);
    if (input.action === 'custom') customAction(settings.value.customActions, input.customActionId);
    if (input.rect) {
      if (captureActionPending) throw new Error('选区正在处理，请稍候');
      const actionToken = Symbol(); captureActionPending = actionToken;
      const version = captureVersion;
      try {
        const displayId = windows.captureDisplayOf(senderId);
        if (displayId === undefined) throw new Error('截图窗口已关闭');
        const cropped = await compositor.render(capture.crop(input.rect, displayId), input.rect, input.annotations ?? []);
        if (version !== captureVersion || windows.captureDisplayOf(senderId) !== displayId) return;
        if (input.action === 'copy-image') {
          await clipboardService.writeImage(cropped);
          if (version === captureVersion) cancelCapture();
          return;
        }
        const image = cropped.toDataURL();
        const display = screen.getAllDisplays().find((item) => String(item.id) === displayId);
        const target = { ...input.rect, x: input.rect.x + (display?.bounds.x ?? 0), y: input.rect.y + (display?.bounds.y ?? 0) };
        captureCommitted = true;
        windows.close('capture'); capture.clear();
        // Publish before the renderer reads its state; cleanup is attached at window creation.
        void tasks.run(input.action, image, input.question ?? '', false, input.customActionId);
        try {
          const win = await windows.showFloatingResult(target);
          if (capturing || windows.get('capture')) win.hide();
        } catch (error) {
          tasks.clear(); restoreCaptureWindows(); throw error;
        }
      } finally { if (captureActionPending === actionToken) captureActionPending = undefined; }
    } else {
      if (input.action === 'copy-image' || !tasks.state) throw new Error('请先框选一个区域');
      void tasks.run(input.action, tasks.state.image, input.question ?? '', true, input.customActionId);
    }
  });
}

async function main() {
  if(!smoke)await removeExpiredRecordings(path.join(app.getPath('temp'),'AI-Screen-recordings')).catch(()=>{});
  nativeTheme.themeSource = 'light';
  settings = new SettingsStore(); await settings.load();
  tasks = new TaskService(settings, (state) => windows.get('result')?.webContents.send(IPC.resultChanged, state), (text) => clipboardService.writeText(text), undefined, new WindowsOCRProvider(), (progress) => windows.get('result')?.webContents.send(IPC.resultProgress, progress));
  longshot = new LongshotService({ window: longshotWindow, clipboard: clipboardService,
    ...(longshotProfiler?{createProcessor:()=>new LongshotProcessor({profiler:longshotProfiler})}:{}),
    diagnosticEnvironment:context=>{
      const display=screen.getAllDisplays().find(item=>String(item.id)===context.displayId);
      const native=display&&detector.getNativeDisplays().find(item=>item.x===display.nativeOrigin.x&&item.y===display.nativeOrigin.y);
      return{appVersion:app.getVersion(),systemVersion:process.getSystemVersion(),platform:process.platform,
        displayWidth:native?.width??0,displayHeight:native?.height??0,scaleFactor:display?.scaleFactor??0};
    },
    compositor:longshotCompositor,
    analyze:async image => {
      const target = longshotWindow.get()?.getBounds() ?? screen.getPrimaryDisplay().workArea;
      void tasks.run('analyze', image.toDataURL(), '', false);
      try { await windows.showFloatingResult(target); }
      catch(error) { tasks.clear(); throw error; }
    },
    createScroller: (context) => new WindowsLongshotScroller(() => BrowserWindow.getAllWindows()
      .filter((win) => windows.roleOf(win.webContents.id) || pins.roleOf(win.webContents.id) || longshotWindow.roleOf(win.webContents.id))
      .map((win) => win.getNativeWindowHandle().readBigUInt64LE().toString()), context.targetWindowId, () => longshotWindow.protectedControlHandles()),
    createSource: (context) => {
      const dependencies={
      displays: captureDisplays,
      profiler:longshotProfiler,
      nativeSize: (display:ReturnType<typeof captureDisplays>[number]) => {
        const electronDisplay = screen.getAllDisplays().find((item) => String(item.id) === display.id);
        if (!electronDisplay) return undefined;
        const physical = detector.getNativeDisplays().find((item) => item.x === electronDisplay.nativeOrigin.x && item.y === electronDisplay.nativeOrigin.y);
        return physical ? { width: physical.width, height: physical.height } : undefined;
      },
      };
      return process.argv.includes('--longshot-inline-capture')
        ?new LiveRegionSource(context.displayId,context.rect,{...dependencies,sources:thumbnailSize=>desktopCapturer.getSources({types:['screen'],thumbnailSize})})
        :isolatedRegionSource(context.displayId,context.rect,dependencies);
    },
    beforeCapture: async (context) => {
      const backdrop = capture.frame(context.displayId)?.image;
      captureCommitted = true; windows.close('capture'); capture.clear();
      return backdrop;
    },
    onIdle: () => { refreshLongshotControls(); if (!quitting) restoreCaptureWindows(); },
    onState: () => refreshLongshotControls(),
    ...(smoke ? { chooseSavePath: async () => smokeSavePath,chooseDiagnosticPath:()=>smokeDiagnosticChooser() } : {}),
  });
  modes.register(longshot);
  videoRecording = new RecordingService({
    productionReady:true,
    backend: () => recordingHost=new ElectronMediaHost({production:true,reselect:async()=>{await videoRecording.cancel();recordingWindow.close();await startCapture('record');},control:(id,command,audio)=>command==='audio'?videoRecording.setAudio(id,audio!):command==='cancel'?closeRecording(id):videoRecording.command(id,command),...(smoke&&process.argv.includes('--recording-only')?{testAudioFrame:()=>smokeRecordingAudioFrame,testVideoFrame:()=>smokeRecordingAudioFrame,testTarget:()=>smokeVideoTarget,denyMicrophoneForTest:smokeMicrophoneDenied}:{} )}),
    sink: (id,options) => LocalVideoFileSink.create(path.join(app.getPath('temp'),'AI-Screen-recordings'),id,options.mimeType),
    otherCaptureActive: () => !!longshot.active,
    target: context => {
      const display=screen.getAllDisplays().find(item=>String(item.id)===context.displayId);
      if(!display)throw new Error('录屏显示器已移除');
      return recordingTarget={displayId:context.displayId,displayBounds:{...display.bounds},scaleFactor:display.scaleFactor,rect:{...context.rect}};
    },
    onStarting:async()=>{captureCommitted=true;windows.close('capture');capture.clear();},
    onPrepared:async()=>{if(recordingTarget)await recordingWindow.showBorder(recordingTarget);},
    onState:state=>{
      const second=Math.floor(state.elapsedMs/1000);
      if(recordingPublishedStatus!==state.status||recordingPublishedSecond!==second){recordingPublishedStatus=state.status;recordingPublishedSecond=second;if(['ready','error','cancelled'].includes(state.status))refreshLongshotControls();else refreshRecordingControls();}
      recordingHost?.publish({...state,message:state.message??recordingShortcutWarning});recordingWindow.publish(state);
      if(state.status==='cancelled'&&!quitting)restoreCaptureWindows();
    },
  });
  modes.register(videoRecording);
  longshotWindow.onPreviewResize = () => longshot.refreshPreview();
  session.defaultSession.setPermissionRequestHandler((_webContents, _permission, callback) => callback(false));
  session.defaultSession.setPermissionCheckHandler(() => false);
  setupIPC();
  void detector.warmup();
  void compositor.warmup().catch(() => {});
  if (smoke) {
    if(process.argv.includes('--recording-only')){
      const{runRecordingUI}=await import('./recording-ui-smoke');
      await runRecordingUI(windows,{service:videoRecording,result:recordingWindow,host:()=>recordingHost,setSave:choose=>{smokeRecordingSave=choose;},setAudioFrame:frame=>{smokeRecordingAudioFrame=frame;},setVideoTarget:target=>{smokeVideoTarget=target;},denyMicrophone:value=>{smokeMicrophoneDenied=value;}});app.exit(0);return;
    }
    const { runSmoke } = await import('./smoke');
    await runSmoke(windows, tasks, capture, { pins, compositor, copiedSize: () => smokeCopiedSize, copiedDigest:()=>smokeCopiedDigest, longshot, longshotWindow, setSavePath: (value: string | undefined) => { smokeSavePath = value; },setDiagnosticChooser:choose=>{smokeDiagnosticChooser=choose;} });
    if(longshotProfiler){
      performanceLoop!.disable();
      await writeFile(path.join(process.cwd(),'.runtime','longshot-performance-native-spans.json'),JSON.stringify({spans:performanceSpans,
        eventLoopDelay:{meanMs:performanceLoop!.mean/1e6,p95Ms:performanceLoop!.percentile(95)/1e6,maxMs:performanceLoop!.max/1e6},
        processEndMemory:process.memoryUsage()},null,2));
    }
    app.exit(0); return;
  }
  tray = new Tray(path.join(__dirname, 'icon.ico'));
  tray.setToolTip('AI Screen · 屏幕助手');
  refreshLongshotControls();
  tray.on('right-click', () => {
    const menu = trayMenu, id = longshot.state?.id;
    longshot.suspendSampling(true, id);
    menu?.popup({ callback: () => longshot.suspendSampling(false, id) });
  });
  tray.on('double-click', () => { if (!captureActivityBusy()) void windows.show('home').catch(showError); });
  try { registerShortcut(settings.value.shortcut); } catch (error) { showError(error); }
  const displaysChanged = () => {
    void longshot.cancel();
    void videoRecording.interrupt('显示器配置发生变化，已停止并保留有效录像').catch(showError);
    if (capturing || windows.get('capture')) cancelCapture();
    windows.disposeCaptures();
    void windows.prepareCaptures(captureDisplays()).catch(() => { /* Retry preparation on the next shortcut. */ });
  };
  screen.on('display-metrics-changed', displaysChanged);
  screen.on('display-removed', displaysChanged);
  screen.on('display-added', displaysChanged);
  powerMonitor.on('suspend',()=>{void videoRecording.interrupt('系统即将休眠，已停止录屏').catch(showError);});
  powerMonitor.on('lock-screen',()=>{void videoRecording.interrupt('屏幕已锁定，已停止录屏').catch(showError);});
  await windows.show('home');
  void windows.prepareCaptures(captureDisplays()).catch(() => { /* Capture can prepare on demand if warmup fails. */ });
}
if (!smoke && !app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (app.isReady() && !captureActivityBusy()) void windows.show('home').catch(showError); });
  app.whenReady().then(main).catch((error) => { if (smoke) console.error(error); else showError(error); app.exit(1); });
  app.on('window-all-closed', () => { /* Keep the tray and global shortcut alive. */ });
  let exitPending=false;
  app.on('before-quit', event => {
    if(!quitting&&videoRecording?.state&&videoRecording.state.status!=='cancelled'){
      event.preventDefault();if(exitPending)return;exitPending=true;
      void(async()=>{
        try{
          await videoRecording.interrupt('应用即将退出，已停止录屏');
          const state=videoRecording.state;
          if(videoRecording.artifact&&!state?.savedName){
            const reply=await dialog.showMessageBox({type:'question',message:'当前录像尚未保存',buttons:['保存并退出','放弃并退出','继续使用'],defaultId:0,cancelId:2});
            if(reply.response===2)return;if(reply.response===0&&!await saveRecording(state!.id))return;
          }
          await videoRecording.cancel();quitting=true;app.quit();
        }catch(error){showError(error);}finally{exitPending=false;}
      })();return;
    }
    quitting=true;
  });
  app.on('will-quit', () => { globalShortcut.unregisterAll(); void longshot?.cancel(); void videoRecording?.cancel();recordingWindow.close(); tasks?.clear(); capture.clear(); windows.disposeCaptures(); detector.dispose(); compositor.dispose(); longshotCompositor.dispose(); pins.dispose(); tray?.destroy(); });
}

function refreshLongshotControls() {
  const state = longshot?.state;
  const active = !!longshot?.active;
  const controllable = active || state?.status === 'error';
  if (!smoke && !quitting) {
    for (const [key, command] of [['Control+Alt+Enter', 'finish'], ['Control+Alt+Escape', 'cancel']] as const) {
      if (controllable && !longshotShortcuts.has(key) && globalShortcut.register(key, () => { const state = longshot.state; if (state) void longshot.command(state.id, command).catch(() => {}); })) longshotShortcuts.add(key);
      if (!controllable && longshotShortcuts.has(key)) { globalShortcut.unregister(key); longshotShortcuts.delete(key); }
    }
  }
  if (!tray || quitting) return;
  tray.setToolTip(controllable ? `AI Screen · 长截图 ${state?.height ?? 0} px\n${state?.message.slice(0, 90) ?? ''}` : 'AI Screen · 屏幕助手');
  trayMenu = Menu.buildFromTemplate([
    ...(controllable ? [
      { label: state?.message ?? '长截图', enabled: false },
      ...(active && state && state.status !== 'finishing' && !state.regionCandidate ? [
        { label: state.paused ? '继续采集' : '暂停采集', click: () => { void longshot.command(state.id, state.paused ? 'resume' : 'pause').catch(() => {}); } },
        ...(state.scrollMode==='auto'?[{ label: '转为手动滚动', click: () => { void longshot.command(state.id, 'manual').catch(() => {}); } }]:[]),
      ] : []),
      { label: `完成长截图${longshotShortcuts.has('Control+Alt+Enter') ? ' · Ctrl+Alt+Enter' : ''}`, enabled: !!state?.canFinish && state.status !== 'finishing', click: () => { if (state) void longshot.command(state.id, 'finish').catch(() => {}); } },
      { label: `取消长截图${longshotShortcuts.has('Control+Alt+Escape') ? ' · Ctrl+Alt+Esc' : ''}`, click: () => { if (state) void longshot.command(state.id, 'cancel').catch(() => {}); } },
    ] : []),
    { label: '框选屏幕', enabled: !captureActivityBusy(), click: () => { void startCapture().catch(showError); } },
    { label: '打开设置', enabled: !captureActivityBusy(), click: () => { void windows.show('home').catch(showError); } },
    { type: 'separator' }, { label: '退出 AI Screen', click: () => app.quit() },
  ]);
  refreshRecordingControls();
}

async function saveRecording(id:string){
  return videoRecording.save(id,async()=>{
    if(smoke)return smokeRecordingSave();
    const format=recordingFormat(videoRecording.artifact!.mimeType);
    const options={title:'保存录像',defaultPath:`录屏-${new Date().toISOString().replace(/[:.]/g,'-')}.${format.extension}`,filters:[{name:`${format.label} 视频`,extensions:[format.extension]}],properties:['showOverwriteConfirmation']as ('showOverwriteConfirmation')[]};
    const win=recordingWindow.get(),reply=win?await dialog.showSaveDialog(win,options):await dialog.showSaveDialog(options);
    return reply.canceled?undefined:reply.filePath;
  });
}
async function closeRecording(id:string){
  const state=videoRecording?.state;if(!state||state.id!==id)throw new Error('录屏会话已失效');
  if(!smoke&&!state.savedName&&(state.elapsedMs>0||videoRecording.artifact)){
    const result=await dialog.showMessageBox({type:'question',message:'放弃本次尚未保存的录像？',buttons:['继续使用','放弃录像'],defaultId:0,cancelId:0});if(result.response!==1)return;
  }
  await videoRecording.cancel();recordingWindow.close();refreshLongshotControls();
}
function refreshRecordingControls(){
  const state=videoRecording?.state,active=!!videoRecording?.active,controllable=!!state&&active;
  const commands=[['Control+Alt+Enter','finish'],['Control+Alt+Space','pause'],['Control+Alt+Escape','cancel']]as const;
  if(!smoke&&!quitting)for(const[key,command]of commands){
    if(controllable&&!recordingShortcuts.has(key)&&!longshotShortcuts.has(key)){
      if(globalShortcut.register(key,()=>{const s=videoRecording.state;if(!s||s.pending||(command!=='cancel'&&!['recording','paused'].includes(s.status)))return;void(command==='cancel'?closeRecording(s.id):videoRecording.command(s.id,command==='pause'&&s.status==='paused'?'resume':command)).catch(showError);}))recordingShortcuts.add(key);
    }
    if(!controllable&&recordingShortcuts.has(key)){globalShortcut.unregister(key);recordingShortcuts.delete(key);}
  }
  const missing=commands.filter(([key])=>!recordingShortcuts.has(key)).map(([key])=>key);
  recordingShortcutWarning=!smoke&&active&&missing.length?`快捷键被占用：${missing.join('、')}；请使用控制条或托盘`:undefined;
  if(!tray||quitting||!active||!state)return;
  tray.setToolTip(`AI Screen · 录屏 ${Math.floor(state.elapsedMs/1000)} 秒`);
  const ready=['recording','paused'].includes(state.status)&&!state.pending;
  trayMenu=Menu.buildFromTemplate([{label:`录屏 ${Math.floor(state.elapsedMs/1000)} 秒`,enabled:false},
    {label:state.status==='paused'?'继续录制':'暂停录制',enabled:ready,click:()=>{void videoRecording.command(state.id,state.status==='paused'?'resume':'pause').catch(showError);}},
    {label:'完成录制',enabled:ready,click:()=>{void videoRecording.command(state.id,'finish').catch(showError);}},
    {label:'取消录制',click:()=>{void closeRecording(state.id).catch(showError);}},{type:'separator'},{label:'退出 AI Screen',click:()=>app.quit()}]);
}
