// Isolated development runner. It saves only a bounded ROI filled by our fixture.
import {app,BrowserWindow,screen,session} from 'electron';
import assert from 'node:assert/strict';
import {mkdir,writeFile,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';
import {RecordingService} from './services/recording/recording-service';
import {ElectronMediaHost} from './services/recording/media-host';
import {LocalVideoFileSink} from './services/recording/video-file-sink';
import {recordingOptionsSchema,type RecordingTarget} from '../shared/recording/contracts';

const root=path.resolve('.runtime/recording-spike');
const output=path.join(root,new Date().toISOString().replace(/[:.]/g,'-'));
app.setPath('userData',path.join(root,'isolated-user-data'));
app.on('window-all-closed',()=>{});
const report: {environment?:unknown;cases:unknown[];failure?:string;checks:Record<string,unknown>}={cases:[],checks:{}};
async function until(predicate:()=>boolean|Promise<boolean>,label:string,ms=15000){
  const end=performance.now()+ms;
  while(!await predicate()){if(performance.now()>end)throw Error(`Recording spike timeout: ${label}`);await delay(40);}
}
function fixtureHTML(){return `<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';script-src 'unsafe-inline';style-src 'unsafe-inline'"><style>body{margin:0;overflow:hidden;background:#555}canvas{display:block}</style><canvas></canvas><script>
  const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d');
  const dpr=devicePixelRatio;canvas.width=Math.round(innerWidth*dpr);canvas.height=Math.round(innerHeight*dpr);canvas.style.width=innerWidth+'px';canvas.style.height=innerHeight+'px';
  ctx.scale(dpr,dpr);window.scene={x:40,y:60,width:400,height:240};const start=performance.now();
  function draw(){const s=window.scene,t=performance.now()-start,count=Math.floor(t/100)%256;
    ctx.fillStyle='#555';ctx.fillRect(0,0,innerWidth,innerHeight);ctx.save();ctx.translate(s.x,s.y);
    ctx.fillStyle='#f7f7fb';ctx.fillRect(0,0,s.width,s.height);
    ctx.fillStyle='hsl('+((t/25)%360)+',70%,45%)';ctx.fillRect(32,40,s.width-64,s.height-100);
    ctx.fillStyle='#ffffff';ctx.fillRect(36+(t/8)%(s.width-100),60,20,40);
    const patches=[[0,0,'#ee2222'],[s.width-20,0,'#22dd22'],[0,s.height-20,'#2233ee'],[s.width-20,s.height-20,'#dddd22']];
    for(const [x,y,c]of patches){ctx.fillStyle=c;ctx.fillRect(x,y,20,20);}
    for(let bit=0;bit<8;bit++){ctx.fillStyle=(count>>bit)&1?'#fff':'#000';ctx.fillRect(16+bit*20,s.height-36,14,14);}
    ctx.fillStyle='#000';ctx.font='14px sans-serif';ctx.fillText('AI Screen controlled recording fixture '+count,26,26);
    ctx.restore();requestAnimationFrame(draw);
  }draw();
</script>`;}
interface PlaybackResult {width:number;height:number;duration:number|null;initialDuration:number|null;samples:{time:number;counter:number;corners:number[][]}[]}
async function inspectVideo(win:BrowserWindow,file:string,times:number[]):Promise<PlaybackResult>{
  await win.loadFile(file);
  return win.webContents.executeJavaScript(`(async()=>{
    const v=document.querySelector('video');
    const wait=(name,action)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('playback '+name+' timeout')),8000);v.addEventListener(name,()=>{clearTimeout(timer);resolve();},{once:true});v.addEventListener('error',()=>{clearTimeout(timer);reject(Error('video decode error '+v.error?.code));},{once:true});action?.();});
    if(v.readyState<1)await wait('loadedmetadata');
    const initialDuration=Number.isFinite(v.duration)?v.duration:null;
    if(!Number.isFinite(v.duration)){await wait('seeked',()=>{v.currentTime=1e8;});}
    const canvas=document.createElement('canvas');canvas.width=v.videoWidth;canvas.height=v.videoHeight;const ctx=canvas.getContext('2d');
    const samples=[];
    for(const time of ${JSON.stringify(times)}){
      await wait('seeked',()=>{v.currentTime=time;});await new Promise(resolve=>setTimeout(resolve,60));ctx.drawImage(v,0,0);
      const pixel=(x,y)=>Array.from(ctx.getImageData(Math.max(0,Math.min(canvas.width-1,Math.round(x))),Math.max(0,Math.min(canvas.height-1,Math.round(y))),1,1).data).slice(0,3);
      const corners=[pixel(8,8),pixel(canvas.width-9,8),pixel(8,canvas.height-9),pixel(canvas.width-9,canvas.height-9)];
      let counter=0;for(let bit=0;bit<8;bit++){const rgb=pixel((23+bit*20)*canvas.width/400,(240-29)*canvas.height/240);if(rgb[0]>128)counter|=1<<bit;}
      samples.push({time:v.currentTime,counter,corners});
    }
    return {width:v.videoWidth,height:v.videoHeight,duration:Number.isFinite(v.duration)?v.duration:null,initialDuration,samples};
  })()`);
}
async function run(){
  await mkdir(output,{recursive:true});
  session.defaultSession.setPermissionCheckHandler(()=>false);
  session.defaultSession.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));
  const display=screen.getPrimaryDisplay(),work=display.workArea;
  report.environment={electron:process.versions.electron,chromium:process.versions.chrome,platform:process.platform,systemVersion:process.getSystemVersion(),hardwareAccelerationDisabled:false,display:{id:String(display.id),bounds:display.bounds,scaleFactor:display.scaleFactor},displayCount:screen.getAllDisplays().length};
  let fixture:BrowserWindow|undefined,playback:BrowserWindow|undefined,current:RecordingService|undefined;
  try{
    assert.ok(work.width>980&&work.height>560,'Display cannot contain controlled fixture and media host');
    fixture=new BrowserWindow({x:work.x+30,y:work.y+30,width:560,height:380,useContentSize:true,frame:false,alwaysOnTop:true,show:false,resizable:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'recording-fixture'}});
    await fixture.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(fixtureHTML())}`);fixture.showInactive();await delay(250);
    const bounds=fixture.getContentBounds();
    const target:RecordingTarget={displayId:String(display.id),displayBounds:display.bounds,scaleFactor:display.scaleFactor,rect:{x:bounds.x-display.bounds.x+40,y:bounds.y-display.bounds.y+60,width:400,height:240}};
    playback=new BrowserWindow({show:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'recording-playback'}});
    const cases=[{id:'hidden-vp8-10s',mime:'video/webm;codecs=vp8',ms:10000,visibility:'hidden'},
      {id:'minimized-vp8-3s',mime:'video/webm;codecs=vp8',ms:3000,visibility:'minimized'},
      {id:'hidden-vp9-3s',mime:'video/webm;codecs=vp9',ms:3000,visibility:'hidden'},
      {id:'hidden-mp4-3s',mime:'video/mp4;codecs=avc1.42001E',ms:3000,visibility:'hidden'}];
    let codecSupport:Record<string,boolean>|undefined;
    for(const item of cases){
      if(codecSupport&&!codecSupport[item.mime]){report.cases.push({...item,status:'unsupported'});continue;}
      console.log(`RECORDING SPIKE START ${item.id}`);
      const host=new ElectronMediaHost();
      current=new RecordingService({backend:()=>host,sink:(id,options)=>LocalVideoFileSink.create(path.join(output,'temporary'),id,options.mimeType),target:()=>target,onState:s=>console.log(`RECORDING ${item.id} ${s.status} ${s.sequence}`)},recordingOptionsSchema.parse({countdownMs:0,mimeType:item.mime}));
      const service=current,controller=new AbortController();
      const starting=service.start({displayId:target.displayId,rect:target.rect,signal:controller.signal});void starting.catch(()=>{});
      await until(async()=>{const win=host.window;if(!win||win.isDestroyed()||!win.webContents.getURL().startsWith('file:'))return false;return win.webContents.executeJavaScript(`!!document.querySelector('#prepare') && !document.querySelector('#prepare').disabled`).catch(()=>false);},'host ready');
      const win=host.window!;win.show();win.focus();
      const point=await win.webContents.executeJavaScript(`(()=>{const r=document.querySelector('#prepare').getBoundingClientRect();return{x:Math.round(r.x+r.width/2),y:Math.round(r.y+r.height/2)}})()`);
      win.webContents.sendInputEvent({type:'mouseDown',button:'left',clickCount:1,...point});win.webContents.sendInputEvent({type:'mouseUp',button:'left',clickCount:1,...point});
      try{
        await starting;assert.equal(service.state?.status,'recording');
        codecSupport=service.state!.media!.codecs;
        assert.equal(host.evidence.selectedDisplayId,target.displayId);assert.equal(host.evidence.sourceEnumerations,1);
        assert.equal(host.evidence.userGesture,true,'media request must originate from trusted host click');
        const repeatDenied=await win.webContents.executeJavaScript(`navigator.mediaDevices.getDisplayMedia({video:true,audio:false}).then(s=>{s.getTracks().forEach(t=>t.stop());return false},()=>true)`,true);
        assert.equal(repeatDenied,true);report.checks.repeatSourceDenied=true;
        if(item.visibility==='minimized')win.minimize();else win.hide();
        await delay(item.ms);
        const stopAt=performance.now();await service.command(service.state!.id,'finish');const stopMs=performance.now()-stopAt;
        const artifact=service.artifact!;assert.ok(artifact.bytes>1000);const extension=artifact.mimeType.startsWith('video/mp4')?'mp4':'webm';
        const saved=path.join(output,`${item.id}.${extension}`);await copyFile(artifact.path,saved);
        const page=path.join(output,'playback.html');await writeFile(page,`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none';media-src 'self';style-src 'unsafe-inline'"><video preload="auto" muted src="./${item.id}.${extension}"></video>`);
        const decoded=await inspectVideo(playback,page,item.ms===10000?[1,5,9]:[.5,1.5,2.5]);
        const info=service.state!.media!;assert.equal(decoded.width,info.width);assert.equal(decoded.height,info.height);
        assert.ok(decoded.initialDuration!==null,'finished file must declare a finite initial duration');
        assert.ok(Math.abs(decoded.initialDuration-artifact.durationMs/1000)<.5,'container and confirmed recording durations must agree');
        const expected=[[238,34,34],[34,221,34],[34,51,238],[221,221,34]];
        for(const sample of decoded.samples)for(let i=0;i<4;i++)for(let c=0;c<3;c++)assert.ok(Math.abs(sample.corners[i][c]-expected[i][c])<45,`ROI corner ${i}/${c}: ${sample.corners[i]}`);
        assert.ok(new Set(decoded.samples.map(sample=>sample.counter)).size>1,'video must contain advancing fixture frames');
        const state=service.state!;
        report.cases.push({...item,status:'passed',artifact:{...artifact,path:path.basename(saved)},media:info,stats:state.stats,stopMs,decoded,source:host.evidence});
        console.log(`RECORDING SPIKE PASS ${item.id} ${info.width}x${info.height} ${state.stats!.frames} frames duration=${decoded.duration} stop=${Math.round(stopMs)}ms`);
      }catch(error){
        report.cases.push({...item,status:'failed',error:error instanceof Error?error.message:String(error),state:service.state,source:host.evidence});
        if(item.mime==='video/webm;codecs=vp8')throw error;
      }finally{await service.cancel();current=undefined;}
    }
    assert.ok(report.cases.length>=2);
    // Test the actual preload/IPC identity from a foreign, sandboxed renderer.
    const rogue=new BrowserWindow({show:false,webPreferences:{preload:path.join(__dirname,'recording-preload.cjs'),sandbox:true,contextIsolation:true,nodeIntegration:false}});
    try{await rogue.loadURL('data:text/html,<p>foreign sender fixture</p>');const denied=await rogue.webContents.executeJavaScript(`window.recordingHost.config().then(()=>false,()=>true)`);assert.equal(denied,true);report.checks.foreignSenderDenied=true;}finally{rogue.destroy();}
  }finally{await current?.cancel();fixture?.destroy();playback?.destroy();}
}
void app.whenReady().then(run).then(async()=>{await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));console.log(`RECORDING REPORT ${path.join(output,'report.json')}`);app.exit(0);}).catch(async(error)=>{
  report.failure=error instanceof Error?error.stack:String(error);console.error(error);await mkdir(output,{recursive:true});await writeFile(path.join(output,'report.json'),JSON.stringify(report,null,2));app.exit(1);
});
