import {app,BrowserWindow,screen,desktopCapturer,nativeImage} from 'electron';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {monitorEventLoopDelay} from 'node:perf_hooks';
import {setTimeout as delay} from 'node:timers/promises';
import {WindowDetector} from './services/window-detector';
import {LiveRegionSource} from './services/live-region-source';
import {isolatedRegionSource} from './services/isolated-region-source';
import {LongshotProcessor} from './services/longshot-processor';
import {StageProfiler,type ProfileSpan} from '../shared/scroll-capture/profiler';
import type {BitmapFrame} from '../shared/scroll-capture/types';
import {NativeCaptureClient} from './services/native-capture-client';
import {toPixelRect} from '../shared/geometry';
import type {Rect} from '../shared/contracts';
const fallbackOnly=process.argv.includes('--fallback-only');
const dimensions=fallbackOnly?[[400,400]]:process.argv.includes('--native-quick')?[[400,400],[800,800],[1600,1000]]:[[400,400],[800,400],[1200,400],[1600,400],[400,800],[800,800],[1200,800],[1600,800],[800,1000],[1200,1000],[1600,1000],[400,500],[1500,900]];
const root=path.resolve('.runtime/longshot-capture-bench');
app.setPath('userData',path.join(root,'profile'));
function texture(x:number,y:number){let n=Math.imul(y+17,1597334677)^Math.imul(x+7,0x119de1f3);return Math.imul(n^(n>>>13),1597334677);}
const p=(values:number[],ratio:number)=>[...values].sort((a,b)=>a-b)[Math.max(0,Math.ceil(values.length*ratio)-1)];
async function run(){
  await mkdir(root,{recursive:true});
  const display=screen.getPrimaryDisplay(),scale=display.scaleFactor,detector=new WindowDetector();
  await detector.warmup();await detector.snapshot();
  const native=detector.getNativeDisplays().find(item=>item.x===display.nativeOrigin.x&&item.y===display.nativeOrigin.y);detector.dispose();assert.ok(native);
  const width=Math.ceil(1640/scale),height=Math.ceil(1040/scale);
  assert.ok(display.workArea.width>=width&&display.workArea.height>=height,'Display too small for this physical-pixel matrix');
  const fixture=new BrowserWindow({x:display.workArea.x,y:display.workArea.y,width,height,frame:false,useContentSize:true,show:false,
    alwaysOnTop:true,skipTaskbar:true,movable:false,resizable:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'capture-bench'}});
  fixture.webContents.setWindowOpenHandler(()=>({action:'deny'}));fixture.webContents.on('will-navigate',event=>event.preventDefault());
  fixture.webContents.session.setPermissionRequestHandler((_c,_p,cb)=>cb(false));
  const html=`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'"><style>body{margin:0;overflow:hidden}#view{position:absolute;top:0;left:0;overflow:hidden}canvas{display:block}::-webkit-scrollbar{display:none}</style><div id="view"><canvas id="scene"></canvas></div><script>
    const texture=${texture.toString()};window.configure=(w,h)=>{const canvas=document.getElementById('scene'),view=document.getElementById('view');canvas.width=w;canvas.height=h+600;canvas.style.width=w/devicePixelRatio+'px';canvas.style.height=canvas.height/devicePixelRatio+'px';view.style.width=w/devicePixelRatio+'px';view.style.height=h/devicePixelRatio+'px';const ctx=canvas.getContext('2d'),im=ctx.createImageData(w,canvas.height);for(let y=0;y<canvas.height;y++)for(let x=0;x<w;x++){const n=texture(x,y),i=(y*w+x)*4;im.data[i]=n>>>16&255;im.data[i+1]=n>>>8&255;im.data[i+2]=n&255;im.data[i+3]=255;}ctx.putImageData(im,0,0);view.scrollTop=0;};window.shift=value=>{const view=document.getElementById('view');view.scrollTop=value/devicePixelRatio;return view.scrollTop*devicePixelRatio;};</script>`;
  try{
    await fixture.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(html)}`);fixture.webContents.setZoomFactor(1);fixture.showInactive();fixture.moveTop();
    const results=[];
    for(const [w,h] of dimensions){
      await fixture.webContents.executeJavaScript(`window.configure(${w},${h})`);
      const point=screen.dipToScreenPoint(fixture.getContentBounds());
      const rect:Rect={x:(point.x-native.x+.1)*display.bounds.width/native.width,y:(point.y-native.y+.1)*display.bounds.height/native.height,
        width:(w-.2)*display.bounds.width/native.width,height:(h-.2)*display.bounds.height/native.height};
      const reference:Buffer[]=[];
      const modes=fallbackOnly?(['inline','native-missing'] as const):(['inline','isolated','native-direct','native-isolated'] as const);
      for(const mode of modes){
        const spans:ProfileSpan[]=[],profiler=new StageProfiler(span=>spans.push(span));
        const dependencies={displays:()=>[{id:String(display.id),label:'',bounds:display.bounds,scaleFactor:scale}],nativeSize:()=>native,profiler};
        const pixels=toPixelRect(rect,display.bounds,native);
        const nativeClient=mode==='native-direct'?new NativeCaptureClient(path.join(__dirname,'native-capture.exe'),{...pixels,x:native.x+pixels.x,y:native.y+pixels.y},{x:native.x,y:native.y,width:native.width,height:native.height}):undefined;
        const source:Pick<LiveRegionSource,'read'|'dispose'|'backend'>=mode==='inline'?new LiveRegionSource(String(display.id),rect,{...dependencies,sources:thumbnailSize=>desktopCapturer.getSources({types:['screen'],thumbnailSize})})
          :nativeClient?{backend:'gdi-roi' as const,read:async(signal:AbortSignal)=>{const frame=await nativeClient.read(signal);return nativeImage.createFromBitmap(Buffer.from(frame.data),{width:frame.width,height:frame.height});},dispose:()=>nativeClient.dispose()}
          :isolatedRegionSource(String(display.id),rect,{...dependencies,backend:mode==='isolated'?'electron-snapshot':'gdi-roi',entryPath:path.join(__dirname,mode==='native-missing'?'fallback/capture-bootstrap.cjs':'capture-bootstrap.cjs')});
        const processor=new LongshotProcessor({profiler}),abort=new AbortController(),loop=monitorEventLoopDelay({resolution:10});
        const captureMs:number[]=[],processMs:number[]=[],frames:BitmapFrame[]=[];
        let startupMs=0,added=0;
        try{
          await fixture.webContents.executeJavaScript('window.shift(0)');await delay(100);
          const warm=performance.now();await source.read(abort.signal);startupMs=performance.now()-warm;spans.length=0;
          assert.equal(source.backend,mode==='inline'||mode==='isolated'||mode==='native-missing'?'electron-snapshot':'gdi-roi');
          loop.enable();const started=performance.now(),cpu=process.cpuUsage();
          for(let index=0;index<4;index++){
            assert.equal(await fixture.webContents.executeJavaScript(`window.shift(${index*120})`),index*120);
            await fixture.webContents.executeJavaScript('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');await delay(50);
            const captureStarted=performance.now(),image=await source.read(abort.signal);
            const frame={...image.getSize(),data:new Uint8Array(image.toBitmap())};captureMs.push(performance.now()-captureStarted);frames.push(frame);
            const processStarted=performance.now(),result=await processor.push(frame);processMs.push(performance.now()-processStarted);
            if(index===0)assert.equal(result.kind,'initial');else{assert.equal(result.kind,'appended');assert.equal(result.viewportDelta,120);added+=result.appendedRows;}
          }
          const elapsedMs=performance.now()-started,usage=process.cpuUsage(cpu);loop.disable();
          for(let index=0;index<frames.length;index++){
            const frame=frames[index];assert.equal(frame.width,w);assert.equal(frame.height,h);
            if(mode==='inline')reference.push(Buffer.from(frame.data));else assert.deepEqual(Buffer.from(frame.data),reference[index],'isolated source changed native pixels');
          }
          const output=await processor.bitmap();assert.equal(output.width,w);assert.equal(output.height,h+360);
          for(let index=0;index<4;index++){
            const from=index*120*w*4;assert.deepEqual(output.data.subarray(from,from+w*h*4),frames[index].data,'output differs from captured source pixels');
          }
          const summary={w,h,mode,backend:source.backend,samples:4,transitions:3,addedRows:added,sourcePixelCorrect:true,outputPixelCorrect:true,startupFirstReadMs:startupMs,
            captureP50Ms:p(captureMs,.5),captureP95Ms:p(captureMs,.95),processingP50Ms:p(processMs,.5),
            fixtureEffectiveNewRowsPerSecond:added*1000/elapsedMs,fixtureElapsedMs:elapsedMs,
            mainEventLoop:{p95Ms:loop.percentile(95)/1e6,maxMs:loop.max/1e6},mainCpuMs:(usage.user+usage.system)/1000,
            observedMainRssBytes:process.memoryUsage().rss,
            stages:Object.fromEntries([...new Set(spans.map(span=>span.stage))].map(stage=>{const values=spans.filter(span=>span.stage===stage).map(span=>span.durationMs);return[stage,{count:values.length,p50Ms:p(values,.5),p95Ms:p(values,.95)}];}))};
          results.push(summary);console.log(JSON.stringify(summary));
        }finally{loop.disable();source.dispose();processor.dispose();}
      }
    }
    const output=path.join(root,`${new Date().toISOString().replace(/[:.]/g,'-')}.json`);
    await writeFile(output,JSON.stringify({conditions:{display:{width:native.width,height:native.height,scale},framesPerMode:4,warmupReads:1,
      fixtureOnly:true,rawFramesSaved:false,realApps:false,progressIncludesFixturePainting:true,resources:'main process only; helper and GPU RSS are separate'},results},null,2));
    console.log(`CAPTURE_BENCH_REPORT ${output}`);
  }finally{fixture.destroy();}
}
app.whenReady().then(run).then(()=>app.exit(0),error=>{console.error(error);app.exit(1);});
