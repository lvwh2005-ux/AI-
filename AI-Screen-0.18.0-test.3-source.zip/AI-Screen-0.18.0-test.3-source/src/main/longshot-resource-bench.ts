import {app,BrowserWindow,screen} from 'electron';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {setTimeout as delay} from 'node:timers/promises';
import {monitorEventLoopDelay} from 'node:perf_hooks';
import {WindowDetector} from './services/window-detector';
import {isolatedRegionSource} from './services/isolated-region-source';
import {LongshotProcessor} from './services/longshot-processor';
import {CapturePipeline} from './services/capture-pipeline';
import {PreviewPump} from './services/preview-pump';
import type {BitmapFrame} from '../shared/scroll-capture/types';
import {PREVIEW_INTERVAL_MS} from '../shared/scroll-capture/preview';
const root=process.env.LONGSHOT_RESOURCE_ROOT!;
app.setPath('userData',path.join(root,'profile'));
const travel=4800;
function texture(x:number,y:number){let n=Math.imul(y+17,1597334677)^Math.imul(x+7,0x119de1f3);return Math.imul(n^(n>>>13),1597334677);}
const p=(values:number[],ratio:number)=>[...values].sort((a,b)=>a-b)[Math.max(0,Math.ceil(values.length*ratio)-1)];
async function stage(stage:string){await writeFile(path.join(root,'stage.json'),JSON.stringify({stage}));console.log('RESOURCE_STAGE '+stage);}
async function run(){
  await mkdir(root,{recursive:true});
  const display=screen.getPrimaryDisplay(),scale=display.scaleFactor,detector=new WindowDetector();await detector.warmup();await detector.snapshot();
  const native=detector.getNativeDisplays().find(item=>item.x===display.nativeOrigin.x&&item.y===display.nativeOrigin.y);detector.dispose();assert.ok(native);
  const fixture=new BrowserWindow({x:display.workArea.x,y:display.workArea.y,width:Math.ceil(1640/scale),height:Math.ceil(1040/scale),frame:false,show:false,alwaysOnTop:true,skipTaskbar:true,movable:false,resizable:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false,backgroundThrottling:false,partition:'resource-bench'}});
  fixture.webContents.setWindowOpenHandler(()=>({action:'deny'}));fixture.webContents.on('will-navigate',event=>event.preventDefault());fixture.webContents.session.setPermissionRequestHandler((_c,_p,cb)=>cb(false));
  const html=`<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'"><style>body{margin:0;overflow:hidden}#view{position:absolute;top:0;left:0;overflow:hidden}canvas{display:block}</style><div id="view"><canvas id="scene"></canvas></div><script>const texture=${texture.toString()};window.configure=(w,h)=>{const c=document.getElementById('scene'),v=document.getElementById('view');c.width=w;c.height=h+${travel};c.style.width=w/devicePixelRatio+'px';c.style.height=c.height/devicePixelRatio+'px';v.style.width=w/devicePixelRatio+'px';v.style.height=h/devicePixelRatio+'px';const ctx=c.getContext('2d'),im=ctx.createImageData(w,c.height);for(let y=0;y<c.height;y++)for(let x=0;x<w;x++){const n=texture(x,y),i=(y*w+x)*4;im.data[i]=n>>>16&255;im.data[i+1]=n>>>8&255;im.data[i+2]=n&255;im.data[i+3]=255;}ctx.putImageData(im,0,0);v.scrollTop=0;};window.shift=value=>{const v=document.getElementById('view');v.scrollTop=value/devicePixelRatio;return v.scrollTop*devicePixelRatio;};</script>`;
  const results=[];
  function source(w:number,h:number){
    const point=screen.dipToScreenPoint(fixture.getContentBounds());
    const rect={x:(point.x-native!.x+.1)*display.bounds.width/native!.width,y:(point.y-native!.y+.1)*display.bounds.height/native!.height,width:(w-.2)*display.bounds.width/native!.width,height:(h-.2)*display.bounds.height/native!.height};
    return isolatedRegionSource(String(display.id),rect,{displays:()=>[{id:String(display.id),label:'',bounds:display.bounds,scaleFactor:scale}],nativeSize:()=>native,entryPath:path.join(__dirname,'capture-bootstrap.cjs')});
  }
  try{
    await fixture.loadURL('data:text/html;charset=UTF-8,'+encodeURIComponent(html));fixture.showInactive();fixture.moveTop();
    await fixture.webContents.executeJavaScript('window.configure(400,400)');
    await stage('idle-before');await delay(15000);
    for(const [w,h,seconds]of [[400,400,60],[800,800,60],[1600,1000,300]]){
      await fixture.webContents.executeJavaScript(`window.configure(${w},${h})`);await delay(100);
      await stage(`capture-${w}x${h}-${seconds}s`);
      const capture=source(w,h),processor=new LongshotProcessor(),abort=new AbortController();let failure:unknown;
      let processed=0,appended=0,duplicates=0,offset=0,direction=1,maxSeen=0,addedRows=0,previews=0;
      const readMs:number[]=[],matchMs:number[]=[],endToEndMs:number[]=[],previewMs:number[]=[];
      const loop=monitorEventLoopDelay({resolution:10});loop.enable();
      const pump=new PreviewPump(PREVIEW_INTERVAL_MS,async()=>{const start=performance.now(),bundle=await processor.preview({width:900,height:700});await processor.encodePreview(bundle.detail===bundle.overview?[bundle.overview]:[bundle.overview,bundle.detail]);previews++;previewMs.push(performance.now()-start);},error=>{failure=error;});
      const pipeline=new CapturePipeline<BitmapFrame&{captured:number;position:number}>({maxFrames:3,maxBytes:64*1024*1024,maxFrameBytes:128*1024*1024,bytes:frame=>frame.data.length,
        consume:async frame=>{const start=performance.now(),result=await processor.push(frame);matchMs.push(performance.now()-start);endToEndMs.push(performance.now()-frame.captured);
          assert.ok(['initial','appended','duplicate'].includes(result.kind),JSON.stringify(result));if(!processed)assert.equal(result.kind,'initial');
          processed++;if(result.kind==='appended'){appended++;addedRows+=result.appendedRows;}if(result.kind==='duplicate')duplicates++;pump.request();},failed:error=>{failure=error;}});
      const started=performance.now();let lastProgress=started;
      try{
        while(performance.now()-started<seconds*1000&&!failure){
          const position=offset;
          await pipeline.capture(w*h*4,async()=>{
            assert.equal(await fixture.webContents.executeJavaScript(`window.shift(${position})`),position);
            await fixture.webContents.executeJavaScript('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))');
            const begin=performance.now(),image=await capture.read(abort.signal);readMs.push(performance.now()-begin);
            assert.equal(capture.backend,'gdi-roi','Resource run must use the requested native backend');
            const frame={...image.getSize(),data:new Uint8Array(image.toBitmap()),captured:begin,position};assert.equal(frame.width,w);assert.equal(frame.height,h);return frame;
          });
          maxSeen=Math.max(maxSeen,position);if(offset===travel)direction=-1;if(!offset)direction=1;offset+=direction*120;
          if(performance.now()-lastProgress>15000){console.log('RESOURCE_PROGRESS '+JSON.stringify({w,h,seconds:Math.round((performance.now()-started)/1000),processed,addedRows,queue:pipeline.stats}));lastProgress=performance.now();}
        }
        pipeline.seal();await pipeline.idle();pump.stop();await pump.idle();if(failure)throw failure;
        const output=await processor.bitmap();assert.equal(output.width,w);assert.equal(output.height,h+maxSeen);
        const words=new Uint32Array(output.data.buffer,output.data.byteOffset,output.data.byteLength/4);
        for(let y=0;y<output.height;y++)for(let x=0;x<w;x++)assert.equal(words[y*w+x],(texture(x,y)&0xffffff|0xff000000)>>>0,`source pixel ${x},${y}`);
        const elapsedMs=performance.now()-started;
        results.push({w,h,backend:capture.backend,targetSeconds:seconds,elapsedMs,processed,appended,duplicates,addedRows,previews,pixelCorrect:true,maxSeen,
          capturedFps:readMs.length*1000/elapsedMs,effectiveNewRowsPerSecond:addedRows*1000/elapsedMs,queue:pipeline.stats,
          capture:{p50:p(readMs,.5),p95:p(readMs,.95)},match:{p50:p(matchMs,.5),p95:p(matchMs,.95)},endToEnd:{p50:p(endToEndMs,.5),p95:p(endToEndMs,.95)},preview:{p50:p(previewMs,.5),p95:p(previewMs,.95)},eventLoop:{p95Ms:loop.percentile(95)/1e6,maxMs:loop.max/1e6}});
      }finally{loop.disable();abort.abort();pipeline.close();pump.stop();capture.dispose();processor.dispose();}
    }
    await stage('cancel-restart-12');await fixture.webContents.executeJavaScript('window.configure(400,400)');
    for(let i=0;i<12;i++){
      const capture=source(400,400),processor=new LongshotProcessor(),abort=new AbortController();
      try{const first=await capture.read(abort.signal);assert.equal((await processor.push({...first.getSize(),data:first.toBitmap()})).kind,'initial');
        const reading=capture.read(abort.signal);const rejected=assert.rejects(reading,/取消|结束|abort/i);setImmediate(()=>abort.abort());await rejected;
      }finally{abort.abort();capture.dispose();processor.dispose();}
    }
    await stage('idle-recovery');await delay(30000);
    await writeFile(path.join(root,'benchmark.json'),JSON.stringify({conditions:{nativeCapture:true,backend:'gdi-roi',syntheticOnly:true,rawFramesSaved:false,display:{width:native.width,height:native.height,scale},physicalInput:false,loops:'120px forward/backward within fixed 4800px coverage; later revisits add no new rows',previewIntervalMs:PREVIEW_INTERVAL_MS},results,cancelRestartSessions:12},null,2));
    console.log('RESOURCE_NATIVE_PASS '+JSON.stringify({cases:results.length,frames:results.reduce((n,item)=>n+item.processed,0),cancelRestart:12}));
  }finally{fixture.destroy();}
}
app.whenReady().then(run).then(()=>app.exit(0),async error=>{console.error(error);await writeFile(path.join(root,'failure.txt'),String(error)).catch(()=>{});app.exit(1);});
