export interface PipelineStats {
  bufferedFrames: number; bufferedBytes: number; queuedFrames: number;
  peakFrames: number; peakBytes: number; backpressureWaits: number; waitingForSpace: boolean;
}
interface Entry<T> { value: T; bytes: number }
export class CaptureBufferError extends Error {
  constructor(message: string, readonly issue: 'capacity'|'size-changed') { super(message); }
}

/** One producer, one ordered consumer. Reservations include the current read
 * and consumer, so prefetch cannot grow without bound while matching is slow.
 * A single oversized (but allowed) frame falls back to serial processing. */
export class CapturePipeline<T> {
  private queue: Entry<T>[] = [];
  private readingBytes = 0;
  private consuming?: Entry<T>;
  private sealed = false;
  private closed = false;
  private failure?: unknown;
  private listeners = new Set<() => void>();
  private peakFrames = 0;
  private peakBytes = 0;
  private backpressureWaits = 0;
  private waitingForSpace = false;

  constructor(private options: {
    maxFrames: number; maxBytes: number; maxFrameBytes: number;
    bytes(value: T): number;
    consume(value: T): Promise<unknown>;
    changed?(stats: PipelineStats): void;
    discarded?(count: number): void;
    failed(error: unknown): void;
  }) {}
  get accepting() { return !this.sealed; }
  /** Capacity check before issuing a controlled scroll. No reservation or
   * mutation: the single producer still reserves through capture(). */
  canCapture(bytes:number){
    return !this.sealed&&Number.isSafeInteger(bytes)&&bytes>0&&bytes<=this.options.maxFrameBytes
      &&this.stats.bufferedFrames<this.options.maxFrames&&this.stats.bufferedBytes+bytes<=Math.max(this.options.maxBytes,bytes);
  }

  get stats(): PipelineStats {
    return {
      bufferedFrames: this.queue.length + Number(!!this.consuming) + Number(this.readingBytes > 0),
      bufferedBytes: this.queue.reduce((sum, entry) => sum + entry.bytes, 0) + (this.consuming?.bytes ?? 0) + this.readingBytes,
      queuedFrames: this.queue.length, peakFrames: this.peakFrames, peakBytes: this.peakBytes,
      backpressureWaits: this.backpressureWaits, waitingForSpace: this.waitingForSpace,
    };
  }

  async capture(bytes: number, read: () => Promise<T | undefined>): Promise<void> {
    if (!Number.isSafeInteger(bytes) || bytes <= 0 || bytes > this.options.maxFrameBytes) throw new CaptureBufferError('采集帧超过缓冲容量，请缩小选区', 'capacity');
    if (this.readingBytes) throw new Error('不能并发读取同一截图帧源');
    const fits = () => this.stats.bufferedFrames < this.options.maxFrames
      && this.stats.bufferedBytes + bytes <= Math.max(this.options.maxBytes, bytes);
    if (!this.sealed && !fits()) {
      this.backpressureWaits++; this.waitingForSpace = true; this.changed();
      while (!this.sealed && !fits()) await this.change();
      this.waitingForSpace = false; this.changed();
    }
    if (this.sealed) return;
    this.readingBytes = bytes; this.changed();
    try {
      const value = await read();
      if (value === undefined) return;
      if (this.closed) { this.options.discarded?.(1); return; }
      // A changed display/frame size must not silently overrun the reservation.
      const actual = this.options.bytes(value);
      if (actual !== bytes) throw new CaptureBufferError('采集帧尺寸已变化，请重新框选', 'size-changed');
      this.queue.push({value, bytes});
    } catch (error) {
      this.close(); throw error;
    } finally {
      this.readingBytes = 0; this.changed(); this.pump();
    }
  }

  discardQueued() {
    const count = this.queue.length; this.queue = [];
    if (count) this.options.discarded?.(count);
    this.changed();
  }
  /** Stop producing; retain ordered frames for Done to drain. */
  seal() { this.sealed = true; this.changed(); }
  /** Cancel/failure: drop waiting frames; an already submitted consumer drains. */
  close() { this.closed = true; this.sealed = true; this.discardQueued(); }
  async idle() {
    while (this.stats.bufferedFrames) await this.change();
    if (this.failure) throw this.failure;
  }
  async consumerIdle() { while (this.consuming) await this.change(); }
  private pump() {
    if (this.closed || this.consuming || !this.queue.length) return;
    const entry = this.queue.shift()!; this.consuming = entry; this.changed();
    void Promise.resolve().then(() => this.options.consume(entry.value)).catch((error: unknown) => {
      this.failure = error; this.close(); this.options.failed(error);
    }).finally(() => { this.consuming = undefined; this.changed(); this.pump(); });
  }
  private change() { return new Promise<void>((resolve) => this.listeners.add(resolve)); }
  private changed() {
    const stats = this.stats;
    this.peakFrames = Math.max(this.peakFrames, stats.bufferedFrames);
    this.peakBytes = Math.max(this.peakBytes, stats.bufferedBytes);
    for (const resolve of this.listeners) resolve(); this.listeners.clear();
    this.options.changed?.(this.stats);
  }
}
