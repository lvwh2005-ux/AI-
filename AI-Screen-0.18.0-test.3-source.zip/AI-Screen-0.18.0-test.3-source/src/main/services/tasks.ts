import { randomUUID } from 'node:crypto';
import type { AIAction, ResultProgress, ResultState, Settings, Turn } from '../../shared/contracts';
import { actions } from '../../shared/actions';
import { CompatibleProvider } from '../providers/compatible';
import { DemoProvider } from '../providers/demo';
import type { SettingsStore } from './settings';
import type { AIProvider, OCRProvider } from '../providers/types';
import { customAction, expandPrompt } from '../../shared/custom-actions';

export class TaskService {
  state: ResultState | null = null;
  private controller?: AbortController;
  constructor(
    private settings: Pick<SettingsStore, 'value' | 'apiKey'>,
    private publish: (state: ResultState) => void,
    private copyText: (text: string) => Promise<void>,
    private createProvider?: (config: Settings) => AIProvider | Promise<AIProvider>,
    private localOCR?: OCRProvider,
    private publishProgress?: (progress: ResultProgress) => void,
  ) {}
  cancel() {
    this.controller?.abort();
    this.controller = undefined;
    if (this.state?.status === 'loading') {
      this.state = { ...this.state, status: 'cancelled', text: this.state.text || '请求已取消。可以重新提问。' };
      this.publish(this.state);
    }
  }
  clear() { this.cancel(); this.state = null; }
  async run(action: AIAction, image: string, question: string, followup: boolean, customActionId?: string) {
    this.cancel();
    const controller = new AbortController();
    this.controller = controller;
    const config = { ...this.settings.value };
    const local = action === 'ocr' && config.ocr === 'windows';
    const demo = !local && config.provider === 'demo';
    const history: Turn[] = followup ? (this.state?.history ?? []) : [];
    const requestId = randomUUID();
    const selected = action === 'custom' ? config.customActions.find((item) => item.id === customActionId && item.enabled) : undefined;
    const actionLabel = selected?.label ?? actions.find((item) => item.id === action)?.label ?? '自定义动作';
    this.state = { requestId, source: local ? 'local-ocr' : demo ? 'demo' : 'ai', action, actionLabel, customActionId, image, question, demo, history, status: 'loading', text: '' };
    this.publish(this.state);
    try {
      const customPrompt = action === 'custom' ? expandPrompt(customAction(config.customActions, customActionId).prompt, config.language, question) : undefined;
      const provider = local ? undefined : this.createProvider ? await this.createProvider(config)
        : demo ? new DemoProvider() : new CompatibleProvider({ ...config, apiKey: await this.settings.apiKey() });
      if (controller.signal.aborted) return;
      const onProgress = (text: string) => {
        if (controller !== this.controller || !this.state) return;
        this.state = { ...this.state, text };
        this.publishProgress?.({ requestId, text });
      };
      let text: string;
      if (local) {
        if (!this.localOCR) throw new Error('本地 OCR 不可用');
        text = await this.localOCR.recognize(image, controller.signal);
      } else {
        text = await provider!.complete({ action, image, question, customPrompt, history: action === 'ocr' ? [] : history, language: config.language, signal: controller.signal, onProgress: config.stream ? onProgress : undefined });
      }
      if (!text.trim()) throw new Error('未识别到文字，请重新框选清晰的文本区域');
      if (controller !== this.controller) return;
      if (action === 'ocr' && !demo) await this.copyText(text);
      if (controller !== this.controller) return;
      const userText = customPrompt || question || actionLabel;
      this.state = { ...this.state!, status: 'done', text, history: [...history, { role: 'user', content: userText }, { role: 'assistant', content: text }].slice(-12) as Turn[] };
    } catch (error) {
      if (controller !== this.controller) return;
      this.state = { ...this.state!, status: 'error', text: error instanceof Error ? error.message : '处理失败，请重试' };
    } finally {
      if (controller === this.controller) { this.controller = undefined; this.publish(this.state!); }
    }
  }
}
