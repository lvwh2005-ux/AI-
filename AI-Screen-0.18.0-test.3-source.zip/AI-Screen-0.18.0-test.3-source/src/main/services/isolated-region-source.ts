import {nativeImage} from 'electron';
import type {Rect} from '../../shared/contracts';
import type {CaptureDisplay} from '../../shared/geometry';
import {profiled,type StageProfiler} from '../../shared/scroll-capture/profiler';
import {LiveRegionSource} from './live-region-source';
import {CaptureProcessClient} from './capture-process-client';
import type {CaptureBackend} from '../../shared/longshot';
export function isolatedRegionSource(displayId:string,rect:Rect,dependencies:{
  displays():readonly CaptureDisplay[];nativeSize(display:CaptureDisplay):{width:number;height:number}|undefined;
  profiler?:StageProfiler;entryPath?:string;
  backend?:CaptureBackend;
}){
  let client:CaptureProcessClient|undefined;
  return new LiveRegionSource(displayId,rect,{
    ...dependencies,
    sources:async()=>{throw new Error('独立采集不在应用主进程枚举图像');},
    remoteRetries:()=>client?.retryCount??0,close:()=>client?.dispose(),
    backend:()=>client?.backend,
    readRegion:async signal=>{
      if(!client){
        const display=dependencies.displays().find(display=>display.id===displayId),nativeSize=display&&dependencies.nativeSize(display);
        if(!display||!nativeSize)throw new Error('长截图显示器信息已变化');
        client=new CaptureProcessClient({displayId,display:{id:display.id,bounds:{...display.bounds},scaleFactor:display.scaleFactor},
          rect:{x:rect.x,y:rect.y,width:rect.width,height:rect.height},
          nativeSize:{width:nativeSize.width,height:nativeSize.height},profiling:!!dependencies.profiler,
          backend:dependencies.backend??(process.env.AI_SCREEN_CAPTURE_BACKEND==='snapshot'?'electron-snapshot':'gdi-roi')},
          {entryPath:dependencies.entryPath,profiler:dependencies.profiler});
      }
      const frame=await client.read(signal);
      const image=profiled(dependencies.profiler,'capture-client-image',()=>nativeImage.createFromBitmap(
        Buffer.from(frame.data.buffer,frame.data.byteOffset,frame.data.byteLength),{width:frame.width,height:frame.height}));
      return{image,bitmapSize:frame.bitmapSize};
    },
  });
}
