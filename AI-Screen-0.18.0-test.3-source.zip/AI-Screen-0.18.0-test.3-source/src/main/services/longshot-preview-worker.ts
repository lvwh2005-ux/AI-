import {parentPort} from 'node:worker_threads';
import type {BitmapFrame} from '../../shared/scroll-capture/types';
import {snapshotPreviews,snapshotViewport,type PreviewSnapshot} from '../../shared/scroll-capture/preview-snapshot';
import type {PreviewSize} from '../../shared/scroll-capture/preview';
import type {ViewportRequest} from '../../shared/scroll-capture/preview-viewport';
import {previewPNG} from './preview-png';
parentPort!.on('message',(message:{operation:string;frames?:BitmapFrame[];snapshot?:PreviewSnapshot;size?:PreviewSize;view?:ViewportRequest})=>{
  try{
    const startedMs=performance.now();let result:unknown,transfer:ArrayBuffer[]=[],stage='preview-sample-cpu';
    if(message.operation==='encode'){
      if(!Array.isArray(message.frames)||message.frames.length<1||message.frames.length>3)throw new Error('预览数量超出预算');
      stage='preview-encode-cpu';
      const encoded:{frame:BitmapFrame;bytes:Buffer;image:string}[]=[];
      result=message.frames.map(frame=>{
        const bytes=Buffer.from(frame.data.buffer,frame.data.byteOffset,frame.data.byteLength);
        const same=encoded.find(item=>item.frame.width===frame.width&&item.frame.height===frame.height&&item.bytes.equals(bytes));
        if(same)return same.image;
        const image=`data:image/png;base64,${previewPNG(frame).toString('base64')}`;encoded.push({frame,bytes,image});return image;
      });
    }else{
      const snapshot=message.snapshot;
      if(!snapshot||snapshot.parts.some(part=>!(part.buffer instanceof SharedArrayBuffer)))throw new Error('预览文档必须使用已提交的共享像素段');
      if(message.operation==='preview'&&message.size){
        const bundle=snapshotPreviews(snapshot,message.size,message.view);result=bundle;
        transfer=[...new Set([bundle.overview.data.buffer as ArrayBuffer,bundle.detail.data.buffer as ArrayBuffer,...(bundle.viewport?[bundle.viewport.frame.data.buffer as ArrayBuffer]:[])])];
      }else if(message.operation==='viewport'&&message.view){
        const view=snapshotViewport(snapshot,message.view);result=view;transfer=[view.frame.data.buffer as ArrayBuffer];
      }else throw new Error('预览操作无效');
    }
    parentPort!.postMessage({result,startedMs,durationMs:performance.now()-startedMs,stage},transfer);
  }catch{parentPort!.postMessage({error:'预览处理失败'});}
});
