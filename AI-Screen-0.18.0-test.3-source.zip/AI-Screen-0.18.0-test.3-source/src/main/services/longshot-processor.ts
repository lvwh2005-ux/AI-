import { Worker } from 'node:worker_threads';
import path from 'node:path';
import type { BitmapFrame, StitchResult } from '../../shared/longshot-stitcher';
import { LONGSHOT_LIMITS } from '../../shared/longshot-limits';
import type { PreviewBundle, PreviewSize } from '../../shared/scroll-capture/preview';
import type { ViewportRequest, ViewportBitmap } from '../../shared/scroll-capture/preview-viewport';
import { profiled, type StageProfiler, type ProfileSpan } from '../../shared/scroll-capture/profiler';
import {LongshotPreviewEncoder} from './longshot-preview-encoder';
import type {PreviewSnapshot} from '../../shared/scroll-capture/preview-snapshot';

export { LONGSHOT_LIMITS } from '../../shared/longshot-limits';
export class LongshotProcessor {
  private worker: Worker;
  private nextId = 0;
  private disposed = false;
  private previewEncoder?:LongshotPreviewEncoder;
  private snapshot?:PreviewSnapshot;
  get available() { return !this.disposed; }
  private pending = new Map<number, { resolve(value: unknown): void; reject(error: Error): void; timer: NodeJS.Timeout }>();
  constructor(private options: {profiler?:StageProfiler;previewWorker?:()=>Worker} = {}) {
    this.worker = new Worker(path.join(__dirname, 'longshot-worker.cjs'), { workerData: {...LONGSHOT_LIMITS,profiling:!!options.profiler} });
    this.worker.on('message', (reply: { id: number; result?: unknown; error?: string; profile?:ProfileSpan[];snapshot?:PreviewSnapshot }) => {
      const pending = this.pending.get(reply.id);
      if (!pending) return;
      this.pending.delete(reply.id); clearTimeout(pending.timer);
      if (reply.profile) this.options.profiler?.observe(reply.profile);
      if(reply.snapshot)this.snapshot=reply.snapshot;
      if (reply.error) pending.reject(new Error(reply.error)); else pending.resolve(reply.result);
    });
    this.worker.on('error', () => this.dispose(new Error('长截图处理线程异常，请重新开始')));
    this.worker.on('exit', () => { if (!this.disposed) this.dispose(new Error('长截图处理线程已退出')); });
  }
  push(frame: BitmapFrame): Promise<StitchResult> {
    // Own a transferable buffer: never detach Electron's native bitmap storage.
    const data = profiled(this.options.profiler,'worker-transfer-copy',()=>new Uint8Array(frame.data),{requestId:this.nextId+1});
    return this.request('push', { ...frame, data }, [data.buffer]);
  }
  bitmap(): Promise<BitmapFrame> { return this.request('bitmap'); }
  private encoder(){
    this.previewEncoder??=new LongshotPreviewEncoder(this.options.profiler?span=>this.options.profiler!.observe([span]):undefined,this.options.previewWorker);
    return this.previewEncoder;
  }
  preview(size: PreviewSize, view?: ViewportRequest): Promise<PreviewBundle> {
    if(this.disposed||!this.snapshot)return Promise.reject(new Error('尚无可预览的长图'));
    return this.encoder().preview(this.snapshot,size,view);
  }
  viewport(view: ViewportRequest): Promise<ViewportBitmap> {
    if(this.disposed||!this.snapshot)return Promise.reject(new Error('尚无可预览的长图'));
    return this.encoder().viewport(this.snapshot,view);
  }
  encodePreview(frames:BitmapFrame[]):Promise<string[]>{
    if(this.disposed)return Promise.reject(new Error('长截图处理已结束'));
    const run=()=>this.encoder().encode(frames);
    return this.options.profiler?this.options.profiler.measureAsync('preview-encode-roundtrip',run):run();
  }
  confirmRegion(): Promise<StitchResult> { return this.request('confirm-region'); }
  keepRegion(): Promise<StitchResult> { return this.request('keep-region'); }
  dispose(error = new Error('长截图已取消')) {
    if (this.disposed) return;
    this.disposed = true;
    this.snapshot=undefined;
    this.previewEncoder?.dispose();
    for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(error); }
    this.pending.clear(); void this.worker.terminate();
  }
  private request<T>(operation: string, frame?: BitmapFrame, transfer: ArrayBuffer[] = [], size?: PreviewSize, view?: ViewportRequest): Promise<T> {
    const run=()=>this.send<T>(operation,frame,transfer,size,view);
    return this.options.profiler ? this.options.profiler.measureAsync(`worker-roundtrip-${operation}`,run,{requestId:this.nextId+1}) : run();
  }
  private send<T>(operation: string, frame?: BitmapFrame, transfer: ArrayBuffer[] = [], size?: PreviewSize, view?: ViewportRequest): Promise<T> {
    if (this.disposed) return Promise.reject(new Error('长截图处理已结束'));
    const id = ++this.nextId;
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => this.dispose(new Error('长截图拼接超时，请减小选区后重试')), 12_000);
      this.pending.set(id, { resolve: (value) => resolve(value as T), reject, timer });
      try { this.worker.postMessage({ id, operation, frame, size, view }, transfer); }
      catch { this.dispose(new Error('无法提交长截图画面')); }
    });
  }
}
