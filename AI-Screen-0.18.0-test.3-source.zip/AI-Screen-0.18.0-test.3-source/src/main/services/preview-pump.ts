/** Coalesces arbitrary requests into one running preview and one dirty flag.
 * Completion spacing bounds worker sampling/PNG work without delaying reads. */
export class PreviewPump {
  private dirty = false;
  private stopped = false;
  private timer?: ReturnType<typeof setTimeout>;
  private running?: Promise<void>;
  private lastCompleted = -Infinity;
  constructor(private interval: number, private render: () => Promise<void>, private failed: (error: unknown) => void) {}
  request() { if (!this.stopped) { this.dirty = true; this.schedule(); } }
  stop() { this.stopped = true; this.dirty = false; if (this.timer) clearTimeout(this.timer); this.timer = undefined; }
  async idle() { await this.running; }
  private schedule() {
    if (this.stopped || this.running || this.timer || !this.dirty) return;
    const delay = Math.max(0, this.interval - (performance.now() - this.lastCompleted));
    this.timer = setTimeout(() => {
      this.timer = undefined;
      if (this.stopped) return;
      this.dirty = false;
      this.running = Promise.resolve().then(this.render).catch((error: unknown) => { this.stop(); this.failed(error); }).finally(() => {
        this.lastCompleted = performance.now(); this.running = undefined; this.schedule();
      });
    }, delay);
  }
}
