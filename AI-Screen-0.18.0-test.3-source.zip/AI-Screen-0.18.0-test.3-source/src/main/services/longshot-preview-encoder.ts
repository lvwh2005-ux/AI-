import {Worker} from 'node:worker_threads';
import path from 'node:path';
import type {BitmapFrame} from '../../shared/scroll-capture/types';
import type {PreviewSnapshot} from '../../shared/scroll-capture/preview-snapshot';
import type {PreviewBundle,PreviewSize} from '../../shared/scroll-capture/preview';
import type {ViewportRequest,ViewportBitmap} from '../../shared/scroll-capture/preview-viewport';
export class LongshotPreviewEncoder{
  constructor(private timing?:(span:{stage:string;startMs:number;durationMs:number})=>void,private createWorker?:()=>Worker){}
  private worker?:Worker;
  private disposed=false;
  private pending?:{resolve(value:unknown):void;reject(error:Error):void;timer:NodeJS.Timeout};
  preview(snapshot:PreviewSnapshot,size:PreviewSize,view?:ViewportRequest):Promise<PreviewBundle>{return this.request({operation:'preview',snapshot,size,view});}
  viewport(snapshot:PreviewSnapshot,view:ViewportRequest):Promise<ViewportBitmap>{return this.request({operation:'viewport',snapshot,view});}
  encode(frames:BitmapFrame[]):Promise<string[]>{
    if(frames.length<1||frames.length>3||frames.some(frame=>!Number.isSafeInteger(frame.width)||!Number.isSafeInteger(frame.height)
      ||frame.width<1||frame.height<1||frame.width>2048||frame.height>2048||frame.data.length!==frame.width*frame.height*4))return Promise.reject(new Error('预览超过像素预算'));
    return this.request({operation:'encode',frames},[...new Set(frames.map(frame=>frame.data.buffer as ArrayBuffer))]);
  }
  private request<T>(message:object,transfer:ArrayBuffer[]=[]):Promise<T>{
    if(this.disposed)return Promise.reject(new Error('长截图预览已结束'));
    if(this.pending)return Promise.reject(new Error('预览已有在途请求'));
    if(!this.worker){
      this.worker=this.createWorker?.()??new Worker(path.join(__dirname,'longshot-preview-worker.cjs'));
      this.worker.on('message',(reply:{result?:unknown;error?:string;durationMs?:number;startedMs?:number;stage?:string})=>{
        const pending=this.pending;if(!pending)return;this.pending=undefined;clearTimeout(pending.timer);
        if(Number.isFinite(reply.durationMs)&&Number.isFinite(reply.startedMs)){
          try{this.timing?.({stage:reply.stage??'preview-work',startMs:reply.startedMs!,durationMs:reply.durationMs!});}catch{/* Observer only. */}
        }
        if(reply.error)pending.reject(new Error(reply.error));else pending.resolve(reply.result);
      });
      this.worker.on('error',()=>this.dispose());this.worker.on('exit',()=>{if(!this.disposed)this.dispose();});
    }
    return new Promise<T>((resolve,reject)=>{
      const timer=setTimeout(()=>this.dispose(),12000);this.pending={resolve:value=>resolve(value as T),reject,timer};
      try{this.worker!.postMessage(message,transfer);}catch{this.dispose();}
    });
  }
  dispose(){
    if(this.disposed)return;this.disposed=true;
    if(this.pending){clearTimeout(this.pending.timer);this.pending.reject(new Error('长截图预览已结束'));this.pending=undefined;}
    void this.worker?.terminate();this.worker=undefined;
  }
}
