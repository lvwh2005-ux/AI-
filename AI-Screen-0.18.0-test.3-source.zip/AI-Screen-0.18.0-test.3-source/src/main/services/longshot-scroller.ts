import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import path from 'node:path';
import { app, screen } from 'electron';
import type { Rect } from '../../shared/contracts';

export interface ScrollDriver {
  prepare?(): Promise<void>;
  bind(rect: Rect, signal: AbortSignal): Promise<void>;
  validate(signal: AbortSignal): Promise<void>;
  step(signal: AbortSignal,wheelUnits?:number): Promise<void>;
  resume(signal: AbortSignal): Promise<void>;
  dispose(): void;
}
interface Pending { resolve(): void; reject(error: Error): void; timer: NodeJS.Timeout }

/** One hidden native worker owns one fixed HWND; later steps never steal focus. */
export class WindowsLongshotScroller implements ScrollDriver {
  private child?: ChildProcessWithoutNullStreams;
  private ready?: Promise<void>;
  private readyResolve?: () => void;
  private readyReject?: (error: Error) => void;
  private readyTimer?: NodeJS.Timeout;
  private disposed = false;
  private attemptedBind = false;
  private readonly diagnostics = process.argv.includes('--smoke-test') && process.argv.includes('--longshot-debug-input');
  private buffer = '';
  private nextId = 0;
  private tail: Promise<void> = Promise.resolve();
  private pending = new Map<number, Pending>();

  constructor(private excludedHandles: readonly string[] | (() => readonly string[]) = [], private expectedWindowId?: string,
    private protectedOverlays: () => readonly string[] = () => []) {}

  /** Start while the foreground Electron overlay still owns activation rights. */
  prepare(): Promise<void> {
    if (this.disposed) return Promise.reject(new Error('自动滚动已结束，请重新开始'));
    return this.start();
  }

  bind(rect: Rect, signal: AbortSignal): Promise<void> {
    // A failed activation still identifies an immutable target. A later UI
    // retry must resume that HWND, never hit-test a newly occluding application.
    if (this.attemptedBind) return this.resume(signal);
    this.attemptedBind = true;
    return this.enqueue('bind', signal, () => {
      if (![rect.x, rect.y, rect.width, rect.height].every(Number.isFinite) || rect.width < 4 || rect.height < 4
        || [rect.x, rect.y, rect.x + rect.width, rect.y + rect.height].some((value) => Math.abs(value) > 10_000_000)) throw new Error('自动滚动选区无效，请重新框选');
      const insetX = Math.min(4, rect.width / 4), insetY = Math.min(4, rect.height / 4);
      const xs = [rect.x + insetX, rect.x + rect.width / 2, rect.x + rect.width - insetX];
      const ys = [rect.y + insetY, rect.y + rect.height / 2, rect.y + rect.height - insetY];
      const coordinates = ys.flatMap((y) => xs.flatMap((x) => {
        const point = screen.dipToScreenPoint({ x: Math.round(x), y: Math.round(y) });
        return [point.x, point.y];
      }));
      const handles = typeof this.excludedHandles === 'function' ? this.excludedHandles() : this.excludedHandles;
      if (this.expectedWindowId !== undefined && !/^\d{1,20}$/.test(this.expectedWindowId)) throw new Error('原始目标窗口信息无效，请重新框选');
      return { coordinates, exclude: handles.filter((handle) => /^\d{1,20}$/.test(handle)).slice(0, 256), expectedTargetId: this.expectedWindowId,
        overlays: this.protectedOverlays().filter((handle) => /^\d{1,20}$/.test(handle)).slice(0, 16), ownerPid: process.pid };
    });
  }
  validate(signal: AbortSignal) { return this.enqueue('validate', signal); }
  step(signal: AbortSignal,wheelUnits=120) {
    return this.enqueue('step',signal,()=>{
      if(!Number.isInteger(wheelUnits)||wheelUnits<15||wheelUnits>480)throw new Error('自动滚动量无效');
      return{wheelUnits};
    });
  }
  resume(signal: AbortSignal) { return this.enqueue('resume', signal); }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.rejectAll(new Error('自动滚动已结束'));
    const child = this.child;
    if (!child || child.killed) return;
    // Let native release restore the cursor only if it still owns its position.
    // No queued wheel command is generated after ownership is revoked above.
    try { child.stdin.end(`${JSON.stringify({ id: ++this.nextId, operation: 'dispose' })}\n`); }
    catch { if (!child.killed) child.kill(); }
    const timer = setTimeout(() => { if (!child.killed) child.kill(); }, 350);
    child.once('exit', () => clearTimeout(timer));
  }

  private enqueue(operation: string, signal: AbortSignal, payload = () => ({})): Promise<void> {
    const request = this.tail.then(async () => {
      signal.throwIfAborted();
      if (this.disposed) throw new Error('自动滚动已结束，请改用手动滚动或重新开始');
      const abort = () => this.dispose();
      signal.addEventListener('abort', abort, { once: true });
      try {
        await this.start();
        signal.throwIfAborted();
        if (this.disposed) throw new Error('自动滚动已结束');
        const data = payload();
        await this.request(operation, data);
        signal.throwIfAborted();
      } catch (error) { signal.throwIfAborted(); throw error; }
      finally { signal.removeEventListener('abort', abort); }
    });
    this.tail = request.catch(() => {});
    return request;
  }

  private start(): Promise<void> {
    if (this.ready) return this.ready;
    if (process.platform !== 'win32') return Promise.reject(new Error('自动滚动仅支持 Windows 10/11，请使用手动滚动'));
    this.ready = new Promise<void>((resolve, reject) => { this.readyResolve = resolve; this.readyReject = reject; });
    const script = app.isPackaged ? path.join(process.resourcesPath, 'longshot-scroller.ps1') : path.join(__dirname, 'longshot-scroller.ps1');
    const powershell = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    try {
      const child = spawn(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
      this.child = child;
      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (chunk: string) => this.receive(chunk));
      child.stderr.resume();
      child.stdin.on('error', () => this.fail(new Error('自动滚动连接已断开，请改用手动滚动')));
      child.on('error', () => this.fail(new Error('无法启动自动滚动，请使用手动滚动')));
      child.on('exit', () => { if (!this.disposed) this.fail(new Error('自动滚动进程已退出，请使用手动滚动')); });
      this.readyTimer = setTimeout(() => this.fail(new Error('自动滚动模块启动超时，请使用手动滚动')), 8000);
    } catch { this.fail(new Error('无法启动自动滚动，请使用手动滚动')); }
    return this.ready;
  }

  private request(operation: string, data: object): Promise<void> {
    const id = ++this.nextId;
    return new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => this.fail(new Error('自动滚动响应超时，请使用手动滚动')), 1800);
      this.pending.set(id, { resolve, reject, timer });
      this.child!.stdin.write(`${JSON.stringify({ id, operation, ...data, diagnostic: this.diagnostics })}\n`, (error) => { if (error) this.fail(new Error('无法发送自动滚动请求，请使用手动滚动')); });
    });
  }

  private receive(chunk: string): void {
    if (this.disposed) return;
    this.buffer += chunk;
    if (this.buffer.length > 65_536) { this.fail(new Error('自动滚动响应异常，请使用手动滚动')); return; }
    let newline: number;
    while ((newline = this.buffer.indexOf('\n')) >= 0) {
      const line = this.buffer.slice(0, newline).replace(/^\uFEFF/, '').trim();
      this.buffer = this.buffer.slice(newline + 1);
      if (!line) continue;
      try {
        const reply = JSON.parse(line) as { ready?: boolean; id?: number; ok?: boolean; error?: string; focusDiagnostic?: string; cursorDiagnostic?: string };
        if (reply.ready === true) { if (this.readyTimer) clearTimeout(this.readyTimer); this.readyResolve?.(); this.readyResolve = undefined; this.readyReject = undefined; continue; }
        const pending = typeof reply.id === 'number' ? this.pending.get(reply.id) : undefined;
        if (!pending) continue;
        this.pending.delete(reply.id!); clearTimeout(pending.timer);
        if (this.diagnostics && typeof reply.cursorDiagnostic === 'string') console.warn('[longshot cursor]', reply.cursorDiagnostic.slice(0, 500));
        if (reply.ok) pending.resolve();
        else {
          // Smoke diagnostics contain HWNDs/PIDs only, never window titles.
          if (this.diagnostics && typeof reply.focusDiagnostic === 'string') console.warn('[longshot focus]', reply.focusDiagnostic.slice(0, 500));
          pending.reject(new Error(typeof reply.error === 'string' ? reply.error.slice(0, 300) : '无法继续自动滚动，请改用手动滚动'));
        }
      } catch { this.fail(new Error('自动滚动响应异常，请使用手动滚动')); return; }
    }
  }
  private rejectAll(error: Error): void {
    if (this.readyTimer) clearTimeout(this.readyTimer);
    this.readyReject?.(error); this.readyReject = undefined; this.readyResolve = undefined;
    for (const pending of this.pending.values()) { clearTimeout(pending.timer); pending.reject(error); }
    this.pending.clear();
  }
  private fail(error: Error): void {
    if (this.disposed) return;
    this.rejectAll(error);
    this.dispose();
  }
}
