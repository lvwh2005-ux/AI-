$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

# The process stays alive between captures. Native enumeration and DPI context
# run on the same thread, avoiding virtualized GetWindowRect fallback values.
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public static class ScreenWindowDetector {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [StructLayout(LayoutKind.Sequential)]
    private struct MONITORINFO { public int cbSize; public RECT rcMonitor; public RECT rcWork; public int dwFlags; }
    public sealed class Bounds { public int x; public int y; public int width; public int height; }
    public sealed class Item { public string id; public string title; public Bounds bounds; }
    public sealed class SnapshotResult { public Item[] windows; public Bounds[] nativeDisplays; }
    private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr param);
    private delegate bool EnumMonitorProc(IntPtr monitor, IntPtr hdc, ref RECT rect, IntPtr param);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowProc callback, IntPtr param);
    [DllImport("user32.dll")] private static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr clip, EnumMonitorProc callback, IntPtr param);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern bool GetMonitorInfo(IntPtr monitor, ref MONITORINFO info);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowText(IntPtr hwnd, StringBuilder text, int length);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(IntPtr hwnd, StringBuilder text, int length);
    [DllImport("user32.dll")] private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr value);
    [DllImport("user32.dll")] private static extern bool SetProcessDpiAwarenessContext(IntPtr value);
    [DllImport("dwmapi.dll", EntryPoint = "DwmGetWindowAttribute")] private static extern int DwmRect(IntPtr hwnd, int attribute, out RECT value, int size);
    [DllImport("dwmapi.dll", EntryPoint = "DwmGetWindowAttribute")] private static extern int DwmInt(IntPtr hwnd, int attribute, out int value, int size);

    public static void Initialize() {
        try { SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch (EntryPointNotFoundException) { }
    }
    public static SnapshotResult Snapshot(string[] excludedHandles) {
        IntPtr previous = IntPtr.Zero;
        previous = SetThreadDpiAwarenessContext(new IntPtr(-4)); // PER_MONITOR_AWARE_V2
        if (previous == IntPtr.Zero) throw new InvalidOperationException("Cannot enter per-monitor DPI context");
        try {
            // Read the original Win32 rcMonitor. Multiplying rounded DIP bounds
            // by scaleFactor can add a pixel and trigger thumbnail resampling.
            List<Bounds> displays = new List<Bounds>();
            if (!EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, delegate(IntPtr monitor, IntPtr hdc, ref RECT rect, IntPtr param) {
                MONITORINFO info = new MONITORINFO();
                info.cbSize = Marshal.SizeOf(typeof(MONITORINFO));
                if (!GetMonitorInfo(monitor, ref info)) return true;
                RECT native = info.rcMonitor;
                int width = native.Right - native.Left, height = native.Bottom - native.Top;
                if (width > 0 && height > 0) displays.Add(new Bounds { x = native.Left, y = native.Top, width = width, height = height });
                return displays.Count < 256;
            }, IntPtr.Zero)) throw new InvalidOperationException("Cannot enumerate display bounds");
            HashSet<string> excluded = new HashSet<string>(excludedHandles ?? new string[0], StringComparer.Ordinal);
            List<Item> items = new List<Item>();
            // EnumWindows visits top-level windows in front-to-back Z order.
            EnumWindows(delegate(IntPtr hwnd, IntPtr param) {
                string id = hwnd.ToInt64().ToString(System.Globalization.CultureInfo.InvariantCulture);
                if (excluded.Contains(id) || !IsWindowVisible(hwnd) || IsIconic(hwnd)) return true;
                int cloaked;
                if (DwmInt(hwnd, 14, out cloaked, sizeof(int)) == 0 && cloaked != 0) return true;
                StringBuilder className = new StringBuilder(256);
                GetClassName(hwnd, className, className.Capacity);
                // Tooltip/shadow helper windows are not screenshot targets.
                string cls = className.ToString();
                if (cls == "tooltips_class32" || cls == "SysShadow" || cls == "IME" || cls == "MSCTFIME UI") return true;
                RECT rect;
                if (DwmRect(hwnd, 9, out rect, Marshal.SizeOf(typeof(RECT))) != 0 && !GetWindowRect(hwnd, out rect)) return true;
                int width = rect.Right - rect.Left, height = rect.Bottom - rect.Top;
                if (width <= 1 || height <= 1) return true;
                StringBuilder title = new StringBuilder(1025);
                GetWindowText(hwnd, title, title.Capacity);
                items.Add(new Item { id = id, title = title.ToString(), bounds = new Bounds { x = rect.Left, y = rect.Top, width = width, height = height } });
                return items.Count < 1024;
            }, IntPtr.Zero);
            return new SnapshotResult { windows = items.ToArray(), nativeDisplays = displays.ToArray() };
        } finally {
            if (previous != IntPtr.Zero) SetThreadDpiAwarenessContext(previous);
        }
    }
}
'@

[ScreenWindowDetector]::Initialize()
[Console]::WriteLine('{"ready":true}')
[Console]::Out.Flush()
while ($null -ne ($line = [Console]::ReadLine())) {
    $requestId = $null
    try {
        $request = $line | ConvertFrom-Json
        $requestId = $request.id
        if ($request.operation -eq 'snapshot') {
            $excluded = @($request.exclude | ForEach-Object { [string]$_ })
            $snapshot = [ScreenWindowDetector]::Snapshot([string[]]$excluded)
            $response = @{ id = $requestId; ok = $true; windows = @($snapshot.windows); nativeDisplays = @($snapshot.nativeDisplays) } | ConvertTo-Json -Depth 6 -Compress
        } else {
            $response = @{ id = $requestId; ok = $false; windows = @(); nativeDisplays = @() } | ConvertTo-Json -Compress
        }
    } catch {
        $response = @{ id = $requestId; ok = $false; windows = @(); nativeDisplays = @() } | ConvertTo-Json -Compress
    }
    [Console]::WriteLine($response)
    [Console]::Out.Flush()
}
