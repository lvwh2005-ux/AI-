import { mkdir, open, rename, rm, type FileHandle } from 'node:fs/promises';
import path from 'node:path';
import { RECORDING_LIMITS, RecordingError, type RecordingArtifact, type RecordingMediaInfo } from '../../../shared/recording/contracts';
import type { VideoFileSink } from './backend';
import {reserveWebmDuration} from './webm-duration';
import{finalizeRecordingMP4}from'./mp4-info';

/** Holds only a bounded queue of compressed blocks, including the current write. */
export class LocalVideoFileSink implements VideoFileSink {
  private tail: Promise<void> = Promise.resolve();
  private next = 0; private pendingBytes = 0; private pendingChunks = 0; private bytes = 0;
  private closing = false; private aborted = false; private failure?: unknown; private artifact?: RecordingArtifact;
  private aborting?: Promise<void>;
  private finishing?: Promise<RecordingArtifact>;
  readonly peaks = { bytes: 0, chunks: 0 };
  private duration?:ReturnType<typeof reserveWebmDuration>;
  private constructor(private file: FileHandle, private partial: string, private base: string,private mimeType?:string) {}
  static async create(root: string, id: string,mimeType?:string) {
    if (!/^[0-9a-f-]{36}$/.test(id)) throw new RecordingError('invalid-session', '录屏临时文件 ID 无效');
    await mkdir(root, { recursive: true });
    const base = path.join(path.resolve(root), `recording-${id}`), partial = `${base}.partial`;
    return new LocalVideoFileSink(await open(partial, 'wx'), partial, base,mimeType);
  }
  append(sequence: number, data: Uint8Array): Promise<void> {
    if (this.closing || this.aborted || this.failure) return Promise.reject(new RecordingError('io-closed', '录屏输出已关闭'));
    if (!Number.isSafeInteger(sequence) || sequence !== this.next || !data.byteLength) return Promise.reject(new RecordingError('chunk-sequence', '录屏数据块顺序或大小不正确'));
    if (data.byteLength > RECORDING_LIMITS.maxChunkBytes || this.pendingChunks >= RECORDING_LIMITS.maxPendingChunks || this.pendingBytes + data.byteLength > RECORDING_LIMITS.maxPendingBytes) return Promise.reject(new RecordingError('backpressure', '录屏写入缓冲已满'));
    this.next++; this.pendingChunks++; this.pendingBytes += data.byteLength;
    this.peaks.bytes = Math.max(this.peaks.bytes, this.pendingBytes); this.peaks.chunks = Math.max(this.peaks.chunks, this.pendingChunks);
    const operation = this.tail.then(async () => {
      if (this.aborted || this.failure) throw new RecordingError('io-closed', '录屏输出已中止');
      let parts=[data];
      if(sequence===0&&this.mimeType?.startsWith('video/webm')){
        this.duration=reserveWebmDuration(data);parts=this.duration.parts;
      }
      for(const part of parts){
        let offset = 0;
        while (offset < part.byteLength) {
          const { bytesWritten } = await this.file.write(part, offset, part.byteLength-offset);
          if (!bytesWritten) throw new RecordingError('io-failed', '录屏写入没有推进');
          offset += bytesWritten;
        }
        this.bytes+=part.byteLength;
      }
      // Never retain the first compressed block through the Duration descriptor.
      if(this.duration)this.duration.parts=[];
    }).catch(error => { this.failure ??= error; throw error; }).finally(() => {
      this.pendingChunks--; this.pendingBytes -= data.byteLength;
    });
    // Keep rejection handling installed even if the sender disappears.
    this.tail = operation.catch(() => {});
    return operation;
  }
  finish(media: RecordingMediaInfo, durationMs: number): Promise<RecordingArtifact> {
    if (this.closing || this.aborted) return Promise.reject(new RecordingError('io-closed', '录屏输出已关闭'));
    this.closing = true;
    this.finishing = this.finalize(media,durationMs);
    return this.finishing;
  }
  private async finalize(media: RecordingMediaInfo, durationMs: number) {
    await this.tail;
    if (this.failure) throw this.failure;
    if (this.aborted || !this.bytes) throw new RecordingError('empty-video', '未生成有效录屏数据');
    if(this.duration){
      if(!Number.isFinite(durationMs)||durationMs<=0)throw new RecordingError('invalid-duration','录屏时长无效');
      const value=durationMs*1_000_000/this.duration.timestampScale,encoded=Buffer.alloc(this.duration.floatBytes);
      if(encoded.length===8)encoded.writeDoubleBE(value);else encoded.writeFloatBE(value);
      const result=await this.file.write(encoded,0,encoded.length,this.duration.durationOffset);
      if(result.bytesWritten!==encoded.length)throw new RecordingError('io-failed','写入录屏时长不完整');
    }
    await this.file.sync(); await this.file.close();
    if(media.mimeType.startsWith('video/mp4'))await finalizeRecordingMP4(this.partial);
    if (this.aborted) throw new RecordingError('cancelled','录屏输出已中止');
    const output = `${this.base}.${media.mimeType.startsWith('video/mp4') ? 'mp4' : 'webm'}`;
    await rename(this.partial, output);
    this.artifact = { path: output, mimeType: media.mimeType, width: media.width, height: media.height, bytes: this.bytes, durationMs };
    if (this.aborted) throw new RecordingError('cancelled','录屏输出已中止');
    return { ...this.artifact };
  }
  abort(): Promise<void> {
    if (!this.aborting) this.aborting = (async () => {
      this.aborted = true; this.closing = true; await this.tail;
      await this.finishing?.catch(() => {});
      await this.file.close().catch(() => {});
      await rm(this.partial, { force: true });
      if (this.artifact) await rm(this.artifact.path, { force: true });
    })().catch(error=>{this.aborting=undefined;throw error;});
    return this.aborting;
  }
}
