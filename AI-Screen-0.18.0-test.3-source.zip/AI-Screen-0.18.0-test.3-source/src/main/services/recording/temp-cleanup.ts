import {lstat,realpath,opendir,rm} from 'node:fs/promises';
import path from 'node:path';

/** Expired app-owned recordings only. Never follows a link or descends into directories. */
export async function removeExpiredRecordings(root:string,now=Date.now()){
  const expected=path.resolve(root);let info;
  try{info=await lstat(expected);}catch(error){if((error as NodeJS.ErrnoException).code==='ENOENT')return 0;throw error;}
  if(!info.isDirectory()||info.isSymbolicLink())return 0;
  const actual=await realpath(expected);if(actual.toLowerCase()!==expected.toLowerCase())return 0;
  const cutoff=now-7*24*60*60*1000;let checked=0,removed=0;
  for await(const entry of await opendir(expected)){
    if(++checked>2048)break;
    if(!/^recording-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.(partial|mp4|webm)$/.test(entry.name)||!entry.isFile()||entry.isSymbolicLink())continue;
    const file=path.join(expected,entry.name),stat=await lstat(file);if(!stat.isFile()||stat.isSymbolicLink()||stat.mtimeMs>=cutoff||stat.birthtimeMs>=cutoff)continue;
    await rm(file);removed++;
  }
  return removed;
}
