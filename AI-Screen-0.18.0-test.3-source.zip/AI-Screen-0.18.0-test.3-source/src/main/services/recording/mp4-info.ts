import {open} from 'node:fs/promises';

interface Box{type:string;start:number;end:number;payload:number}
interface Track{id:number;kind:string;codec:string;timescale:number;samples:number;start:number;end:number;defaultDuration:number}
function boxes(data:Buffer,start=0,end=data.length):Box[]{
  const result:Box[]=[];
  for(let at=start;at<end;){
    if(end-at<8)throw Error('Truncated MP4 box');
    let size=data.readUInt32BE(at),header=8;
    if(size===1){if(end-at<16)throw Error('Truncated extended MP4 box');size=Number(data.readBigUInt64BE(at+8));header=16;}
    if(size===0)size=end-at;
    if(!Number.isSafeInteger(size)||size<header||at+size>end)throw Error('Invalid MP4 box bounds');
    result.push({type:data.toString('ascii',at+4,at+8),start:at,end:at+size,payload:at+header});at+=size;
  }
  return result;
}
function child(data:Buffer,parent:Box,type:string){return boxes(data,parent.payload,parent.end).find(b=>b.type===type);}
function value64(data:Buffer,offset:number){const n=Number(data.readBigUInt64BE(offset));if(!Number.isSafeInteger(n))throw Error('MP4 timestamp exceeds safe range');return n;}

interface DurationField{position:number;bytes:4|8;track?:number;scale:'movie'|'media'}
/** Chromium fragmented MP4 metadata; compressed media is skipped, never buffered. */
async function scanRecordingMP4(filePath:string){
  const file=await open(filePath,'r'),tracks=new Map<number,Track>(),fields:DurationField[]=[];let fragments=0,ftyp=false,movieScale=0;
  try{
    const size=(await file.stat()).size;
    for(let at=0;at<size;){
      const header=Buffer.alloc(16),read=await file.read(header,0,Math.min(16,size-at),at);if(read.bytesRead<8)throw Error('Truncated MP4 header');
      const type=header.toString('ascii',4,8),h=header.readUInt32BE(0)===1?16:8,length=header.readUInt32BE(0)===1?value64(header,8):header.readUInt32BE(0)||size-at;
      if(!Number.isSafeInteger(length)||length<h||at+length>size)throw Error('Invalid top-level MP4 box');
      if(type==='ftyp')ftyp=true;
      if(type==='moov'||type==='moof'){
        if(length>16*1024*1024)throw Error('MP4 metadata exceeds diagnostic budget');
        const data=Buffer.alloc(length);const loaded=await file.read(data,0,length,at);if(loaded.bytesRead!==length)throw Error('Truncated MP4 metadata');
        const root=boxes(data)[0];
        if(type==='moov'){
          const mvhd=child(data,root,'mvhd');if(!mvhd)throw Error('MP4 movie header missing');const version=data[mvhd.payload];movieScale=data.readUInt32BE(mvhd.payload+(version===1?20:12));if(!movieScale)throw Error('Invalid movie timescale');fields.push({position:at+mvhd.payload+(version===1?24:16),bytes:version===1?8:4,scale:'movie'});
          for(const trak of boxes(data,root.payload,root.end).filter(b=>b.type==='trak')){
            const tkhd=child(data,trak,'tkhd'),mdia=child(data,trak,'mdia');if(!tkhd||!mdia)throw Error('MP4 track metadata missing');
            const mdhd=child(data,mdia,'mdhd'),hdlr=child(data,mdia,'hdlr'),minf=child(data,mdia,'minf');if(!mdhd||!hdlr||!minf)throw Error('MP4 media metadata missing');
            const id=data.readUInt32BE(tkhd.payload+(data[tkhd.payload]===1?20:12)),timescale=data.readUInt32BE(mdhd.payload+(data[mdhd.payload]===1?20:12));
            const stbl=child(data,minf,'stbl'),stsd=stbl&&child(data,stbl,'stsd');if(!stsd||!timescale)throw Error('MP4 codec/timescale missing');
            const entry=boxes(data,stsd.payload+8,stsd.end)[0];tracks.set(id,{id,kind:data.toString('ascii',hdlr.payload+8,hdlr.payload+12),codec:entry.type,timescale,samples:0,start:Infinity,end:0,defaultDuration:0});
            fields.push({position:at+tkhd.payload+(data[tkhd.payload]===1?28:20),bytes:data[tkhd.payload]===1?8:4,track:id,scale:'movie'},{position:at+mdhd.payload+(data[mdhd.payload]===1?24:16),bytes:data[mdhd.payload]===1?8:4,track:id,scale:'media'});
          }
          const mvex=child(data,root,'mvex');if(mvex)for(const trex of boxes(data,mvex.payload,mvex.end).filter(b=>b.type==='trex')){const track=tracks.get(data.readUInt32BE(trex.payload+4));if(track)track.defaultDuration=data.readUInt32BE(trex.payload+12);}
        }else{
          fragments++;
          for(const traf of boxes(data,root.payload,root.end).filter(b=>b.type==='traf')){
            const tfhd=child(data,traf,'tfhd'),tfdt=child(data,traf,'tfdt');if(!tfhd||!tfdt)throw Error('MP4 fragment timing missing');
            const flags=data.readUIntBE(tfhd.payload+1,3),track=tracks.get(data.readUInt32BE(tfhd.payload+4));if(!track)throw Error('Unknown fragmented MP4 track');
            let cursor=tfhd.payload+8;if(flags&1)cursor+=8;if(flags&2)cursor+=4;const defaultDuration=flags&8?data.readUInt32BE(cursor):track.defaultDuration;
            let timestamp=data[tfdt.payload]===1?value64(data,tfdt.payload+4):data.readUInt32BE(tfdt.payload+4);track.start=Math.min(track.start,timestamp);
            for(const trun of boxes(data,traf.payload,traf.end).filter(b=>b.type==='trun')){
              const f=data.readUIntBE(trun.payload+1,3),count=data.readUInt32BE(trun.payload+4);if(count>1_000_000)throw Error('MP4 fragment sample count exceeds budget');
              let p=trun.payload+8;if(f&1)p+=4;if(f&4)p+=4;
              for(let i=0;i<count;i++){
                const duration=f&0x100?data.readUInt32BE(p):defaultDuration;if(f&0x100)p+=4;if(f&0x200)p+=4;if(f&0x400)p+=4;
                let composition=0;if(f&0x800){composition=data[trun.payload]===1?data.readInt32BE(p):data.readUInt32BE(p);p+=4;}
                if(p>trun.end||!duration)throw Error('Invalid MP4 sample duration');track.end=Math.max(track.end,timestamp+composition+duration);timestamp+=duration;
              }
              track.samples+=count;
            }
          }
        }
      }
      at+=length;
    }
    if(!ftyp||!tracks.size||!fragments)throw Error('Not a Chromium fragmented MP4 recording');
    return{fields,movieScale,summary:{bytes:size,fragments,tracks:[...tracks.values()].map(t=>({id:t.id,kind:t.kind,codec:t.codec,timescale:t.timescale,samples:t.samples,startSeconds:t.start/t.timescale,endSeconds:t.end/t.timescale,durationSeconds:(t.end-t.start)/t.timescale,framesPerSecond:t.samples/((t.end-t.start)/t.timescale)}))}};
  }finally{await file.close();}
}
export async function inspectRecordingMP4(filePath:string){return(await scanRecordingMP4(filePath)).summary;}
/** Native MediaRecorder leaves header durations zero. Fill them from encoded sample timing. */
export async function finalizeRecordingMP4(filePath:string){
  const {fields,movieScale,summary}=await scanRecordingMP4(filePath),file=await open(filePath,'r+');
  try{
    for(const field of fields){const track=field.track===undefined?undefined:summary.tracks.find(t=>t.id===field.track),seconds=track?.endSeconds??Math.max(...summary.tracks.map(t=>t.endSeconds)),value=Math.round(seconds*(field.scale==='media'?track!.timescale:movieScale));if(!Number.isSafeInteger(value)||value<=0||(field.bytes===4&&value>0xffffffff))throw Error('MP4 duration exceeds header capacity');const data=Buffer.alloc(field.bytes);if(field.bytes===8)data.writeBigUInt64BE(BigInt(value));else data.writeUInt32BE(value);const result=await file.write(data,0,data.length,field.position);if(result.bytesWritten!==data.length)throw Error('Incomplete MP4 duration write');}
    await file.sync();return summary;
  }finally{await file.close();}
}
