import {copyFile,open,rename,rm} from 'node:fs/promises';
import {constants} from 'node:fs';
import {randomUUID} from 'node:crypto';
import path from 'node:path';
import {RecordingError} from '../../../shared/recording/contracts';
import{recordingFormat}from'../../../shared/recording/format';

export function checkRecordingExtension(destination:string,mimeType:string){const format=recordingFormat(mimeType);if(path.extname(destination).toLowerCase()!==`.${format.extension}`)throw new RecordingError('invalid-save',`请使用 .${format.extension} 文件名，当前录像为 ${format.label} 格式`);}

/** Copy on the chosen target volume, then replace. Cancelling never replaces the target. */
export async function saveRecordingAtomic(source:string,destination:string,check:()=>void){
  if(path.resolve(source)===path.resolve(destination))throw new RecordingError('invalid-save','请选择其他保存位置');
  const temporary=path.join(path.dirname(destination),`.${path.basename(destination)}.ai-screen-${randomUUID()}.tmp`);
  try{
    check();await copyFile(source,temporary,constants.COPYFILE_EXCL);
    const file=await open(temporary,'r+');try{await file.sync();}finally{await file.close();}
    check();await rename(temporary,destination);
  }finally{await rm(temporary,{force:true});}
}
