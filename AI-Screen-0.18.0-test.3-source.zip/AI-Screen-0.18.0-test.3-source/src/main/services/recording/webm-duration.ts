import { RecordingError } from '../../../shared/recording/contracts';

interface Element { id: number; size: number; unknown: boolean; sizeAt: number; sizeBytes: number; dataAt: number; end: number }
function element(data: Uint8Array, at: number): Element {
  function vint(position: number, keepMarker: boolean) {
    const first=data[position]; if (!first) throw new RecordingError('webm-header','WebM 头部 VINT 无效');
    let length=1,mask=0x80;while(!(first&mask)){length++;mask>>=1;}
    if (length>(keepMarker?4:8)||position+length>data.length) throw new RecordingError('webm-header','WebM 头部不完整');
    let value=BigInt(keepMarker?first:first&(mask-1));
    for(let i=1;i<length;i++)value=value*256n+BigInt(data[position+i]);
    const unknown=!keepMarker&&value===(1n<<BigInt(7*length))-1n;
    if(!unknown&&value>BigInt(Number.MAX_SAFE_INTEGER))throw new RecordingError('webm-header','WebM 元素大小超限');
    return {length,value:unknown?0:Number(value),unknown};
  }
  const id=vint(at,true),sizeAt=at+id.length,size=vint(sizeAt,false),dataAt=sizeAt+size.length;
  return {id:id.value,size:size.value,unknown:size.unknown,sizeAt,sizeBytes:size.length,dataAt,end:dataAt+size.value};
}
function sizeVint(size:number,bytes:number) {
  while(BigInt(size)>=(1n<<BigInt(7*bytes))-1n)bytes++;
  const out=Buffer.alloc(bytes);let value=BigInt(size)|(1n<<BigInt(7*bytes));
  for(let i=bytes-1;i>=0;i--){out[i]=Number(value&255n);value>>=8n;}return out;
}
/** Only for this app's index-free Chromium MediaRecorder stream, not imported WebM.
 * Reserve Duration before writing the first block; later offsets never move again.
 * Matroska schema: Duration 0x4489 is float, in TimestampScale units (default 1ms).
 */
export function reserveWebmDuration(data:Uint8Array):{parts:Uint8Array[];durationOffset:number;floatBytes:number;timestampScale:number;addedBytes:number}{
  const header=data.subarray(0,Math.min(data.length,65536));
  const ebml=element(header,0);
  if(ebml.id!==0x1a45dfa3||ebml.unknown)throw new RecordingError('webm-header','不是预期的 WebM 头');
  const segment=element(header,ebml.end);
  if(segment.id!==0x18538067||!segment.unknown)throw new RecordingError('webm-header','仅支持录制器的流式 WebM Segment');
  const info=element(header,segment.dataAt);
  if(info.id!==0x1549a966||info.unknown||info.end>header.length)throw new RecordingError('webm-header','未找到完整的录制器 Info');
  let timestampScale=1_000_000,duration:Element|undefined;
  for(let at=info.dataAt;at<info.end;){
    const child=element(header,at);
    if(child.unknown||child.end>info.end)throw new RecordingError('webm-header','Info 子元素无效');
    if(child.id===0x2ad7b1){timestampScale=0;for(let i=child.dataAt;i<child.end;i++)timestampScale=timestampScale*256+header[i];}
    if(child.id===0x4489)duration=child;
    at=child.end;
  }
  if(!Number.isSafeInteger(timestampScale)||timestampScale<=0)throw new RecordingError('webm-header','TimestampScale 无效');
  if(duration){
    if(duration.size!==4&&duration.size!==8)throw new RecordingError('webm-header','Duration 浮点大小无效');
    return{parts:[data],durationOffset:duration.dataAt,floatBytes:duration.size,timestampScale,addedBytes:0};
  }
  // Info must directly precede Tracks in the specific stream we produce.
  // Reject indexed/foreign layouts instead of silently breaking their offsets.
  if(element(header,info.end).id!==0x1654ae6b)throw new RecordingError('webm-header','不支持非录制器的 WebM 布局');
  const reserved=Buffer.alloc(11);reserved.set([0x44,0x89,0x88]);
  const size=sizeVint(info.size+reserved.length,info.sizeBytes),sizeGrowth=size.length-info.sizeBytes;
  return {parts:[data.subarray(0,info.sizeAt),size,data.subarray(info.dataAt,info.end),reserved,data.subarray(info.end)],durationOffset:info.end+sizeGrowth+3,floatBytes:8,timestampScale,addedBytes:11+sizeGrowth};
}
