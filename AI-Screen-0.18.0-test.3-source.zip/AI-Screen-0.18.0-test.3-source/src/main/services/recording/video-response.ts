import {createReadStream}from 'node:fs';
import {Readable}from 'node:stream';
import type{RecordingArtifact}from '../../../shared/recording/contracts';
export function recordingByteRange(header:string|null,size:number){
  if(!header)return{start:0,end:size-1,status:200};
  const match=/^bytes=(\d*)-(\d*)$/.exec(header);if(!match||(!match[1]&&!match[2]))return undefined;
  let start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2])),end=match[1]&&match[2]?Number(match[2]):size-1;
  if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=size||end<start)return undefined;
  end=Math.min(end,size-1);return{start,end,status:206};
}
export function recordingVideoResponse(request:Request,artifact:RecordingArtifact|undefined,expectedURL:string){
  if(!artifact||request.url!==expectedURL||!['GET','HEAD'].includes(request.method))return new Response(null,{status:403});
  const range=recordingByteRange(request.headers.get('Range'),artifact.bytes);
  if(!range)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${artifact.bytes}`}});
  const headers:Record<string,string>={'Content-Type':artifact.mimeType,'Content-Length':String(range.end-range.start+1),'Accept-Ranges':'bytes','Cache-Control':'no-store','Access-Control-Allow-Origin':'*'};
  if(range.status===206)headers['Content-Range']=`bytes ${range.start}-${range.end}/${artifact.bytes}`;
  const stream=request.method==='HEAD'?null:Readable.toWeb(createReadStream(artifact.path,{start:range.start,end:range.end}))as ReadableStream<Uint8Array>;
  return new Response(stream,{status:range.status,headers});
}
