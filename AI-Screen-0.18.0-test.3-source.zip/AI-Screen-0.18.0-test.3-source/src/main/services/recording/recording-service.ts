import { randomUUID } from 'node:crypto';
import { setTimeout as delay } from 'node:timers/promises';
import type { CaptureModeContext, CaptureModeExtension } from '../capture-modes';
import { recordingOptionsSchema, recordingTargetSchema, recordingCommandSchema,recordingAudioSchema,RecordingError, type RecordingState, type RecordingTarget, type RecordingOptions, type RecordingArtifact, type RecordingCommand,type RecordingAudio } from '../../../shared/recording/contracts';
import { recordingActive, recordingTransition } from '../../../shared/recording/state';
import type { RecordingBackend, VideoFileSink } from './backend';
import {saveRecordingAtomic,checkRecordingExtension} from './save-video';
import path from 'node:path';

interface Session {
  state: RecordingState; backend: RecordingBackend; controller: AbortController; sink?: VideoFileSink;
  startup?: Promise<void>; stopping?: Promise<void>; cleanup?: Promise<void>; cancelling?: Promise<void>;
  saving?:Promise<boolean>;ticker?:ReturnType<typeof setInterval>;countdownEnd?:number;operation?:Promise<void>;
  detach(): void; startAt?: number; accumulatedMs: number; failed: boolean; released: boolean;
}
export interface RecordingDependencies {
  backend(): RecordingBackend;
  sink(id: string, options: RecordingOptions): Promise<VideoFileSink>;
  target(context: CaptureModeContext): RecordingTarget;
  otherCaptureActive?(): boolean;
  onPrepared?(): Promise<void>;
  onStarting?():Promise<void>;
  productionReady?:boolean;
  onState?(state: RecordingState): void;
  now?(): number;
}
/** Owns the normal recording workflow independently of the frozen selection window. */
export class RecordingService implements CaptureModeExtension {
  readonly mode = 'record' as const;
  get available(){return this.deps.productionReady===true;}
  private current?: Session;
  private last?: RecordingState;
  private result?: RecordingArtifact;
  constructor(private deps: RecordingDependencies, private options: RecordingOptions = recordingOptionsSchema.parse({})) {}
  get state() { const state = this.current?.state ?? this.last; return state ? structuredClone({ ...state, elapsedMs: this.current ? this.elapsed(this.current) : state.elapsedMs,countdownRemainingMs:this.current?.countdownEnd?Math.max(0,this.current.countdownEnd-this.now()):undefined }) : undefined; }
  get artifact() { return this.result ? { ...this.result } : undefined; }
  get active() { return !!this.current && (recordingActive(this.current.state.status) || !!this.current.cancelling || (this.current.state.status==='error'&&!this.current.released)); }
  private now() { return this.deps.now?.() ?? performance.now(); }
  private elapsed(s: Session) { return s.accumulatedMs + (s.startAt === undefined ? 0 : Math.max(0, this.now()-s.startAt)); }
  private publish(s: Session, status?: RecordingState['status']) {
    if (status) s.state = recordingTransition(s.state, status); else s.state = { ...s.state, sequence: s.state.sequence+1 };
    s.state.elapsedMs = this.elapsed(s);s.state.countdownRemainingMs=s.countdownEnd?Math.max(0,s.countdownEnd-this.now()):undefined;
    this.last = structuredClone(s.state); this.deps.onState?.(structuredClone(s.state));
  }
  private check(s: Session) { if (this.current !== s || s.controller.signal.aborted) throw new RecordingError('cancelled', '录屏会话已取消'); }
  async start(context: CaptureModeContext) {
    if (this.current) throw new RecordingError('busy', '请先关闭当前录屏结果或会话');
    if (this.deps.otherCaptureActive?.()) throw new RecordingError('busy', '请先完成或取消正在进行的长截图');
    if (context.signal.aborted) throw new RecordingError('cancelled', '选区已取消');
    const target = recordingTargetSchema.parse(this.deps.target(context)), options = recordingOptionsSchema.parse(context.recordingOptions??this.options);
    const s: Session = { state: { id: randomUUID(), sequence: 0, status: 'idle', elapsedMs: 0 }, backend: this.deps.backend(), controller: new AbortController(), accumulatedMs: 0, failed: false, released: false, detach: () => {} };
    this.result = undefined; this.current = s;
    const abort = () => { void this.cancel().catch(() => {}); };
    context.signal.addEventListener('abort', abort, { once: true });
    s.detach = () => context.signal.removeEventListener('abort', abort);
    this.publish(s, 'preparing');
    if(this.deps.productionReady){s.ticker=setInterval(()=>{if(this.current===s&&this.active)this.publish(s);},250);s.ticker.unref();}
    s.startup = this.prepare(s, target, options);
    return s.startup;
  }
  private async prepare(s: Session, target: RecordingTarget, options: RecordingOptions) {
    try {
      if(this.deps.onStarting){s.detach();await this.deps.onStarting();this.check(s);}
      const media = await s.backend.prepare({ id: s.state.id, target, options,ui:this.deps.productionReady?'toolbar':'experiment' }, {
        chunk: (sequence, data) => { this.check(s); if(!s.sink)throw new RecordingError('invalid-state','录屏输出尚未就绪');return s.sink.append(sequence, data); },
        failed: error => { void this.fail(s, error); },
        interrupted:reason=>{void this.interrupt(reason).catch(error=>this.fail(s,error));},
      }, s.controller.signal);
      this.check(s); s.state.media = media;
      // The preparation toolbar owns format selection. Open the matching sink
      // only after options are committed, before countdown or recorder start.
      const selectedOptions=recordingOptionsSchema.parse(media.options??options);
      const sink=await this.deps.sink(s.state.id,selectedOptions);
      if(s.controller.signal.aborted){await sink.abort();this.check(s);}
      s.sink=sink;this.check(s);
      s.state.audio={systemEnabled:!!media.audio?.systemAvailable,microphoneEnabled:!!media.audio?.microphoneAvailable};
      // Handoff first. Closing a selection afterwards cannot abort this independent session.
      s.detach(); await this.deps.onPrepared?.(); this.check(s);
      s.countdownEnd=this.now()+selectedOptions.countdownMs;this.publish(s, 'countdown');
      if (selectedOptions.countdownMs) await delay(selectedOptions.countdownMs, undefined, { signal: s.controller.signal });
      s.countdownEnd=undefined;this.check(s); await s.backend.start(); this.check(s);
      s.startAt = this.now(); this.publish(s, 'recording');
    } catch (error) {
      if (!s.controller.signal.aborted) await this.fail(s, error);
      throw error;
    }
  }
  async command(id: string, command: RecordingCommand): Promise<void> {
    command=recordingCommandSchema.parse(command);
    const s = this.current;
    if (!s || s.state.id !== id) throw new RecordingError('stale-session', '录屏会话已失效');
    if (command === 'cancel') return this.cancel();
    if (command === 'finish' && s.stopping) return s.stopping;
    if (s.state.pending) throw new RecordingError('busy', '正在处理上一个录屏操作');
    if (command === 'finish') {
      if (!['recording','paused'].includes(s.state.status)) throw new RecordingError('invalid-state', '当前不能完成录屏');
      s.accumulatedMs = this.elapsed(s); s.startAt = undefined;
      s.state.pending = command; this.publish(s, 'stopping');
      s.stopping = this.finish(s); return s.stopping;
    }
    if ((command === 'pause' && s.state.status !== 'recording') || (command === 'resume' && s.state.status !== 'paused')) throw new RecordingError('invalid-state', '当前不能暂停或继续录屏');
    s.state.pending = command; this.publish(s);
    const operation=(async()=>{try {
      if (command === 'pause') {
        await s.backend.pause(); this.check(s); s.accumulatedMs = this.elapsed(s); s.startAt = undefined;
      } else { await s.backend.resume(); this.check(s); s.startAt = this.now(); }
      s.state.pending = undefined; this.publish(s, command === 'pause' ? 'paused' : 'recording');
    } catch (error) { if (!s.controller.signal.aborted) await this.fail(s, error); throw error; }})();s.operation=operation;
    try{await operation;}finally{if(s.operation===operation)s.operation=undefined;}
  }
  private async finish(s: Session) {
    try {
      const stats = await s.backend.stop(); this.check(s);
      s.accumulatedMs = this.elapsed(s); s.startAt = undefined;
      const artifact = await s.sink!.finish(s.state.media!, s.accumulatedMs); this.check(s);
      await s.backend.dispose(); this.check(s);
      s.released = true;
      clearInterval(s.ticker);
      this.result = artifact; s.state.stats = stats; s.state.pending = undefined; s.detach(); this.publish(s, 'ready');
    } catch (error) { if (!s.controller.signal.aborted) await this.fail(s, error); throw error; }
  }
  private cleanup(s: Session) {
    if (!s.cleanup) {
      s.released=false;
      s.detach(); s.controller.abort();
      clearInterval(s.ticker);
      s.cleanup = Promise.allSettled([s.backend.dispose(), s.sink?.abort()]).then(results => {
        if(results.some(result=>result.status==='rejected'))throw new RecordingError('cleanup-failed','录屏资源或临时文件清理失败，请重试关闭');
        s.released=true;
      }).catch(error=>{s.cleanup=undefined;throw error;});
    }
    return s.cleanup;
  }
  private async fail(s: Session, error: unknown) {
    if (this.current !== s || s.controller.signal.aborted || s.failed || ['ready','saving','cancelled'].includes(s.state.status)) return;
    s.failed = true; s.accumulatedMs = this.elapsed(s); s.startAt = undefined;
    s.state.error = { code: error instanceof RecordingError ? error.code : 'media-failed', message: error instanceof Error ? error.message : '录屏失败' };
    s.state.pending = undefined; this.publish(s, 'error');
    try{await this.cleanup(s);}catch(error){s.state.error={code:'cleanup-failed',message:error instanceof Error?error.message:'录屏清理失败'};this.publish(s);}
  }
  async cancel() {
    const s = this.current; if (!s) return;
    if (s.cancelling) return s.cancelling;
    s.cancelling = (async () => {
      s.accumulatedMs = this.elapsed(s); s.startAt = undefined;
      s.controller.abort();await s.saving?.catch(()=>{});
      await this.cleanup(s); await s.startup?.catch(() => {}); await s.stopping?.catch(() => {});await s.operation?.catch(()=>{});
      this.result = undefined; s.state.pending = undefined; this.publish(s, 'cancelled');
      if (this.current === s) this.current = undefined;
    })().catch(error=>{
      s.cancelling=undefined;s.state.pending=undefined;s.state.error={code:'cleanup-failed',message:error instanceof Error?error.message:'录屏清理失败'};
      this.publish(s,s.state.status==='error'?undefined:'error');throw error;
    });
    return s.cancelling;
  }
  async interrupt(reason:string){
    const s=this.current;if(!s)return;
    await s.operation?.catch(()=>{});if(this.current!==s)return;
    s.state.message=reason;
    if(s.state.status==='recording'||s.state.status==='paused'){await this.command(s.state.id,'finish');}
    else if(s.state.status==='stopping'){await s.stopping;}
    else if(['preparing','countdown'].includes(s.state.status)){await this.cancel();}
  }
  async setAudio(id:string,value:RecordingAudio){
    const s=this.current;if(!s||s.state.id!==id)throw new RecordingError('stale-session','录屏会话已失效');
    const audio=recordingAudioSchema.parse(value);
    if(!['recording','paused'].includes(s.state.status)||s.state.pending||!s.backend.setAudio)throw new RecordingError('invalid-state','当前不能改变声音');
    if((audio.systemEnabled&&!s.state.media?.audio?.systemAvailable)||(audio.microphoneEnabled&&!s.state.media?.audio?.microphoneAvailable))throw new RecordingError('audio-unavailable','请在录制前开启所需声音来源');
    s.state.pending='audio';this.publish(s);
    const operation=(async()=>{try{await s.backend.setAudio!(audio);this.check(s);s.state.audio=audio;s.state.pending=undefined;this.publish(s);}catch(error){if(!s.controller.signal.aborted)await this.fail(s,error);throw error;}})();s.operation=operation;
    try{await operation;}finally{if(s.operation===operation)s.operation=undefined;}
  }
  async save(id:string,choosePath:()=>Promise<string|undefined>):Promise<boolean>{
    const s=this.current;if(!s||s.state.id!==id)throw new RecordingError('stale-session','录屏会话已失效');
    if(s.saving)return s.saving;
    if(s.state.status!=='ready'||!this.result)throw new RecordingError('invalid-state','录像尚未完成');
    const artifact=this.result;s.state.error=undefined;this.publish(s,'saving');
    s.saving=(async()=>{
      try{
        const destination=await choosePath();this.check(s);if(!destination)return false;
        checkRecordingExtension(destination,artifact.mimeType);
        await saveRecordingAtomic(artifact.path,destination,()=>this.check(s));this.check(s);
        s.state.savedName=path.basename(destination);s.state.message='已保存录像';return true;
      }catch(error){if(!s.controller.signal.aborted){s.state.error={code:'save-failed',message:error instanceof Error?error.message:'保存失败，请重试'};}throw error;}
      finally{s.saving=undefined;if(this.current===s&&!s.controller.signal.aborted)this.publish(s,'ready');}
    })();return s.saving;
  }
}
