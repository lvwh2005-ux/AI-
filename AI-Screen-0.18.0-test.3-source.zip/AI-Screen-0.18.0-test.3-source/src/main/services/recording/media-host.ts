import { BrowserWindow, desktopCapturer, ipcMain, session, type IpcMainInvokeEvent, type Session } from 'electron';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { z } from 'zod';
import { RECORDING_IPC, RECORDING_LIMITS, recordingRequestSchema, recordingOptionsSchema, recordingAudioSchema,hostEventSchema, RecordingError, type RecordingRequest, type RecordingOptions, type RecordingMediaInfo, type RecordingStats, type HostEvent, type HostCommand,type RecordingState,type RecordingAudio,type RecordingCommand } from '../../../shared/recording/contracts';
import { recordingSource } from '../../../shared/recording/geometry';
import {recordingDisplayPermission} from '../../../shared/recording/permissions';
import type { RecordingBackend, RecordingBackendEvents } from './backend';
import {recordingControlsBounds,RECORDING_TOOLBAR_SIZE as SIZE} from '../../../shared/recording/layout';
import {release} from 'node:os';

const hosts = new Map<number, ElectronMediaHost>();
let installed = false;
const chunkSchema = z.object({ id: z.string().uuid(), sequence: z.number().int().nonnegative(), data: z.instanceof(ArrayBuffer).refine(data => data.byteLength > 0 && data.byteLength <= RECORDING_LIMITS.maxChunkBytes) }).strict();
function sender(event: IpcMainInvokeEvent) {
  const host = hosts.get(event.sender.id);
  if (!host || event.senderFrame !== event.sender.mainFrame || !host.isCurrent()) throw new RecordingError('unauthorized', '无权访问录屏媒体宿主');
  return host;
}
function installIPC() {
  if (installed) return; installed = true;
  function handle(channel:string,callback:(event:IpcMainInvokeEvent,value:unknown)=>unknown){
    ipcMain.handle(channel,async(event,value)=>{
      try{return{ok:true,value:await callback(event,value)};}
      catch(error){return{ok:false,error:error instanceof z.ZodError?'媒体消息格式无效':error instanceof Error?error.message:'媒体宿主调用失败'};}
    });
  }
  handle(RECORDING_IPC.config, event => sender(event).configuration());
  handle(RECORDING_IPC.configure,(event,value)=>{const input=z.object({id:z.string().uuid(),options:recordingOptionsSchema}).strict().parse(value);return sender(event).configure(input.id,input.options);});
  handle(RECORDING_IPC.layout,(event,value)=>{const input=z.object({id:z.string().uuid(),expanded:z.boolean().optional(),height:z.number().int().min(SIZE.height).max(SIZE.expandedHeight).optional(),x:z.number().finite().min(-100000).max(100000).optional(),y:z.number().finite().min(-100000).max(100000).optional()}).strict().parse(value);return sender(event).layout(input.id,input);});
  handle(RECORDING_IPC.event, (event, value) => sender(event).receive(hostEventSchema.parse(value)));
  handle(RECORDING_IPC.chunk, (event, value) => {
    const host = sender(event), input = chunkSchema.parse(value);
    return host.chunk(input.id, input.sequence, new Uint8Array(input.data));
  });
  handle(RECORDING_IPC.control,(event,value)=>{
    const host=sender(event),input=z.object({id:z.string().uuid(),command:z.enum(['pause','resume','finish','cancel','audio','reselect']),audio:recordingAudioSchema.optional()}).strict().parse(value);
    return host.control(input.id,input.command,input.audio);
  });
}
interface Pending { resolve(event: HostEvent): void; reject(error: Error): void; timer: ReturnType<typeof setTimeout>|undefined }
export interface MediaHostOptions{production?:boolean;reselect?():Promise<void>;control?(id:string,command:RecordingCommand|'audio',audio?:RecordingAudio):Promise<void>;testAudioFrame?():Electron.WebFrameMain|undefined;testVideoFrame?():Electron.WebFrameMain|undefined;testTarget?():RecordingRequest['target']|undefined;denyMicrophoneForTest?:boolean}

/** Explicit local host identity + one-shot source grant; no defaultSession changes. */
export class ElectronMediaHost implements RecordingBackend {
  private win?: BrowserWindow; private ses?: Session; private request?: RecordingRequest; private events?: RecordingBackendEvents;
  private disposed = false; private granted = false; private armed = false; private expectedChunk = 0; private inFlightChunks = 0;
  private permissionGranted = false;
  private microphoneAuthorized=false;
  private waiters = new Map<HostEvent['type'], Pending>();
  private abortListener?: () => void;
  private inputSignal?: AbortSignal;
  private disposing?: Promise<void>;
  private senderId?: number;
  private lastState?:RecordingState;private compact=false;private expanded=false;private expandedHeight:number=SIZE.expandedHeight;
  readonly evidence: { sourceId?: string; selectedDisplayId?: string; userGesture?: boolean; sourceEnumerations: number; permissions: string[] } = { sourceEnumerations: 0, permissions: [] };
  private readonly file = path.join(__dirname, '../recording/media-host.html');
  constructor(private options:MediaHostOptions={}){}
  get window() { return this.win; }
  isCurrent() { return !this.disposed && !!this.win && !this.win.isDestroyed() && this.win.webContents.getURL() === pathToFileURL(this.file).href; }
  configuration() { if (!this.request) throw new RecordingError('invalid-state', '录屏配置未就绪'); return {...this.request,target:this.options.testTarget?.()??this.request.target,ui:this.options.production?'toolbar':'experiment'}; }
  configure(id:string,options:RecordingOptions){
    if(id!==this.request?.id||this.granted||!this.isCurrent()||this.lastState?.status!=='preparing')throw new RecordingError('invalid-state','录制已开始，不能更改设备或格式');
    this.request.options=recordingOptionsSchema.parse(options);
    if(!options.microphone)this.microphoneAuthorized=false;
  }
  layout(id:string,value:{expanded?:boolean;height?:number;x?:number;y?:number}){
    if(id!==this.request?.id||!this.options.production||!this.isCurrent())throw new RecordingError('unauthorized','录屏布局未授权');
    if(value.expanded!==undefined)this.expanded=value.expanded;
    if(value.height!==undefined)this.expandedHeight=value.height;
    const current=this.win!.getBounds();this.place(this.compact?SIZE.activeWidth:SIZE.prepareWidth,this.expanded?this.expandedHeight:SIZE.height,{x:value.x??current.x,y:value.y??current.y});
  }
  control(id:string,command:RecordingCommand|'audio'|'reselect',audio?:RecordingAudio){
    if(id!==this.request?.id||!this.options.control)throw new RecordingError('unauthorized','录屏控制未授权');
    if(command==='reselect'){
      if(this.granted||this.lastState?.status!=='preparing'||!this.options.reselect)throw new RecordingError('invalid-state','请先结束本次录制');
      return this.options.reselect();
    }
    return this.options.control(id,command,audio);
  }
  publish(state:RecordingState){
    this.lastState=state;const win=this.win;if(!win||win.isDestroyed())return;
    if(this.options.production){
      const compact=state.status!=='preparing';
      if(compact!==this.compact){this.compact=compact;this.expanded=false;this.place(compact?SIZE.activeWidth:SIZE.prepareWidth,SIZE.height,win.getBounds());}
      win.webContents.send(RECORDING_IPC.state,state);
    }
  }
  private place(width:number,height:number,position?:{x:number;y:number}){
    if(!this.win||!this.request)return;
    const {screen}=require('electron')as typeof import('electron');
    const target=this.request.target,global={...target.rect,x:target.rect.x+target.displayBounds.x,y:target.rect.y+target.displayBounds.y},area=screen.getDisplayMatching(position?{...position,width,height}:target.displayBounds).workArea;
    const proposed=recordingControlsBounds(global,area,width,height);
    if(position){proposed.x=Math.max(area.x,Math.min(position.x,area.x+area.width-proposed.width));proposed.y=Math.max(area.y,Math.min(position.y,area.y+area.height-proposed.height));}
    const next={x:Math.round(proposed.x),y:Math.round(proposed.y),width:Math.round(proposed.width),height:Math.round(proposed.height)},current=this.win.getBounds();
    if(Object.keys(next).some(key=>next[key as keyof typeof next]!==current[key as keyof typeof next]))this.win.setBounds(next);
  }
  async prepare(request: RecordingRequest, events: RecordingBackendEvents, signal: AbortSignal): Promise<RecordingMediaInfo> {
    if (this.win || this.disposed) throw new RecordingError('invalid-state', '媒体宿主不可重复准备');
    if (signal.aborted) throw new RecordingError('cancelled', '媒体准备已取消');
    this.request = recordingRequestSchema.parse(request); this.events = events; this.inputSignal = signal;
    this.lastState={id:request.id,sequence:0,status:'preparing',elapsedMs:0};
    installIPC();
    this.ses = session.fromPartition(`recording-${request.id}`, { cache: false });
    const b = request.target.displayBounds;
    const win = this.win = new BrowserWindow({ x: Math.round(b.x+b.width-370), y: Math.round(b.y+32), width: 350, height: 220, show: false,frame:!this.options.production,useContentSize:true,
      title: this.options.production?'AI Screen · 录屏':'AI Screen · 录屏媒体实验', autoHideMenuBar: true, skipTaskbar: true,transparent:!!this.options.production,backgroundColor:this.options.production?'#00000000':'#f6f7f9',hasShadow:!this.options.production,
      webPreferences: { preload: path.join(__dirname,'recording-preload.cjs'), session: this.ses, nodeIntegration: false, contextIsolation: true, sandbox: true, webSecurity: true, backgroundThrottling: false } });
    this.senderId = win.webContents.id; hosts.set(this.senderId, this);
    if(this.options.production){
      if(process.platform!=='win32'||Number(release().split('.')[2])<19041)throw new RecordingError('capture-exclusion','录屏需要支持窗口捕获排除的 Windows 10 2004 或更新系统');
      win.setContentProtection(true);win.setAlwaysOnTop(true);win.setResizable(false);win.setMenuBarVisibility(false);this.place(SIZE.prepareWidth,SIZE.height);
      win.on('close',event=>{if(!this.disposed&&this.request){event.preventDefault();void this.options.control?.(this.request.id,'cancel').catch(()=>{});}});
    }
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', e => e.preventDefault());
    win.webContents.on('will-frame-navigate', e => e.preventDefault());
    // No network is needed in this file-only media host.
    this.ses.webRequest.onBeforeRequest({ urls: ['http://*/*','https://*/*','ws://*/*','wss://*/*'] }, (_details, callback) => callback({ cancel: true }));
    // Keep display/camera checks denied. After an explicit microphone grant,
    // the same local main frame may enumerate input names and reopen a device.
    this.ses.setPermissionCheckHandler((contents,permission,_origin,details)=>
      permission==='media'&&details.mediaType==='audio'&&this.microphoneAuthorized&&!!this.request?.options.microphone&&!this.options.denyMicrophoneForTest&&contents===win.webContents&&this.isCurrent()&&this.armed&&details.isMainFrame&&details.requestingUrl===pathToFileURL(this.file).href);
    this.ses.setPermissionRequestHandler((contents, permission, callback, details) => {
      this.evidence.permissions.push(permission);
      const types = 'mediaTypes' in details ? details.mediaTypes : undefined;
      // Electron 44 reports display capture as media + []; cameras/mics have named types.
      // Newer runtimes use display-capture. Microphone is a separate one-shot opt-in.
      const displayOnly = recordingDisplayPermission(permission,{...details,mediaTypes:types},pathToFileURL(this.file).href,this.request!.options.systemAudio);
      const microphoneOnly=permission==='media'&&Array.isArray(types)&&types.length===1&&types[0]==='audio'&&this.request!.options.microphone&&!this.options.denyMicrophoneForTest;
      const allowed = contents === win.webContents && this.isCurrent() && this.armed && details.isMainFrame
        && details.requestingUrl === pathToFileURL(this.file).href && ((displayOnly&&!this.permissionGranted)||microphoneOnly);
      if(allowed){if(microphoneOnly)this.microphoneAuthorized=true;else this.permissionGranted=true;}
      callback(allowed);
    });
    this.ses.setDisplayMediaRequestHandler(async (input, callback) => {
      let answered=false;
      const respond=(streams:Parameters<typeof callback>[0])=>{
        if(answered)return;answered=true;
        try{callback(streams);}catch(error){this.rejectAll(error);}
      };
      if (!this.isCurrent() || !this.armed || this.granted || input.frame !== win.webContents.mainFrame || !input.userGesture || !input.videoRequested || (input.audioRequested&&!this.request!.options.systemAudio)) { respond(null); return; }
      // Consume before async source enumeration, preventing concurrent grants.
      this.granted = true; this.evidence.userGesture = input.userGesture;
      try {
        this.evidence.sourceEnumerations++;
        const sources = await desktopCapturer.getSources({ types: ['screen'], thumbnailSize: { width: 0, height: 0 } });
        const source = recordingSource(sources, request.target.displayId);
        if (!this.isCurrent() || input.frame !== win.webContents.mainFrame) { respond(null); return; }
        const fixture=this.options.testVideoFrame?.();if(this.options.testVideoFrame&&!fixture)throw new RecordingError('fixture-gone','测试视频源已关闭');
        const audio=this.request!.options.systemAudio?(this.options.testAudioFrame?this.options.testAudioFrame():'loopback'):undefined;if(this.request!.options.systemAudio&&!audio)throw new RecordingError('fixture-gone','测试音源已关闭');
        this.evidence.sourceId = fixture?'isolated-web-frame':source.id; this.evidence.selectedDisplayId = source.display_id;
        respond({ video: fixture??source,...(audio?{audio,enableLocalEcho:false}:{}) });
      } catch (error) { respond(null); this.rejectAll(error); }
    });
    const gone = () => {
      if (!this.disposed) { const error = new RecordingError('host-gone','录屏媒体宿主已关闭'); this.rejectAll(error); this.events?.failed(error); }
    };
    win.webContents.on('render-process-gone', gone);
    win.on('closed', gone);
    this.abortListener = () => { void this.dispose(); };
    signal.addEventListener('abort', this.abortListener, { once: true });
    const prepared = this.wait('prepared',this.options.production?0:30000);
    // Install a rejection handler before loading so a cancelled load cannot orphan it.
    void prepared.catch(() => {});
    try {
      await win.loadFile(this.file);
      if (this.disposed || signal.aborted) throw new RecordingError('cancelled','录屏准备已取消');
      this.armed = true; win.show(); win.focus();
      if(this.lastState)this.publish(this.lastState);
      const result = await prepared;
      if (result.type !== 'prepared') throw new RecordingError('invalid-state','媒体准备确认不正确');
      return result.media;
    } catch (error) { this.rejectAll(error); await this.dispose(); throw error; }
  }
  private wait(type: HostEvent['type'], timeoutMs = 15000): Promise<HostEvent> {
    if (this.disposed || this.waiters.has(type)) return Promise.reject(new RecordingError('invalid-state','媒体宿主已关闭或有重复命令'));
    return new Promise((resolve,reject) => {
      const timer = timeoutMs?setTimeout(() => { this.waiters.delete(type); reject(new RecordingError('host-timeout',`媒体宿主等待 ${type} 超时`)); }, timeoutMs):undefined;
      this.waiters.set(type,{resolve,reject,timer});
    });
  }
  private rejectAll(error: unknown) {
    const failure = error instanceof Error ? error : new Error('录屏宿主失败');
    for (const pending of this.waiters.values()) { clearTimeout(pending.timer); pending.reject(failure); }
    this.waiters.clear();
  }
  receive(event: HostEvent) {
    if (event.id !== this.request?.id || !this.isCurrent()) throw new RecordingError('stale-session','媒体会话已失效');
    if (event.type === 'failed') {
      const error = new RecordingError(event.code,event.message); this.rejectAll(error); this.events?.failed(error); return;
    }
    if(event.type==='interrupted'){this.events?.interrupted?.(event.reason);return;}
    const pending = this.waiters.get(event.type);
    if (!pending) throw new RecordingError('invalid-state',`未等待媒体确认 ${event.type}`);
    clearTimeout(pending.timer); this.waiters.delete(event.type); pending.resolve(event);
  }
  async chunk(id: string, sequence: number, data: Uint8Array) {
    if (id !== this.request?.id || !this.isCurrent() || !this.granted) throw new RecordingError('stale-session','视频数据不属于当前会话');
    if (sequence !== this.expectedChunk || this.inFlightChunks) throw new RecordingError('chunk-sequence','视频数据必须按序逐块确认');
    this.expectedChunk++; this.inFlightChunks++;
    try { await this.events!.chunk(sequence,data); } finally { this.inFlightChunks--; }
  }
  private async send(command: HostCommand['command'], expected: HostEvent['type']) {
    if (!this.isCurrent()) throw new RecordingError('invalid-state','媒体宿主未就绪');
    const response = this.wait(expected, command === 'dispose' ? 1000 : 15000);
    this.win!.webContents.send(RECORDING_IPC.command,{id:this.request!.id,command});
    return response;
  }
  async start() { await this.send('start','started'); }
  async pause() { await this.send('pause','paused'); }
  async resume() { await this.send('resume','resumed'); }
  async probeAudio(){const event=await this.send('probe-audio','audio-probe');if(event.type!=='audio-probe')throw new RecordingError('invalid-state','声音检测确认无效');return{rms:event.rms,amplitude440:event.amplitude440};}
  async setAudio(audio:RecordingAudio){
    if(!this.isCurrent())throw new RecordingError('invalid-state','媒体宿主未就绪');
    const response=this.wait('audio-updated');this.win!.webContents.send(RECORDING_IPC.command,{id:this.request!.id,command:'audio',audio});await response;
  }
  async stop(): Promise<RecordingStats> {
    const event = await this.send('stop','stopped');
    if (event.type !== 'stopped') throw new RecordingError('invalid-state','停止确认无效');
    return event.stats;
  }
  dispose(): Promise<void> {
    if (this.disposing) return this.disposing;
    this.disposing = this.close();
    return this.disposing;
  }
  private async close() {
    if (this.disposed) return;
    this.armed = false;
    const win = this.win;
    if (win && !win.isDestroyed() && this.isCurrent()) {
      try { await this.send('dispose','released'); } catch { /* Destroy below also releases Chromium-owned media. */ }
    }
    this.disposed = true;
    if (this.abortListener) this.inputSignal?.removeEventListener('abort',this.abortListener);
    this.rejectAll(new RecordingError('cancelled','录屏宿主已销毁'));
    this.ses?.setPermissionCheckHandler(() => false);
    this.ses?.setPermissionRequestHandler((_contents,_permission,callback) => callback(false));
    this.ses?.setDisplayMediaRequestHandler((_request, callback) => callback(null));
    if (this.senderId !== undefined) hosts.delete(this.senderId);
    if (win && !win.isDestroyed()) win.destroy();
  }
}
