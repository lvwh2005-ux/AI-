import type { RecordingRequest, RecordingMediaInfo, RecordingStats, RecordingArtifact } from '../../../shared/recording/contracts';

export interface RecordingBackendEvents {
  chunk(sequence: number, data: Uint8Array): Promise<void>;
  failed(error: Error): void;
  interrupted?(reason:string):void;
}
export interface RecordingBackend {
  prepare(request: RecordingRequest, events: RecordingBackendEvents, signal: AbortSignal): Promise<RecordingMediaInfo>;
  start(): Promise<void>;
  pause(): Promise<void>;
  resume(): Promise<void>;
  stop(): Promise<RecordingStats>;
  dispose(): Promise<void>;
  setAudio?(audio:import('../../../shared/recording/contracts').RecordingAudio):Promise<void>;
}
export interface VideoFileSink {
  append(sequence: number, data: Uint8Array): Promise<void>;
  finish(media: RecordingMediaInfo, durationMs: number): Promise<RecordingArtifact>;
  abort(): Promise<void>;
}
