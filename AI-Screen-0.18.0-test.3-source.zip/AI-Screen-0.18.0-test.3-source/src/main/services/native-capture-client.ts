import {spawn,type ChildProcessWithoutNullStreams} from 'node:child_process';
import type {Rect} from '../../shared/contracts';
import type {BitmapFrame} from '../../shared/scroll-capture/types';
import {LONGSHOT_LIMITS,LONGSHOT_MAX_WIDTH} from '../../shared/longshot-limits';
import {setTimeout as delay} from 'node:timers/promises';

export type NativeCaptureChild=Pick<ChildProcessWithoutNullStreams,'stdout'|'stdin'|'stderr'|'once'|'kill'|'pid'>;
interface Pending {resolve(frame:BitmapFrame&{nativeMs:number}):void;reject(error:Error):void;timer:NodeJS.Timeout}
/** One fresh raw ROI per pull, with bounded framing and no image encoding.
 * The worker owns DC/DIB resources for the lifetime of this one session. */
export class NativeCaptureClient {
  private child?:NativeCaptureChild;
  private pending?:Pending;
  private header=Buffer.alloc(24);private headerBytes=0;
  private pixels?:Uint8Array;private pixelBytes=0;private nativeMs=0;
  private disposed=false;
  private reading=false;private nextReadAt=0;
  constructor(private executable:string,private rect:Rect,private monitor:Rect,
    private options:{launch?():NativeCaptureChild;timeoutMs?:number;frameIntervalMs?:number}={}){
    const values=[rect.x,rect.y,rect.width,rect.height,monitor.x,monitor.y,monitor.width,monitor.height];
    if(values.some(value=>!Number.isSafeInteger(value)||value< -2147483648||value>2147483647)||rect.width<1||rect.height<1||rect.width>LONGSHOT_MAX_WIDTH
      ||monitor.width<1||monitor.height<1||rect.x<monitor.x||rect.y<monitor.y
      ||rect.x+rect.width>monitor.x+monitor.width||rect.y+rect.height>monitor.y+monitor.height
      ||rect.width*rect.height*4>LONGSHOT_LIMITS.maxBytes/2)throw new Error('原生采集选区无效');
  }
  async read(signal:AbortSignal):Promise<BitmapFrame&{nativeMs:number}>{
    if(signal.aborted)throw new DOMException('采集已取消','AbortError');
    if(this.disposed)throw new Error('原生采集已结束');
    if(this.reading)throw new Error('不能并发读取原生采集帧');
    this.reading=true;
    const abort=()=>this.dispose(new DOMException('采集已取消','AbortError'));
    signal.addEventListener('abort',abort,{once:true});
    try{
      const wait=this.nextReadAt-performance.now();
      if(wait>0)await delay(wait,undefined,{signal});
      if(this.disposed)throw new Error('原生采集已结束');
      this.nextReadAt=performance.now()+(this.options.frameIntervalMs??1000/30);
      return await new Promise((resolve,reject)=>{
        this.pending={resolve,reject,timer:setTimeout(()=>this.dispose(new Error('原生采集读取超时')),this.options.timeoutMs??4000)};
        try{
          if(!this.child){
            this.child=this.options.launch?.()??spawn(this.executable,
              [this.rect.x,this.rect.y,this.rect.width,this.rect.height,this.monitor.x,this.monitor.y,this.monitor.width,this.monitor.height].map(String),
              {stdio:'pipe',windowsHide:true});
            this.child.stdout.on('data',(chunk:Buffer)=>this.receive(chunk));
            this.child.stdout.once('error',()=>this.dispose(new Error('原生采集输出已关闭')));
            this.child.stdout.once('end',()=>this.dispose(new Error('原生采集输出已关闭')));
            this.child.stderr.resume();
            this.child.stdin.on('error',()=>this.dispose(new Error('原生采集输入已关闭')));
            this.child.once('error',()=>this.dispose(new Error('无法启动原生采集')));
            this.child.once('exit',()=>this.dispose(new Error('原生采集进程已退出')));
          }
          this.child.stdin.write(Buffer.from([114]));
        }catch{this.dispose(new Error('无法启动原生采集'));}
      });
    }finally{signal.removeEventListener('abort',abort);this.reading=false;}
  }
  dispose(error:Error=new Error('原生采集已结束')){
    if(this.disposed)return;this.disposed=true;
    const pending=this.pending;this.pending=undefined;
    if(pending){clearTimeout(pending.timer);pending.reject(error);}
    this.pixels=undefined;this.child?.stdin.destroy();this.child?.kill();this.child=undefined;
  }
  private receive(chunk:Buffer){
    if(this.disposed)return;
    if(!this.pending){this.dispose(new Error('原生采集返回了未请求的帧'));return;}
    let at=0;
    while(at<chunk.length){
      if(this.headerBytes<24){
        const size=Math.min(24-this.headerBytes,chunk.length-at);chunk.copy(this.header,this.headerBytes,at,at+size);this.headerBytes+=size;at+=size;
        if(this.headerBytes<24)return;
        const duration=Number(this.header.readBigInt64LE(16))/1000;
        if(this.header.readUInt32LE(0)!==0x31434447||this.header.readUInt32LE(4)!==this.rect.width*this.rect.height*4
          ||this.header.readUInt32LE(8)!==this.rect.width||this.header.readUInt32LE(12)!==this.rect.height
          ||!Number.isFinite(duration)||duration<0||duration>4000){this.dispose(new Error('原生采集返回的数据无效'));return;}
        this.pixels=new Uint8Array(this.rect.width*this.rect.height*4);this.pixelBytes=0;this.nativeMs=duration;
      }
      const pixels=this.pixels!,size=Math.min(pixels.length-this.pixelBytes,chunk.length-at);
      pixels.set(chunk.subarray(at,at+size),this.pixelBytes);this.pixelBytes+=size;at+=size;
      if(this.pixelBytes===pixels.length){
        if(at!==chunk.length){this.dispose(new Error('原生采集返回了多余数据'));return;}
        const pending=this.pending!;this.pending=undefined;clearTimeout(pending.timer);
        this.headerBytes=0;this.pixels=undefined;
        pending.resolve({width:this.rect.width,height:this.rect.height,data:pixels,nativeMs:this.nativeMs});return;
      }
    }
  }
}
