import {createHash} from 'node:crypto';
import type {BitmapFrame} from '../../shared/scroll-capture/types';
import type {ReadChange} from '../../shared/scroll-capture/telemetry';

/** Exact adjacent-read evidence, independent of matching/revisiting. Keeps only
 * one digest, never a source frame, and never exports that digest. */
export class FrameFingerprint {
  private previous?:string;
  observe(frame:BitmapFrame):ReadChange{
    const digest=createHash('sha256').update(`${frame.width}x${frame.height}:`).update(frame.data).digest('hex');
    const change=this.previous===undefined?'first':this.previous===digest?'same':'changed';
    this.previous=digest;return change;
  }
  clear(){this.previous=undefined;}
}
