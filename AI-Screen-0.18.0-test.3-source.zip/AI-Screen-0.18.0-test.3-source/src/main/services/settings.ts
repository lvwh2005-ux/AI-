import { app, safeStorage } from 'electron';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { settingsSchema, type Settings, type SettingsInput } from '../../shared/contracts';
import { completionUrl } from '../providers/compatible';

export class SettingsStore {
  value: Settings = settingsSchema.parse({});
  private encryptedKey = '';
  private file = path.join(app.getPath('userData'), 'settings.json');
  async load() {
    try {
      const stored = JSON.parse(await readFile(this.file, 'utf8'));
      this.value = settingsSchema.parse(stored);
      completionUrl(this.value.baseUrl);
      this.encryptedKey = typeof stored.encryptedKey === 'string' ? stored.encryptedKey : '';
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw new Error('设置文件读取失败，请备份并移走用户数据目录中的 settings.json 后重试');
    }
  }
  get hasApiKey() { return Boolean(this.encryptedKey); }
  async apiKey() {
    if (!this.encryptedKey) return '';
    try { return (await safeStorage.decryptStringAsync(Buffer.from(this.encryptedKey, 'base64'))).result; }
    catch { throw new Error('无法解密 API Key，请在设置中重新填写'); }
  }
  async save(input: SettingsInput) {
    const next = settingsSchema.parse(input);
    completionUrl(next.baseUrl);
    if (next.provider === 'compatible' && !next.model.trim()) throw new Error('请填写支持图片输入的模型名称');
    let encryptedKey = input.clearApiKey ? '' : this.encryptedKey;
    if (input.apiKey?.trim()) {
      if (!await safeStorage.isAsyncEncryptionAvailable()) throw new Error('系统凭据加密暂不可用，未保存密钥');
      encryptedKey = (await safeStorage.encryptStringAsync(input.apiKey.trim())).toString('base64');
    }
    await mkdir(path.dirname(this.file), { recursive: true });
    await writeFile(this.file + '.tmp', JSON.stringify({ ...next, encryptedKey }, null, 2), 'utf8');
    await rename(this.file + '.tmp', this.file);
    this.value = next;
    this.encryptedKey = encryptedKey;
  }
}
