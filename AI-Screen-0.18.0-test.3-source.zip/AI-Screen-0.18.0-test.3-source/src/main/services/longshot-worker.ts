import { parentPort, workerData } from 'node:worker_threads';
import { ScrollCaptureEngine, type BitmapFrame } from '../../shared/scroll-capture/engine';
import type { PreviewSize } from '../../shared/scroll-capture/preview';
import type { ViewportRequest } from '../../shared/scroll-capture/preview-viewport';
import { StageProfiler, profiled, type ProfileSpan } from '../../shared/scroll-capture/profiler';

let spans: ProfileSpan[] = [],dropped=0;
const profiler=workerData.profiling ? new StageProfiler(span=>{if(spans.length<512)spans.push(span);else dropped++;}) : undefined;
const stitcher = new ScrollCaptureEngine({...workerData,profiler,sharedDocument:true});
parentPort!.on('message', (input: { id: number; operation: 'push' | 'bitmap' | 'preview' | 'viewport' | 'confirm-region' | 'keep-region'; frame?: BitmapFrame; size?: PreviewSize; view?: ViewportRequest }) => {
  spans=[];dropped=0;
  const profile=()=>profiler ? {profile:[...spans,...(dropped?[{stage:'profile-overflow',startMs:0,durationMs:0,metrics:{dropped}}]:[])]
    .map(span=>({...span,metrics:{...span.metrics,requestId:input.id}}))} : {};
  const post=(message:{id:number;result?:unknown;error?:string},transfer:ArrayBuffer[]=[])=>parentPort!.postMessage({...message,...profile(),
    ...(['push','confirm-region','keep-region'].includes(input.operation)?{snapshot:stitcher.previewSnapshot()}:{})},transfer);
  try {
    if (input.operation === 'push' && input.frame) post({ id: input.id, result: profiled(profiler,'worker-push',()=>stitcher.push(input.frame!)) });
    else if (input.operation === 'confirm-region') post({ id: input.id, result: stitcher.confirmRegion() });
    else if (input.operation === 'keep-region') post({ id: input.id, result: stitcher.keepRegion() });
    else if (input.operation === 'preview') {
      if (!input.size) throw new Error('未指定预览尺寸');
      const previews = profiled(profiler,'preview-sample',()=>stitcher.previews(input.size!,input.view));
      post({ id: input.id, result: previews }, [...new Set([previews.overview.data.buffer as ArrayBuffer,previews.detail.data.buffer as ArrayBuffer,
        ...(previews.viewport?[previews.viewport.frame.data.buffer as ArrayBuffer]:[])])]);
    } else if(input.operation==='viewport'&&input.view){
      const view=profiled(profiler,'preview-viewport-sample',()=>stitcher.viewport(input.view!));
      post({id:input.id,result:view},[view.frame.data.buffer as ArrayBuffer]);
    } else if (input.operation === 'bitmap') {
      const frame = profiled(profiler,'output-bitmap',()=>stitcher.bitmap());
      stitcher.clear();
      post({ id: input.id, result: frame }, [frame.data.buffer as ArrayBuffer]);
    } else throw new Error('不支持的长截图处理操作');
  } catch (error) { post({ id: input.id, error: error instanceof Error ? error.message : '长截图拼接失败' }); }
});
