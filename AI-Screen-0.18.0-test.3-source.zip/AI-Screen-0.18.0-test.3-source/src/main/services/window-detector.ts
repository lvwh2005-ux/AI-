import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import path from 'node:path';
import { app } from 'electron';
import type { DetectedWindow, WindowRect } from '../../shared/window-candidates';

export type { DetectedWindow } from '../../shared/window-candidates';
interface Worker {
  child: ChildProcessWithoutNullStreams;
  ready: Promise<boolean>;
  resolveReady(value: boolean): void;
  readyTimer: NodeJS.Timeout;
  isReady: boolean;
  buffer: string;
}
interface Pending { worker: Worker; generation: number; timer: NodeJS.Timeout; resolve(value: DetectedWindow[]): void }

/** One prewarmed native worker, not one PowerShell process per pointer event. */
export class WindowDetector {
  private worker?: Worker;
  private pending = new Map<number, Pending>();
  private nextId = 0;
  private disposed = false;
  private retryAfter = 0;
  private nativeDisplays: WindowRect[] = [];
  private snapshotGeneration = 0;

  getNativeDisplays(): WindowRect[] { return this.nativeDisplays.map((bounds) => ({ ...bounds })); }

  async warmup(): Promise<void> { await this.start(); }

  async snapshot(excludedHandles: readonly string[] = []): Promise<DetectedWindow[]> {
    const generation = ++this.snapshotGeneration;
    this.nativeDisplays = [];
    if (this.disposed || process.platform !== 'win32') return [];
    // A first capture must still work if PowerShell compilation is not ready.
    // Keep warming in the background and use manual region selection meanwhile.
    let timeout: NodeJS.Timeout | undefined;
    const ready = await Promise.race([this.start(), new Promise<boolean>((resolve) => { timeout = setTimeout(() => resolve(false), 500); })]);
    if (timeout) clearTimeout(timeout);
    const worker = this.worker;
    if (!ready || !worker?.isReady) return [];
    const id = ++this.nextId;
    return new Promise<DetectedWindow[]>((resolve) => {
      const timer = setTimeout(() => this.stop(worker), 800);
      this.pending.set(id, { worker, generation, timer, resolve });
      const exclude = excludedHandles.filter((handle) => /^\d{1,20}$/.test(handle)).slice(0, 256);
      worker.child.stdin.write(`${JSON.stringify({ id, operation: 'snapshot', exclude })}\n`, (error) => { if (error) this.stop(worker); });
    });
  }

  dispose(): void {
    this.disposed = true;
    this.nativeDisplays = [];
    if (this.worker) this.stop(this.worker);
  }

  private start(): Promise<boolean> {
    if (this.disposed || process.platform !== 'win32' || Date.now() < this.retryAfter) return Promise.resolve(false);
    if (this.worker) return this.worker.ready;
    const script = app.isPackaged ? path.join(process.resourcesPath, 'window-detector.ps1') : path.join(__dirname, 'window-detector.ps1');
    const powershell = path.join(process.env.SystemRoot ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    let child: ChildProcessWithoutNullStreams;
    try {
      child = spawn(powershell, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    } catch {
      this.retryAfter = Date.now() + 1000;
      return Promise.resolve(false);
    }
    let resolveReady!: (value: boolean) => void;
    const ready = new Promise<boolean>((resolve) => { resolveReady = resolve; });
    const worker: Worker = { child, ready, resolveReady, isReady: false, buffer: '', readyTimer: setTimeout(() => this.stop(worker), 8000) };
    this.worker = worker;
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk: string) => this.receive(worker, chunk));
    // Native errors can include window titles; never forward worker diagnostics.
    child.stderr.resume();
    child.stdin.on('error', () => this.stop(worker));
    child.on('error', () => this.stop(worker));
    child.on('exit', () => this.stop(worker));
    return ready;
  }

  private receive(worker: Worker, chunk: string): void {
    if (this.worker !== worker) return;
    worker.buffer += chunk;
    if (worker.buffer.length > 2_000_000) { this.stop(worker); return; }
    let newline: number;
    while ((newline = worker.buffer.indexOf('\n')) >= 0) {
      const line = worker.buffer.slice(0, newline).replace(/^\uFEFF/, '').trim();
      worker.buffer = worker.buffer.slice(newline + 1);
      if (!line) continue;
      try {
        const response = JSON.parse(line) as { ready?: boolean; id?: number; ok?: boolean; windows?: unknown; nativeDisplays?: unknown };
        if (response.ready === true) {
          worker.isReady = true;
          clearTimeout(worker.readyTimer);
          worker.resolveReady(true);
          continue;
        }
        if (typeof response.id !== 'number') continue;
        const pending = this.pending.get(response.id);
        if (!pending || pending.worker !== worker) continue;
        this.pending.delete(response.id);
        clearTimeout(pending.timer);
        const windows = response.ok && Array.isArray(response.windows) ? response.windows.filter(isDetectedWindow).slice(0, 1024) : [];
        if (pending.generation === this.snapshotGeneration) {
          this.nativeDisplays = response.ok && Array.isArray(response.nativeDisplays)
            ? response.nativeDisplays.filter(isNativeDisplay).slice(0, 256).map((bounds) => ({ ...bounds })) : [];
        }
        pending.resolve(windows);
      } catch { this.stop(worker); return; }
    }
  }

  private stop(worker: Worker): void {
    if (this.worker === worker) { this.worker = undefined; this.retryAfter = Date.now() + 1000; this.nativeDisplays = []; }
    clearTimeout(worker.readyTimer);
    worker.resolveReady(false);
    for (const [id, pending] of this.pending) {
      if (pending.worker !== worker) continue;
      clearTimeout(pending.timer);
      this.pending.delete(id);
      pending.resolve([]);
    }
    if (!worker.child.killed) worker.child.kill();
  }
}

function isNativeDisplay(value: unknown): value is WindowRect {
  if (!value || typeof value !== 'object') return false;
  const bounds = value as Partial<WindowRect>;
  return [bounds.x, bounds.y, bounds.width, bounds.height].every((number) => typeof number === 'number' && Number.isSafeInteger(number))
    && bounds.width! > 0 && bounds.height! > 0;
}

function isDetectedWindow(value: unknown): value is DetectedWindow {
  if (!value || typeof value !== 'object') return false;
  const item = value as Partial<DetectedWindow>;
  const bounds = item.bounds;
  return typeof item.id === 'string' && /^\d{1,20}$/.test(item.id) && typeof item.title === 'string' && item.title.length <= 1024
    && !!bounds && [bounds.x, bounds.y, bounds.width, bounds.height].every((number) => typeof number === 'number' && Number.isFinite(number)) && bounds.width > 0 && bounds.height > 0;
}
