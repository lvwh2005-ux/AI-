import { clipboard, ClipboardItem, type NativeImage } from 'electron';

/** The same async Electron clipboard path used before the capture refactor. */
export class ClipboardService {
  constructor(private imageWriter?: (image: NativeImage) => Promise<void>) {}
  async writeImage(image: NativeImage): Promise<void> {
    if (this.imageWriter) return this.imageWriter(image);
    await clipboard.write([new ClipboardItem({ 'image/png': new Blob([new Uint8Array(image.toPNG())], { type: 'image/png' }) })]);
  }
  async writeText(text: string): Promise<void> { await clipboard.writeText(text); }
}
