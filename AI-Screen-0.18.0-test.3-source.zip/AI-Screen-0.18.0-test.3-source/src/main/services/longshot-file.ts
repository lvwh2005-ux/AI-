import { writeFile, rename, unlink } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import type {buildDiagnosticReport} from '../../shared/scroll-capture/diagnostics';

/** Save only after the native save dialog has supplied the destination. */
export async function saveLongshotPNG(destination: string, png: Uint8Array, isCurrent = () => true) {
  return saveFile(destination,png,isCurrent);
}
export async function saveLongshotDiagnostics(destination:string,report:ReturnType<typeof buildDiagnosticReport>,isCurrent=()=>true){
  if(path.extname(destination).toLowerCase()!=='.json')throw new Error('请使用 .json 文件后缀保存诊断报告');
  return saveFile(destination,Buffer.from(JSON.stringify(report,null,2)+'\n','utf8'),isCurrent);
}
async function saveFile(destination:string,data:Uint8Array,isCurrent:()=>boolean){
  const temporary = path.join(path.dirname(destination), `.${path.basename(destination)}.${randomUUID()}.tmp`);
  try {
    if (!isCurrent()) throw new Error('长截图保存已取消');
    await writeFile(temporary, data, { flag: 'wx' });
    if (!isCurrent()) throw new Error('长截图保存已取消');
    await rename(temporary, destination);
  } finally { await unlink(temporary).catch(() => {}); }
}
