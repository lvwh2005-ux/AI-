import type { NativeImage } from 'electron';
import type { Rect } from '../../shared/contracts';
import { toPixelRect, type CaptureDisplay } from '../../shared/geometry';
import type { PixelRegion } from '../../shared/scroll-capture/types';
import {setTimeout as delay} from 'node:timers/promises';
import { profiled, type StageProfiler } from '../../shared/scroll-capture/profiler';
import type {CaptureBackend} from '../../shared/longshot';

export interface LiveRegionDependencies {
  displays(): readonly CaptureDisplay[];
  sources(size: { width: number; height: number }): Promise<readonly { display_id: string; thumbnail: NativeImage }[]>;
  nativeSize?(display: CaptureDisplay): { width: number; height: number } | undefined;
  profiler?: StageProfiler;
  readRegion?(signal:AbortSignal):Promise<{image:NativeImage;bitmapSize:{width:number;height:number}}>;
  remoteRetries?():number;
  close?():void;
  backend?():CaptureBackend|undefined;
}

const systemDependencies: LiveRegionDependencies = {
  displays: () => (require('electron') as typeof import('electron')).screen.getAllDisplays().map((display) => ({
    id: String(display.id), label: display.label, bounds: display.bounds, scaleFactor: display.scaleFactor,
  })),
  sources: (thumbnailSize) => (require('electron') as typeof import('electron')).desktopCapturer.getSources({ types: ['screen'], thumbnailSize }),
};

function checkAbort(signal: AbortSignal) {
  if (signal.aborted) throw new DOMException('长截图已取消', 'AbortError');
}

// Live sampling deliberately owns no ordinary CaptureService snapshots. Each
// read captures the current desktop and crops only its original in-memory image.
export class LiveRegionSource {
  private readonly display: CaptureDisplay;
  private readonly rect: Rect;
  private bitmapSize?: { width: number; height: number };
  private readonly nativeSize?: { width: number; height: number };
  private retries=0;
  private disposed=false;
  get retryCount(){return this.retries+(this.dependencies.remoteRetries?.()??0);}
  get capturedBitmapSize(){return this.bitmapSize?{...this.bitmapSize}:undefined;}
  get backend():CaptureBackend|undefined{return this.dependencies.readRegion?this.dependencies.backend?.():'electron-snapshot';}
  dispose(){if(this.disposed)return;this.disposed=true;this.dependencies.close?.();}

  constructor(private readonly displayId: string, rect: Rect, private readonly dependencies: LiveRegionDependencies = systemDependencies) {
    const display = dependencies.displays().find((item) => item.id === displayId);
    if (!display) throw new Error('长截图所在显示器已断开，请重新框选');
    const { bounds, scaleFactor } = display;
    if (![bounds.x, bounds.y, bounds.width, bounds.height, scaleFactor].every(Number.isFinite)
      || bounds.width <= 0 || bounds.height <= 0 || scaleFactor <= 0) throw new Error('长截图显示器信息无效，请重新框选');
    if (![rect.x, rect.y, rect.width, rect.height].every(Number.isFinite)
      || rect.x < 0 || rect.y < 0 || rect.width <= 0 || rect.height <= 0
      || rect.x + rect.width > bounds.width || rect.y + rect.height > bounds.height) {
      throw new Error('长截图选区必须完整位于一个显示器内');
    }
    this.display = { ...display, bounds: { ...bounds } };
    this.rect = { ...rect };
    if (dependencies.nativeSize) {
      const native = dependencies.nativeSize(display);
      if (!native || ![native.width, native.height].every((value) => Number.isSafeInteger(value) && value > 0)) throw new Error('未取得显示器原生像素尺寸，请重新唤起截图后重试');
      this.nativeSize = { ...native };
    }
  }

  get globalRect(): Rect {
    return { ...this.rect, x: this.display.bounds.x + this.rect.x, y: this.display.bounds.y + this.rect.y };
  }
  /** Exact reservation in production (nativeSize), refreshed after each read.
   * The bitmap is still validated by read before entering the frame queue. */
  get frameBytes(): number {
    const { bounds, scaleFactor } = this.display;
    const size = this.bitmapSize ?? this.nativeSize ?? {width: Math.round(bounds.width * scaleFactor), height: Math.round(bounds.height * scaleFactor)};
    const pixels = toPixelRect(this.rect, bounds, size);
    return pixels.width * pixels.height * 4;
  }
  globalRectForPixels(region: PixelRegion): Rect {
    this.checkDisplay();
    if (!this.bitmapSize) throw new Error('尚未读取选区像素');
    const pixels = toPixelRect(this.rect, this.display.bounds, this.bitmapSize);
    if (![region.x,region.y,region.width,region.height].every(Number.isInteger) || region.x<0 || region.y<0 || region.width<=0 || region.height<=0 || region.x+region.width>pixels.width || region.y+region.height>pixels.height) throw new Error('正文区域超出原始选区');
    return { x:this.display.bounds.x+(pixels.x+region.x)*this.display.bounds.width/this.bitmapSize.width,
      y:this.display.bounds.y+(pixels.y+region.y)*this.display.bounds.height/this.bitmapSize.height,
      width:region.width*this.display.bounds.width/this.bitmapSize.width,
      height:region.height*this.display.bounds.height/this.bitmapSize.height };
  }

  private checkDisplay() {
    const current = this.dependencies.displays().find((item) => item.id === this.displayId);
    if (!current) throw new Error('长截图所在显示器已断开，请重新框选');
    const original = this.display;
    if (current.scaleFactor !== original.scaleFactor
      || (['x', 'y', 'width', 'height'] as const).some((key) => current.bounds[key] !== original.bounds[key])) {
      throw new Error('显示器的位置、尺寸或缩放已变化，长截图已停止，请重新框选');
    }
  }

  async read(signal: AbortSignal): Promise<NativeImage> {
    checkAbort(signal);
    if(this.disposed)throw new Error('长截图采集已结束');
    this.checkDisplay();
    const { bounds, scaleFactor } = this.display;
    if(this.dependencies.readRegion){
      const result=await this.dependencies.readRegion(signal);
      checkAbort(signal);this.checkDisplay();
      if(this.disposed)throw new Error('长截图采集已结束');
      const size=result.bitmapSize,expected=this.nativeSize;
      if(!expected||size.width!==expected.width||size.height!==expected.height)throw new Error('屏幕图像未按原生分辨率返回，已停止以避免重采样错接');
      const pixels=toPixelRect(this.rect,bounds,size),actual=result.image.getSize();
      if(result.image.isEmpty()||actual.width!==pixels.width||actual.height!==pixels.height)throw new Error('独立采集选区尺寸无效');
      this.bitmapSize={...size};return result.image;
    }
    for(let attempt=0;attempt<2;attempt++){
      let sources: readonly { display_id: string; thumbnail: NativeImage }[];
      try {
        const read = () => profiled(this.dependencies.profiler,'source-dispatch',()=>this.dependencies.sources(this.nativeSize ?? {
          width: Math.max(1, Math.round(bounds.width * scaleFactor)),
          height: Math.max(1, Math.round(bounds.height * scaleFactor)),
        }));
        sources = await (this.dependencies.profiler ? this.dependencies.profiler.measureAsync('source-read',read) : read());
      } catch (error) {
        checkAbort(signal);
        this.checkDisplay();
        throw error;
      }
      checkAbort(signal);
      this.checkDisplay();
      const source = sources.find((item) => item.display_id === this.displayId);
      if (!source || source.thumbnail.isEmpty()){
        if(attempt===0){
          // A transient empty enumeration is not a valid/stationary frame. Retry
          // once with a new native read; never substitute a cached bitmap.
          await delay(80,undefined,{signal});checkAbort(signal);this.checkDisplay();this.retries++;continue;
        }
        throw new Error('无法读取长截图所在显示器，重新读取后仍未取得图像，请重新框选');
      }
      const bitmapSize = source.thumbnail.getSize();
      if (this.nativeSize && (bitmapSize.width !== this.nativeSize.width || bitmapSize.height !== this.nativeSize.height)) throw new Error('屏幕图像未按原生分辨率返回，已停止以避免重采样错接');
      if (this.bitmapSize && (bitmapSize.width !== this.bitmapSize.width || bitmapSize.height !== this.bitmapSize.height)) {
        throw new Error('实时截图分辨率已变化，长截图已停止，请重新框选');
      }
      const pixels = toPixelRect(this.rect, bounds, bitmapSize);
      const image = profiled(this.dependencies.profiler,'capture-crop',()=>source.thumbnail.crop(pixels),{width:pixels.width,height:pixels.height});
      checkAbort(signal);
      this.bitmapSize = { ...bitmapSize };
      return image;
    }
    throw new Error('无法读取长截图所在显示器，请重新框选');
  }
}
