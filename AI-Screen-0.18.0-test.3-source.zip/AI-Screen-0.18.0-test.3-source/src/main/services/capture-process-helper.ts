import {app,desktopCapturer,screen} from 'electron';
import path from 'node:path';
import {mkdirSync} from 'node:fs';
import {LiveRegionSource} from './live-region-source';
import {captureRequestSchema,captureIssue,type CaptureProcessConfig} from './capture-process-protocol';
import {StageProfiler,type ProfileSpan} from '../../shared/scroll-capture/profiler';
import {toPixelRect} from '../../shared/geometry';
import {NativeCaptureClient} from './native-capture-client';
import type {CaptureBackend} from '../../shared/longshot';

/** An isolated broker owns the native ROI worker and snapshot fallback. No
 * windows, settings, shortcuts, keys, disk frames or public IPC endpoints. */
export async function runCaptureHelper(){
  if(!process.send||!process.connected){app.exit(2);return;}
  const profilePath=path.join(app.getPath('temp'),'ai-screen-capture',String(process.pid));
  mkdirSync(profilePath,{recursive:true});app.setPath('userData',profilePath);app.setPath('sessionData',profilePath);
  let source:LiveRegionSource|undefined,reading=false;
  let native:NativeCaptureClient|undefined,nativeDelivered=false,config:CaptureProcessConfig|undefined;
  let backend:CaptureBackend='electron-snapshot',origin:{x:number;y:number}|undefined;
  let spans:ProfileSpan[]=[];
  const send=(reply:unknown)=>{
    if(process.connected)process.send!(reply,undefined,undefined,error=>{if(error)app.exit(0);});
  };
  const close=()=>{native?.dispose();source?.dispose();};
  process.once('disconnect',()=>{close();app.exit(0);});app.once('will-quit',close);
  await app.whenReady();
  process.on('message',async message=>{
    const parsed=captureRequestSchema.safeParse(message);
    if(!parsed.success){app.exit(2);return;}
    const request=parsed.data;
    if(request.kind==='init'){
      if(source||reading){app.exit(2);return;}
      try{
        config=request.config;
        const capturedConfig=config;
        const displays=()=>screen.getAllDisplays().map(display=>({id:String(display.id),label:'',bounds:{...display.bounds},scaleFactor:display.scaleFactor}));
        const current=displays().find(display=>display.id===capturedConfig.displayId);
        if(!current||current.scaleFactor!==config.display.scaleFactor||(['x','y','width','height'] as const).some(key=>current.bounds[key]!==capturedConfig.display.bounds[key])){
          send({id:request.id,kind:'error',issue:'display-changed',retries:0});return;
        }
        const profiler=config.profiling?new StageProfiler(span=>{if(spans.length<64)spans.push(span);}):undefined;
        source=new LiveRegionSource(config.displayId,config.rect,{displays,nativeSize:()=>capturedConfig.nativeSize,profiler,
          sources:thumbnailSize=>desktopCapturer.getSources({types:['screen'],thumbnailSize})});
        if(process.platform==='win32'&&config.backend!=='electron-snapshot'){
          const display=screen.getAllDisplays().find(item=>String(item.id)===capturedConfig.displayId)!;
          origin={...display.nativeOrigin};
          const crop=toPixelRect(config.rect,config.display.bounds,config.nativeSize);
          const executable=path.join(app.isPackaged?process.resourcesPath:__dirname,'native-capture.exe');
          native=new NativeCaptureClient(executable,{...crop,x:origin.x+crop.x,y:origin.y+crop.y},
            {...config.nativeSize,x:origin.x,y:origin.y});backend='gdi-roi';
        }
        send({id:request.id,kind:'initialized',backend});
      }catch{send({id:request.id,kind:'error',issue:'protocol-error',retries:0});}
      return;
    }
    if(!source||reading){app.exit(2);return;}
    reading=true;spans=[];const retriesBefore=source.retryCount;
    try{
      if(native){
        const display=screen.getAllDisplays().find(item=>String(item.id)===config!.displayId),expected=config!.display;
        if(!display||display.scaleFactor!==expected.scaleFactor||(['x','y','width','height'] as const).some(key=>display.bounds[key]!==expected.bounds[key])
          ||display.nativeOrigin.x!==origin!.x||display.nativeOrigin.y!==origin!.y)throw new Error('显示器已变化');
        try{
          const start=performance.now(),frame=await native.read(new AbortController().signal);nativeDelivered=true;
          if(config!.profiling)spans.push({stage:'native-roi-read',startMs:start,durationMs:performance.now()-start},
            {stage:'native-grab',startMs:performance.now()-frame.nativeMs,durationMs:frame.nativeMs});
          send({id:request.id,kind:'frame',width:frame.width,height:frame.height,data:frame.data,bitmapSize:config!.nativeSize,
            backend,retries:0,profile:spans,timeOrigin:performance.timeOrigin});return;
        }catch(error){
          // Startup-only fallback. Never change pixel sources after committing
          // a native frame into a document; later failures stop the session.
          if(nativeDelivered)throw error;
          native.dispose();native=undefined;backend='electron-snapshot';
        }
      }
      const image=await source.read(new AbortController().signal),start=performance.now(),data=image.toBitmap();
      if(config!.profiling)spans.push({stage:'bitmap-copy',startMs:start,durationMs:performance.now()-start});
      send({id:request.id,kind:'frame',...image.getSize(),bitmapSize:source.capturedBitmapSize,data,backend,
        retries:source.retryCount-retriesBefore,profile:spans,timeOrigin:performance.timeOrigin});
    }catch(error){send({id:request.id,kind:'error',issue:captureIssue(error),retries:source.retryCount-retriesBefore});}
    finally{reading=false;}
  });
  send({kind:'ready'});
}
