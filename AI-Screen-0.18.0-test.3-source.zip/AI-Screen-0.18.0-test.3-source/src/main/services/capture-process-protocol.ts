import {z} from 'zod';
import {toPixelRect} from '../../shared/geometry';
import {LONGSHOT_LIMITS,LONGSHOT_MAX_WIDTH} from '../../shared/longshot-limits';
export const CAPTURE_HELPER_FLAG='--longshot-capture-helper';
const finite=z.number().finite(),positive=z.number().int().positive().max(100_000);
export const captureProcessConfigSchema=z.object({
  displayId:z.string().min(1).max(80),
  display:z.object({id:z.string().min(1).max(80),bounds:z.object({x:finite,y:finite,width:finite.positive(),height:finite.positive()}).strict(),scaleFactor:finite.positive().max(16)}).strict(),
  rect:z.object({x:finite.nonnegative(),y:finite.nonnegative(),width:finite.positive(),height:finite.positive()}).strict(),
  nativeSize:z.object({width:positive,height:positive}).strict(),
  profiling:z.boolean(),
  backend:z.enum(['gdi-roi','electron-snapshot']).optional(),
}).strict().superRefine((value,context)=>{
  if(value.display.id!==value.displayId||value.rect.x+value.rect.width>value.display.bounds.width||value.rect.y+value.rect.height>value.display.bounds.height){
    context.addIssue({code:'custom',message:'Invalid capture display/region'});return;
  }
  const crop=toPixelRect(value.rect,value.display.bounds,value.nativeSize);
  if(crop.width>LONGSHOT_MAX_WIDTH||crop.width*crop.height*4>LONGSHOT_LIMITS.maxBytes/2)context.addIssue({code:'custom',message:'Capture exceeds frame budget'});
});
export type CaptureProcessConfig=z.infer<typeof captureProcessConfigSchema>;
export const captureRequestSchema=z.discriminatedUnion('kind',[
  z.object({kind:z.literal('init'),id:z.number().int().positive(),config:captureProcessConfigSchema}).strict(),
  z.object({kind:z.literal('read'),id:z.number().int().positive()}).strict(),
]);
export const captureProcessErrors={
  'display-changed':'显示器的位置、尺寸或缩放已变化，长截图已停止，请重新框选',
  'empty-source':'无法读取长截图所在显示器，重新读取后仍未取得图像，请重新框选',
  'native-size':'屏幕图像未按原生分辨率返回，已停止以避免重采样错接',
  'capture-error':'独立采集进程无法读取当前选区，请重新框选',
  'protocol-error':'独立采集返回的数据无效，已停止采集',
} as const;
export type CaptureProcessIssue=keyof typeof captureProcessErrors;
export function captureIssue(error:unknown):CaptureProcessIssue{
  const message=error instanceof Error?error.message:'';
  if(/显示器.*(变化|断开)/.test(message))return'display-changed';
  if(/重新读取后仍/.test(message))return'empty-source';
  if(/原生分辨率|实时截图分辨率/.test(message))return'native-size';
  return'capture-error';
}
