﻿$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = $utf8
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;

public static class LongshotNativeScroll {
    [StructLayout(LayoutKind.Sequential)] private struct POINT { public int X; public int Y; }
    [StructLayout(LayoutKind.Sequential)] private struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public UIntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Explicit)] private struct INPUTUNION { [FieldOffset(0)] public MOUSEINPUT mi; }
    [StructLayout(LayoutKind.Sequential)] private struct INPUT { public uint type; public INPUTUNION data; }
    [DllImport("user32.dll")] private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")] private static extern bool SetProcessDpiAwarenessContext(IntPtr context);
    [DllImport("user32.dll")] private static extern IntPtr WindowFromPoint(POINT point);
    [DllImport("user32.dll")] private static extern IntPtr GetAncestor(IntPtr hwnd, uint flags);
    [DllImport("user32.dll")] private static extern IntPtr GetWindow(IntPtr hwnd, uint command);
    [DllImport("user32.dll")] private static extern bool GetWindowDisplayAffinity(IntPtr hwnd, out uint affinity);
    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] private static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);
    [DllImport("user32.dll")] private static extern bool IsWindow(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hwnd, out RECT bounds);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out POINT point);
    [DllImport("user32.dll")] private static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] private static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, INPUT[] inputs, int size);
    [DllImport("dwmapi.dll", EntryPoint = "DwmGetWindowAttribute")] private static extern int DwmInt(IntPtr hwnd, int attribute, out int value, int size);
    private static IntPtr target = IntPtr.Zero;
    private static uint targetPid;
    private static RECT originalBounds;
    private static POINT[] samples;
    private static POINT originalCursor;
    private static bool haveOriginalCursor;
    private static bool parked;
    private static bool bindAttempted;
    public static string CursorDiagnostic;
    private static HashSet<string> excluded = new HashSet<string>(StringComparer.Ordinal);
    private static HashSet<string> overlays = new HashSet<string>(StringComparer.Ordinal);

    public static void Initialize() { try { SetProcessDpiAwarenessContext(new IntPtr(-4)); } catch (EntryPointNotFoundException) { } }
    public static void Execute(string operation, int[] coordinates, string[] exclusions, string expectedTargetId, string[] overlayHandles, uint ownerPid, int wheelUnits) {
        CursorDiagnostic = null;
        IntPtr previous = SetThreadDpiAwarenessContext(new IntPtr(-4));
        if (previous == IntPtr.Zero) throw new InvalidOperationException("系统无法提供可靠的物理屏幕坐标，请改用手动滚动");
        try {
            if (operation == "bind") Bind(coordinates, exclusions, expectedTargetId, overlayHandles, ownerPid);
            else if (operation == "validate") Validate(true, true);
            else if (operation == "resume") Resume();
            else if (operation == "step") Step(wheelUnits);
            else if (operation == "dispose") Release();
            else throw new InvalidOperationException("未知的自动滚动操作");
        } finally { SetThreadDpiAwarenessContext(previous); }
    }
    private static IntPtr Root(IntPtr hwnd) { return hwnd == IntPtr.Zero ? IntPtr.Zero : GetAncestor(hwnd, 2); }
    private static string Id(IntPtr hwnd) { return hwnd.ToInt64().ToString(System.Globalization.CultureInfo.InvariantCulture); }
    private static bool AtCentre(POINT point, int tolerance = 2) {
        return Math.Abs((long)point.X - samples[4].X) <= tolerance && Math.Abs((long)point.Y - samples[4].Y) <= tolerance;
    }
    private static bool InScrollPoint(POINT point) {
        // A few pixels of hardware/remote-pointer jitter are not a takeover.
        // Keep the wheel inside the selection and on the original root window.
        return AtCentre(point, 12) && point.X >= samples[0].X && point.X <= samples[8].X
            && point.Y >= samples[0].Y && point.Y <= samples[8].Y && Root(WindowFromPoint(point)) == target;
    }
    private static string DescribeCursor(POINT current) {
        return "expectedX=" + samples[4].X + "; expectedY=" + samples[4].Y + "; currentX=" + current.X + "; currentY=" + current.Y;
    }
    private static bool HitsTarget(POINT point) {
        IntPtr hit = Root(WindowFromPoint(point));
        if (hit == target) return true;
        if (!overlays.Contains(Id(hit))) return false;
        // Only our capture-excluded panel is transparent to this guard. Any
        // other intervening visible window still blocks automatic scrolling.
        IntPtr window = GetWindow(hit, 2); // GW_HWNDNEXT: next lower Z order
        for (int count = 0; window != IntPtr.Zero && count < 1024; count++, window = GetWindow(window, 2)) {
            if (!IsWindowVisible(window) || IsIconic(window) || overlays.Contains(Id(window))) continue;
            int cloaked; if (DwmInt(window, 14, out cloaked, sizeof(int)) == 0 && cloaked != 0) continue;
            RECT rect;
            if (!GetWindowRect(window, out rect) || point.X < rect.Left || point.X >= rect.Right || point.Y < rect.Top || point.Y >= rect.Bottom) continue;
            return window == target;
        }
        return false;
    }
    private static void Bind(int[] coordinates, string[] exclusions, string expectedTargetId, string[] overlayHandles, uint ownerPid) {
        if (bindAttempted) throw new InvalidOperationException("自动滚动目标已固定，请继续原目标或重新框选");
        bindAttempted = true;
        Release();
        if (coordinates == null || coordinates.Length != 18) throw new InvalidOperationException("自动滚动选区无效，请重新框选");
        excluded = new HashSet<string>(exclusions ?? new string[0], StringComparer.Ordinal);
        overlays.Clear();
        foreach (string handle in overlayHandles ?? new string[0]) {
            long value; uint pid, affinity;
            if (!long.TryParse(handle, out value)) continue;
            IntPtr overlay = new IntPtr(value);
            GetWindowThreadProcessId(overlay, out pid);
            if (pid == ownerPid && GetWindowDisplayAffinity(overlay, out affinity) && affinity == 0x11) overlays.Add(Id(overlay));
        }
        samples = new POINT[9];
        for (int i = 0; i < 9; i++) samples[i] = new POINT { X = coordinates[i * 2], Y = coordinates[i * 2 + 1] };
        IntPtr found = WindowFromPoint(samples[4]);
        target = Root(found);
        if (target == IntPtr.Zero || excluded.Contains(Id(target)) || excluded.Contains(Id(found))) {
            target = IntPtr.Zero;
            throw new InvalidOperationException("选区没有可滚动的目标窗口，请重新框选或改用手动滚动");
        }
        if (!String.IsNullOrEmpty(expectedTargetId) && Id(target) != expectedTargetId) {
            target = IntPtr.Zero;
            throw new InvalidOperationException("目标窗口已变化或被遮挡，请重新框选或使用手动滚动");
        }
        GetWindowThreadProcessId(target, out targetPid);
        if (targetPid == 0 || !GetWindowRect(target, out originalBounds)) { target = IntPtr.Zero; throw new InvalidOperationException("无法读取目标窗口，请改用手动滚动"); }
        haveOriginalCursor = GetCursorPos(out originalCursor);
        Validate(false, false);
        ActivateOnce();
        Park();
        Validate(true, true);
    }
    private static void ActivateOnce() {
        if (Root(GetForegroundWindow()) == target) return;
        bool requested = SetForegroundWindow(target);
        // Cross-thread foreground activation can complete asynchronously. Poll
        // the actual foreground; never manufacture input or bypass its lock.
        for (int attempt = 0; attempt < 10; attempt++) {
            if (Root(GetForegroundWindow()) == target) return;
            Thread.Sleep(25);
        }
        IntPtr foreground = Root(GetForegroundWindow()); uint foregroundPid = 0;
        if (foreground != IntPtr.Zero) GetWindowThreadProcessId(foreground, out foregroundPid);
        InvalidOperationException error = new InvalidOperationException("目标窗口未激活，请先切换到目标窗口，再继续自动或改用手动滚动");
        error.Data["focusDiagnostic"] = "requested=" + requested + "; target=" + Id(target) + "; targetPid=" + targetPid + "; foreground=" + Id(foreground) + "; foregroundPid=" + foregroundPid + "; helperPid=" + System.Diagnostics.Process.GetCurrentProcess().Id;
        throw error;
    }
    private static void Park() {
        POINT centre = samples[4];
        if (!SetCursorPos(centre.X, centre.Y)) throw new InvalidOperationException("无法定位滚动光标，请改用手动滚动");
        parked = true;
    }
    private static void Validate(bool checkForeground, bool checkCursor) {
        if (target == IntPtr.Zero) throw new InvalidOperationException("没有保留的自动滚动目标，请重新框选或使用手动滚动");
        if (!IsWindow(target) || !IsWindowVisible(target) || IsIconic(target)) throw new InvalidOperationException("目标窗口已关闭、隐藏或最小化，请重新开始或改用手动滚动");
        uint pid; GetWindowThreadProcessId(target, out pid);
        if (pid != targetPid) throw new InvalidOperationException("目标窗口已变化，请重新开始长截图");
        int cloaked;
        if (DwmInt(target, 14, out cloaked, sizeof(int)) == 0 && cloaked != 0) throw new InvalidOperationException("目标窗口不在当前桌面，请切回后继续自动");
        RECT bounds;
        if (!GetWindowRect(target, out bounds) || bounds.Left != originalBounds.Left || bounds.Top != originalBounds.Top || bounds.Right != originalBounds.Right || bounds.Bottom != originalBounds.Bottom) throw new InvalidOperationException("目标窗口位置或大小已变化，请重新框选长截图");
        foreach (POINT point in samples) {
            if (!HitsTarget(point)) throw new InvalidOperationException("目标区域被其他窗口遮挡，请移开遮挡后继续自动");
        }
        if (checkForeground && Root(GetForegroundWindow()) != target) throw new InvalidOperationException("已切换到其他窗口，自动滚动已暂停；切回目标后点击继续自动");
        if (checkCursor && parked) {
            POINT current;
            bool found = GetCursorPos(out current);
            if (found && (current.X != samples[4].X || current.Y != samples[4].Y)) CursorDiagnostic = DescribeCursor(current);
            if (!found || !InScrollPoint(current)) {
                InvalidOperationException error = new InvalidOperationException("检测到鼠标移动，自动滚动已暂停；点击继续自动重新接管");
                error.Data["cursorDiagnostic"] = found ? DescribeCursor(current) : "GetCursorPos failed";
                throw error;
            }
        }
    }
    private static void SafeKeys() {
        foreach (int key in new int[] { 0x10, 0x11, 0x12, 0x5B, 0x5C, 0x01, 0x02, 0x04, 0x05, 0x06 }) {
            if ((GetAsyncKeyState(key) & 0x8000) != 0) throw new InvalidOperationException("请松开鼠标按键和 Ctrl、Alt、Shift、Win，再继续自动滚动");
        }
    }
    private static void Resume() {
        Validate(false, false);
        SafeKeys();
        ActivateOnce();
        Validate(true, false);
        Park();
        Validate(true, true);
    }
    private static void Step(int wheelUnits) {
        if (wheelUnits < 15 || wheelUnits > 480) throw new InvalidOperationException("自动滚动量无效");
        Validate(true, true);
        SafeKeys();
        // Only initial bind and explicit resume park the pointer. Do not fight
        // small movements by warping it back on every scrolling step.
        Validate(true, true);
        INPUT input = new INPUT(); input.type = 0;
        input.data.mi.dwFlags = 0x0800; // MOUSEEVENTF_WHEEL
        input.data.mi.mouseData = unchecked((uint)-wheelUnits);
        if (SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT))) != 1) throw new InvalidOperationException("系统未接受滚动输入；目标可能以管理员权限运行，请改用手动滚动");
        Validate(true, true);
    }
    private static void Release() {
        if (parked && haveOriginalCursor && samples != null) {
            POINT current;
            if (GetCursorPos(out current) && AtCentre(current)) SetCursorPos(originalCursor.X, originalCursor.Y);
        }
        target = IntPtr.Zero; samples = null; parked = false; haveOriginalCursor = false;
    }
}
'@

[LongshotNativeScroll]::Initialize()
[Console]::WriteLine('{"ready":true}')
[Console]::Out.Flush()
while ($null -ne ($line = [Console]::ReadLine())) {
    $requestId = $null
    $operation = ''
    try {
        $request = $line | ConvertFrom-Json
        $requestId = $request.id
        $operation = [string]$request.operation
        $coordinates = @($request.coordinates | ForEach-Object { [int]$_ })
        $exclude = @($request.exclude | ForEach-Object { [string]$_ })
        $overlayHandles = @($request.overlays | ForEach-Object { [string]$_ })
        [LongshotNativeScroll]::Execute($operation, [int[]]$coordinates, [string[]]$exclude, [string]$request.expectedTargetId, [string[]]$overlayHandles, [uint32]$request.ownerPid, [int]$request.wheelUnits)
        $success = @{ id = $requestId; ok = $true }
        if ($request.diagnostic -and [LongshotNativeScroll]::CursorDiagnostic) { $success.cursorDiagnostic = [LongshotNativeScroll]::CursorDiagnostic }
        $response = $success | ConvertTo-Json -Compress
    } catch {
        $errorMessage = '自动滚动调用失败，请改用手动滚动'
        $nativeError = $_.Exception
        while ($null -ne $nativeError.InnerException) { $nativeError = $nativeError.InnerException }
        if ($nativeError -is [System.InvalidOperationException]) { $errorMessage = $nativeError.Message }
        $failure = @{ id = $requestId; ok = $false; error = $errorMessage }
        if ($nativeError.Data.Contains('focusDiagnostic')) { $failure.focusDiagnostic = [string]$nativeError.Data['focusDiagnostic'] }
        if ($request.diagnostic -and $nativeError.Data.Contains('cursorDiagnostic')) { $failure.cursorDiagnostic = [string]$nativeError.Data['cursorDiagnostic'] }
        $response = $failure | ConvertTo-Json -Compress
    }
    [Console]::WriteLine($response)
    [Console]::Out.Flush()
    if ($operation -eq 'dispose') { break }
}
