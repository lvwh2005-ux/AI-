// A recording window temporarily owns shortcut suspension; close/blur must release it.
export class ShortcutRecording {
  private active = false;
  constructor(private suspend: () => void, private restore: () => void) {}
  get recording() { return this.active; }
  begin() {
    if (this.active) return;
    this.suspend(); this.active = true;
  }
  end() {
    if (!this.active) return;
    this.active = false; this.restore();
  }
}
