import { BrowserWindow, nativeImage, type NativeImage } from 'electron';
import type { Rect } from '../../shared/contracts';
import { annotationGeometry, annotationsSchema, drawAnnotatedBitmap, type Annotation } from '../../shared/annotations';

const page = '<!doctype html><html><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; script-src \'none\'; connect-src \'none\'; frame-src \'none\'"></head><body></body></html>';

function deadline<T>(promise: Promise<T>, milliseconds: number, message: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(message)), milliseconds);
    promise.then((value) => { clearTimeout(timer); resolve(value); }, (error) => { clearTimeout(timer); reject(error); });
  });
}
function cancellable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) return Promise.reject(new Error('截图标注已取消'));
  return new Promise((resolve, reject) => {
    const abort = () => reject(new Error('截图标注已取消'));
    signal.addEventListener('abort', abort, { once: true });
    promise.then((value) => { signal.removeEventListener('abort', abort); resolve(value); }, (error) => { signal.removeEventListener('abort', abort); reject(error); });
  });
}

export class AnnotationCompositor {
  private window?: BrowserWindow;
  private preparing?: Promise<void>;
  private queue: Promise<void> = Promise.resolve();
  private generation = 0;
  private cancellation = new AbortController();

  warmup(): Promise<void> {
    if (this.preparing) return this.preparing;
    if (this.window && !this.window.isDestroyed()) return Promise.resolve();
    const win = new BrowserWindow({ show: false, width: 1, height: 1, skipTaskbar: true, frame: false, focusable: false, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, webSecurity: true, backgroundThrottling: false, partition: 'annotation-compositor', devTools: false } });
    this.window = win;
    win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    win.webContents.on('will-navigate', (event) => event.preventDefault());
    win.webContents.session.setPermissionCheckHandler(() => false);
    win.webContents.session.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    win.on('closed', () => { if (this.window === win) { this.window = undefined; this.preparing = undefined; } });
    win.webContents.on('render-process-gone', () => { if (!win.isDestroyed()) win.destroy(); });
    const preparing = deadline(win.loadURL(`data:text/html;charset=UTF-8,${encodeURIComponent(page)}`), 8000, '标注绘制模块启动超时，请重试').then(() => {
      if (win.isDestroyed()) throw new Error('标注绘制窗口已关闭，请重试');
    }).catch((error) => {
      if (!win.isDestroyed()) win.destroy();
      throw error;
    }).finally(() => { if (this.preparing === preparing) this.preparing = undefined; });
    this.preparing = preparing;
    return preparing;
  }

  render(cropped: NativeImage, rect: Rect, annotations: Annotation[]): Promise<NativeImage> {
    if (!annotations.length) return Promise.resolve(cropped);
    let validated: Annotation[];
    try {
      validated = annotationsSchema.parse(annotations);
      if (![rect.width, rect.height].every(Number.isFinite) || rect.width <= 0 || rect.height <= 0 || cropped.isEmpty()) throw new Error('截图选区无效');
    } catch { return Promise.reject(new Error('截图标注无效或内容过多，请清除部分标注后重试')); }
    const generation = this.generation;
    const signal = this.cancellation.signal;
    const render = async () => {
      if (generation !== this.generation) throw new Error('截图标注已取消');
      await this.warmup();
      const win = this.window;
      if (!win || win.isDestroyed() || generation !== this.generation) throw new Error('截图标注已取消');
      const input = { image: cropped.toDataURL(), size: { width: rect.width, height: rect.height }, annotations: validated };
      // Only these two application-owned functions become executable code.
      // Screenshot pixels and user-entered text are always JSON data arguments.
      const code = `(${drawAnnotatedBitmap.toString()})(${JSON.stringify(input)}, (${annotationGeometry.toString()}))`;
      try {
        const result: unknown = await deadline(cancellable(win.webContents.executeJavaScript(code), signal), 10_000, '截图标注绘制超时，请重试');
        if (generation !== this.generation) throw new Error('截图标注已取消');
        if (typeof result !== 'string' || !result.startsWith('data:image/png;base64,')) throw new Error('标注图片返回格式无效');
        const image = nativeImage.createFromDataURL(result);
        if (image.isEmpty()) throw new Error('标注图片生成失败');
        return image;
      } catch (error) {
        if (!win.isDestroyed()) win.destroy();
        throw error;
      }
    };
    const result = this.queue.then(render, render);
    this.queue = result.then(() => {}, () => {});
    return result;
  }

  dispose() {
    this.generation++;
    this.cancellation.abort(); this.cancellation = new AbortController();
    const win = this.window;
    this.window = undefined; this.preparing = undefined;
    if (win && !win.isDestroyed()) win.destroy();
  }
}
