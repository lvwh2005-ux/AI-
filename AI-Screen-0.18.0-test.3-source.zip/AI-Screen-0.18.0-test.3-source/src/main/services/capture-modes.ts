import type { CaptureMode, ModeCapability } from '../../shared/capture-modes';
import { modeCapabilities } from '../../shared/capture-modes';
import type { Rect } from '../../shared/contracts';
import type { LongshotScrollMode } from '../../shared/longshot';

export interface CaptureModeContext { displayId: string; rect: Rect; signal: AbortSignal; scrollMode?: LongshotScrollMode; targetWindowId?: string;recordingOptions?:import('../../shared/recording/contracts').RecordingOptions }
export interface CaptureModeExtension {
  mode: 'longshot' | 'record';
  readonly available?: boolean;
  readonly active?: boolean;
  start(context: CaptureModeContext): Promise<void>;
  cancel(): Promise<void>;
}
/** Native collection backends register here; selection UI does not own them. */
export class CaptureModeRegistry {
  private extensions = new Map<CaptureMode, CaptureModeExtension>();
  register(extension: CaptureModeExtension) { this.extensions.set(extension.mode, extension); }
  capabilities(): ModeCapability[] {
    return modeCapabilities.map((item) => this.extensions.has(item.mode) && this.extensions.get(item.mode)?.available !== false ? { ...item, available: true, explanation: item.mode === 'longshot' ? '框选后直接开始手动采集；在原页面上下滚动，回看去重，固定栏可确认裁为正文区域。' : '框选后在悬浮工具条选择格式和声音，点击开始录制；支持暂停、预览与另存。' } : { ...item });
  }
  async start(mode: CaptureMode, context: CaptureModeContext) {
    const extension = this.extensions.get(mode);
    if (!extension || extension.available === false) throw new Error(modeCapabilities.find((item) => item.mode === mode)?.explanation ?? '此模式不可用');
    if ([...this.extensions.values()].some(item => item !== extension && item.active)) throw new Error('请先完成或取消正在进行的采集');
    await extension.start(context);
  }
}
