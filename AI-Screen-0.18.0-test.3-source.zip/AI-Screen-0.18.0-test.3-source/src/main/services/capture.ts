import type { NativeImage, Rectangle } from 'electron';
import { captureDisplayPlan, toPixelRect, type CaptureDisplay } from '../../shared/geometry';
import type { CaptureFrame, PixelSample, Rect } from '../../shared/contracts';

interface CaptureDependencies {
  displays(): CaptureDisplay[];
  preferredDisplay(): string;
  sources(size: { width: number; height: number }): Promise<readonly { display_id: string; thumbnail: NativeImage }[]>;
}
export class CaptureService {
  private frames = new Map<string, { display: CaptureDisplay; bitmap: NativeImage; preview?: string }>();
  private generation = 0;
  constructor(private dependencies: CaptureDependencies) {}

  async takeAll(): Promise<CaptureDisplay[]> {
    const generation = ++this.generation;
    this.frames.clear();
    const plan = captureDisplayPlan(this.dependencies.displays(), this.dependencies.preferredDisplay());
    if (!plan.length) throw new Error('没有可用的显示器');
    // One enumeration captures the complete display group. Request the largest
    // physical dimensions so smaller screens retain their available resolution.
    const thumbnailSize = plan.reduce((size, display) => ({
      width: Math.max(size.width, display.pixelSize.width),
      height: Math.max(size.height, display.pixelSize.height),
    }), { width: 0, height: 0 });
    const sources = await this.dependencies.sources(thumbnailSize);
    if (generation !== this.generation) throw new Error('截图已取消，请重新截图');
    // Electron may return smaller thumbnails; crop() uses actual bitmap dimensions.
    const snapshots = plan.map(({ pixelSize: _pixelSize, ...display }) => {
      const source = sources.find((item) => item.display_id === display.id);
      if (!source || source.thumbnail.isEmpty()) throw new Error(`无法读取${display.label}，请重试或检查屏幕录制权限`);
      return { display, bitmap: source.thumbnail };
    });
    this.frames = new Map(snapshots.map((frame) => [frame.display.id, frame]));
    return snapshots.map(({ display }) => display);
  }
  // Retained for callers that only need the cursor display's bounds.
  async take(): Promise<Rectangle> { return (await this.takeAll())[0].bounds; }
  frame(displayId?: string): CaptureFrame | null {
    const snapshot = displayId === undefined ? this.frames.values().next().value : this.frames.get(displayId);
    if (!snapshot) return null;
    // The full-screen preview is temporary; selected content is cropped from
    // the original bitmap so copying, OCR and AI input retain their quality.
    snapshot.preview ??= `data:image/jpeg;base64,${snapshot.bitmap.toJPEG(95).toString('base64')}`;
    return {
      image: snapshot.preview, width: snapshot.display.bounds.width, height: snapshot.display.bounds.height,
      displayId: snapshot.display.id, displayLabel: snapshot.display.label, scaleFactor: snapshot.display.scaleFactor,
    };
  }
  crop(rect: Rect, displayId?: string) {
    const snapshot = displayId === undefined ? this.frames.values().next().value : this.frames.get(displayId);
    if (!snapshot) throw new Error('选区已失效，请重新截图');
    return snapshot.bitmap.crop(toPixelRect(rect, snapshot.display.bounds, snapshot.bitmap.getSize()));
  }
  sample(point: { x: number; y: number }, displayId: string): PixelSample | null {
    const snapshot = this.frames.get(displayId);
    if (!snapshot) return null;
    const size = snapshot.bitmap.getSize(), bounds = snapshot.display.bounds;
    const x = Math.max(0, Math.min(size.width - 1, Math.floor(point.x * size.width / bounds.width)));
    const y = Math.max(0, Math.min(size.height - 1, Math.floor(point.y * size.height / bounds.height)));
    const left = Math.max(0, x - 7), top = Math.max(0, y - 7);
    const width = Math.min(size.width, x + 8) - left, height = Math.min(size.height, y + 8) - top;
    const patch = snapshot.bitmap.crop({ x: left, y: top, width, height });
    const bytes = patch.toBitmap();
    const offset = ((y - top) * width + x - left) * 4;
    // Electron's native image bitmap is BGRA on Windows, independently of preview JPEG.
    const rgb: [number, number, number] = [bytes[offset + 2], bytes[offset + 1], bytes[offset]];
    return { image: patch.toDataURL(), width, height, center: { x: x - left, y: y - top }, rgb,
      hex: `#${rgb.map((channel) => channel.toString(16).padStart(2, '0')).join('').toUpperCase()}`,
      position: { x: Math.round(bounds.x + point.x), y: Math.round(bounds.y + point.y) } };
  }
  clear() { this.generation++; this.frames.clear(); }
}
