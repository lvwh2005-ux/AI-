import {spawn,type ChildProcess} from 'node:child_process';
import {z} from 'zod';
import {toPixelRect} from '../../shared/geometry';
import {CAPTURE_HELPER_FLAG,captureProcessConfigSchema,captureProcessErrors,type CaptureProcessConfig} from './capture-process-protocol';
import type {StageProfiler,ProfileSpan} from '../../shared/scroll-capture/profiler';
import type {CaptureBackend} from '../../shared/longshot';

export type CaptureChild=Pick<ChildProcess,'on'|'once'|'send'|'kill'|'pid'>;
const size=z.object({width:z.number().int().positive(),height:z.number().int().positive()}).strict();
const backendSchema=z.enum(['gdi-roi','electron-snapshot']);
const spanSchema=z.object({stage:z.enum(['source-dispatch','source-read','capture-crop','bitmap-copy','native-roi-read','native-grab']),startMs:z.number().finite().nonnegative(),durationMs:z.number().finite().nonnegative(),metrics:z.record(z.string(),z.number().finite()).optional()}).strict();
const replySchema=z.discriminatedUnion('kind',[
  z.object({kind:z.literal('initialized'),id:z.number().int().positive(),backend:backendSchema.optional()}).strict(),
  z.object({kind:z.literal('error'),id:z.number().int().positive(),issue:z.enum(['display-changed','empty-source','native-size','capture-error','protocol-error']),retries:z.number().int().min(0).max(1)}).strict(),
  z.object({kind:z.literal('frame'),id:z.number().int().positive(),width:z.number().int().positive(),height:z.number().int().positive(),bitmapSize:size,
    data:z.instanceof(Uint8Array),retries:z.number().int().min(0).max(1),profile:z.array(spanSchema).max(65),timeOrigin:z.number().finite(),backend:backendSchema.optional()}).strict(),
]);
export type CaptureProcessFrame=Extract<z.infer<typeof replySchema>,{kind:'frame'}>;
interface Pending {id:number;resolve(reply:z.infer<typeof replySchema>):void;reject(error:Error):void;timer:NodeJS.Timeout}
interface Options {launch?():CaptureChild;entryPath?:string;timeoutMs?:number;profiler?:StageProfiler}

/** One helper and one in-flight read, on a private inherited IPC channel.
 * Same Electron runtime on both ends keeps V8 binary serialization compatible. */
export class CaptureProcessClient{
  private child?:CaptureChild;
  private disposed=false;
  private reading=false;
  private nextId=0;
  private pending?:Pending;
  private ready?:{resolve():void;reject(error:Error):void;timer:NodeJS.Timeout};
  private starting?:Promise<void>;
  private retries=0;
  private backendName?:CaptureBackend;
  private frameBackend?:CaptureBackend;
  private readonly config:CaptureProcessConfig;
  get retryCount(){return this.retries;}
  get pid(){return this.child?.pid;}
  get backend(){return this.backendName;}
  constructor(config:CaptureProcessConfig,private options:Options={}){this.config=captureProcessConfigSchema.parse(config);}
  async read(signal:AbortSignal):Promise<CaptureProcessFrame>{
    if(signal.aborted)throw new DOMException('长截图已取消','AbortError');
    if(this.disposed)throw new Error('独立采集进程已结束');
    if(this.reading)throw new Error('不能并发读取同一截图帧源');
    this.reading=true;
    const abort=()=>this.dispose(new DOMException('长截图已取消','AbortError'));
    signal.addEventListener('abort',abort,{once:true});
    try{
      await this.start();
      if(signal.aborted)throw new DOMException('长截图已取消','AbortError');
      const run=()=>this.request('read');
      const reply=await(this.options.profiler?this.options.profiler.measureAsync('capture-process-roundtrip',run):run());
      if(reply.kind!=='frame')throw new Error(captureProcessErrors['protocol-error']);
      return reply;
    }catch(error){this.dispose(error instanceof Error?error:new Error('独立采集失败'));throw error;}
    finally{signal.removeEventListener('abort',abort);this.reading=false;}
  }
  dispose(error=new Error('独立采集进程已结束')){
    if(this.disposed)return;this.disposed=true;
    if(this.ready){clearTimeout(this.ready.timer);this.ready.reject(error);this.ready=undefined;}
    if(this.pending){clearTimeout(this.pending.timer);this.pending.reject(error);this.pending=undefined;}
    this.child?.kill();this.child=undefined;
  }
  private start():Promise<void>{
    return this.starting??=this.initialize();
  }
  private async initialize(){
    const ready=new Promise<void>((resolve,reject)=>{
      this.ready={resolve,reject,timer:setTimeout(()=>this.dispose(new Error('独立采集进程启动超时')),this.options.timeoutMs??8000)};
    });
    // Attach a handler immediately, including the synchronous spawn-failure path.
    const handledReady=ready.catch(error=>{throw error;});
    try{
      if(this.options.launch)this.child=this.options.launch();
      else{
        const {app}=require('electron') as typeof import('electron');
        const environment={...process.env};delete environment.ELECTRON_RUN_AS_NODE;delete environment.AI_SCREEN_DEV_URL;
        this.child=spawn(process.execPath,[...(!app.isPackaged?[this.options.entryPath??app.getAppPath()]:[]),CAPTURE_HELPER_FLAG],
          {env:environment,stdio:['ignore','ignore','ignore','ipc'],serialization:'advanced',windowsHide:true});
      }
      this.child.on('message',message=>this.receive(message));
      this.child.once('error',()=>this.dispose(new Error('无法启动独立采集进程')));
      this.child.once('exit',()=>this.dispose(new Error('独立采集进程已退出')));
      this.child.once('disconnect',()=>this.dispose(new Error('独立采集进程连接已关闭')));
    }catch{this.dispose(new Error('无法启动独立采集进程'));}
    await handledReady;
    const initialized=await this.request('init');
    if(initialized.kind!=='initialized')throw new Error(captureProcessErrors['protocol-error']);
  }
  private request(kind:'init'|'read'):Promise<z.infer<typeof replySchema>>{
    if(this.disposed||!this.child)return Promise.reject(new Error('独立采集进程已结束'));
    if(this.pending)return Promise.reject(new Error('采集进程已有在途请求'));
    const id=++this.nextId;
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>this.dispose(new Error('独立采集读取超时')),this.options.timeoutMs??6000);
      this.pending={id,resolve,reject,timer};
      try{this.child!.send({kind,id,...(kind==='init'?{config:this.config}:{})},error=>{if(error)this.dispose(new Error('无法提交独立采集请求'));});}
      catch{this.dispose(new Error('无法提交独立采集请求'));}
    });
  }
  private receive(message:unknown){
    if(this.disposed)return;
    if(this.ready&&message&&typeof message==='object'&&Object.keys(message).length===1&&(message as {kind?:unknown}).kind==='ready'){
      clearTimeout(this.ready.timer);this.ready.resolve();this.ready=undefined;return;
    }
    const pending=this.pending;
    if(!pending)return;
    const parsed=replySchema.safeParse(message);
    if(!parsed.success){this.dispose(new Error(captureProcessErrors['protocol-error']));return;}
    const reply=parsed.data;if(reply.id!==pending.id)return;
    if(reply.kind==='frame'&&reply.backend){
      if(this.frameBackend&&this.frameBackend!==reply.backend){this.dispose(new Error(captureProcessErrors['protocol-error']));return;}
      this.frameBackend=reply.backend;
    }
    if((reply.kind==='initialized'||reply.kind==='frame')&&reply.backend)this.backendName=reply.backend;
    if(reply.kind==='frame'){
      const expected=toPixelRect(this.config.rect,this.config.display.bounds,this.config.nativeSize);
      if(reply.bitmapSize.width!==this.config.nativeSize.width||reply.bitmapSize.height!==this.config.nativeSize.height
        ||reply.width!==expected.width||reply.height!==expected.height||reply.data.byteLength!==expected.width*expected.height*4){
        this.dispose(new Error(captureProcessErrors['protocol-error']));return;
      }
      const origin=reply.timeOrigin-performance.timeOrigin;
      const spans:ProfileSpan[]=reply.profile.map(span=>({...span,stage:`capture-child-${span.stage}`,startMs:span.startMs+origin}));
      this.options.profiler?.observe(spans);
    }
    if(reply.kind==='frame'||reply.kind==='error')this.retries+=reply.retries;
    this.pending=undefined;clearTimeout(pending.timer);
    if(reply.kind==='error')pending.reject(new Error(captureProcessErrors[reply.issue]));else pending.resolve(reply);
  }
}
