import {deflateSync,crc32} from 'node:zlib';
import type {BitmapFrame} from '../../shared/scroll-capture/types';
function chunk(kind:string,data:Buffer){
  const type=Buffer.from(kind),length=Buffer.alloc(4),checksum=Buffer.alloc(4);
  length.writeUInt32BE(data.length);checksum.writeUInt32BE(crc32(data,crc32(type)));
  return Buffer.concat([length,type,data,checksum]);
}
/** Windows NativeImage BGRA premultiplied pixels to standard RGBA PNG.
 * Used only for bounded previews, in a dedicated worker; final output is unchanged. */
export function previewPNG(frame:BitmapFrame):Buffer{
  const {width,height,data}=frame;
  if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>2048||height>2048||data.length!==width*height*4)throw new Error('预览像素无效或超过预算');
  const rows=Buffer.alloc((width*4+1)*height);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const from=(y*width+x)*4,to=y*(width*4+1)+1+x*4,alpha=data[from+3];
    if(alpha===255){rows[to]=data[from+2];rows[to+1]=data[from+1];rows[to+2]=data[from];}
    else if(alpha){rows[to]=Math.min(255,Math.round(data[from+2]*255/alpha));rows[to+1]=Math.min(255,Math.round(data[from+1]*255/alpha));rows[to+2]=Math.min(255,Math.round(data[from]*255/alpha));}
    rows[to+3]=alpha;
  }
  const header=Buffer.alloc(13);header.writeUInt32BE(width,0);header.writeUInt32BE(height,4);header[8]=8;header[9]=6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',deflateSync(rows,{level:1})),chunk('IEND',Buffer.alloc(0))]);
}
