import { dialog, nativeImage, type NativeImage } from 'electron';
import { randomUUID } from 'node:crypto';
import path from 'node:path';
import type { CaptureModeContext, CaptureModeExtension } from './capture-modes';
import type { LongshotCommand, LongshotCommandResult, LongshotState } from '../../shared/longshot';
import type { BitmapFrame, StitchResult } from '../../shared/longshot-stitcher';
import { AutoScrollPolicy } from '../../shared/longshot-auto';
import {AutoScrollScheduler} from '../../shared/auto-scroll-scheduler';
import { stableLongshotFrame } from '../../shared/longshot-stability';
import { LiveRegionSource } from './live-region-source';
import { LongshotProcessor, LONGSHOT_LIMITS } from './longshot-processor';
import { saveLongshotPNG,saveLongshotDiagnostics } from './longshot-file';
import type { ClipboardService } from './clipboard';
import type { LongshotWindow } from '../longshot-window';
import { WindowsLongshotScroller, type ScrollDriver } from './longshot-scroller';
import { annotationsSchema, type Annotation } from '../../shared/annotations';
import type { AnnotationCompositor } from './annotation-compositor';
import { LONGSHOT_MAX_WIDTH } from '../../shared/longshot-limits';
import { PREVIEW_INTERVAL_MS, type PreviewSize } from '../../shared/scroll-capture/preview';
import { CaptureTelemetry, type CaptureActivity } from '../../shared/scroll-capture/telemetry';
import { CaptureBufferError, CapturePipeline } from './capture-pipeline';
import { PreviewPump } from './preview-pump';
import type { ViewportBitmap } from '../../shared/scroll-capture/preview-viewport';
import {FrameFingerprint} from './frame-fingerprint';
import {buildDiagnosticReport,type DiagnosticEnvironment} from '../../shared/scroll-capture/diagnostics';

type Processor = Pick<LongshotProcessor, 'available'|'push'|'bitmap'|'preview'|'viewport'|'confirmRegion'|'keepRegion'|'dispose'> & Partial<Pick<LongshotProcessor,'encodePreview'>>;
interface Session {
  state: LongshotState; source: LiveRegionSource; processor: Processor;
  abort: AbortController; detach(): void; loop?: Promise<void>; wake?: () => void;
  stop: boolean; probe?: BitmapFrame; image?: NativeImage; ioPending: boolean;
  suspended: boolean; samplingRevision: number; rejected?: string;
  scroller?: ScrollDriver; bound: boolean; policy: AutoScrollPolicy;
  scrollChanging: boolean; autoFinishMessage?: string; stableSince: number;
  autoQueued:boolean;autoVerifyUntil:number;
  frameTimes:WeakMap<BitmapFrame,{started:number;captured:number;wheelUnits:number}>;
  scheduler:AutoScrollScheduler;lastWheelUnits:number;
  context: CaptureModeContext;
  lastPreviewSize?: PreviewSize;
  lastPreviewViewport?:number;lastPreviewTop?:number;
  lastPreviewRequest?:number;
  meter: CaptureTelemetry; telemetryTimer?: NodeJS.Timeout; lastTelemetryAt: number;
  processing?: Promise<StitchResult>;
  pipeline?: CapturePipeline<BitmapFrame>; previewPump?: PreviewPump;
  fingerprint:FrameFingerprint;startedAt:number;diagnosticPending:boolean;
}
class LongshotReadError extends Error { constructor(message:string,readonly issue:'capacity'|'capture-error'){super(message);} }
interface Dependencies {
  window: LongshotWindow; clipboard: ClipboardService;
  beforeCapture(context: CaptureModeContext): Promise<string | undefined>;
  onIdle(): void;
  onState?(state: LongshotState | null): void;
  chooseSavePath?(): Promise<string | undefined>;
  chooseDiagnosticPath?():Promise<string|undefined>;
  diagnosticEnvironment?(context:CaptureModeContext):DiagnosticEnvironment;
  createSource?(context: CaptureModeContext): LiveRegionSource;
  createProcessor?(): Processor;
  createScroller?(context: CaptureModeContext): ScrollDriver;
  compositor: AnnotationCompositor;
  analyze(image: NativeImage): Promise<void>;
}
const activeStatuses = new Set(['preparing', 'capturing', 'finishing']);
export class LongshotService implements CaptureModeExtension {
  readonly mode = 'longshot' as const;
  private session?: Session;
  constructor(private deps: Dependencies) {}
  refreshPreview() {
    const session = this.session;
    if (session && !session.stop && this.current(session)) session.previewPump?.request();
  }
  get state(): LongshotState | null { return this.session ? { ...this.session.state } : null; }
  get active() { return !!this.session && activeStatuses.has(this.session.state.status); }
  original(id: string) {
    const session = this.session;
    if (!session || session.state.id !== id || session.state.status !== 'done' || !session.image) throw new Error('长图尚未完成或会话已结束');
    return {image: session.image.toDataURL(), width: session.state.width, height: session.state.height};
  }
  async start(context: CaptureModeContext): Promise<void> {
    if (this.active) throw new Error('长截图正在进行，请先完成或取消');
    if (context.signal.aborted) throw new Error('截图已取消');
    if (this.session) { this.release(this.session); this.session = undefined; this.deps.onState?.(null); }
    this.deps.window.close();
    const source = this.deps.createSource?.(context) ?? new LiveRegionSource(context.displayId, context.rect);
    const abort = new AbortController();
    const session: Session = {
      state: { id: randomUUID(), status: 'preparing', width: 0, height: 0, frames: 0, message: '正在准备，请先保持页面静止…', canFinish: false,
        scrollMode: context.scrollMode ?? 'manual', paused: false, scrollSteps: 0, initialHeight: 0, appendedRows: 0 },
      source, processor: this.deps.createProcessor?.() ?? new LongshotProcessor(), abort, detach: () => {}, stop: false, ioPending: false, suspended: false, samplingRevision: 0,
      bound: false, policy: new AutoScrollPolicy(), scrollChanging: false, stableSince: Date.now(),
      autoQueued:false,autoVerifyUntil:0,
      frameTimes:new WeakMap(),
      scheduler:new AutoScrollScheduler(),lastWheelUnits:120,
      context, meter:new CaptureTelemetry(), lastTelemetryAt:0,
      fingerprint:new FrameFingerprint(),startedAt:performance.now(),diagnosticPending:false,
    };
    this.session = session;
    session.state.diagnosticEnvironment=this.deps.diagnosticEnvironment?.(context);
    session.previewPump = new PreviewPump(PREVIEW_INTERVAL_MS, () => this.updatePreview(session), (error) => {
      if (this.current(session) && !session.stop) this.fail(session, error);
    });
    session.pipeline = new CapturePipeline({
      maxFrames: 3, maxBytes: 64 * 1024 * 1024, maxFrameBytes: LONGSHOT_LIMITS.maxBytes / 2,
      bytes: (frame: BitmapFrame) => frame.data.byteLength,
      consume: async (frame) => {
        const automatic=session.state.scrollMode==='auto',revision=session.samplingRevision;
        const wheelUnits=session.frameTimes.get(frame)?.wheelUnits??120;
        const result=await this.accept(session,frame);
        if(!automatic||!this.current(session)||session.stop||session.state.paused||session.suspended||session.diagnosticPending
          ||revision!==session.samplingRevision||session.state.scrollMode!=='auto')return;
        // Feedback controls future input, while already captured frames retain
        // their order. The producer never awaits this individual commit.
        session.scheduler.observe(result,wheelUnits);
        const action=session.policy.observe(result);
        if(action.kind==='pause')this.pauseAutomatic(session,action.reason);
        else if(action.kind==='finish'){session.autoFinishMessage=action.reason;session.stop=true;session.wake?.();}
        else if(action.kind==='verify'){session.autoVerifyUntil=Date.now()+action.delayMs;session.wake?.();}
      },
      discarded: (count) => session.meter.discard(count),
      changed: (stats) => {
        const wasWaiting = session.meter.snapshot().waitingForSpace;
        session.meter.queue(stats);
        if (!this.current(session)) return;
        if (!wasWaiting && stats.waitingForSpace && !session.state.paused && !session.suspended && !session.stop && !session.rejected) {
          this.update(session, {message: '拼接正在追赶采集，已暂缓读屏以保留帧顺序；请暂缓滚动'});
        }
        this.activity(session, session.meter.snapshot().activity);
      },
      failed: (error) => { if (this.current(session) && !session.stop) this.fail(session, error); },
    });
    const cancel = () => { if (this.session === session) void this.cancel(); };
    context.signal.addEventListener('abort', cancel, { once: true });
    session.detach = () => context.signal.removeEventListener('abort', cancel);
    try {
      // Start the helper while the user-activated screenshot window still owns
      // foreground rights. It never scrolls until the overlay has left.
      if (session.state.scrollMode === 'auto') {
        session.scroller = this.deps.createScroller?.(context) ?? new WindowsLongshotScroller([], context.targetWindowId);
        try { await session.scroller.prepare?.(); }
        catch (error) { if (this.current(session)) this.inputFailure(session, error); }
        if (!this.current(session)) return;
      }
      const backdrop = await this.deps.beforeCapture(context);
      if (!this.current(session)) return;
      const controlsVisible = await this.deps.window.showControls(source.globalRect, backdrop);
      // cancel() already revoked this session's window. Do not close a newer
      // session's window if its startup overtakes this awaited page load.
      if (!this.current(session)) return;
      this.update(session, { controlsInTray: !controlsVisible, panelOverlay: this.deps.window.overlaysSelection });
      // Let the frozen overlays leave the compositor before the first live read.
      await this.delay(session, 100);
      if (!this.current(session)) return;
      session.stableSince = Date.now();
      session.loop = this.collect(session);
      // Keep the collection promise separate: finish() waits for it. Calling
      // finish from inside collect would wait on itself at the end of a page.
      void session.loop.then(() => {
        if (this.current(session) && session.autoFinishMessage && session.state.status !== 'finishing') {
          void this.finish(session).catch(() => {});
        }
      });
    } catch (error) { if (this.current(session)) { this.fail(session, error); throw error; } }
  }
  async command(id: string, command: LongshotCommand, annotations: Annotation[] = []): Promise<LongshotCommandResult> {
    const marks = annotationsSchema.parse(annotations);
    if (marks.length && !['copy', 'save', 'analyze'].includes(command)) throw new Error('此操作不接受标注');
    const session = this.session;
    if (!session || session.state.id !== id) throw new Error('长截图会话已结束');
    if (command === 'cancel' || command === 'close') { await this.cancel(); return {}; }
    if(command==='export-diagnostics')return this.exportDiagnostics(session);
    if(session.diagnosticPending)throw new Error('请先关闭诊断保存对话框');
    if (command === 'finish') { await this.finish(session); return {}; }
    // The live toolbar's download action reuses the existing completion and
    // save flow. The source session must still own the image after awaiting.
    if (command === 'save' && session.state.status !== 'done') {
      await this.finish(session);
      if (!this.current(session)) return { cancelled: true };
    }
    if (command === 'confirm-region' || command === 'keep-region') {
      if (!this.active || session.stop || !session.state.regionCandidate || session.scrollChanging) throw new Error('没有待确认的正文区域');
      session.scrollChanging = true;
      const revision = this.invalidateSampling(session);
      try {
        if (command === 'keep-region') {
          const result = await session.processor.keepRegion();
          if (!this.current(session) || session.stop || revision !== session.samplingRevision) return {};
          session.meter.resolveReview(result);
          this.update(session, { regionCandidate: undefined, paused: session.state.scrollMode === 'auto' });
          await this.applyResult(session, result, {width:session.state.sourcePixelWidth!,height:session.state.sourcePixelHeight!});
          return {};
        }
        const candidate = session.state.regionCandidate;
        const confirmStarted=performance.now();
        const result = await session.processor.confirmRegion();
        session.meter.measure('match',performance.now()-confirmStarted);session.meter.resolveReview(result);
        if (!this.current(session) || session.stop || revision !== session.samplingRevision) return {};
        if (result.kind !== 'appended') {
          await session.processor.keepRegion();
          if (!this.current(session) || session.stop || revision !== session.samplingRevision) return {};
          this.update(session, {regionCandidate:undefined});
          await this.applyResult(session,result,{width:session.state.sourcePixelWidth!,height:session.state.sourcePixelHeight!});
          return {};
        }
        session.scroller?.dispose(); session.scroller = undefined; session.bound = false;
        await this.deps.window.showControls(session.source.globalRectForPixels(candidate));
        if (!this.current(session) || session.stop || revision !== session.samplingRevision) return {};
        this.update(session, { initialHeight: candidate.height, regionCandidate: undefined, scrollMode: 'manual' });
        await this.applyResult(session, result, candidate);
        this.update(session, { paused: false, error: undefined, message: '已使用正文区域；继续手动上下滚动，可靠内容会自动拼接' });
        return {message: '已裁去外围固定栏，保留从首屏开始的正文'};
      } finally { session.scrollChanging = false; session.wake?.(); }
    }
    if (command === 'pause' || command === 'resume' || command === 'manual') {
      if (!this.active || session.stop || session.state.status === 'finishing') throw new Error('采集已经停止');
      if(session.state.regionCandidate)throw new Error('请先确认正文区域或保留原范围');
      if (command === 'manual') {
        this.invalidateSampling(session); session.scroller?.dispose(); session.scroller = undefined;
        session.bound = false; session.wake?.(); session.stableSince = Date.now();
        this.update(session, { scrollMode: 'manual', paused: false, error: undefined, message: session.rejected
          ? `${session.rejected}；请先回到最后成功拼接的位置，再手动上下滚动。`
          : '已转为手动；可以连续缓慢上下滚动，新增内容会自动拼接' });
        session.meter.resetRate();this.activity(session,'waiting-change',true);
        return {};
      }
      if(session.state.scrollMode==='manual'){
        if(command==='pause'){
          this.invalidateSampling(session);session.meter.resetRate();
          this.update(session,{paused:true,message:'手动采集已暂停；暂停期间的滚动不会加入长图'});
          this.activity(session,'paused',true);
          // Drain an already submitted worker frame before acknowledging Pause.
          // A read still in flight is discarded by samplingRevision in collect.
          await session.pipeline?.consumerIdle(); await session.processing;
        }else if(session.state.paused){
          this.invalidateSampling(session);session.meter.resetRate();
          this.update(session,{paused:false,error:undefined,message:'已继续手动采集；若暂停期间滚动过，请先回到最后成功拼接的位置'});
          this.activity(session,'waiting-change',true);session.wake?.();
        }
        return {};
      }
      if (command === 'pause') { this.pauseAutomatic(session, '已暂停自动滚动；点击继续后恢复原目标窗口', false); return {}; }
      if (!session.state.paused) return {};
      if (session.scrollChanging) throw new Error('正在恢复自动滚动，请稍候');
      session.scrollChanging = true;
      const revision = this.invalidateSampling(session);
      try {
        if (session.bound) await session.scroller!.resume(session.abort.signal);
        else await this.bindScroller(session);
        if (!this.current(session) || session.stop || revision !== session.samplingRevision || session.state.scrollMode !== 'auto') return {};
        session.policy.resume(); session.probe = undefined; session.stableSince = Date.now();
        this.update(session, { paused: false, error: undefined, message: '正在继续自动采集，请保持目标页面可见…' });
        session.wake?.();
      } catch (error) { if (this.current(session) && !session.stop && revision === session.samplingRevision) this.inputFailure(session, error); }
      finally { session.scrollChanging = false; }
      return {};
    }
    if (session.state.status !== 'done' || !session.image) throw new Error('请先完成长截图');
    if (session.ioPending) throw new Error('图片正在处理，请稍候');
    session.ioPending = true;
    try {
      const image = await this.deps.compositor.render(session.image, {x:0,y:0,width:session.state.width,height:session.state.height}, marks);
      if (!this.current(session)) return {cancelled:true};
      if (command === 'copy') {
        await this.deps.clipboard.writeImage(image);
        return { message: '长截图已复制' };
      }
      if (command === 'analyze') {
        await this.deps.analyze(image);
        return {message:'已打开 AI 分析，可在结果窗口取消或继续提问'};
      }
      let destination: string | undefined;
      if (this.deps.chooseSavePath) destination = await this.deps.chooseSavePath();
      else {
        const options = { title: '保存长截图', defaultPath: `长截图-${new Date().toISOString().replace(/[:.]/g, '-')}.png`, filters: [{ name: 'PNG 图片', extensions: ['png'] }], properties: ['showOverwriteConfirmation', 'createDirectory'] as ('showOverwriteConfirmation' | 'createDirectory')[] };
        const win = this.deps.window.get();
        const result = win ? await dialog.showSaveDialog(win, options) : await dialog.showSaveDialog(options);
        destination = result.canceled ? undefined : result.filePath;
      }
      if (!destination) return { cancelled: true };
      if (path.extname(destination).toLowerCase() !== '.png') throw new Error('请使用 .png 文件后缀保存长截图');
      if (!this.current(session) || !session.image) return { cancelled: true };
      await saveLongshotPNG(destination, image.toPNG(), () => this.current(session));
      return { message: 'PNG 长截图已保存' };
    } finally { session.ioPending = false; }
  }
  async cancel(): Promise<void> {
    const session = this.session;
    if (!session) return;
    this.release(session); this.session = undefined;
    this.deps.window.close(); this.deps.onState?.(null); this.deps.onIdle();
  }
  private async exportDiagnostics(session:Session):Promise<LongshotCommandResult>{
    if(session.state.status==='finishing')throw new Error('请等待长截图生成完成后再导出诊断');
    if(session.diagnosticPending)throw new Error('诊断报告正在保存，请稍候');
    // Freeze the allow-listed snapshot before temporarily holding sampling.
    const report=buildDiagnosticReport(session.state,performance.now()-session.startedAt,session.state.diagnosticEnvironment);
    session.diagnosticPending=true;this.invalidateSampling(session);
    if(!session.stop){this.update(session,{message:'选择诊断文件保存位置期间暂缓采集'});this.activity(session,'paused',true);}
    try{
      let destination:string|undefined;
      if(this.deps.chooseDiagnosticPath)destination=await this.deps.chooseDiagnosticPath();
      else{
        const win=this.deps.window.get(),options={title:'保存长截图诊断报告',defaultPath:`AI-Screen-长截图诊断-${new Date().toISOString().replace(/[:.]/g,'-')}.json`,filters:[{name:'JSON 诊断报告',extensions:['json']}]};
        const selected=win?await dialog.showSaveDialog(win,options):await dialog.showSaveDialog(options);
        destination=selected.canceled?undefined:selected.filePath;
      }
      if(!destination||!this.current(session))return{cancelled:true};
      await saveLongshotDiagnostics(destination,report,()=>this.current(session));
      return{message:'诊断报告已保存；未包含截图、网址、标题或凭证'};
    }finally{
      session.diagnosticPending=false;
      if(this.current(session)&&!session.stop){
        this.invalidateSampling(session);session.meter.resetRate();
        const paused=session.suspended||session.state.paused||!!session.state.regionCandidate;
        this.update(session,{message:session.rejected??(paused?'采集仍暂停；继续前请回到最后可靠位置':'已恢复采集；选择文件期间的滚动不会加入长图')});
        this.activity(session,paused?'paused':'waiting-change',true);session.wake?.();
      }
    }
  }
  suspendSampling(suspended: boolean, id = this.session?.state.id) {
    const session = this.session;
    if (!session || session.state.id !== id || !this.active) return;
    session.suspended = suspended; this.invalidateSampling(session);
    session.stableSince = Date.now();
    session.meter.resetRate();
    this.update(session, { message: suspended ? '托盘菜单打开期间暂停采集' : session.state.regionCandidate ? '请先确认正文区域，再继续滚动' : session.state.paused ? '采集已暂停，请点击继续' : session.state.scrollMode === 'manual' ? '正在恢复采集，可以继续缓慢上下滚动' : '请保持页面静止，正在恢复采集…' });
    this.activity(session,suspended||session.state.paused?'paused':'waiting-change',true);
  }
  private current(session: Session) { return this.session === session && !session.abort.signal.aborted; }
  private invalidateSampling(session: Session) {
    session.samplingRevision++; session.probe = undefined;
    session.autoQueued=false;session.autoVerifyUntil=0;session.scheduler.reset();
    session.pipeline?.discardQueued(); session.wake?.();
    return session.samplingRevision;
  }
  private update(session: Session, patch: Partial<LongshotState>) {
        if (!this.current(session)) return;
    session.state = { ...session.state, ...patch };
    session.meter.phase(this.resolvedActivity(session,session.meter.snapshot().activity));
    session.state.telemetry=session.meter.snapshot();
    this.deps.window.publish(session.state); this.deps.onState?.({ ...session.state });
  }
  private resolvedActivity(session:Session,activity:CaptureActivity):CaptureActivity{
    if(session.state.status==='done')return 'completed';
    if(session.state.status==='finishing')return 'finishing';
    if(session.state.status==='error')return 'error';
    if(session.diagnosticPending)return 'paused';
    if(session.state.regionCandidate)return 'reviewing';
    if(session.state.paused||session.suspended)return 'paused';
    if(session.state.scrollMode==='manual'&&(session.state.consecutiveRejections??0)>=3)return 'seeking-overlap';
    return activity==='seeking-overlap'?'waiting-change':activity;
  }
  private activity(session:Session,activity:CaptureActivity,immediate=false){
    if(!this.current(session))return;
    session.meter.phase(this.resolvedActivity(session,activity));
    session.state.telemetry=session.meter.snapshot();
    const publish=()=>{
      session.telemetryTimer=undefined;
      if(!this.current(session))return;
      session.state.telemetry=session.meter.snapshot();session.lastTelemetryAt=performance.now();
      // Numeric-only updates never resend the large PNG previews.
      this.deps.window.publishTelemetry({id:session.state.id,telemetry:session.state.telemetry});
    };
    if(immediate||performance.now()-session.lastTelemetryAt>=200){if(session.telemetryTimer)clearTimeout(session.telemetryTimer);publish();}
    else if(!session.telemetryTimer)session.telemetryTimer=setTimeout(publish,200-(performance.now()-session.lastTelemetryAt));
  }
  private release(session: Session) {
    if(session.telemetryTimer)clearTimeout(session.telemetryTimer);session.telemetryTimer=undefined;
    session.stop = true; session.abort.abort(); session.wake?.(); session.detach();
    session.source.dispose?.();
    session.pipeline?.close(); session.previewPump?.stop();
    session.probe = undefined; session.image = undefined; session.state.preview = undefined; session.state.livePreview = undefined;
    session.state.liveDetailPreview = undefined; session.state.livePreviewRegion = undefined; session.state.liveDetailRegion = undefined;
    session.state.liveViewport = undefined;
    session.scroller?.dispose(); session.scroller = undefined;
    session.processor.dispose();
    session.fingerprint.clear();
    this.deps.compositor.dispose();
  }
  private delay(session: Session, ms: number): Promise<void> {
    return new Promise((resolve) => {
      const done = () => { clearTimeout(timer); if (session.wake === done) session.wake = undefined; resolve(); };
      const timer = setTimeout(done, ms); session.wake = done;
      if (!this.current(session) || session.stop) done();
    });
  }
  private async read(session: Session): Promise<BitmapFrame> {
    let timer: NodeJS.Timeout | undefined;
    const retries=session.source.retryCount??0;
    this.activity(session,'capturing');const started=performance.now();
    try {
      const image = await Promise.race([session.source.read(session.abort.signal), new Promise<never>((_resolve, reject) => { timer = setTimeout(() => reject(new LongshotReadError('屏幕读取超时，请重试','capture-error')), 6000); })]);
      if(session.state.captureBackend!==session.source.backend)this.update(session,{captureBackend:session.source.backend});
      const size = image.getSize();
      if (size.width > LONGSHOT_MAX_WIDTH || size.width * size.height * 4 > LONGSHOT_LIMITS.maxBytes / 2) throw new LongshotReadError('选区过大，请缩小范围后重试','capacity');
      const frame={...size,data:image.toBitmap()};session.meter.captured(performance.now(),session.fingerprint.observe(frame));
      session.frameTimes.set(frame,{started,captured:performance.now(),wheelUnits:session.lastWheelUnits});return frame;
    } catch(error){if(this.current(session))session.meter.error(error instanceof LongshotReadError?error.issue:'capture-error');throw error;
    } finally { session.meter.retried((session.source.retryCount??0)-retries);session.meter.measure('capture',performance.now()-started);if (timer) clearTimeout(timer); }
  }
  private async accept(session: Session, frame: BitmapFrame): Promise<StitchResult> {
    const task=(async()=>{
      this.activity(session,'matching');const started=performance.now();let result:StitchResult;
      const times=session.frameTimes.get(frame);
      if(times)session.meter.measure('queueWait',started-times.captured);
      try{result=await session.processor.push(frame);}catch(error){session.meter.error('processing-error');throw error;}
      finally{session.meter.measure('match',performance.now()-started);}
      if(times){session.meter.measure('endToEnd',performance.now()-times.started);session.frameTimes.delete(frame);}
      session.meter.result(result,session.state.status==='error');return this.applyResult(session,result,frame);
    })();
    session.processing=task;
    try{return await task;}finally{if(session.processing===task)session.processing=undefined;}
  }
  private async applyResult(session: Session, result: StitchResult, frame: {width:number;height:number}): Promise<StitchResult> {
    if (!this.current(session)) return result;
    const evidence={consecutiveRejections:result.consecutiveRejections??0,recoveredAfter:result.recoveredAfter,verification:result.verification,ignoredPixels:result.ignoredPixels,
      addedTop:result.addedTop??0,addedBottom:result.addedBottom??0,viewportY:result.viewportY??0,coveredTop:result.coveredTop??0,coveredBottom:result.coveredBottom,
      viewportDelta:result.viewportDelta??0,revisited:result.revisited,relocated:result.relocated};
    if (!session.state.sourcePixelWidth) this.update(session, { sourcePixelWidth: frame.width, sourcePixelHeight: frame.height });
    if (result.kind === 'limit') {
      session.stop = true; session.wake?.();
      session.source.dispose?.();
      session.pipeline?.close(); session.previewPump?.stop();
      session.rejected = result.reason ?? '已达到长图上限';
      this.update(session, { ...evidence, message: `${session.rejected}，请完成已有内容或取消`, canFinish: session.state.frames > 0,
        status: session.state.status === 'finishing' ? 'finishing' : 'error', error: session.rejected });
      session.scroller?.dispose(); session.scroller = undefined;
      this.deps.onIdle();
      await session.previewPump?.idle();
      if (this.current(session) && session.state.status === 'error') await this.updatePreview(session, true);
      return result;
    }
    if (result.kind === 'rejected') {
      session.rejected = result.reason ?? '无法可靠拼接，请回到上次位置并慢慢上下滚动';
      if (session.state.status !== 'error') this.update(session, { ...evidence, message: session.rejected+((result.consecutiveRejections??0)>=3?'；已保留现有长图，请往回滚至最后可靠采集的位置重新接上':'') });
      session.previewPump?.request(); return result;
    }
    if (result.kind === 'review') {
      this.invalidateSampling(session);
      session.rejected = result.reason ?? '固定区域与正文的运动不一致';
      if (session.state.status !== 'finishing' && session.state.status !== 'error') {
        this.update(session, { ...evidence, regionCandidate: result.regionCandidate, paused: true, message: '请暂停滚动：缩略图蓝框为建议正文区域，确认后会裁去外围固定栏' });
      }
      return result;
    }
    if (result.kind === 'duplicate') {
      if(result.recoveredAfter)session.rejected=undefined;
      const message=!session.rejected&&session.state.status!=='error'&&!session.state.paused&&!session.suspended
        ?result.recoveredAfter||result.relocated?'已重新定位到已采集内容，已去重；可以继续上下滚动'
          :result.revisited?'正在回看已采集内容，已去重；继续上下滚动可补充两端内容'
          :result.verification==='localized'?'画面仅有局部变化，已去重；继续上下滚动即可':'画面未变化，已自动去重；继续上下滚动即可'
        :session.state.message;
      this.update(session,{...evidence,message});
      session.previewPump?.request();
      return result;
    }
    session.rejected = undefined;
    const initialHeight = session.state.initialHeight || frame.height;
    this.update(session, { ...evidence, width: result.width, height: result.height, frames: session.state.frames + 1, canFinish: true,
      initialHeight, appendedRows: Math.max(0, result.height - initialHeight), fixedTop: result.fixedTop, fixedBottom: result.fixedBottom,
      contentRect: result.contentRect, verifiedTransitions: result.verifiedTransitions, lastOverlapRows: result.lastOverlapRows,
      // A producer/preview failure may overtake this worker reply. Retain its
      // terminal state while still allowing the already verified frame to commit.
      status: session.state.status === 'error' ? 'error' : session.state.status === 'finishing' ? 'finishing' : 'capturing',
      message: session.state.status === 'error' || session.state.paused || session.suspended ? session.state.message : result.recoveredAfter
        ?'已重新接上并拼接；未通过的画面没有加入长图，可以继续上下滚动':session.state.scrollMode === 'auto'
        ? '已拼接，正在自动向下滚动…' : result.addedTop?'已向顶部补充内容；可以继续上下滚动':'已采集；可以连续缓慢上下滚动，新增内容会自动拼接' });
    session.previewPump?.request();
    return result;
  }
  private async updatePreview(session: Session, stoppedByLimit = false) {
    if (!this.current(session) || (session.stop && !stoppedByLimit) || !session.state.frames) return;
    const region=session.state.livePreviewRegion;
    const size=this.deps.window.previewSize();
    const request=this.deps.window.previewRequest?.()??{sequence:0};
    const baseCurrent=region?.width===session.state.width && region.height===session.state.height && size.width===session.lastPreviewSize?.width && size.height===session.lastPreviewSize?.height
      && (session.state.viewportY??0)===session.lastPreviewViewport && (session.state.coveredTop??0)===session.lastPreviewTop;
    if(baseCurrent&&request.sequence===session.lastPreviewRequest)return;
    if(baseCurrent&&!request.view){this.update(session,{liveViewport:undefined});session.lastPreviewRequest=request.sequence;return;}
    // PreviewPump throttles/coalesces requests; matching and reads do not await it.
    this.activity(session,'previewing');const started=performance.now();
    try{
    const png=(frame:BitmapFrame)=>nativeImage.createFromBitmap(Buffer.from(frame.data.buffer,frame.data.byteOffset,frame.data.byteLength),{width:frame.width,height:frame.height}).toDataURL();
    const encode=async(frames:BitmapFrame[])=>session.processor.encodePreview?session.processor.encodePreview(frames):frames.map(png);
    const encodeView=(view:ViewportBitmap|undefined,image:string|undefined)=>{if(!view||!image)return undefined;const {frame,...metadata}=view;return {...metadata,image};};
    const isLatest=()=>{
      const latest=this.deps.window.previewRequest?.()??{sequence:0},latestSize=this.deps.window.previewSize();
      return latest.sequence===request.sequence&&latestSize.width===size.width&&latestSize.height===size.height;
    };
    if(baseCurrent&&request.view){
      const view=await session.processor.viewport(request.view);
      if(!this.current(session)||(session.stop&&!stoppedByLimit))return;
      const [image]=await encode([view.frame]);
      if(!this.current(session)||(session.stop&&!stoppedByLimit))return;
      if(!isLatest()){session.previewPump?.request();return;}
      this.update(session,{liveViewport:encodeView(view,image)});session.lastPreviewRequest=request.sequence;return;
    }
    const previews=await session.processor.preview(size,request.view);
    if (!this.current(session) || (session.stop && !stoppedByLimit) || (stoppedByLimit && session.state.status !== 'error') || !previews.overview.width) return;
    if(!isLatest()){session.previewPump?.request();return;}
    const sameDetail=previews.detailRegion.y===0&&previews.detailRegion.height===previews.overviewRegion.height;
    const [overview,...other]=await encode([previews.overview,...(!sameDetail?[previews.detail]:[]),...(previews.viewport?[previews.viewport.frame]:[])]);
    if(!this.current(session)||(session.stop&&!stoppedByLimit))return;
    if(!isLatest()){session.previewPump?.request();return;}
    this.update(session,{livePreview:overview,livePreviewRegion:previews.overviewRegion,
      liveDetailPreview:sameDetail?overview:other[0],liveDetailRegion:previews.detailRegion,
      liveViewport:encodeView(previews.viewport,other[sameDetail?0:1])});
    session.lastPreviewSize=size;session.lastPreviewViewport=previews.viewportY??0;session.lastPreviewTop=previews.coveredTop??0;
    session.lastPreviewRequest=request.sequence;
    }catch(error){session.meter.error('processing-error');throw error;}
    finally{session.meter.measure('preview',performance.now()-started);}
  }
  private errorMessage(error: unknown) { return error instanceof Error ? error.message : '自动滚动不可用，请转为手动'; }
  private inputFailure(session:Session,error:unknown){session.meter.error('input-error');this.pauseAutomatic(session,this.errorMessage(error));}
  private pauseAutomatic(session: Session, reason: string, showError = true) {
    this.invalidateSampling(session);
    this.update(session, { paused: true, message: reason, error: showError ? reason : undefined });
    session.meter.resetRate();this.activity(session,'paused',true);
  }
  private async bindScroller(session: Session) {
    session.scroller ??= this.deps.createScroller?.(session.context) ?? new WindowsLongshotScroller([], session.context.targetWindowId);
    await session.scroller.bind(session.source.globalRect, session.abort.signal);
    if (this.current(session)) session.bound = true;
  }
  private async collect(session: Session) {
    try {
      while (this.current(session) && !session.stop) {
        if (session.suspended || session.state.paused || session.scrollChanging || session.diagnosticPending) { session.stableSince = Date.now(); await this.delay(session, 150); continue; }
        const revision = session.samplingRevision;
        const automatic = session.state.scrollMode === 'auto';
        if (automatic) {
          try {
            if (!session.bound) await this.bindScroller(session);
            await session.scroller!.validate(session.abort.signal);
          } catch (error) { if (this.current(session) && !session.stop && revision === session.samplingRevision) this.inputFailure(session, error); continue; }
        }
        if (!this.current(session) || session.stop) break;
        if (session.suspended || session.state.paused || session.diagnosticPending || revision !== session.samplingRevision) continue;
        if(automatic&&session.autoQueued){
          if(session.autoVerifyUntil){
            const remaining=session.autoVerifyUntil-Date.now();
            if(remaining>0){await this.delay(session,Math.min(remaining,150));continue;}
            session.autoVerifyUntil=0;session.autoQueued=false;session.probe=undefined;continue;
          }
          // Establish the first reliable document once. Subsequent scrolls may
          // overlap matching as long as a future frame has queue capacity.
          if(!session.state.frames||!session.pipeline!.canCapture(session.source.frameBytes)){
            await this.delay(session,25);continue;
          }
          try{
            this.activity(session,'scrolling');
            const units=session.scheduler.units(session.state.sourcePixelHeight??session.state.initialHeight??0);
            await session.scroller!.step(session.abort.signal,units);session.lastWheelUnits=units;session.policy.didScroll();
            if(!this.current(session)||session.stop)break;
            this.update(session,{scrollSteps:(session.state.scrollSteps??0)+1});
            if(session.suspended||session.state.paused||session.diagnosticPending||revision!==session.samplingRevision)continue;
            session.autoQueued=false;session.probe=undefined;session.stableSince=Date.now();
            this.activity(session,'waiting-change');
            await this.delay(session,session.scheduler.settleDelayMs);continue;
          }catch(error){if(this.current(session)&&!session.stop&&revision===session.samplingRevision)this.inputFailure(session,error);continue;}
        }
        if (!automatic) {
          // Reserve capacity before reading; keep every queued frame in order.
          // Only the consumer awaits matching. Preview is coalesced separately.
          await session.pipeline!.capture(session.source.frameBytes, async () => {
            if (!this.current(session) || session.stop || session.suspended || session.state.paused || session.diagnosticPending || revision !== session.samplingRevision) return;
            const frame = await this.read(session);
            if (!this.current(session) || session.stop || session.suspended || session.state.paused || session.diagnosticPending || revision !== session.samplingRevision) {
              session.meter.discard(); return;
            }
            return frame;
          });
          if (!session.pipeline!.accepting) break;
          continue;
        }
        const frame = await this.read(session);
        if (!this.current(session) || session.stop){session.meter.discard();break;}
        if (session.suspended || session.state.paused || session.diagnosticPending || revision !== session.samplingRevision){session.meter.discard();this.activity(session,session.state.paused||session.suspended||session.diagnosticPending?'paused':'waiting-change');continue;}
        if (automatic) {
          try { await session.scroller!.validate(session.abort.signal); }
          catch (error) { if (this.current(session) && !session.stop && revision === session.samplingRevision) this.inputFailure(session, error); continue; }
          if (!this.current(session) || session.stop) break;
          if (session.suspended || session.state.paused || revision !== session.samplingRevision){session.meter.discard();continue;}
        }
        if (session.probe && stableLongshotFrame(session.probe, frame)) {
          session.scheduler.settled();
          // Capture is saved before scheduling input. Matching feedback arrives
          // independently from the same bounded ordered consumer used by manual.
          await session.pipeline!.capture(frame.data.length,async()=>{
            if(!this.current(session)||session.stop||session.state.paused||session.suspended||session.diagnosticPending||revision!==session.samplingRevision)return;
            return frame;
          });
          session.stableSince = Date.now();
          if (!this.current(session) || session.stop) break;
          if(!session.pipeline!.accepting)break;
          if(automatic&&session.state.scrollMode==='auto'&&!session.state.paused&&!session.suspended&&revision===session.samplingRevision){
            session.autoQueued=true;session.probe=undefined;continue;
          }
        } else {if(session.probe)session.scheduler.unsettled();this.activity(session,'waiting-stable');this.update(session, { message: '等待画面稳定；滚动后请稍停，避开动画或持续变化区域' });}
        if (automatic && Date.now() - session.stableSince > 8000) { this.pauseAutomatic(session, '画面持续变化，自动滚动已暂停；请避开动画、视频或转为手动'); continue; }
        session.probe = session.stop ? undefined : frame;
        if (this.current(session) && !session.stop) await this.delay(session, session.scheduler.settleDelayMs);
      }
    } catch (error) {
      if (this.current(session) && !session.stop) {
        if (error instanceof CaptureBufferError) session.meter.error(error.issue);
        this.fail(session, error);
      }
    }
  }
  private fail(session: Session, error: unknown) {
    session.stop = true; session.wake?.(); session.probe = undefined;
    session.source.dispose?.();
    session.pipeline?.close(); session.previewPump?.stop();
    session.scroller?.dispose(); session.scroller = undefined;
    const canFinish = session.state.frames > 0 && session.processor.available;
    this.update(session, { status: 'error', error: error instanceof Error ? error.message : '长截图采集失败', message: canFinish ? '采集已停止，可完成已有部分或取消' : '采集已停止，请取消后重试', canFinish });
    this.deps.onIdle();
  }
  private async finish(session: Session) {
    if (session.state.status === 'done') return;
    if (session.state.status === 'finishing') throw new Error('长截图正在生成，请稍候');
    if (!session.state.canFinish) throw new Error('尚未采集首屏，请等首屏预览出现后再滚动');
    const sampleFinal=session.state.status!=='error'&&session.state.scrollMode==='manual'&&!session.state.paused&&!session.state.regionCandidate;
    session.stop = true; session.wake?.();
    session.pipeline?.seal(); session.previewPump?.stop();
    session.scroller?.dispose(); session.scroller = undefined;
    this.update(session, { status: 'finishing', message: '正在生成 PNG 长截图…', error: undefined });
    try {
      await session.loop;
      await session.pipeline?.idle().catch((error: unknown) => {
        // fail() already stopped the queue. A recoverable task error must not
        // block export of verified segments when the worker is still available.
        if (!session.processor.available) throw error;
        session.rejected ??= this.errorMessage(error);
      });
      await session.previewPump?.idle();
      if (!this.current(session)) return;
      // Collect the final manual viewport after the in-flight read drains.
      // Otherwise clicking Done just after scrolling can omit the last rows.
      if (sampleFinal && !session.state.paused && !session.state.regionCandidate) {
        try { await this.accept(session, await this.read(session)); }
        catch (error) { if (!this.current(session)) return; session.rejected = this.errorMessage(error); }
      }
      if (!this.current(session)) return;
      const bitmap = await session.processor.bitmap();
      if (!this.current(session)) return;
      session.processor.dispose(); session.source.dispose?.(); session.probe = undefined; session.fingerprint.clear();session.detach();
      session.image = nativeImage.createFromBitmap(Buffer.from(bitmap.data.buffer, bitmap.data.byteOffset, bitmap.data.byteLength), { width: bitmap.width, height: bitmap.height });
      if (session.image.isEmpty()) throw new Error('长截图生成失败');
      const ratio = Math.min(1, 960 / bitmap.width, 6000 / bitmap.height);
      const preview = session.image.resize({ width: Math.max(1, Math.round(bitmap.width * ratio)), height: Math.max(1, Math.round(bitmap.height * ratio)), quality: 'good' }).toDataURL();
      const extended = (session.state.appendedRows ?? 0) > 0;
      this.update(session, { status: 'done', width: bitmap.width, height: bitmap.height, preview, livePreview: undefined, livePreviewRegion: undefined, liveDetailPreview: undefined, liveDetailRegion: undefined, liveViewport:undefined,canFinish: false, regionCandidate: undefined,
        error: !extended ? `没有拼接出长图，当前只保留首屏截图。${session.rejected ? `原因：${session.rejected}` : '请重新选择可滚动正文，避开固定输入栏和侧栏。'}`
          : session.rejected ? `仅完成可靠片段：${session.rejected}` : undefined,
        message: !extended ? '只采集到首屏，没有新增拼接内容。' : session.autoFinishMessage ?? '拼接结果已生成。预览已缩小，复制和保存使用原始 PNG。' });
      this.deps.onIdle();
      await this.deps.window.showPreview();
    } catch (error) { if (this.current(session)) { this.fail(session, error); throw error; } }
  }
}
