// Windows ROI capture worker. Private inherited pipes only; no windows, files,
// input injection, network, settings, or clipboard. One request -> one fresh DIB.
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

internal static class NativeCapture {
    [StructLayout(LayoutKind.Sequential)] struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] struct MonitorInfo { public int Size; public Rect Monitor, Work; public uint Flags; }
    [StructLayout(LayoutKind.Sequential)] struct BitmapInfo {
        public uint Size; public int Width, Height; public ushort Planes, Bits;
        public uint Compression, ImageBytes; public int XResolution, YResolution; public uint Colors, Important;
    }
    [DllImport("user32.dll", SetLastError=true)] static extern bool SetProcessDpiAwarenessContext(IntPtr value);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromRect(ref Rect rect, uint flags);
    [DllImport("user32.dll", SetLastError=true)] static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
    [DllImport("user32.dll", SetLastError=true)] static extern IntPtr GetDC(IntPtr window);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr window, IntPtr dc);
    [DllImport("gdi32.dll", SetLastError=true)] static extern IntPtr CreateCompatibleDC(IntPtr dc);
    [DllImport("gdi32.dll", SetLastError=true)] static extern IntPtr CreateDIBSection(IntPtr dc, ref BitmapInfo info, uint usage, out IntPtr bits, IntPtr section, uint offset);
    [DllImport("gdi32.dll", SetLastError=true)] static extern IntPtr SelectObject(IntPtr dc, IntPtr value);
    [DllImport("gdi32.dll", SetLastError=true)] static extern bool BitBlt(IntPtr target, int x, int y, int width, int height, IntPtr source, int sourceX, int sourceY, uint operation);
    [DllImport("gdi32.dll")] static extern bool GdiFlush();
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr value);
    [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr dc);
    static void Check(bool value) { if (!value) throw new Win32Exception(Marshal.GetLastWin32Error()); }
    static int Number(string value) { return int.Parse(value, NumberStyles.Integer, CultureInfo.InvariantCulture); }
    static bool Same(Rect a, Rect b) { return a.Left==b.Left && a.Top==b.Top && a.Right==b.Right && a.Bottom==b.Bottom; }

    static int Main(string[] args) {
        IntPtr screen=IntPtr.Zero, memory=IntPtr.Zero, bitmap=IntPtr.Zero, previous=IntPtr.Zero;
        try {
            if (args.Length!=8) return 2;
            int x=Number(args[0]), y=Number(args[1]), width=Number(args[2]), height=Number(args[3]);
            int mx=Number(args[4]), my=Number(args[5]), mw=Number(args[6]), mh=Number(args[7]);
            long length=(long)width*height*4;
            if (width<1 || width>8192 || height<1 || mw<1 || mh<1 || length>134217728
                || x<mx || y<my || (long)x+width>(long)mx+mw || (long)y+height>(long)my+mh) return 2;
            Check(SetProcessDpiAwarenessContext(new IntPtr(-4)));
            Rect region=new Rect { Left=x, Top=y, Right=checked(x+width), Bottom=checked(y+height) };
            Rect expected=new Rect { Left=mx, Top=my, Right=checked(mx+mw), Bottom=checked(my+mh) };
            IntPtr monitor=MonitorFromRect(ref region, 0);
            Check(monitor!=IntPtr.Zero);
            screen=GetDC(IntPtr.Zero); Check(screen!=IntPtr.Zero);
            memory=CreateCompatibleDC(screen); Check(memory!=IntPtr.Zero);
            BitmapInfo info=new BitmapInfo { Size=40, Width=width, Height=-height, Planes=1, Bits=32 };
            IntPtr bits; bitmap=CreateDIBSection(screen,ref info,0,out bits,IntPtr.Zero,0);
            Check(bitmap!=IntPtr.Zero && bits!=IntPtr.Zero);
            previous=SelectObject(memory,bitmap); Check(previous!=IntPtr.Zero && previous!=new IntPtr(-1));
            byte[] pixels=new byte[(int)length];
            Stream input=Console.OpenStandardInput();
            using (BinaryWriter output=new BinaryWriter(Console.OpenStandardOutput())) {
                int command;
                while ((command=input.ReadByte())!=-1 && command!=113) {
                    if (command!=114) return 2;
                    MonitorInfo current=new MonitorInfo { Size=Marshal.SizeOf(typeof(MonitorInfo)) };
                    Check(GetMonitorInfo(monitor,ref current));
                    if (!Same(current.Monitor,expected)) return 3;
                    long start=Stopwatch.GetTimestamp();
                    Check(BitBlt(memory,0,0,width,height,screen,x,y,0x40CC0020)); Check(GdiFlush());
                    Marshal.Copy(bits,pixels,0,pixels.Length);
                    // BI_RGB's high byte is unused; the composed desktop is opaque.
                    for (int i=3;i<pixels.Length;i+=4) pixels[i]=255;
                    long micros=(Stopwatch.GetTimestamp()-start)*1000000/Stopwatch.Frequency;
                    output.Write((uint)0x31434447); output.Write(pixels.Length);
                    output.Write(width); output.Write(height); output.Write(micros);
                    output.Write(pixels); output.Flush();
                }
            }
            return 0;
        } catch (IOException) { return 1; }
          catch (Exception error) { Console.Error.WriteLine("CAPTURE_FAILED "+error.GetType().Name); return 1; }
        finally {
            if (memory!=IntPtr.Zero && previous!=IntPtr.Zero && previous!=new IntPtr(-1)) SelectObject(memory,previous);
            if (bitmap!=IntPtr.Zero) DeleteObject(bitmap);
            if (memory!=IntPtr.Zero) DeleteDC(memory);
            if (screen!=IntPtr.Zero) ReleaseDC(IntPtr.Zero,screen);
        }
    }
}
