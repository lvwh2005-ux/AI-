import { runInputSchema } from '../shared/contracts';
import type { WindowRole } from './windows';

// The sender's window role owns the input shape, not the renderer's payload.
export function parseActionInput(value: unknown, role: WindowRole) {
  const input = runInputSchema.parse(value);
  if (role === 'capture' && !input.rect) throw new Error('请先框选一个区域');
  if (role !== 'capture' && (role !== 'result' || input.rect || input.annotations || input.action === 'copy-image')) {
    throw new Error('此窗口无权限执行该操作');
  }
  if (input.action === 'ask' && !input.question) throw new Error('请输入你的问题');
  if (input.action === 'custom' && !input.customActionId) throw new Error('请选择自定义动作');
  if (input.action !== 'custom' && input.customActionId) throw new Error('此操作不接受自定义动作 ID');
  return input;
}
