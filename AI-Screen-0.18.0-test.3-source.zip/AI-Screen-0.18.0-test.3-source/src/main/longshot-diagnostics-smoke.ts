import assert from 'node:assert/strict';
import {randomUUID} from 'node:crypto';
import {readFile,stat,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {app,type BrowserWindow} from 'electron';
import type {LongshotService} from './services/longshot';
import type {LongshotWindow} from './longshot-window';
import type {buildDiagnosticReport} from '../shared/scroll-capture/diagnostics';

type Chooser=(choose:()=>Promise<string|undefined>)=>void;
const sleep=(ms:number)=>new Promise<void>(resolve=>setTimeout(resolve,ms));
async function until(check:()=>boolean|Promise<boolean>,label:string){const end=Date.now()+6000;while(Date.now()<end){if(await check())return;await sleep(35);}throw new Error(`Diagnostic smoke timed out: ${label}`);}

/** Owned Canvas only; paths and file dialogs are injected. Does not read or
 * change the real clipboard, settings or AI service. */
export async function verifyDiagnosticExport(window:LongshotWindow,service:LongshotService,home:BrowserWindow,fixture:BrowserWindow,setChooser:Chooser,copiedDigest:()=>string|undefined){
  const preview=window.thumbnailWindow()!,id=service.state!.id;
  const destination=path.join(process.cwd(),'.runtime','longshot-stage4.1-diagnostics.json');
  const js=(code:string)=>preview.webContents.executeJavaScript(code);
  const clickExport=()=>js(`document.querySelector('[data-longshot-diagnostics=export]').click();undefined`);
  async function idle(){await until(()=>js(`!document.querySelector('[data-longshot-diagnostics=export]').disabled`),'export settles');}
  const clipboardBefore=copiedDigest();
  await until(()=>(service.state?.telemetry?.identicalReadStreak??0)>=3,'identical reads observed');
  await js(`document.querySelector('[data-longshot-diagnostics=toggle]').click();undefined`);
  await until(()=>js(`!!document.querySelector('[data-longshot-guidance=unchanged-read]')`),'unchanged-read guidance renders');
  await until(()=>js(`document.querySelector('[data-diagnostic-progress]').textContent.includes('0 px/秒')`),'static progress rate renders');
  assert.equal(await home.webContents.executeJavaScript(`window.screenAI.commandLongshot(${JSON.stringify(id)},'export-diagnostics').then(()=>false,()=>true)`),true);
  assert.equal(await js(`window.screenAI.commandLongshot(${JSON.stringify(randomUUID())},'export-diagnostics').then(()=>false,()=>true)`),true);
  let release!:(value:string|undefined)=>void;
  setChooser(()=>new Promise(resolve=>{release=resolve;}));
  try{
    await clickExport();await until(()=>!!release,'chooser opened');
    assert.equal(service.state?.paused,false,'Saving diagnostics must not change the user pause flag');
    assert.equal(service.state?.telemetry?.activity,'paused');
    await assert.rejects(service.command(id,'finish'),/诊断保存对话框/);
    await sleep(600);const before=service.state!;
    await fixture.webContents.executeJavaScript('window.scrollBy({top:120,behavior:"instant"});undefined');await sleep(650);
    assert.equal(service.state?.height,before.height);assert.equal(service.state?.frames,before.frames);assert.equal(service.state?.telemetry?.processed,before.telemetry?.processed);
    await fixture.webContents.executeJavaScript('window.scrollTo(0,0);undefined');await sleep(100);
    release(undefined);await idle();assert.equal(service.state?.status,'capturing');assert.equal(service.state?.paused,false);
    await until(()=>(service.state?.telemetry?.identicalReadStreak??0)>=3,'reads resume after cancelling chooser');

    setChooser(async()=>destination);await clickExport();await idle();
    const report=JSON.parse(await readFile(destination,'utf8')) as ReturnType<typeof buildDiagnosticReport>;
    assert.equal(report.format,'ai-screen-longshot-diagnostics');assert.equal(report.environment.appVersion,app.getVersion());
    assert.ok(report.environment.displayWidth>0&&report.environment.scaleFactor>0);assert.equal(report.capture.width,service.state?.width);
    assert.ok(report.telemetry.identicalReads>=3);assert.equal(report.guidance.code,'unchanged-read');
    assert.ok(report.telemetry.queueWait.count>0&&report.telemetry.queueWait.average>=0);
    assert.ok(report.telemetry.endToEnd.count>0&&report.telemetry.endToEnd.average>=report.telemetry.queueWait.average);
    assert.equal(report.telemetry.effectiveNewRowsPerSecond,0,'Static reads must not count as effective new content');
    assert.ok(!/data:image|apiKey|livePreview|targetWindowId|displayId|https?:|sessionId/.test(JSON.stringify(report)));
    assert.ok(await js(`document.querySelector('[data-longshot-diagnostics=panel]').textContent.includes('诊断报告已保存')`));
    await writeFile(path.join(process.cwd(),'.runtime','longshot-stage4.1-diagnostics-panel.png'),(await preview.webContents.capturePage()).toPNG());

    setChooser(async()=>path.join(process.cwd(),'.runtime','diagnostic-must-not-write.png'));await clickExport();await idle();
    assert.ok(await js(`document.querySelector('[data-longshot-diagnostics=panel] [role=alert]')?.textContent.includes('.json')`));
    assert.equal(service.state?.status,'capturing');assert.equal(service.state?.paused,false);
    assert.equal(await stat(path.join(process.cwd(),'.runtime','diagnostic-must-not-write.png')).then(()=>true,()=>false),false);

    setChooser(async()=>undefined);await service.command(id,'pause');await clickExport();await idle();assert.equal(service.state?.paused,true,'Cancelled export preserves user Pause');
    await service.command(id,'resume');service.suspendSampling(true,id);await clickExport();await idle();
    assert.equal(service.state?.telemetry?.activity,'paused','Export must not release another sampling suspension');service.suspendSampling(false,id);
    assert.equal(copiedDigest(),clipboardBefore,'Diagnostic export must not call the clipboard writer');
    console.log('LONGSHOT DIAGNOSTICS PASS: exact adjacent-read evidence and actionable guidance render, UI exports allow-listed JSON, chooser holds reads without accepting scrolled frames, cancellation/error resume, Pause/menu holds preserved, Finish/foreign/stale commands denied, clipboard unchanged.');
  }finally{
    release?.(undefined);setChooser(async()=>undefined);
    if(!preview.isDestroyed())await js(`document.querySelector('[aria-label="关闭诊断"]')?.click();undefined`);
  }
}

export async function verifyDiagnosticCancel(window:LongshotWindow,service:LongshotService,setChooser:Chooser){
  const id=service.state!.id,destination=path.join(process.cwd(),'.runtime',`cancelled-report-${randomUUID()}.json`);
  let release!:(value:string|undefined)=>void;setChooser(()=>new Promise(resolve=>{release=resolve;}));
  const saving=service.command(id,'export-diagnostics');
  try{
    await until(()=>!!release,'cancel chooser opened');await service.cancel();release(destination);
    assert.equal((await saving).cancelled,true);assert.equal(service.state,null);assert.equal(window.collectionWindows().length,0);
    assert.equal(await stat(destination).then(()=>true,()=>false),false);
    console.log('LONGSHOT DIAGNOSTIC CANCEL PASS: cancellation destroys collection surfaces and a late chooser cannot save or revive its old session.');
  }finally{release?.(undefined);setChooser(async()=>undefined);await saving.catch(()=>{});}
}

export async function verifyDiagnosticResult(window:LongshotWindow,service:LongshotService,setChooser:Chooser){
  const controls=window.get()!,state=service.state!,stitched=(state.appendedRows??0)>0;
  const destination=path.join(process.cwd(),'.runtime',`longshot-stage4.1-${stitched?'stitched':'single'}-report.json`);
  const js=(code:string)=>controls.webContents.executeJavaScript(code);
  setChooser(async()=>destination);
  try{
    assert.equal(state.status,'done');assert.equal(state.liveViewport,undefined,'Finished session releases its ROI PNG');
    await until(()=>js(`!!document.querySelector('.longshot-result [data-longshot-diagnostics=toggle]')`),'result diagnostic entry');
    await js(`document.querySelector('[data-longshot-diagnostics=toggle]').click();undefined`);
    await until(()=>js(`!!document.querySelector('[data-longshot-guidance=${stitched?'stitched':'single-frame'}]')`),'result guidance');
    await js(`document.querySelector('[data-longshot-diagnostics=export]').click();undefined`);
    await until(()=>js(`!document.querySelector('[data-longshot-diagnostics=export]').disabled&&document.querySelector('[data-longshot-diagnostics=panel]').textContent.includes('诊断报告已保存')`),'result report saved');
    const report=JSON.parse(await readFile(destination,'utf8')) as ReturnType<typeof buildDiagnosticReport>;
    assert.equal(report.capture.status,'done');assert.equal(report.capture.height,state.height);assert.equal(report.capture.frames,state.frames);assert.equal(report.guidance.code,stitched?'stitched':'single-frame');
    assert.equal(service.state?.status,'done');assert.equal(window.collectionWindows().length,0);
    await js(`document.querySelector('[aria-label="关闭诊断"]').click();undefined`);
    console.log(`LONGSHOT DIAGNOSTIC RESULT PASS: ${stitched?'stitched':'single-frame'} result exports matching metadata without restarting sampling or mislabeling a single frame.`);
  }finally{setChooser(async()=>undefined);}
}
