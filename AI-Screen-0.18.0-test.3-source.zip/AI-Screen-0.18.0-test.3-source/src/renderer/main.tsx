import React from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { Home } from './views/Home';
import { Capture } from './views/Capture';
import { Result } from './views/Result';
import { Pin } from './views/Pin';
import { Longshot } from './views/Longshot';
import { LiveThumbnail } from './longshot/LiveThumbnail';
import{Recording}from'./views/Recording';
import './interface.css';

const route = location.hash.slice(1);
document.documentElement.dataset.route = route;
createRoot(document.getElementById('root')!).render(
  <React.StrictMode>{!window.screenAI ? <div className="fatal">请使用 npm run dev 启动桌面应用。浏览器预览无法访问屏幕和剪贴板。</div>
    : route==='recording'?<Recording/>: route === 'capture' ? <Capture /> : route === 'result' ? <Result /> : route === 'pin' ? <Pin /> : route === 'longshot' ? <Longshot /> : route === 'longshot-thumbnail' ? <LiveThumbnail /> : <Home />}</React.StrictMode>,
);
