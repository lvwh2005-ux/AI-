import { useCallback, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';
import type { LongshotState } from '../../shared/longshot';
import { clampPreviewZoom, previewCssScale, wheelPreviewZoom, zoomScroll } from '../../shared/scroll-capture/preview-viewport';
import { PreviewViewSender } from './preview-view-sender';

export function usePreviewZoom(state:LongshotState|null,viewport:RefObject<HTMLDivElement|null>,size:{width:number;height:number},detail:boolean){
  const [config,setConfig]=useState<{zoom:number|null;follow:boolean}>({zoom:null,follow:true});
  const [sequence,setSequence]=useState(0),[error,setError]=useState('');
  const configRef=useRef(config),stateRef=useRef(state),sender=useRef<PreviewViewSender|null>(null),seq=useRef(0),lastKey=useRef('');
  const ignoredScroll=useRef<{x:number;y:number}|null>(null),previousTop=useRef(0);
  const anchor=useRef<{source:{x:number;y:number};point:{x:number;y:number}}|null>(null);
  stateRef.current=state;configRef.current=config;
  const change=useCallback((value:{zoom:number|null;follow:boolean})=>{configRef.current=value;setConfig(value);},[]);
  const writeScroll=useCallback((x:number,y:number)=>{
    const element=viewport.current;if(!element)return;
    element.scrollLeft=x;element.scrollTop=y;ignoredScroll.current={x:element.scrollLeft,y:element.scrollTop};
  },[viewport]);
  const request=useCallback(()=>{
    const element=viewport.current,snapshot=stateRef.current,current=configRef.current;
    if(!sender.current||!element||!snapshot?.frames||element.clientWidth<1||element.clientHeight<1)return;
    const ratio=current.zoom?previewCssScale(current.zoom,devicePixelRatio):1;
    const view=current.zoom?{zoom:current.zoom,follow:current.follow,x:Math.max(0,element.scrollLeft/ratio),y:Math.max(0,element.scrollTop/ratio),
      coveredTop:snapshot.coveredTop??0,viewportDip:{width:element.clientWidth,height:element.clientHeight}}:null;
    const key=JSON.stringify(view);if(key===lastKey.current)return;lastKey.current=key;
    const next=++seq.current;setSequence(next);setError('');sender.current.submit({id:snapshot.id,op:'view',sequence:next,view});
  },[viewport]);
  useEffect(()=>{
    seq.current=0;lastKey.current='';setSequence(0);setError('');change({zoom:null,follow:true});previousTop.current=stateRef.current?.coveredTop??0;
    const id=state?.id;if(!id)return;
    const current=new PreviewViewSender(input=>window.screenAI.previewWindow(input),(input,failure)=>{
      if(stateRef.current?.id===id&&input.sequence===seq.current)setError(failure instanceof Error?failure.message:'清晰预览加载失败');
    });sender.current=current;
    return()=>{current.dispose();if(sender.current===current)sender.current=null;};
  },[state?.id,change]);
  useLayoutEffect(()=>{
    const element=viewport.current;if(!element)return;
    if(config.zoom&&anchor.current&&state){
      const next=zoomScroll(state,{width:element.clientWidth,height:element.clientHeight},anchor.current.source,anchor.current.point,previewCssScale(config.zoom,devicePixelRatio));
      anchor.current=null;writeScroll(next.x,next.y);
    }
    const top=state?.coveredTop??0,difference=previousTop.current-top;
    if(config.zoom&&!config.follow&&difference&&element.scrollTop/previewCssScale(config.zoom,devicePixelRatio)>=(state?.fixedTop??0)){
      writeScroll(element.scrollLeft,element.scrollTop+difference*previewCssScale(config.zoom,devicePixelRatio));
    }
    previousTop.current=top;request();
  },[config.zoom,config.follow,size.width,size.height,state?.width,state?.height,state?.coveredTop,request,writeScroll,viewport]);
  useLayoutEffect(()=>{
    const tile=state?.liveViewport;
    if(!config.zoom||!config.follow||!tile||tile.sequence!==seq.current||tile.zoom!==config.zoom)return;
    const ratio=previewCssScale(config.zoom,devicePixelRatio);writeScroll(tile.region.x*ratio,tile.region.y*ratio);
  },[state?.liveViewport,config.zoom,config.follow,writeScroll]);
  useEffect(()=>{if(state?.regionCandidate){change({zoom:null,follow:true});}},[!!state?.regionCandidate,change]);
  const choose=useCallback((zoom:number)=>{anchor.current=null;change({zoom:clampPreviewZoom(zoom),follow:true});},[change]);
  const exit=useCallback(()=>{anchor.current=null;change({zoom:null,follow:true});},[change]);
  const zoomAt=useCallback((zoom:number,clientX?:number,clientY?:number)=>{
    const element=viewport.current,snapshot=stateRef.current;if(!element||!snapshot?.frames)return;
    const rect=element.getBoundingClientRect(),sheet=element.querySelector('[data-preview-sheet]')?.getBoundingClientRect();
    if(!sheet?.width)return;
    const current=configRef.current,region=current.zoom?{x:0,y:0,width:snapshot.width,height:snapshot.height}:
      detail?snapshot.liveDetailRegion:snapshot.livePreviewRegion;
    if(!region)return;
    const x=clientX??rect.left+element.clientWidth/2,y=clientY??rect.top+element.clientHeight/2;
    const oldRatio=sheet.width/region.width;
    anchor.current={source:{x:Math.max(0,region.x+(x-sheet.left)/oldRatio),y:Math.max(0,region.y+(y-sheet.top)/oldRatio)},point:{x:x-rect.left,y:y-rect.top}};
    change({zoom:clampPreviewZoom(zoom),follow:false});
  },[viewport,detail,change]);
  const zoomAtRef=useRef(zoomAt);zoomAtRef.current=zoomAt;
  useEffect(()=>{
    const element=viewport.current;if(!element)return;
    const wheel=(event:WheelEvent)=>{
      if(!event.ctrlKey||stateRef.current?.regionCandidate||!stateRef.current?.frames)return;
      event.preventDefault();event.stopPropagation();
      const sheet=element.querySelector('[data-preview-sheet]')?.getBoundingClientRect();
      const current=configRef.current.zoom??(sheet&&stateRef.current.width?sheet.width/stateRef.current.width*devicePixelRatio:1);
      zoomAtRef.current(wheelPreviewZoom(current,event.deltaY,event.deltaMode),event.clientX,event.clientY);
    };
    element.addEventListener('wheel',wheel,{passive:false});return()=>element.removeEventListener('wheel',wheel);
  },[viewport]);
  const onScroll=()=>{
    const element=viewport.current;if(!element||!configRef.current.zoom)return;
    const ignore=ignoredScroll.current;
    if(ignore&&Math.abs(element.scrollLeft-ignore.x)<1&&Math.abs(element.scrollTop-ignore.y)<1)return;
    ignoredScroll.current=null;if(configRef.current.follow)change({...configRef.current,follow:false});request();
  };
  const resumeFollow=()=>{change({...configRef.current,follow:true});lastKey.current='';request();};
  return{...config,sequence,error,choose,exit,zoomAt,onScroll,resumeFollow,loading:!!config.zoom&&(state?.liveViewport?.sequence!==sequence||state.liveViewport.zoom!==config.zoom)};
}
