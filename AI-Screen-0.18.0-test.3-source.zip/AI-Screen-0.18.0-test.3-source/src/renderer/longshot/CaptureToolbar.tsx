import type { LongshotCommand, LongshotState } from '../../shared/longshot';
import { LongshotGlyph, ToolbarChrome } from './ToolbarChrome';
import { finishable } from './useLongshotSession';

export function CaptureToolbar({ state, pending, message, error, command, retry, edit, share }: {
  state: LongshotState | null; pending: LongshotCommand | null; message: string; error: boolean;
  command(action: LongshotCommand): Promise<void>;
  retry(): Promise<void>;
  edit(): void; share(): void;
}) {
  const automatic = state?.scrollMode === 'auto';
  const active = state && ['preparing', 'capturing'].includes(state.status);
  const busy = !!pending || state?.status === 'finishing';
  const reviewing = !!state?.regionCandidate;
  return <main className={`scroll-toolbar${reviewing ? ' is-reviewing' : ''}`} data-status={state?.status ?? 'preparing'} data-scroll-mode={state?.scrollMode} data-paused={state?.paused ? 'true' : 'false'} aria-label="长截图工具栏" aria-description={message}>
    <ToolbarChrome reviewing={reviewing}
      edit={<button data-longshot-action="edit" aria-label="完成采集并标注长图" disabled={!finishable(state) || busy} onClick={edit}><LongshotGlyph name="pen" /></button>}
      share={<button data-longshot-action="share" aria-label="完成采集并分享长图" disabled={!finishable(state) || busy} onClick={share}><LongshotGlyph name="share" /></button>}
      save={<button data-longshot-action="save" aria-label="完成采集并另存 PNG" disabled={!finishable(state) || busy} onClick={() => void command('save')}><LongshotGlyph name="save" /></button>} mode={reviewing ? <>
        <button data-longshot-action="confirm-region" disabled={busy} onClick={() => void command('confirm-region')}>使用正文区域</button>
        <button data-longshot-action="keep-region" disabled={busy} onClick={() => void command('keep-region')}>保留原范围</button>
      </> : automatic && active ? <>
        <button data-longshot-action={state.paused ? 'resume' : 'pause'} disabled={busy} onClick={() => void command(state.paused ? 'resume' : 'pause')}>
          <svg viewBox="0 0 24 24" aria-hidden="true">{state.paused ? <path d="m9 5 10 7-10 7Z" /> : <path d="M8 5v14M16 5v14" />}</svg>{state.paused ? '继续自动' : '暂停自动'}
        </button>
        <button className="scroll-manual" data-longshot-action="manual" disabled={busy} onClick={() => void command('manual')}>手动</button>
      </> : active ? <button data-longshot-action={state.paused?'resume':'pause'} disabled={busy} aria-label={state.paused?'继续手动采集':'暂停手动采集'} onClick={()=>void command(state.paused?'resume':'pause')}>
        <svg viewBox="0 0 24 24" aria-hidden="true">{state.paused?<path d="m9 5 10 7-10 7Z"/>:<path d="M8 5v14M16 5v14"/>}</svg>{state.paused?'继续':'暂停'}
      </button> : <span className="scroll-mode-label"><LongshotGlyph name="scroll" />{state?.status === 'finishing' ? '正在生成…' : state?.status === 'error' ? '采集已停止' : '手动滚动'}</span>} actions={<>
      {!state && error && <button onClick={() => void retry()}>重试</button>}
      <button className="scroll-cancel" data-longshot-action="cancel" aria-label="取消长截图" disabled={!state || pending === 'cancel'} onClick={() => void command('cancel')}><LongshotGlyph name="cancel" /></button>
      <button className="scroll-finish" data-longshot-action="finish" aria-label="完成并查看图片" disabled={!finishable(state) || busy} onClick={() => void command('finish')}><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 12 5 5L20 6" /></svg></button>
    </>} />
    <span className="scroll-accessible-status" role={error ? 'alert' : 'status'}>{message}</span>
  </main>;
}
