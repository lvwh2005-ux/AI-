import { useState } from 'react';
import { PREVIEW_ZOOM_PRESETS } from '../../shared/scroll-capture/preview-viewport';
export function PreviewZoomControls({zoom,follow,disabled,choose,adjust,fit,resume}:{zoom:number|null;follow:boolean;disabled:boolean;choose(value:number):void;adjust(value:number):void;fit():void;resume():void}){
  const[menu,setMenu]=useState(false);
  return <div className="scroll-preview-zoom" aria-label="预览缩放">
    <button data-preview-zoom="out" aria-label="缩小预览" disabled={disabled} onClick={()=>adjust((zoom??1)/1.25)}>−</button>
    <button data-preview-zoom="menu" aria-haspopup="menu" aria-expanded={menu} disabled={disabled} onClick={()=>setMenu(!menu)}>{zoom?`${Math.round(zoom*100)}%`:'按窗口'} ▾</button>
    <button data-preview-zoom="in" aria-label="放大预览" disabled={disabled} onClick={()=>adjust((zoom??1)*1.25)}>＋</button>
    <button data-preview-zoom="original" aria-label="100% 原图：一个原始像素对应一个屏幕物理像素" aria-pressed={zoom===1} disabled={disabled} onClick={()=>{setMenu(false);choose(1);}}>原图</button>
    <button data-preview-zoom="fit" aria-label="适应窗口" disabled={disabled} onClick={()=>{setMenu(false);fit();}}>适应</button>
    <button data-preview-zoom="follow" aria-pressed={!!zoom&&follow} disabled={disabled||!zoom} onClick={resume}>跟随</button>
    {menu&&!disabled&&<div className="scroll-preview-zoom-menu" role="menu" aria-label="缩放比例">{PREVIEW_ZOOM_PRESETS.map(value=><button key={value} role="menuitemradio" aria-checked={zoom===value} data-preview-zoom-preset={value} onClick={()=>{setMenu(false);choose(value);}}>{Math.round(value*100)}%</button>)}</div>}
  </div>;
}
