import type { PreviewEdge, PreviewWindowRequest, PreviewWindowState } from '../../shared/scroll-capture/preview-window';
type Point = { x: number; y: number };

/** At most one IPC in flight and one latest point, including pointer-up before
 * Begin replies. End is ordered after the final point, never ahead of it. */
export class PreviewGesture {
  private token?: string;
  private latest?: Point;
  private ending = false;
  private busy = false;
  private done = false;
  readonly completed: Promise<void>;
  private complete!: () => void;
  constructor(private id: string, edge: PreviewEdge, point: Point,
    private send: (request: PreviewWindowRequest) => Promise<PreviewWindowState>,
    private accept: (state: PreviewWindowState) => void, private fail: (error: unknown) => void) {
    this.completed = new Promise(resolve => { this.complete = resolve; });
    void send({ id, op: 'begin', edge, point }).then(state => {
      if (!state.token) throw new Error('预览拖动未能开始');
      this.token = state.token; this.accept(state); void this.drain();
    }).catch(error => this.failed(error));
  }
  move(point: Point) { if (!this.done && !this.ending) { this.latest = { ...point }; void this.drain(); } }
  end(point?: Point) {
    if (this.done || this.ending) return;
    if (point) this.latest = { ...point };
    this.ending = true; void this.drain();
  }
  private async drain() {
    if (this.busy || this.done || !this.token) return;
    this.busy = true;
    try {
      while (!this.done) {
        if (this.latest) {
          const point = this.latest; this.latest = undefined;
          this.accept(await this.send({ id: this.id, op: 'update', token: this.token, point }));
        } else if (this.ending) {
          this.accept(await this.send({ id: this.id, op: 'end', token: this.token })); this.done = true; this.complete();
        } else break;
      }
    } catch (error) { this.failed(error); }
    finally { this.busy = false; }
  }
  private failed(error: unknown) {
    if (this.done) return;
    this.done = true; this.latest = undefined; this.fail(error);
    // A failed update must not leave a live gesture blocking the next drag.
    if (this.token) void this.send({ id: this.id, op: 'end', token: this.token }).catch(() => {}).finally(this.complete);
    else this.complete();
  }
}
