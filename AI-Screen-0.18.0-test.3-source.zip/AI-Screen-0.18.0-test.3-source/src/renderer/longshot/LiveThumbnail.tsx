import { useLongshotSession } from './useLongshotSession';
import { useEffect, useRef, useState } from 'react';
import '../longshot.css';
import { activityLabels } from '../../shared/scroll-capture/telemetry';
import { DiagnosticsPanel } from './DiagnosticsPanel';
import { usePreviewWindow } from './usePreviewWindow';
import { previewEdges } from '../../shared/scroll-capture/preview-window';
import { previewCssScale } from '../../shared/scroll-capture/preview-viewport';
import { usePreviewZoom } from './usePreviewZoom';
import { PreviewZoomControls } from './PreviewZoomControls';
export function LiveThumbnail() {
  const { state,command,pending,notice } = useLongshotSession();
  const windowLayout = usePreviewWindow(state?.id);
  const viewport = useRef<HTMLDivElement>(null);
  const [size,setSize] = useState({width:0,height:0});
  const [mode,setMode] = useState<'overview'|'detail'>('detail');
  const [diagnostics,setDiagnostics]=useState(false);
  useEffect(()=>{
    const element=viewport.current;
    if(!element) return;
    const measure=()=>setSize({width:element.clientWidth,height:element.clientHeight});
    const observer=new ResizeObserver(measure);observer.observe(element);measure();
    return ()=>observer.disconnect();
  },[]);
  const detail = mode === 'detail' && !state?.regionCandidate && !!state?.liveDetailPreview;
  const zoom=usePreviewZoom(state,viewport,size,detail);
  const tile=state?.liveViewport,cssScale=previewCssScale(zoom.zoom??1,devicePixelRatio);
  const prefix=(tile?.coveredTop??0)-(state?.coveredTop??0);
  const validTile=!!tile&&tile.documentWidth===state?.width&&tile.zoom===zoom.zoom&&!(prefix&&tile.region.y<(state?.fixedTop??0));
  const tileY=(tile?.region.y??0)+(prefix&&(tile?.region.y??0)>=(state?.fixedTop??0)?prefix:0);
  const region = detail ? state?.liveDetailRegion : state?.livePreviewRegion;
  const width = region?.width ?? state?.width ?? 0, height = region?.height ?? state?.height ?? 0;
  const ratio = width && height ? Math.min(size.width/width,size.height/height) : 0;
  const image = detail ? state?.liveDetailPreview : state?.livePreview;
  const preview = image?.startsWith('data:image/png;base64,') ? image : undefined;
  const attention = !!state?.regionCandidate || !!state?.error || state?.status === 'error' || !!state?.paused;
  const fit=()=>{zoom.exit();setMode('overview');};
  return <main className="scroll-thumbnail" data-preview-mode={zoom.zoom?'zoom':detail ? 'detail' : 'overview'} data-preview-scale={zoom.zoom??'fit'} data-position-mode={windowLayout.layout?.positionMode ?? 'auto'} data-attention={attention ? 'true' : 'false'} aria-label="实时长图缩略预览" aria-description={state?.message}
    onPointerMove={windowLayout.move} onPointerUp={windowLayout.end} onPointerCancel={event=>windowLayout.end(event,false)} onLostPointerCapture={event=>windowLayout.end(event,false)}>
    <header data-preview-drag="true" onPointerDown={windowLayout.begin('move')} aria-label="拖动标题区域移动预览；拖动边缘调整大小">
      <span aria-label={state?.height ? `已采集 ${state.width} × ${state.height} 像素` : '准备首屏'}><i aria-hidden="true">⠿</i> {state?.height ? `${state.width} × ${state.height} px` : '准备首屏…'}</span>
      <nav aria-label="预览方式"><button data-preview-mode="overview" aria-pressed={!zoom.zoom&&!detail} aria-label="查看完整长图概览" onClick={fit}>概览</button><button data-preview-mode="detail" aria-pressed={!zoom.zoom&&detail} disabled={!!state?.regionCandidate} aria-label="按宽度查看当前采集位置；不改变完整长图" onClick={()=>{zoom.exit();setMode('detail');}}>清晰</button><button data-longshot-diagnostics="toggle" aria-expanded={diagnostics} onClick={()=>setDiagnostics(!diagnostics)}>诊断</button><button data-preview-auto="true" aria-label="恢复自动位置" disabled={windowLayout.pending||windowLayout.layout?.positionMode!=='manual'} onClick={()=>void windowLayout.automatic()}>复位</button></nav>
    </header>
    <PreviewZoomControls zoom={zoom.zoom} follow={zoom.follow} disabled={!state?.frames||!!state.regionCandidate} choose={zoom.choose} adjust={zoom.zoomAt} fit={fit} resume={zoom.resumeFollow}/>
    <div ref={viewport} onScroll={zoom.onScroll} className={`scroll-thumbnail-image${zoom.zoom?' scroll-thumbnail-zoomed':''}`} data-has-preview={preview ? 'true' : 'false'} aria-label="长图预览；Ctrl 加滚轮缩放，普通滚轮浏览">
      {zoom.zoom ? <div data-preview-sheet className="scroll-preview-canvas" style={{width:(state?.width??0)*cssScale,height:(state?.height??0)*cssScale}}>{validTile&&<img data-preview-tile src={tile.image} alt="从原始长图读取的当前可见区域" draggable={false} style={{left:tile.region.x*cssScale,top:tileY*cssScale,width:tile.region.width*cssScale,height:tile.region.height*cssScale,imageRendering:zoom.zoom>=1?'pixelated':'auto'}}/>}</div>
        : preview ? <div data-preview-sheet className="scroll-thumbnail-sheet" style={{width:width*ratio,height:height*ratio}}><img src={preview} alt={detail ? '当前采集区域，完整长图请切换概览' : '已可靠拼接的完整概览'} draggable={false} />{state?.regionCandidate && state.sourcePixelWidth && state.sourcePixelHeight && <div className="scroll-region-candidate" aria-label="建议正文区域" style={{left:`${state.regionCandidate.x/state.sourcePixelWidth*100}%`,top:`${state.regionCandidate.y/state.sourcePixelHeight*100}%`,width:`${state.regionCandidate.width/state.sourcePixelWidth*100}%`,height:`${state.regionCandidate.height/state.sourcePixelHeight*100}%`}} />}</div> : <span>上下滚动的内容<br />会在这里延伸</span>}
    </div>
    {zoom.loading&&<div className="scroll-preview-loading" role="status">正在读取原图…</div>}
    <footer role={state?.error ? 'alert' : 'status'}><strong>{zoom.zoom?`${Math.round(zoom.zoom*100)}% · ${zoom.follow?'跟随':'浏览'}`:detail && region && region.height<(state?.height??0) ? region.y===0?'显示顶部':region.y+region.height>=(state?.height??0)?'显示末段':'显示当前区域' : detail ? '按宽度显示' : '完整概览'}</strong><div className="scroll-thumbnail-progress"><b>{state?.telemetry?activityLabels[state.telemetry.activity]:'准备中'} · 已拼 {state?.frames??0} 段{state?.telemetry?.rejected?` · 拒绝 ${state.telemetry.rejected}`:''}</b><span>{state?.error || state?.message || '等待首屏预览'}</span></div></footer>
    {diagnostics&&<DiagnosticsPanel state={state} close={()=>setDiagnostics(false)} exportReport={()=>void command('export-diagnostics')} pending={!!pending} notice={notice}/>}
    {(windowLayout.error||zoom.error)&&<div className="scroll-preview-error" role="alert">{windowLayout.error||zoom.error}</div>}
    {previewEdges.filter(edge=>edge!=='move').map(edge=><div key={edge} aria-hidden="true" data-preview-resize={edge} className={`scroll-preview-handle scroll-preview-${edge}`} onPointerDown={windowLayout.begin(edge)}/>)}
  </main>;
}
