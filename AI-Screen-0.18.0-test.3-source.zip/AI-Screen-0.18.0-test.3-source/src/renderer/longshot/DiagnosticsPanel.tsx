import type { LongshotState } from '../../shared/longshot';
import { activityLabels } from '../../shared/scroll-capture/telemetry';
import {diagnosticGuidance} from '../../shared/scroll-capture/diagnostics';
import {ANALYSIS_BUDGET} from '../../shared/scroll-capture/analysis-frame';
import {FRAME_ANALYSIS_LIMITS} from '../../shared/scroll-capture/analysis-work';

export function DiagnosticsPanel({state,close,exportReport,pending,notice}:{state:LongshotState|null;close():void;exportReport():void;pending:boolean;notice?:{message:string;error?:boolean}|null}){
  const value=state?.telemetry;
  const advice=diagnosticGuidance(state),environment=state?.diagnosticEnvironment;
  const ms=(number:number|undefined)=>number===undefined?'—':`${Math.round(number)} ms`;
  return <aside className="scroll-diagnostics" aria-label="长截图诊断" data-longshot-diagnostics="panel">
    <div><strong>本次采集诊断</strong><button aria-label="关闭诊断" onClick={close}>×</button></div>
    <section className="scroll-diagnostic-guidance" data-longshot-guidance={advice.code}><strong>{advice.title}</strong><span>{advice.action}</span></section>
    <dl>
      <dt>当前状态</dt><dd>{value?activityLabels[value.activity]:'准备中'} · {state?.scrollMode==='auto'?'自动滚动':'手动滚动'}</dd>
      <dt>采集方式</dt><dd>{state?.captureBackend==='gdi-roi'?'原生选区采集':state?.captureBackend==='electron-snapshot'?'显示器快照裁切':'准备中'}</dd>
      <dt>版本 / 显示器</dt><dd>{environment?.appVersion??'—'} · {environment?.displayWidth??'—'} × {environment?.displayHeight??'—'} · {environment?.scaleFactor?`${Math.round(environment.scaleFactor*100)}%`:'—'}</dd>
      <dt>滚动输入</dt><dd>{state?.scrollMode==='auto'?'SendInput 滚轮':'用户自行滚动'}</dd>
      <dt>原始选区</dt><dd>{state?.sourcePixelWidth??'—'} × {state?.sourcePixelHeight??'—'} px</dd>
      <dt>快速匹配采样预算</dt><dd>{ANALYSIS_BUDGET.maxPixels.toLocaleString()} 样本像素 · 原图精验</dd>
      <dt>整帧共享分析预算</dt><dd>{FRAME_ANALYSIS_LIMITS.samples.toLocaleString()} 采样 · {FRAME_ANALYSIS_LIMITS.probes.toLocaleString()} 对齐探测</dd>
      <dt>近期有效新增速度</dt><dd data-diagnostic-progress>{value?.effectiveNewRowsPerSecond===undefined?'采样中':`${Math.round(value.effectiveNewRowsPerSecond)} px/秒`}</dd>
      <dt>采到 / 已处理</dt><dd>{value?.captured??0} / {value?.processed??0} 帧</dd>
      <dt>新增 / 去重</dt><dd>{value?.appended??0} / {value?.duplicates??0} 次</dd>
      <dt>相邻读屏 变化 / 相同</dt><dd data-diagnostic-reads>{value?.changedReads??0} / {value?.identicalReads??0} 帧</dd>
      <dt>拒绝 / 待确认</dt><dd>{value?.rejected??0} / {value?.reviews??0} 次</dd>
      <dt>过期丢弃 / 读屏失败</dt><dd>{value?.discarded??0} / {value?.readErrors??0} 帧</dd>
      <dt>空画面重新读取</dt><dd>{value?.readRetries??0} 次</dd>
      <dt>缓冲 / 排队</dt><dd>{value?.bufferedFrames??0} / {value?.queuedFrames??0} 帧 · {((value?.bufferedBytes??0)/1048576).toFixed(1)} MiB</dd>
      <dt>缓冲峰值 / 背压</dt><dd>{((value?.peakBytes??0)/1048576).toFixed(1)} MiB / {value?.backpressureWaits??0} 次{value?.waitingForSpace?' · 暂缓读屏':''}</dd>
      <dt>局部容错 / 重新接上</dt><dd data-diagnostic-localized>{value?.localizedFrames??0} / {value?.recoveries??0} 次</dd>
      <dt>顶部 / 底部新增</dt><dd>{value?.prependedRows??0} / {value?.appendedBottomRows??0} px</dd>
      <dt>回看 / 历史定位</dt><dd>{value?.revisits??0} / {value?.relocations??0} 次</dd>
      <dt>视口 / 已覆盖正文</dt><dd>{state?.viewportY??0} / {state?.coveredTop??0}…{state?.coveredBottom??'—'} px</dd>
      <dt>连续拒绝 / 最近校验</dt><dd data-diagnostic-streak>{value?.rejectionStreak??0} 帧 / {value?.lastVerification==='localized'?`局部变化 ${value.lastIgnoredPixels??0}px`:value?.lastVerification==='strict'?'严格校验':'等待校验'}</dd>
      <dt>读屏 当前 / 平均</dt><dd>{ms(value?.capture.last)} / {ms(value?.capture.average)}</dd>
      <dt>处理往返 当前 / 平均</dt><dd>{ms(value?.match.last)} / {ms(value?.match.average)}</dd>
      <dt>排队 当前 / 平均</dt><dd>{ms(value?.queueWait.last)} / {ms(value?.queueWait.average)}</dd>
      <dt>读屏至处理完成 当前 / 平均</dt><dd>{ms(value?.endToEnd.last)} / {ms(value?.endToEnd.average)}</dd>
      <dt>预览 当前 / 平均</dt><dd>{ms(value?.preview.last)} / {ms(value?.preview.average)}</dd>
      <dt>实际采集速率</dt><dd>{value?.captureFps===undefined?'采样中':`${value.captureFps.toFixed(1)} 帧/秒`}</dd>
      <dt>最近问题代码</dt><dd data-diagnostic-issue>{value?.lastIssue??'无'}</dd>
    </dl>
    <p>{state?.error||state?.message||'等待采集数据'}</p>
    <div className="scroll-diagnostic-export"><button data-longshot-diagnostics="export" disabled={!state||pending||state.status==='finishing'} onClick={exportReport}>{pending?'正在导出…':'导出诊断 JSON'}</button><small>仅保存数值与参数，不含截图或凭证。</small></div>
    {notice&&<p role={notice.error?'alert':'status'}>{notice.message}</p>}
  </aside>;
}
