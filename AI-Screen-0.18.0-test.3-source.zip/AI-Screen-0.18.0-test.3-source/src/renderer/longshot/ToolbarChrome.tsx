import type { ReactNode } from 'react';
import { CaptureIcon } from '../components/CaptureIcon';

export function LongshotGlyph({ name }: { name: 'chevron' | 'scroll' | 'pen' | 'share' | 'save' | 'cancel' | 'finish' }) {
  const paths = {
    chevron: 'm8 10 4 4 4-4', scroll: 'm6 5 6 6 6-6M6 12l6 6 6-6',
    pen: 'm14 4 6 6M4 20h16M5 15 16 4a2 2 0 0 1 4 4L9 19H5Z',
    share: 'M14 4v5C7 9 4 13 4 20c3-5 6-6 10-6v5l7-8Z',
    save: 'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',
    cancel: 'm5 5 14 14M19 5 5 19', finish: 'm4 12 5 5L20 6',
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d={paths[name]} /></svg>;
}

/** The live capture toolbar shell. Commands remain owned by CaptureToolbar. */
export function ToolbarChrome({ mode, actions, save, edit, share, reviewing = false }: { mode: ReactNode; actions: ReactNode; save: ReactNode; edit:ReactNode; share:ReactNode; reviewing?: boolean }) {
  return <div className="scroll-toolbar-actions">
    {!reviewing && <><span className="scroll-toolbar-kind" aria-label="当前仅支持竖向长截图"><CaptureIcon name="longshot" />长截图</span><span className="scroll-toolbar-divider" /></>}
    {mode}
    <span className="scroll-toolbar-spacer" />
    {!reviewing && <><span className="scroll-toolbar-divider" />{edit}{share}{save}</>}
    {actions}
  </div>;
}
