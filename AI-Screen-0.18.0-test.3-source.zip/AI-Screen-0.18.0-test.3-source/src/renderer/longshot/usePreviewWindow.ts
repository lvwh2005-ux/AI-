import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import type { PreviewEdge, PreviewWindowState } from '../../shared/scroll-capture/preview-window';
import { PreviewGesture } from './preview-gesture';

export function usePreviewWindow(id?: string) {
  const [layout, setLayout] = useState<PreviewWindowState | null>(null);
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);
  const autoPending = useRef(false), lastGesture = useRef<PreviewGesture | null>(null);
  const mounted = useRef(false), currentId = useRef(id), revision = useRef(-1);
  currentId.current = id;
  const gesture = useRef<{ pump: PreviewGesture; pointerId: number; node: HTMLElement } | null>(null);
  const accept = useCallback((state: PreviewWindowState) => {
    if (mounted.current && currentId.current === state.id && state.revision >= revision.current) {
      revision.current = state.revision; setLayout(state);
    }
  }, []);
  const failed = useCallback((failure: unknown) => {
    if (mounted.current) setError(failure instanceof Error ? failure.message : '预览窗口调整失败');
  }, []);
  useEffect(() => {
    mounted.current = true; revision.current = -1; setLayout(null); setError('');
    const unsubscribe = window.screenAI.onPreviewWindow(accept);
    if (id) void window.screenAI.previewWindow({ id, op: 'get' }).then(accept).catch(failure=>{if(currentId.current===id)failed(failure);});
    return () => {
      mounted.current = false; unsubscribe(); gesture.current?.pump.end(); gesture.current = null;
    };
  }, [id, accept, failed]);

  const begin = (edge: PreviewEdge) => (event: ReactPointerEvent<HTMLElement>) => {
    if (!id || event.button !== 0 || gesture.current || autoPending.current || (edge === 'move' && (event.target as HTMLElement).closest('button'))) return;
    event.preventDefault(); event.stopPropagation(); setError('');
    try { event.currentTarget.setPointerCapture(event.pointerId); } catch { return; }
    const session = id;
    const preceding = lastGesture.current?.completed;
    gesture.current = { pointerId: event.pointerId, node: event.currentTarget,
      pump: new PreviewGesture(session, edge, { x: event.screenX, y: event.screenY }, async input => { if (input.op === 'begin') await preceding; return window.screenAI.previewWindow(input); }, accept,
        failure => { if (currentId.current === session) failed(failure); }) };
    lastGesture.current = gesture.current.pump;
  };
  const move = (event: ReactPointerEvent<HTMLElement>) => {
    if (gesture.current?.pointerId === event.pointerId) gesture.current.pump.move({ x: event.screenX, y: event.screenY });
  };
  const end = (event: ReactPointerEvent<HTMLElement>, usePoint = true) => {
    const active = gesture.current;
    if (!active || active.pointerId !== event.pointerId) return;
    gesture.current = null;
    active.pump.end(usePoint ? { x: event.screenX, y: event.screenY } : undefined);
    if (active.node.hasPointerCapture(event.pointerId)) active.node.releasePointerCapture(event.pointerId);
  };
  const automatic = async () => {
    if (!id || gesture.current || autoPending.current) return;
    setError(''); autoPending.current = true; setPending(true);
    try {
      await lastGesture.current?.completed;
      if (mounted.current && currentId.current === id) accept(await window.screenAI.previewWindow({ id, op: 'auto' }));
    } catch (failure) { if (currentId.current === id) failed(failure); }
    finally { autoPending.current = false; if (mounted.current && currentId.current === id) setPending(false); }
  };
  return { layout, error, pending, begin, move, end, automatic };
}
