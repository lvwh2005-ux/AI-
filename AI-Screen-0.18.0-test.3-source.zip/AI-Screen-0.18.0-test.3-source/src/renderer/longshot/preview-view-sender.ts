import type { PreviewWindowRequest, PreviewWindowState } from '../../shared/scroll-capture/preview-window';
type Request = Extract<PreviewWindowRequest, {op:'view'}>;
/** Panning/zooming only needs the newest viewport, unlike the source-frame queue. */
export class PreviewViewSender {
  private latest?: Request;
  private busy = false;
  private disposed = false;
  constructor(private send:(request:Request)=>Promise<PreviewWindowState>,private failed:(request:Request,error:unknown)=>void) {}
  submit(request:Request) { if(!this.disposed){this.latest=request;void this.drain();} }
  dispose(){this.disposed=true;this.latest=undefined;}
  private async drain(){
    if(this.busy||this.disposed)return;this.busy=true;
    try{while(this.latest&&!this.disposed){const request=this.latest;this.latest=undefined;try{await this.send(request);}catch(error){if(!this.disposed)this.failed(request,error);}}}
    finally{this.busy=false;}
  }
}
