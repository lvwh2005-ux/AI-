import { useEffect, useRef, useState } from 'react';
import type { LongshotCommand, LongshotState } from '../../shared/longshot';
import { annotationsSchema, annotationTools, type Annotation, type AnnotationTool } from '../../shared/annotations';
import { AnnotationLayer } from '../capture/AnnotationLayer';
import { CaptureIcon } from '../components/CaptureIcon';
import { LongshotGlyph } from './ToolbarChrome';
import './editor.css';
import {DiagnosticsPanel} from './DiagnosticsPanel';
import {previewCssScale} from '../../shared/scroll-capture/preview-viewport';

export type ResultPane = 'view' | 'annotate' | 'share';
const labels = {pen:'画笔',arrow:'箭头',rectangle:'矩形',text:'文字'};
type History = {past:Annotation[][]; items:Annotation[]; future:Annotation[][]};
export function LongshotResultEditor({state, pending, message, error, notice, initialPane, command}: {
  state:LongshotState; pending:LongshotCommand|null; message:string; error:boolean;
  notice:{message:string;error?:boolean}|null; initialPane:ResultPane;
  command(action:LongshotCommand, annotations?:Annotation[]):Promise<void>;
}) {
  const [image,setImage]=useState(state.preview);
  const [imageError,setImageError]=useState('');
  const [localError,setLocalError]=useState('');
  const [tool,setTool]=useState<AnnotationTool|null>(initialPane==='annotate'?'pen':null);
  const [color,setColor]=useState('#EF4444');
  const [width,setWidth]=useState(3);
  const [fontSize,setFontSize]=useState(24);
  const [history,setHistory]=useState<History>({past:[],items:[],future:[]});
  const [sharing,setSharing]=useState(initialPane==='share');
  const [diagnostics,setDiagnostics]=useState(false);
  const [sharePosition,setSharePosition]=useState({left:8,bottom:60});
  const [zoom,setZoom]=useState(0);
  const [viewportWidth,setViewportWidth]=useState(1);
  const [aiTarget,setAITarget]=useState('设置中的 AI 服务');
  const viewport=useRef<HTMLElement>(null);
  const shareArea=useRef<HTMLDivElement>(null);
  const busy=!!pending;
  const extended=(state.appendedRows??0)>0;
  const scale=zoom?previewCssScale(zoom,devicePixelRatio):Math.min(1,Math.max(1,viewportWidth-24)/state.width);

  useEffect(()=>{
    let active=true;
    void window.screenAI.getLongshotImage(state.id).then(result=>{if(active){setImage(result.image);setImageError('');}}).catch(failure=>{if(active)setImageError(failure instanceof Error?failure.message:'原图预览加载失败');});
    void window.screenAI.getSettings().then(settings=>{
      if(!active)return;
      if(settings.provider==='demo')setAITarget('演示模式，不联网');
      else {try{setAITarget(new URL(settings.baseUrl).host);}catch{setAITarget('设置中的 AI 服务');}}
    }).catch(()=>{});
    return()=>{active=false;};
  },[state.id]);
  useEffect(()=>{
    const element=viewport.current;if(!element)return;
    const measure=()=>setViewportWidth(element.clientWidth);
    const observer=new ResizeObserver(measure);observer.observe(element);measure();
    return()=>observer.disconnect();
  },[]);
  function update(items:Annotation[]) {
    const parsed=annotationsSchema.safeParse(items);
    if(!parsed.success){setLocalError('标注过多或格式无效，请撤销或清除部分标注');return;}
    setLocalError('');setHistory(previous=>({past:[...previous.past,previous.items].slice(-40),items:parsed.data,future:[]}));
  }
  function undo(){setHistory(previous=>previous.past.length?{past:previous.past.slice(0,-1),items:previous.past.at(-1)!,future:[previous.items,...previous.future].slice(0,40)}:previous);}
  function redo(){setHistory(previous=>previous.future.length?{past:[...previous.past,previous.items].slice(-40),items:previous.future[0],future:previous.future.slice(1)}:previous);}
  useEffect(()=>{
    const key=(event:KeyboardEvent)=>{
      if(busy || event.defaultPrevented || (event.target instanceof HTMLElement && (event.target.closest('input,textarea,select') || event.target.isContentEditable)))return;
      if(event.ctrlKey && event.key.toLowerCase()==='z'){event.preventDefault();if(event.shiftKey)redo();else undo();}
      if(event.ctrlKey && event.key.toLowerCase()==='y'){event.preventDefault();redo();}
    };
    window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);
  },[busy]);
  useEffect(()=>{
    if(!sharing)return;
    const position=()=>{const anchor=shareArea.current?.getBoundingClientRect();if(anchor)setSharePosition({left:Math.max(8,Math.min(anchor.right-275,window.innerWidth-283)),bottom:Math.max(8,window.innerHeight-anchor.top+8)});};
    position();window.addEventListener('resize',position);
    const outside=(event:PointerEvent)=>{if(!shareArea.current?.contains(event.target as Node))setSharing(false);};
    window.addEventListener('pointerdown',outside);return()=>{window.removeEventListener('pointerdown',outside);window.removeEventListener('resize',position);};
  },[sharing]);
  async function output(action:'copy'|'save'|'analyze') {setLocalError('');setSharing(false);await command(action,history.items);}

  return <main className="longshot-result longshot-editor" data-status="done" data-annotation-count={history.items.length} aria-label="长截图结果">
    <header className="longshot-header"><div className="longshot-brand"><span className="longshot-result-icon"><CaptureIcon name="longshot" /></span><div><strong>{extended?'长截图已完成':'首屏截图已就绪'}</strong><small>{state.width} × {state.height} px · 原图保留在本机</small></div></div><button className="longshot-close" data-longshot-action="close" aria-label="关闭长截图" onClick={()=>void command('close')}>×</button></header>
    <section className="longshot-completion-summary"><p className={error||localError?'is-error':''} role={error||localError?'alert':'status'}>{localError||message}</p><small>{imageError||'标注、复制和保存均使用原始尺寸；AI 分析仅在点击后发送当前图片。'}</small></section>
    <section className="longshot-edit-controls" aria-label="长图标注工具">
      <div className="longshot-edit-tools" role="toolbar" aria-label="标注工具">
        <button data-longshot-tool="browse" aria-pressed={!tool} disabled={busy} onClick={()=>setTool(null)}>浏览</button>
        {annotationTools.map(name=><button key={name} data-longshot-tool={name} aria-pressed={tool===name} disabled={busy} onClick={()=>setTool(name)}><CaptureIcon name={name}/>{labels[name]}</button>)}
        <label className="longshot-color"><span>颜色</span><input type="color" aria-label="标注颜色" value={color} disabled={busy} onChange={event=>setColor(event.target.value.toUpperCase())}/></label>
        <select aria-label="画笔线宽" value={width} disabled={busy} onChange={event=>setWidth(Number(event.target.value))}><option value={2}>细线</option><option value={3}>中线</option><option value={6}>粗线</option><option value={12}>加粗</option></select>
        {tool==='text'&&<select aria-label="文字大小" value={fontSize} disabled={busy} onChange={event=>setFontSize(Number(event.target.value))}>{[16,24,36,48,72].map(size=><option key={size} value={size}>{size}px</option>)}</select>}
        <button data-longshot-edit="undo" title="撤销 · Ctrl+Z" disabled={busy||!history.past.length} onClick={undo}><CaptureIcon name="undo"/>撤销</button>
        <button data-longshot-edit="redo" title="重做 · Ctrl+Y" disabled={busy||!history.future.length} onClick={redo}>重做</button>
        <button data-longshot-edit="clear" disabled={busy||!history.items.length} onClick={()=>update([])}>清除</button>
        <select aria-label="长图缩放" value={zoom} disabled={busy} onChange={event=>setZoom(Number(event.target.value))}><option value={0}>适应宽度</option>{[.25,.5,1,1.5,2].map(value=><option key={value} value={value}>{value*100}%</option>)}</select>
        <button data-longshot-original="true" aria-label="100% 原图：一个原始像素对应一个屏幕物理像素" aria-pressed={zoom===1} disabled={busy} onClick={()=>setZoom(1)}>原图 100%</button>
      </div>
    </section>
    <section ref={viewport} className="longshot-preview-area longshot-edit-viewport" aria-label="长截图预览">
      {image ? <div className="longshot-scaled-sheet" style={{width:state.width*scale,height:state.height*scale}}>
        <div className="longshot-original-sheet" style={{width:state.width,height:state.height,transform:`scale(${scale})`}}>
          <img className="longshot-original-image" src={image} alt="长截图原图" draggable={false} style={{imageRendering:zoom>=1?'pixelated':'auto'}} onError={()=>setImageError('图片显示失败，仍可尝试复制或保存原图')}/>
          <AnnotationLayer rect={{x:0,y:0,width:state.width,height:state.height}} annotations={history.items} tool={tool} color={color} width={width} fontSize={fontSize} disabled={busy} onCommit={annotation=>update([...history.items,annotation])} onError={setLocalError}/>
        </div>
      </div>:<p>正在加载原图…</p>}
    </section>
    <footer className="longshot-footer"><span>{extended?`已拼接 ${state.frames} 帧`:'仅保留首屏，未拼接'}{history.items.length>0&&` · ${history.items.length} 处标注`}{notice&&!notice.error&&<small role="status"> · {notice.message}</small>}</span><div className="longshot-actions">
      <button data-longshot-diagnostics="toggle" aria-expanded={diagnostics} disabled={busy} onClick={()=>{setSharing(false);setDiagnostics(!diagnostics);}}>诊断</button>
      <button data-longshot-action="copy" disabled={busy} onClick={()=>void output('copy')}>{pending==='copy'?'复制中…':extended?'复制长图':'复制首屏'}</button>
      <div ref={shareArea} className="longshot-share-area"><button data-longshot-action="share" aria-expanded={sharing} disabled={busy} onClick={()=>setSharing(!sharing)}><LongshotGlyph name="share"/>分享</button>
        {sharing&&<div className="longshot-share-menu" style={sharePosition} role="group" aria-label="分享长图"><strong>分享当前长图</strong><button data-longshot-share="copy" disabled={busy} onClick={()=>void output('copy')}>复制图片，粘贴到 QQ / 微信</button><button data-longshot-share="save" disabled={busy} onClick={()=>void output('save')}>导出 PNG 文件后发送</button><small>包含当前标注。由你选择应用及接收人，不会自动发送。</small></div>}
      </div>
      <button data-longshot-action="save" disabled={busy} onClick={()=>void output('save')}>{pending==='save'?'保存中…':'另存 PNG'}</button>
      <button data-longshot-action="analyze" className="longshot-ai" disabled={busy} title={`将当前长图（含标注）交给 ${aiTarget}。超长图片识别能力取决于所配模型。`} onClick={()=>void output('analyze')}><CaptureIcon name="analyze"/>{pending==='analyze'?'准备分析…':'AI 分析'}</button>
    </div></footer>
    {diagnostics&&<DiagnosticsPanel state={state} close={()=>setDiagnostics(false)} exportReport={()=>void command('export-diagnostics')} pending={busy} notice={notice}/>}
  </main>;
}
