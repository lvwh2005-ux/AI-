import { useCallback, useEffect, useRef, useState } from 'react';
import type { LongshotBridge, LongshotCommand, LongshotState } from '../../shared/longshot';
import type { Annotation } from '../../shared/annotations';


export function finishable(state: LongshotState | null) {
  return !!state && (state.status === 'capturing' ? state.canFinish ?? state.frames > 0 : state.status === 'error' && state.canFinish === true);
}

export function useLongshotSession() {
  const bridge = window.screenAI as typeof window.screenAI & LongshotBridge;
  const [state, setState] = useState<LongshotState | null>(null);
  const [pending, setPending] = useState<LongshotCommand | null>(null);
  const [notice, setNotice] = useState<{ message: string; error?: boolean } | null>(null);
  const [loadError, setLoadError] = useState('');
  const mounted = useRef(false);
  const current = useRef<LongshotState | null>(null);
  const identity = useRef('');
  const revision = useRef(0);
  const operation = useRef(0);
  const pendingRef = useRef<LongshotCommand | null>(null);

  const accept = useCallback((next: LongshotState | null) => {
    if (!mounted.current || !next || !next.id || (identity.current && identity.current !== next.id)) return;
    // A delayed capture update cannot replace the completed preview.
    if (current.current?.status === 'done' && next.status !== 'done') return;
    identity.current = next.id;
    current.current = next;
    setState(next); setLoadError('');
  }, []);
  const refresh = useCallback(async () => {
    const before = revision.current;
    try {
      const initial = await bridge.getLongshot();
      // Subscription updates take precedence over an older initial read.
      if (mounted.current && before === revision.current) accept(initial);
    } catch (failure) {
      if (mounted.current && before === revision.current) setLoadError(failure instanceof Error ? failure.message : '无法读取长截图状态');
    }
  }, [accept, bridge]);
  const command = useCallback(async (action: LongshotCommand, annotations?: Annotation[]) => {
    const snapshot = current.current;
    if (!snapshot) return;
    if (pendingRef.current && action !== 'cancel' && action !== 'close') return;
    if ((pendingRef.current === 'cancel' || pendingRef.current === 'close') && (action === 'cancel' || action === 'close')) return;
    if (action === 'finish' && !finishable(snapshot)) return;
    if (action === 'copy' && snapshot.status !== 'done') return;
    if (action === 'analyze' && snapshot.status !== 'done') return;
    if (action === 'save' && snapshot.status !== 'done' && !finishable(snapshot)) return;
    if ((action === 'confirm-region' || action === 'keep-region') && (!snapshot.regionCandidate || !['preparing','capturing'].includes(snapshot.status))) return;
    if (action === 'pause' || action === 'resume' || action === 'manual') {
      if (!['preparing', 'capturing'].includes(snapshot.status) || snapshot.regionCandidate) return;
      if (action === 'manual' && snapshot.scrollMode !== 'auto') return;
      if ((action === 'pause' && snapshot.paused) || (action === 'resume' && !snapshot.paused)) return;
    }
    const request = ++operation.current;
    const id = snapshot.id;
    pendingRef.current = action; setPending(action); setNotice(null);
    try {
      const response = await bridge.commandLongshot(id, action, annotations);
      if (!mounted.current || current.current?.id !== id || operation.current !== request) return;
      const message = response.cancelled ? '已取消保存' : response.message || (action === 'copy' ? '长截图已复制' : '');
      if (message) setNotice({ message });
    } catch (failure) {
      if (mounted.current && current.current?.id === id && operation.current === request) setNotice({ message: failure instanceof Error ? failure.message : '操作失败，请重试', error: true });
    } finally {
      if (mounted.current && current.current?.id === id && operation.current === request) { pendingRef.current = null; setPending(null); }
    }
  }, [bridge]);

  useEffect(() => {
    mounted.current = true;
    const unsubscribe = bridge.onLongshot((next) => { revision.current++; accept(next); });
    const unsubscribeTelemetry=bridge.onLongshotTelemetry(({id,telemetry})=>{
      const value=current.current;
      if(!mounted.current||!value||value.id!==id||value.status==='done'||telemetry.sequence<=(value.telemetry?.sequence??-1))return;
      revision.current++;accept({...value,telemetry});
    });
    void refresh();
    return () => { mounted.current = false; operation.current++; unsubscribe(); unsubscribeTelemetry(); };
  }, [accept, bridge, refresh]);
  useEffect(() => {
    const keys = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        const status = current.current?.status;
        void command(status === 'done' || status === 'cancelled' ? 'close' : 'cancel');
      } else if (event.key === 'Enter' && event.ctrlKey && finishable(current.current)) { event.preventDefault(); void command('finish'); }
    };
    window.addEventListener('keydown', keys);
    return () => window.removeEventListener('keydown', keys);
  }, [command]);

  return { state, pending, notice, loadError, refresh, command };
}
