import type { ReactNode } from 'react';
import type { ActionId } from '../../shared/contracts';

export type CaptureIconName = ActionId | 'close' | 'send' | 'screenshot' | 'longshot' | 'record' | 'ai-screen' | 'pen' | 'arrow' | 'rectangle' | 'text' | 'undo' | 'clear' | 'pin' | 'more' | 'dashboard' | 'settings' | 'shield' | 'check';

const paths: Record<CaptureIconName, ReactNode> = {
  dashboard: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
  settings: <><path d="M4 7h16M4 17h16" /><circle cx="9" cy="7" r="3" fill="var(--surface)" /><circle cx="16" cy="17" r="3" fill="var(--surface)" /></>,
  shield: <><path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z" /><path d="m8 12 3 3 5-6" /></>,
  check: <path d="m5 12 4 4L19 6" />,
  'copy-image': <>
    <rect x="4" y="4" width="16" height="16" rx="3" />
    <circle cx="9" cy="9" r="1.25" />
    <path d="m4 16 5-5 4 4 3-3 4 4" />
  </>,
  ocr: <>
    <path d="M8 4H4v4m12-4h4v4M4 16v4h4m12-4v4h-4" />
    <path d="M8 9h8M8 12h8M8 15h5" />
  </>,
  translate: <>
    <path d="M3 6h11M8 3v3m4 0c-1 5-4 8-8 10M5 9c1.5 3 4 5 7 7" />
    <path d="m13 21 4-10 4 10m-6.8-3h5.6" />
  </>,
  analyze: <path d="M12 3c1.2 5.7 3.3 7.8 9 9-5.7 1.2-7.8 3.3-9 9-1.2-5.7-3.3-7.8-9-9 5.7-1.2 7.8-3.3 9-9Z" />,
  ask: <>
    <path d="M7 4h10a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3h-6l-6 4v-4a3 3 0 0 1-2-3V7a3 3 0 0 1 3-3Z" />
    <path d="M7 9h9m-9 4h6" />
  </>,
  custom: <>
    <path d="M10 5c.9 4.4 2.6 6.1 7 7-4.4.9-6.1 2.6-7 7-.9-4.4-2.6-6.1-7-7 4.4-.9 6.1-2.6 7-7Z" />
    <path d="M19 3v4m-2-2h4" />
  </>,
  close: <path d="m6 6 12 12M18 6 6 18" />,
  send: <path d="M4 12h16m-6-6 6 6-6 6" />,
  screenshot: <path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5M7 7h10v10H7Z" />,
  longshot: <><rect x="5" y="3" width="14" height="18" rx="2" /><path d="M9 7h6M9 11h6m-6 5 3 3 3-3m-3-3v6" /></>,
  record: <><rect x="3" y="6" width="13" height="12" rx="2" /><path d="m16 10 5-3v10l-5-3Z" /></>,
  'ai-screen': <><rect x="3" y="4" width="18" height="14" rx="2" /><path d="M9 21h6m-3-3v3m0-14 .9 2.7L16 11l-3.1 1.3L12 15l-.9-2.7L8 11l3.1-1.3Z" /></>,
  pen: <path d="m5 16 11-12 4 4L9 20l-5 1Zm9-10 4 4M5 16l4 4" />,
  arrow: <path d="M5 19 19 5M8 5h11v11" />,
  rectangle: <rect x="4" y="5" width="16" height="14" rx="1" />,
  text: <path d="M4 7V4h16v3m-8-3v16m-4 0h8" />,
  undo: <path d="M8 5 3 10l5 5m-5-5h12a5 5 0 0 1 0 10h-3" />,
  clear: <path d="m5 8 8-5 8 12-8 5Z M13 20h8M9 16l8-5" />,
  pin: <path d="M8 3h8M9 3v6l-4 4v2h14v-2l-4-4V3M12 15v6" />,
  more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
};

export function CaptureIcon({ name, className }: { name: CaptureIconName; className?: string }) {
  return <svg className={className} width="18" height="18" viewBox="0 0 24 24"
    fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
    aria-hidden="true" focusable="false">
    {paths[name]}
  </svg>;
}
