import { Children, isValidElement, useEffect, useMemo, useState, type ReactNode } from 'react';
import ReactMarkdown, { type Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';
import hljs from 'highlight.js/lib/core';
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import python from 'highlight.js/lib/languages/python';
import json from 'highlight.js/lib/languages/json';
import bash from 'highlight.js/lib/languages/bash';
import powershell from 'highlight.js/lib/languages/powershell';
import xml from 'highlight.js/lib/languages/xml';
import css from 'highlight.js/lib/languages/css';
import sql from 'highlight.js/lib/languages/sql';
import csharp from 'highlight.js/lib/languages/csharp';
import cpp from 'highlight.js/lib/languages/cpp';

const languages = { javascript, typescript, python, json, bash, powershell, xml, css, sql, csharp, cpp };
for (const [name, language] of Object.entries(languages)) hljs.registerLanguage(name, language);
const aliases: Record<string, keyof typeof languages> = {
  js: 'javascript', jsx: 'javascript', javascript: 'javascript',
  ts: 'typescript', tsx: 'typescript', typescript: 'typescript',
  py: 'python', python: 'python', json: 'json',
  sh: 'bash', shell: 'bash', bash: 'bash',
  ps: 'powershell', ps1: 'powershell', powershell: 'powershell',
  html: 'xml', xml: 'xml', svg: 'xml', css: 'css', sql: 'sql',
  cs: 'csharp', csharp: 'csharp', 'c#': 'csharp', c: 'cpp', cpp: 'cpp', 'c++': 'cpp',
};

/** Links never navigate the Electron renderer. The main process validates again before opening. */
export function safeMarkdownLink(value: string | undefined): string | null {
  if (!value || value.length > 2048 || /[\u0000-\u001f\u007f]/.test(value)) return null;
  const trimmed = value.trim();
  if (!/^https?:\/\//i.test(trimmed)) return null;
  try {
    const parsed = new URL(trimmed);
    if (!['https:', 'http:'].includes(parsed.protocol) || parsed.username || parsed.password) return null;
    return parsed.href;
  } catch { return null; }
}

/** HAST appends one LF to block code; remove that LF, preserving its actual trailing blank lines. */
export function codeBlockText(value: ReactNode): string {
  function text(node: ReactNode): string {
    if (typeof node === 'string' || typeof node === 'number') return String(node);
    if (isValidElement<{ children?: ReactNode }>(node)) return text(node.props.children);
    return Children.toArray(node).map(text).join('');
  }
  const result = text(value);
  return result.endsWith('\n') ? result.slice(0, -1) : result;
}

/** Highlight only explicitly supported languages; unknown/unfinished language labels stay plain. */
export function highlightedCode(code: string, language: string): string | null {
  const key = language.toLowerCase();
  if (!Object.hasOwn(aliases, key) || code.length > 80_000) return null;
  try { return hljs.highlight(code, { language: aliases[key], ignoreIllegals: true }).value; }
  catch { return null; }
}

interface MarkdownAnswerProps {
  text: string;
  onCopy: (text: string) => Promise<void>;
  onOpenLink: (url: string) => void;
}

function CodeBlock({ code, language, onCopy }: { code: string; language: string; onCopy: MarkdownAnswerProps['onCopy'] }) {
  const [copyState, setCopyState] = useState<'idle' | 'copying' | 'copied' | 'error'>('idle');
  const highlighted = useMemo(() => highlightedCode(code, language), [code, language]);
  useEffect(() => { setCopyState('idle'); }, [code]);
  async function copy() {
    setCopyState('copying');
    try { await onCopy(code); setCopyState('copied'); }
    catch { setCopyState('error'); }
  }
  return <div className="markdown-code-block">
    <div className="markdown-code-toolbar"><span>{language || '代码'}</span><button type="button" disabled={copyState === 'copying'} onClick={() => void copy()} aria-label="复制代码">{copyState === 'copied' ? '已复制' : copyState === 'error' ? '复制失败 · 重试' : '复制代码'}</button></div>
    <pre>{highlighted === null ? <code>{code}</code> : <code className="hljs" dangerouslySetInnerHTML={{ __html: highlighted }} />}</pre>
    <span className="markdown-copy-status" role="status">{copyState === 'copied' ? '代码已复制到剪贴板' : copyState === 'error' ? '无法复制代码，请重试' : ''}</span>
  </div>;
}

export function MarkdownAnswer({ text, onCopy, onOpenLink }: MarkdownAnswerProps) {
  const components = useMemo<Components>(() => ({
    a: ({ href, children }) => {
      const url = safeMarkdownLink(href);
      if (!url) return <span>{children}</span>;
      // Deliberately omit href: middle-click, context menus and default navigation must not open a URL.
      return <a className="markdown-link" role="link" tabIndex={0} title={`在浏览器打开：${url}`} onClick={() => onOpenLink(url)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); onOpenLink(url); } }}>{children}<span aria-hidden="true"> ↗</span></a>;
    },
    img: ({ alt }) => <span className="markdown-image-placeholder">{alt ? `图片：${alt}（外部图片已省略）` : '外部图片已省略'}</span>,
    pre: ({ children }) => {
      const element = Children.toArray(children).find((child) => isValidElement<{ className?: string }>(child));
      const className = isValidElement<{ className?: string }>(element) ? element.props.className ?? '' : '';
      const language = /(?:^|\s)language-([^\s]+)/.exec(className)?.[1] ?? '';
      return <CodeBlock code={codeBlockText(children)} language={language} onCopy={onCopy} />;
    },
    table: ({ children }) => <div className="markdown-table"><table>{children}</table></div>,
  }), [onCopy, onOpenLink]);
  return <div className="answer markdown-answer"><ReactMarkdown remarkPlugins={[remarkGfm]} components={components} skipHtml urlTransform={(url) => safeMarkdownLink(url) ?? ''}>{text}</ReactMarkdown></div>;
}
