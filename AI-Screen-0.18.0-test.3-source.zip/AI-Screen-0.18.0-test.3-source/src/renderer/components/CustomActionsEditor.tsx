import type { CustomAction } from '../../shared/contracts';
import { CaptureIcon } from './CaptureIcon';

interface Props {
  value: CustomAction[];
  disabled?: boolean;
  onChange(value: CustomAction[]): void;
}

export function CustomActionsEditor({ value, disabled, onChange }: Props) {
  function update(id: string, patch: Partial<CustomAction>) {
    onChange(value.map((action) => action.id === id ? { ...action, ...patch } : action));
  }
  function add() {
    if (value.length >= 8) return;
    const id = `custom-${Date.now().toString(36)}-${crypto.randomUUID().slice(0, 8)}`;
    onChange([...value, { id, label: '自定义动作', prompt: '请使用 {{language}} 简要总结图片内容。', enabled: true }]);
  }
  return <details className="custom-actions-editor" onInvalidCapture={(event) => { event.currentTarget.open = true; }}>
    <summary><span className="custom-actions-title"><CaptureIcon name="custom" />自定义 AI 动作</span><span className="custom-actions-count">{value.filter((action) => action.enabled).length} / {value.length} 项已启用</span></summary>
    <p className="field-hint">将常用提示词放进截图工具栏，最多 8 项。<code>{'{{language}}'}</code> 使用回答语言，<code>{'{{question}}'}</code> 使用工具栏中填写的问题。</p>
    <fieldset disabled={disabled}>
      {value.map((action, index) => <div className="custom-action-item" key={action.id}>
        <div className="custom-action-heading"><span>动作 {index + 1}</span><label className="check"><input type="checkbox" checked={action.enabled} onChange={(event) => update(action.id, { enabled: event.target.checked })} />启用</label><button type="button" className="remove-action" onClick={() => onChange(value.filter((item) => item.id !== action.id))} aria-label={`删除动作 ${action.label || index + 1}`}>删除</button></div>
        <label htmlFor={`action-label-${action.id}`}>按钮名称<input id={`action-label-${action.id}`} value={action.label} maxLength={16} required onChange={(event) => update(action.id, { label: event.target.value })} placeholder="例如：解释代码" /></label>
        <label htmlFor={`action-prompt-${action.id}`}>提示词<textarea id={`action-prompt-${action.id}`} value={action.prompt} maxLength={4000} required rows={3} onChange={(event) => update(action.id, { prompt: event.target.value })} placeholder="描述 AI 应如何处理选区" /></label>
        <p className="field-hint action-limit">{action.prompt.length} / 4000 字</p>
      </div>)}
      {!value.length && <p className="custom-action-empty">添加常用操作，例如总结内容、解释代码或整理为表格。</p>}
      <button className="add-custom-action" type="button" disabled={value.length >= 8} onClick={add}>＋ 添加动作{value.length >= 8 ? ' · 已达上限' : ''}</button>
    </fieldset>
  </details>;
}
