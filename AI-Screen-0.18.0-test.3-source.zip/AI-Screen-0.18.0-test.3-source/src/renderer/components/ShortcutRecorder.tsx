import { useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { shortcutFromKeyEvent } from '../../shared/shortcut';

interface Props {
  value: string;
  disabled?: boolean;
  onChange(value: string): void;
  onRecordingChange(recording: boolean): void;
  onError(message: string): void;
}
type Mode = 'idle' | 'arming' | 'recording' | 'releasing' | 'finishing';

export function ShortcutRecorder(props: Props) {
  const [mode, setMode] = useState<Mode>('idle');
  const [hint, setHint] = useState('点击后按下组合键，Esc 取消。');
  const state = useRef<Mode>('idle');
  const mounted = useRef(true);
  const session = useRef(0);
  const pending = useRef<Promise<void>>(Promise.resolve());
  const latest = useRef(props);
  latest.current = props;

  // Serialize suspension and restoration, including cancellation while suspension is pending.
  function setSuspended(value: boolean) {
    const next = pending.current.catch(() => {}).then(() => window.screenAI.setShortcutRecording(value));
    pending.current = next;
    return next;
  }
  function changeMode(value: Mode) {
    state.current = value;
    if (mounted.current) setMode(value);
  }
  async function finish() {
    if (state.current === 'idle' || state.current === 'finishing') return;
    ++session.current;
    changeMode('finishing');
    try { await setSuspended(false); }
    catch (error) { if (mounted.current) latest.current.onError((error as Error).message); }
    finally {
      changeMode('idle');
      if (mounted.current) latest.current.onRecordingChange(false);
    }
  }
  async function begin() {
    if (state.current !== 'idle' || latest.current.disabled) return;
    const token = ++session.current;
    changeMode('arming');
    setHint('请按 Ctrl / Alt / Shift / Win 与一个普通键。');
    latest.current.onRecordingChange(true);
    try {
      await setSuspended(true);
      if (mounted.current && token === session.current) changeMode('recording');
    } catch (error) {
      if (mounted.current && token === session.current) {
        latest.current.onError((error as Error).message);
        await finish();
      }
    }
  }
  function record(event: KeyboardEvent<HTMLButtonElement>) {
    if (state.current === 'idle') return;
    event.preventDefault();
    event.stopPropagation();
    if (event.code === 'Escape') { setHint('已取消，原快捷键保持不变。'); void finish(); return; }
    if (state.current !== 'recording' || event.repeat || event.nativeEvent.isComposing) return;
    const value = shortcutFromKeyEvent(event);
    if (!value) {
      if (!/^(Control|Alt|Shift|Meta)(Left|Right)$/.test(event.code)) setHint('请使用修饰键和字母、数字、方向键或功能键。');
      return;
    }
    latest.current.onChange(value);
    setHint('已录制，保存设置后生效。');
    // Keep the old shortcut suspended until a key is released, so holding the
    // recorded combination cannot immediately trigger capture through repeat.
    changeMode('releasing');
  }
  useEffect(() => {
    mounted.current = true;
    const onWindowBlur = () => { void finish(); };
    window.addEventListener('blur', onWindowBlur);
    return () => {
      mounted.current = false;
      ++session.current;
      window.removeEventListener('blur', onWindowBlur);
      // The main process also restores registration when the settings window loses focus.
      void setSuspended(false).catch(() => {});
    };
  }, []);

  const title = mode === 'arming' ? '准备录制…' : mode === 'recording' ? '按下组合键…' : mode === 'releasing' ? `${props.value} · 请松开按键` : mode === 'finishing' ? '正在恢复…' : props.value;
  return <div className="shortcut-field">
    <label htmlFor="shortcut-recorder">全局快捷键</label>
    <button id="shortcut-recorder" className={`shortcut-recorder ${mode !== 'idle' ? 'recording' : ''}`} type="button" disabled={props.disabled}
      onClick={() => void begin()} onKeyDown={record} onKeyUp={() => { if (state.current === 'releasing') void finish(); }} onBlur={() => void finish()} aria-pressed={mode !== 'idle'} aria-describedby="shortcut-hint">
      <kbd>{title}</kbd><span>{mode === 'idle' ? '录制' : 'Esc 取消'}</span>
    </button>
    <p className="field-hint" id="shortcut-hint" role="status">{hint}</p>
  </div>;
}
