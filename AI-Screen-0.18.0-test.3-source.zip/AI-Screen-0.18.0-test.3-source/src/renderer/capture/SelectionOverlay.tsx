import type { ReactNode, RefObject } from 'react';
import { resizeHandles } from '../../shared/geometry';
import type { ScreenshotController } from './ScreenshotController';

export function SelectionOverlay({ controller: c, imageRef, children }: { controller: ScreenshotController; imageRef: RefObject<HTMLImageElement | null>; children: ReactNode }) {
  const r = c.rect;
  return <div className="capture" data-phase={c.phase} data-mode={c.mode} onPointerDown={c.down} onPointerMove={c.move} onPointerUp={c.up} onPointerCancel={c.pointerCancel} onContextMenu={c.contextMenu} onDoubleClick={c.doubleClick}>
    {c.frame && <img ref={imageRef} className="screen-image" src={c.frame.image} draggable={false} alt="待框选的屏幕" />}
    {c.frame && !r && !c.drawing && c.candidate && <div className="window-candidate" style={{ left: c.candidate.bounds.x, top: c.candidate.bounds.y, width: c.candidate.bounds.width, height: c.candidate.bounds.height }}><span className="candidate-caption">{c.candidate.id === 'display' ? '当前显示器' : '窗口'} · 单击选择 / 拖动框选</span></div>}
    {r && <div className={`selection ${!c.busy && !c.tool ? 'editable' : ''}`} style={{ left: r.x, top: r.y, width: r.width, height: r.height }}>
      <span className={`dimensions ${r.y < 30 ? 'dimensions-inside' : ''}`}>{Math.round(r.width)} × {Math.round(r.height)}</span>
      {!c.tool && resizeHandles.map((handle) => <span key={handle} className={`resize-handle handle-${handle}`} data-resize={handle} />)}
    </div>}
    {children}
  </div>;
}
