import { useEffect, useRef, useState, type PointerEvent } from 'react';
import type { ActionId, CaptureSession, PublicSettings, Rect } from '../../shared/contracts';
import { adjustSelection, selection, type ResizeHandle } from '../../shared/geometry';
import { pickWindow, type DetectedWindow } from '../../shared/window-candidates';
import { screenshotTransition, type ScreenshotEvent, type ScreenshotPhase } from '../../shared/screenshot-state';
import { modeCapabilities, type CaptureMode } from '../../shared/capture-modes';
import { annotationsSchema, type Annotation, type AnnotationTool } from '../../shared/annotations';
import type { LongshotScrollMode } from '../../shared/longshot';

type Point = { x: number; y: number };
type Anchor = Point & { mode: 'draw' | 'move' | ResizeHandle; original?: Rect; candidate: Rect; dragged: boolean };
export function useScreenshotController() {
  const [session, setSession] = useState<CaptureSession | null>(null);
  const [phase, setPhase] = useState<ScreenshotPhase>('idle');
  const phaseRef = useRef<ScreenshotPhase>('idle');
  const [rect, setRect] = useState<Rect>();
  const [candidate, setCandidate] = useState<DetectedWindow>();
  const [cursor, setCursor] = useState<Point | null>(null);
  const [mode, setMode] = useState<CaptureMode>('screenshot');
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [tool, setAnnotationTool] = useState<AnnotationTool | null>(null);
  const [color, setColor] = useState('#E45454');
  const [lineWidth, setLineWidth] = useState(3);
  const [asking, setAsking] = useState(false);
  const [pendingCustomId, setPendingCustomId] = useState<string>();
  const [question, setQuestion] = useState('');
  const [more, setMore] = useState(false);
  const [error, setError] = useState('');
  const [activeAction, setActiveAction] = useState<ActionId | 'pin'>();
  const anchor = useRef<Anchor | null>(null);
  const sessionRef = useRef('');
  const actionEpoch = useRef(0);
  const [viewport, setViewport] = useState({ width: innerWidth, height: innerHeight });
  const frame = session?.frame;
  const settings: PublicSettings | undefined = session?.settings;
  const busy = phase === 'ai-processing';
  function transition(event: ScreenshotEvent) {
    phaseRef.current = screenshotTransition(phaseRef.current, event); setPhase(phaseRef.current);
  }
  function candidateAt(point: Point, content = session) {
    return pickWindow(content?.candidates ?? [], point) ?? { id: 'display', title: content?.frame.displayLabel ?? '当前显示器', bounds: { x: 0, y: 0, width: content?.frame.width ?? innerWidth, height: content?.frame.height ?? innerHeight } };
  }
  function reset() {
    actionEpoch.current++;
    anchor.current = null; setRect(undefined); setAnnotations([]); setAnnotationTool(null);
    setAsking(false); setQuestion(''); setPendingCustomId(undefined); setMore(false); setError('');
    transition('RESET');
  }
  function close() { void window.screenAI.cancelCapture().catch((e) => setError(e.message)); }
  useEffect(() => {
    const unsubscribe = window.screenAI.onCapture((content) => {
      sessionRef.current = content?.sessionId ?? '';
      actionEpoch.current++;
      anchor.current = null; setSession(content); setRect(undefined); setAnnotations([]); setAnnotationTool(null);
      setMode(content?.initialMode??'screenshot'); setAsking(false); setQuestion(''); setPendingCustomId(undefined); setMore(false); setError(''); setActiveAction(undefined);
      phaseRef.current = 'idle'; transition(content ? 'START' : 'CLOSE');
      const point = content?.cursor;
      const inside = point && point.x >= 0 && point.y >= 0 && point.x < content.frame.width && point.y < content.frame.height;
      setCursor(inside ? point : null); setCandidate(inside ? candidateAt(point, content) : undefined);
    });
    void window.screenAI.capturePrepared().catch((e) => setError(e.message));
    const escape = (event: KeyboardEvent) => { if (!event.defaultPrevented && event.key === 'Escape') close(); };
    const resize = () => setViewport({ width: innerWidth, height: innerHeight });
    window.addEventListener('keydown', escape); window.addEventListener('resize', resize);
    return () => { unsubscribe(); window.removeEventListener('keydown', escape); window.removeEventListener('resize', resize); };
  }, []);
  function point(event: PointerEvent): Point { return { x: Math.max(0, Math.min(innerWidth, event.clientX)), y: Math.max(0, Math.min(innerHeight, event.clientY)) }; }
  function isToolbar(target: EventTarget) { return (target as Element).closest('.capture-tools,.mode-toolbar,.mode-panel'); }
  function down(event: PointerEvent<HTMLDivElement>) {
    if (busy || !frame || event.button !== 0 || isToolbar(event.target) || (event.target as Element).closest('.annotation-layer')) return;
    const handle = (event.target as Element).closest<HTMLElement>('[data-resize]')?.dataset.resize as ResizeHandle | undefined;
    const operation = rect && (event.target as Element).closest('.selection') ? handle ?? 'move' : 'draw';
    if (tool && operation !== 'draw') return;
    event.currentTarget.setPointerCapture(event.pointerId);
    const p = point(event);
    anchor.current = { ...p, mode: operation, original: rect, candidate: candidateAt(p).bounds, dragged: false };
    transition('POINTER_DOWN'); setCursor(p); setError(''); setMore(false); setAsking(false);
    if (operation === 'draw') { setRect(undefined); setAnnotations([]); setAnnotationTool(null); }
  }
  function nextRect(event: PointerEvent) {
    const start = anchor.current!, current = point(event);
    if (Math.hypot(current.x - start.x, current.y - start.y) >= 4) start.dragged = true;
    return start.mode === 'draw' ? selection(start, current) : adjustSelection(start.original!, start.mode, { x: current.x - start.x, y: current.y - start.y }, { width: innerWidth, height: innerHeight });
  }
  function move(event: PointerEvent) {
    if (!frame || busy) return;
    if (isToolbar(event.target)) { setCursor(null); return; }
    const p = point(event); setCursor(p);
    if (anchor.current) {
      const next = nextRect(event);
      if (anchor.current.dragged) setRect(next);
    } else if (!rect) {
      const next = candidateAt(p);
      setCandidate((previous) => previous?.id === next.id ? previous : next);
    }
  }
  function up(event: PointerEvent<HTMLDivElement>) {
    const start = anchor.current;
    if (!start) return;
    let next = nextRect(event);
    if (!start.dragged) next = start.mode === 'draw' ? start.candidate : start.original!;
    anchor.current = null;
    const valid = next.width >= 4 && next.height >= 4;
    setRect(valid ? next : undefined); transition(valid ? 'SELECT' : 'RESET'); setCursor(null);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    // Live capture modes own their preparation/recording toolbar. Hand off the
    // completed rectangle without another options card on the frozen screen.
    if (valid && (mode === 'longshot'||mode==='record') && (session?.capabilities ?? modeCapabilities).some(item => item.mode === mode && item.available)) void startMode('manual', next,mode==='record'?{frameRate:30,countdownMs:3000,mimeType:'video/mp4;codecs=avc1.42001E',systemAudio:false,microphone:false}:undefined);
  }
  function pointerCancel() { setRect(anchor.current?.original); transition(anchor.current?.original ? 'SELECT' : 'RESET'); anchor.current = null; }
  function changeMode(next: CaptureMode) { if (busy) return; reset(); setMode(next); }
  function setTool(next: AnnotationTool | null) {
    if (busy) return;
    setAnnotationTool(next); setAsking(false); setMore(false); setCursor(null); transition(next ? 'ANNOTATE' : 'EDIT');
  }
  async function run(action: ActionId, customActionId?: string, target = rect) {
    if (!target || phaseRef.current === 'ai-processing') return;
    const needsQuestion = action === 'ask' || (action === 'custom' && !!settings?.customActions.find((item) => item.id === customActionId)?.prompt.includes('{{question}}'));
    if (needsQuestion && (!asking || pendingCustomId !== customActionId)) {
      setPendingCustomId(customActionId); setAsking(true); setAnnotationTool(null); transition('EDIT'); setMore(false); setError(''); setCursor(null); return;
    }
    if (needsQuestion && !question.trim()) { setError('先输入一个问题'); return; }
    const currentSession = sessionRef.current;
    const currentAction = ++actionEpoch.current;
    if (!rect) { setRect(target); transition('SELECT'); }
    transition('PROCESS'); setActiveAction(action); setError(''); setCursor(null);
    try { await window.screenAI.runAction({ action, rect: target, annotations: rect ? annotations : [], question: needsQuestion ? question : '', ...(action === 'custom' ? { customActionId } : {}) }); }
    catch (e) { if (sessionRef.current === currentSession && actionEpoch.current === currentAction) { setError((e as Error).message); transition('FAIL'); } }
  }
  async function pin() {
    if (!rect || busy) return;
    const currentSession = sessionRef.current;
    const currentAction = ++actionEpoch.current;
    transition('PROCESS'); setActiveAction('pin'); setError(''); setCursor(null);
    try { await window.screenAI.pinSelection({ rect, annotations }); }
    catch (e) { if (sessionRef.current === currentSession && actionEpoch.current === currentAction) { setError((e as Error).message); transition('FAIL'); } }
  }
  async function startMode(scrollMode: LongshotScrollMode = 'manual', target = rect,recordingOptions?:import('../../shared/recording/contracts').RecordingOptions) {
    if (!target || phaseRef.current === 'ai-processing') return;
    const currentSession = sessionRef.current;
    const currentAction = ++actionEpoch.current;
    transition('PROCESS'); setError('');
    try { await window.screenAI.startCaptureMode(mode, target, mode === 'longshot' ? scrollMode : undefined,recordingOptions); if (sessionRef.current === currentSession && actionEpoch.current === currentAction) transition('FAIL'); }
    catch (e) { if (sessionRef.current === currentSession && actionEpoch.current === currentAction) { setError((e as Error).message); transition('FAIL'); } }
  }
  function contextMenu(event: React.MouseEvent) {
    event.preventDefault();
    if (busy) { reset(); void window.screenAI.resetCaptureAction().catch((e) => setError(e.message)); return; }
    if (rect || phase === 'selecting') reset(); else close();
  }
  function doubleClick(event: React.MouseEvent) {
    if (!tool && !busy && rect && mode === 'screenshot' && !(event.target as Element).closest('.capture-tools')) void run('copy-image');
  }
  return { session, frame, settings, phase, rect, candidate, cursor, mode, annotations, tool, color, lineWidth, asking, pendingCustomId, question, more, error, busy, activeAction, viewport,
    capabilities: session?.capabilities ?? modeCapabilities, drawing: phase === 'selecting',
    down, move, up, pointerCancel, contextMenu, doubleClick, reset, close, changeMode, setTool, setColor, setLineWidth, setQuestion, setMore, setError, run, pin, startMode,
    commitAnnotation: (annotation: Annotation) => { if (!busy) { const next = annotationsSchema.safeParse([...annotations, annotation]); if (next.success) setAnnotations(next.data); else setError('标注内容已达到上限，请撤销或清除部分标注'); } },
    undo: () => { if (!busy) setAnnotations((previous) => previous.slice(0, -1)); }, clearAnnotations: () => { if (!busy) setAnnotations([]); },
    recognize: (wholeDisplay = false) => { if (frame) void run('analyze', undefined, wholeDisplay ? { x: 0, y: 0, width: frame.width, height: frame.height } : candidate?.bounds ?? { x: 0, y: 0, width: frame.width, height: frame.height }); },
  };
}
export type ScreenshotController = ReturnType<typeof useScreenshotController>;
