import { useEffect, useRef, useState } from 'react';
import type { PixelSample } from '../../shared/contracts';

/** Samples the retained original bitmap; JPEG preview never supplies pixel colors. */
export function MagnifierOverlay({ sessionId, point, viewport }: { sessionId: string; point: { x: number; y: number } | null; viewport: { width: number; height: number } }) {
  const [sample, setSample] = useState<PixelSample | null>(null);
  const latest = useRef(point); latest.current = point;
  useEffect(() => {
    if (!sessionId || !point) { setSample(null); return; }
    let active = true, timer: ReturnType<typeof setTimeout>;
    const update = async () => {
      const current = latest.current;
      if (!active || !current) return;
      try { const next = await window.screenAI.samplePixel(sessionId, current); if (active) setSample(next); } catch { if (active) setSample(null); }
      if (active) timer = setTimeout(() => void update(), 32);
    };
    void update();
    return () => { active = false; clearTimeout(timer); };
  }, [sessionId, !!point]);
  if (!point || !sample) return null;
  const width = 156, height = 162, gap = 26;
  const left = Math.max(8, Math.min(point.x + gap + width < viewport.width ? point.x + gap : point.x - width - gap, viewport.width - width - 8));
  const top = Math.max(8, Math.min(point.y + gap + height < viewport.height ? point.y + gap : point.y - height - gap, viewport.height - height - 8));
  return <div className="magnifier-overlay" style={{ left, top }} aria-hidden="true">
    <div className="magnifier-pixels"><img src={sample.image} draggable={false} style={{ width: sample.width * 8, height: sample.height * 8, left: 74 - (sample.center.x + .5) * 8, top: 50 - (sample.center.y + .5) * 8 }} /><i /></div>
    <div className="magnifier-meta"><span>{sample.position.x}, {sample.position.y}</span><span><i style={{ background: sample.hex }} />{sample.hex}</span><small>RGB {sample.rgb.join(', ')}</small></div>
  </div>;
}
