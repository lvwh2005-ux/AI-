import { useEffect, useRef, useState, type PointerEvent } from 'react';
import type { Rect } from '../../shared/contracts';
import { annotationGeometry, annotationSchema, normalizeAnnotationPoint, type Annotation, type AnnotationPoint, type AnnotationTool } from '../../shared/annotations';
import './annotation.css';

export interface AnnotationLayerProps {
  rect: Rect;
  annotations: Annotation[];
  tool: AnnotationTool | null;
  color: string;
  width: number;
  fontSize?: number;
  disabled?: boolean;
  onCommit(annotation: Annotation): void;
  onError?(message: string): void;
}
interface TextDraft { position: AnnotationPoint; value: string }

export function AnnotationLayer({ rect, annotations, tool, color, width, fontSize = 20, disabled = false, onCommit, onError }: AnnotationLayerProps) {
  const [draft, setDraft] = useState<Annotation | null>(null);
  const [textDraft, setTextDraft] = useState<TextDraft | null>(null);
  const active = useRef<Annotation | null>(null);
  const editing = useRef<TextDraft | null>(null);
  const root = useRef<HTMLDivElement>(null);
  const limited = useRef(false);
  const enabled = !!tool && !disabled;

  function commit(annotation: Annotation) {
    const parsed = annotationSchema.safeParse(annotation);
    if (parsed.success) onCommit(parsed.data);
    else onError?.('标注内容无效，请调整颜色、线宽或文字后重试');
  }
  function finishText() {
    const current = editing.current;
    editing.current = null; setTextDraft(null);
    if (current?.value.trim()) commit({ id: crypto.randomUUID(), kind: 'text', color, width, fontSize, position: current.position, text: current.value });
  }
  useEffect(() => {
    active.current = null; setDraft(null); limited.current = false;
    if (!enabled) { editing.current = null; setTextDraft(null); }
  }, [tool, enabled]);

  function point(event: PointerEvent): AnnotationPoint {
    const bounds = root.current!.getBoundingClientRect();
    return normalizeAnnotationPoint({ x: event.clientX, y: event.clientY }, bounds);
  }
  function down(event: PointerEvent<SVGSVGElement>) {
    if (!enabled || event.button !== 0) return;
    event.preventDefault(); event.stopPropagation();
    const position = point(event);
    if (tool === 'text') {
      finishText();
      const next = { position, value: '' }; editing.current = next; setTextDraft(next);
      return;
    }
    const common = { id: crypto.randomUUID(), color, width };
    const annotation: Annotation = tool === 'pen' ? { ...common, kind: 'pen', points: [position] } : { ...common, kind: tool as 'arrow' | 'rectangle', start: position, end: position };
    active.current = annotation; setDraft(annotation); limited.current = false;
    event.currentTarget.setPointerCapture(event.pointerId);
  }
  function update(event: PointerEvent): Annotation | null {
    const previous = active.current;
    if (!previous || previous.kind === 'text') return null;
    const position = point(event);
    let next: Annotation;
    if (previous.kind === 'pen') {
      const last = previous.points.at(-1)!;
      if (Math.hypot((position.x - last.x) * rect.width, (position.y - last.y) * rect.height) < 0.8) return previous;
      if (previous.points.length >= 4000) {
        if (!limited.current) onError?.('这一笔已达到长度上限，松开鼠标后可继续绘制');
        limited.current = true; return previous;
      }
      next = { ...previous, points: [...previous.points, position] };
    } else next = { ...previous, end: position };
    active.current = next; setDraft(next); return next;
  }
  function move(event: PointerEvent<SVGSVGElement>) {
    if (!active.current) return;
    event.preventDefault(); event.stopPropagation(); update(event);
  }
  function up(event: PointerEvent<SVGSVGElement>) {
    if (!active.current) return;
    event.preventDefault(); event.stopPropagation();
    const final = update(event);
    active.current = null; setDraft(null);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
    if (!final) return;
    if (final.kind === 'arrow' || final.kind === 'rectangle') {
      const dx = Math.abs(final.end.x - final.start.x) * rect.width, dy = Math.abs(final.end.y - final.start.y) * rect.height;
      if (final.kind === 'arrow' ? Math.hypot(dx, dy) < 2 : dx < 2 || dy < 2) return;
    }
    commit(final);
  }
  const all = draft ? [...annotations, draft] : annotations;
  return <div ref={root} className={`annotation-layer ${enabled ? 'is-drawing' : ''}`} style={{ left: rect.x, top: rect.y, width: rect.width, height: rect.height }} data-annotation-tool={tool ?? undefined}>
    <svg className="annotation-canvas" viewBox={`0 0 ${rect.width} ${rect.height}`} preserveAspectRatio="none" aria-label={enabled ? '截图标注区域' : '截图标注'} style={{ pointerEvents: enabled ? 'auto' : 'none', cursor: tool === 'text' ? 'text' : 'crosshair' }} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={(event) => { event.stopPropagation(); active.current = null; setDraft(null); }}>
      {all.map((annotation) => {
        const shape = annotationGeometry(annotation, rect);
        return <g key={annotation.id} stroke={annotation.color} strokeWidth={annotation.width} strokeLinecap="round" strokeLinejoin="round" fill="none" pointerEvents="none">
          {shape.paths.map((points, index) => <polyline key={index} points={points.map(({ x, y }) => `${x},${y}`).join(' ')} />)}
          {shape.dots?.map((position, index) => <circle key={index} cx={position.x} cy={position.y} r={annotation.width / 2} fill={annotation.color} stroke="none" />)}
          {shape.text && <text x={shape.text.position.x} y={shape.text.position.y + shape.text.fontSize} fontFamily='"Segoe UI", "Microsoft YaHei", sans-serif' fontSize={shape.text.fontSize} fill={annotation.color} stroke="none">{shape.text.lines.map((line, index) => <tspan key={index} x={shape.text!.position.x} dy={index ? shape.text!.fontSize * 1.35 : 0}>{line || '\u00a0'}</tspan>)}</text>}
        </g>;
      })}
    </svg>
    {textDraft && enabled && <textarea className="annotation-text-input" autoFocus aria-label="标注文字" placeholder="输入文字，Enter 完成" maxLength={1000} value={textDraft.value} style={{ left: textDraft.position.x * rect.width, top: textDraft.position.y * rect.height, width: Math.max(32, Math.min(260, rect.width * (1 - textDraft.position.x))), color, fontSize }} onChange={(event) => { const next = { ...textDraft, value: event.target.value }; editing.current = next; setTextDraft(next); }} onPointerDown={(event) => event.stopPropagation()} onPointerUp={(event) => event.stopPropagation()} onDoubleClick={(event) => event.stopPropagation()} onKeyDown={(event) => {
      event.stopPropagation();
      if (event.key === 'Escape') { event.preventDefault(); editing.current = null; setTextDraft(null); }
      else if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); finishText(); }
    }} onBlur={finishText} />}
  </div>;
}
