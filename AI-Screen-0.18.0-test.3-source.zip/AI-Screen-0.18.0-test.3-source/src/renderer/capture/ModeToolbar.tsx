import type { ScreenshotController } from './ScreenshotController';
import { CaptureIcon } from '../components/CaptureIcon';
const labels = { screenshot: '截图', longshot: '长截图', record: '录屏', 'ai-screen': 'AI 识屏' } as const;
export function ModeToolbar({ controller: c }: { controller: ScreenshotController }) {
  const capability = c.capabilities.find((item) => item.mode === c.mode)!;
  return <div className="mode-container">
    <div className="mode-toolbar" role="toolbar" aria-label="截图模式">
      {c.capabilities.map((item) => <button key={item.mode} data-mode={item.mode} aria-pressed={c.mode === item.mode} className={c.mode === item.mode ? 'is-active' : ''} title={item.explanation} onClick={() => c.changeMode(item.mode)}><CaptureIcon name={item.mode} /><span>{labels[item.mode]}</span>{!item.available && <small>待接入</small>}</button>)}
      <i /><button className="mode-close" title="退出 · Esc" aria-label="退出截图" onClick={c.close}><CaptureIcon name="close" /></button>
    </div>
    <div className="mode-panel">
      <div className="mode-panel-heading"><CaptureIcon name={c.mode} />{labels[c.mode]}<span> / 选择屏幕内容</span></div>
      <span>{capability.explanation}</span>
      {c.mode === 'ai-screen' && <div className="recognize-actions"><button onClick={() => c.recognize()}>识别当前窗口</button><button onClick={() => c.recognize(true)}>识别当前屏幕</button><small>将选定内容发送至已配置的 AI 服务；演示模式不会联网。</small></div>}
      {c.error && <p role="alert">{c.error}</p>}
      <div className="mode-panel-shortcuts"><kbd>单击</kbd>选窗口<i /><kbd>拖动</kbd>框选<i /><kbd>Esc</kbd>退出</div>
    </div>
  </div>;
}
