import { useLayoutEffect, useRef, useState } from 'react';
import type { ActionId } from '../../shared/contracts';
import { toolbarPosition } from '../../shared/geometry';
import { annotationTools } from '../../shared/annotations';
import { CaptureIcon, type CaptureIconName } from '../components/CaptureIcon';
import type { ScreenshotController } from './ScreenshotController';

const primary: { id: ActionId; label: string }[] = [
  { id: 'copy-image', label: '复制' }, { id: 'translate', label: '翻译' },
  { id: 'analyze', label: 'AI 分析' }, { id: 'ask', label: '询问 AI' },
];
const annotationLabels = { pen: '画笔', arrow: '箭头', rectangle: '矩形', text: '文字' };
export function SelectionToolbar({ controller: c }: { controller: ScreenshotController }) {
  const ref = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ width: Math.min(550, c.viewport.width - 16), height: 44 });
  useLayoutEffect(() => {
    const node = ref.current;
    if (!node) return;
    const measure = () => { const { width, height } = node.getBoundingClientRect(); setSize((previous) => previous.width === width && previous.height === height ? previous : { width, height }); };
    measure(); const observer = new ResizeObserver(measure); observer.observe(node);
    return () => observer.disconnect();
  }, []);
  if (!c.rect) return null;
  const position = toolbarPosition(c.rect, c.viewport, size);
  function hint(action: ActionId) {
    if (action === 'copy-image') return '复制选区图片 · 双击选区';
    if (action === 'ocr' && c.settings?.ocr === 'windows') return '复制文字 · Windows 本地识别';
    try { return c.settings?.provider === 'compatible' ? `选区将发送至 ${new URL(c.settings.baseUrl).host}` : '演示模式 · 不联网'; }
    catch { return '请在设置中检查 AI 服务地址'; }
  }
  function icon(name: CaptureIconName) { return c.busy && c.activeAction === name ? <span className="tool-spinner" /> : <CaptureIcon name={name} />; }
  const longshotAvailable = c.capabilities.some(item => item.mode === 'longshot' && item.available);
  return <div ref={ref} className="capture-tools" style={position}>
    {c.mode === 'longshot' ? <div className="toolbar longshot-handoff" role="toolbar" aria-label="长截图启动状态">
      <span className="longshot-handoff-label">竖向截图</span><i className="tool-separator" />
      {c.busy ? <span className="longshot-handoff-label" role="status"><span className="tool-spinner" />正在进入…</span>
        : longshotAvailable ? <button data-action="start-mode" onClick={() => void c.startMode('manual')}>重试</button>
        : <span className="longshot-handoff-label" role="status">采集模块未接入</span>}
      <button data-action="normal-mode" disabled={c.busy} onClick={() => c.changeMode('screenshot')}>普通截图</button>
      <button data-action="reselect" disabled={c.busy} onClick={c.reset}>重选</button>
      <button className="tool-close" title="退出 · Esc" aria-label="取消截图" onClick={c.close}><CaptureIcon name="close" /></button>
    </div> : c.mode === 'record' ? <div className="toolbar" role="toolbar" aria-label="录屏准备"><span className="longshot-handoff-label">{c.busy?'正在打开录屏工具条…':'录屏准备'}</span><button data-action="start-mode" disabled={c.busy} onClick={()=>void c.startMode()}>重试</button><button disabled={c.busy} onClick={c.reset}>重选</button><button title="取消录屏" onClick={c.close}><CaptureIcon name="close"/></button></div> : <>
      <div className="toolbar" role="toolbar" aria-label="选区操作">
        {primary.map((action) => <button key={action.id} data-action={action.id} disabled={c.busy} title={hint(action.id)} aria-label={action.label} aria-expanded={action.id === 'ask' ? c.asking : undefined} className={`tool-button ${action.id === 'ask' && c.asking ? 'is-active' : ''}`} onClick={() => void c.run(action.id)}>{icon(action.id)}<span className="tool-label">{action.label}</span></button>)}
        <i className="tool-separator" />
        <button disabled={c.busy} data-action="annotate" className={c.tool ? 'is-active' : ''} title="标注截图" aria-expanded={!!c.tool} onClick={() => c.setTool(c.tool ? null : 'pen')}><CaptureIcon name="pen" /><span className="tool-label">画笔</span></button>
        <button disabled={c.busy} data-action="pin" title="固定选区到桌面 · 始终置顶" onClick={() => void c.pin()}>{icon('pin')}<span className="tool-label">固定</span></button>
        <button disabled={c.busy} data-action="more" className={c.more ? 'is-active' : ''} title="复制文字与自定义动作" aria-expanded={c.more} onClick={() => c.setMore(!c.more)}><CaptureIcon name="more" /><span className="tool-label">更多</span></button>
        <i className="tool-separator" /><button className="tool-close" title="退出 · Esc" aria-label="取消截图" onClick={c.close}><CaptureIcon name="close" /></button>
      </div>
      {c.more && <div className="more-panel"><button className="copy-ocr" data-action="ocr" disabled={c.busy} title={hint('ocr')} onClick={() => void c.run('ocr')}><CaptureIcon name="ocr" />复制文字</button>
        {c.settings?.customActions.some((item) => item.enabled) && <div className="custom-toolbar" aria-label="自定义动作">{c.settings.customActions.filter((item) => item.enabled).map((item) => <button key={item.id} disabled={c.busy} title={item.prompt} onClick={() => void c.run('custom', item.id)}><CaptureIcon name="custom" />{item.label}</button>)}</div>}
      </div>}
      {!!c.tool && <div className="annotation-toolbar" role="toolbar" aria-label="标注工具">
        {annotationTools.map((tool) => <button key={tool} data-tool={tool} aria-pressed={c.tool === tool} className={c.tool === tool ? 'is-active' : ''} title={annotationLabels[tool]} onClick={() => c.setTool(tool)}><CaptureIcon name={tool} /><span>{annotationLabels[tool]}</span></button>)}
        <i className="tool-separator" /><input type="color" aria-label="标注颜色" value={c.color} onChange={(e) => c.setColor(e.target.value.toUpperCase())} />
        <select aria-label="线宽" value={c.lineWidth} onChange={(e) => c.setLineWidth(Number(e.target.value))}><option value={2}>细</option><option value={3}>中</option><option value={6}>粗</option></select>
        <button data-tool="undo" title="撤销上一处标注" disabled={!c.annotations.length} onClick={c.undo}><CaptureIcon name="undo" /></button><button data-tool="clear" title="清除全部标注" disabled={!c.annotations.length} onClick={c.clearAnnotations}><CaptureIcon name="clear" /></button><button onClick={() => c.setTool(null)}>完成</button>
      </div>}
      {c.asking && <form className="question-bar" onSubmit={(e) => { e.preventDefault(); void c.run(c.pendingCustomId ? 'custom' : 'ask', c.pendingCustomId); }}><input key={c.pendingCustomId ?? 'ask'} autoFocus maxLength={8000} value={c.question} onChange={(e) => c.setQuestion(e.target.value)} placeholder={c.pendingCustomId ? `${c.settings?.customActions.find((item) => item.id === c.pendingCustomId)?.label}：输入补充问题…` : '针对这个选区提问…'} /><button disabled={c.busy} title="发送问题" aria-label="发送问题"><CaptureIcon name="send" /></button></form>}
    </>}
    {(c.error || (c.busy && c.mode !== 'longshot')) && <div className={`capture-feedback ${c.error ? 'has-error' : ''}`} role={c.error ? 'alert' : 'status'}>{c.error || '正在处理…'}</div>}
  </div>;
}
