import type {RecordingAudio} from '../../shared/recording/contracts';

/** One stable destination track: muting changes gain, never the recorder's track list. */
export class RecordingAudioMixer{
  private context:AudioContext;
  private destination:MediaStreamAudioDestinationNode;
  private bus:GainNode;
  private analyser:AnalyserNode;
  private probePull?:GainNode;
  private gains:{system?:GainNode;microphone?:GainNode}={};
  private nodes:MediaStreamAudioSourceNode[]=[];
  private streams:MediaStream[]=[];
  private closed=false;
  private constructor(){this.context=new AudioContext({sampleRate:48000});this.destination=this.context.createMediaStreamDestination();this.bus=this.context.createGain();this.analyser=this.context.createAnalyser();this.analyser.fftSize=8192;this.bus.connect(this.destination);this.bus.connect(this.analyser);}
  static async create(system:MediaStream|undefined,microphone:MediaStream|undefined){
    const mixer=new RecordingAudioMixer();
    try{
      for(const [key,stream]of [['system',system],['microphone',microphone]] as const){
        if(!stream)continue;
        const audio=new MediaStream(stream.getAudioTracks());if(!audio.getAudioTracks().length)throw Error(key==='system'?'没有获得系统声音音轨':'没有获得麦克风音轨');
        mixer.streams.push(audio);const source=mixer.context.createMediaStreamSource(audio),gain=mixer.context.createGain();
        source.connect(gain).connect(mixer.bus);mixer.nodes.push(source);mixer.gains[key]=gain;
      }
      await mixer.context.resume();mixer.setEnabled({systemEnabled:!!system,microphoneEnabled:!!microphone});return mixer;
    }catch(error){await mixer.dispose();throw error;}
  }
  get track(){return this.destination.stream.getAudioTracks()[0];}
  setEnabled(audio:RecordingAudio){
    const count=Number(audio.systemEnabled)+Number(audio.microphoneEnabled),level=count===2?.5:1;
    this.gains.system?.gain.setValueAtTime(audio.systemEnabled?level:0,this.context.currentTime);
    this.gains.microphone?.gain.setValueAtTime(audio.microphoneEnabled?level:0,this.context.currentTime);
  }
  /** Numeric diagnostics only; never sends raw captured audio across IPC. */
  probe(){if(!this.probePull){this.probePull=this.context.createGain();this.probePull.gain.value=0;this.analyser.connect(this.probePull).connect(this.context.destination);}const data=new Float32Array(this.analyser.fftSize);this.analyser.getFloatTimeDomainData(data);let energy=0,re=0,im=0;for(let i=0;i<data.length;i++){energy+=data[i]*data[i];re+=data[i]*Math.cos(2*Math.PI*440*i/this.context.sampleRate);im+=data[i]*Math.sin(2*Math.PI*440*i/this.context.sampleRate);}return{rms:Math.sqrt(energy/data.length),amplitude440:2*Math.hypot(re,im)/data.length};}
  async dispose(){if(this.closed)return;this.closed=true;for(const n of this.nodes)n.disconnect();for(const gain of Object.values(this.gains))gain.disconnect();this.bus.disconnect();this.analyser.disconnect();this.probePull?.disconnect();this.destination.disconnect();for(const stream of this.streams)for(const track of stream.getTracks())track.stop();this.destination.stream.getTracks().forEach(track=>track.stop());await this.context.close();}
}
