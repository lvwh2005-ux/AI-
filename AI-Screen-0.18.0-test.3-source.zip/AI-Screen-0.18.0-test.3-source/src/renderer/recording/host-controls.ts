import type{RecordingHostBridge,RecordingRequest,RecordingState,RecordingCommand,RecordingOptions}from '../../shared/recording/contracts';
import{MicrophonePreview,microphoneError}from './microphone';
const paths={grip:'M8 5h.01M8 10h.01M8 15h.01M12 5h.01M12 10h.01M12 15h.01',mic:'M10 12a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v4a3 3 0 0 0 3 3ZM4 9a6 6 0 0 0 12 0M10 15v3M7 18h6',speaker:'M9 4 5 7H2v6h3l4 3V4ZM13 7a5 5 0 0 1 0 6M15 4a9 9 0 0 1 0 12',pause:'M7 5v10M13 5v10',play:'m7 4 9 6-9 6V4Z',stop:'M5 5h10v10H5z',close:'m5 5 10 10M15 5 5 15',reselect:'M3 7V3h4M13 3h4v4M17 13v4h-4M7 17H3v-4',chevron:'m6 8 4 4 4-4',more:'M4 10h.01M10 10h.01M16 10h.01'};
function icon(name:keyof typeof paths){return `<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${paths[name]}"/></svg>`;}
export function mountRecordingControls(request:RecordingRequest,bridge:RecordingHostBridge){
  document.documentElement.dataset.ui='toolbar';document.title='AI Screen · 录屏';document.body.dataset.phase='preparing';
  document.body.innerHTML=`<main class="record-shell"><div id="record-controls" role="toolbar" aria-label="录屏工具条">
    <span class="drag-handle" title="拖动工具条">${icon('grip')}</span>
    <span class="prepare-only record-range" title="拖动工具条不会移动录制范围">${Math.round(request.target.rect.width)} × ${Math.round(request.target.rect.height)}</span>
    <select class="prepare-only" data-record-format aria-label="录像格式"><option value="mp4">MP4</option><option value="webm">WebM</option></select>
    <span class="record-only record-dot"></span><span id="record-clock" class="record-only">00:00</span><span id="record-phase" class="record-only"></span>
    <button data-control="pause" class="record-only icon-button" title="暂停 · Ctrl+Alt+Space" aria-label="暂停" hidden>${icon('pause')}</button>
    <button data-control="finish" class="record-only finish-button" title="完成 · Ctrl+Alt+Enter" hidden>${icon('stop')}<span>完成</span></button>
    <i class="divider"></i>
    <button data-audio="system" data-record-audio="system" class="icon-button audio-button" aria-label="系统声音" title="系统声音：关闭" aria-pressed="false">${icon('speaker')}<span class="off-slash"></span></button>
    <button data-audio="microphone" data-record-audio="microphone" class="icon-button audio-button" aria-label="麦克风" title="麦克风：关闭" aria-pressed="false">${icon('mic')}<span class="off-slash"></span><span class="input-level"><i></i></span></button>
    <button data-menu="audio" class="icon-button device-arrow prepare-only" aria-label="选择麦克风与检测声音" title="声音设备与检测">${icon('chevron')}</button>
    <button data-control="reselect" class="prepare-only icon-button" title="重新选择录制范围" aria-label="重新选择范围">${icon('reselect')}</button>
    <button id="prepare" class="prepare-only start-button" disabled>${icon('play')}<span>开始</span></button>
    <button data-menu="more" class="record-only icon-button" aria-label="录屏选项" title="录屏选项">${icon('more')}</button>
    <button data-control="cancel" class="prepare-only icon-button close-button" title="取消录屏 · Esc" aria-label="取消录屏">${icon('close')}</button>
  </div><section id="record-panel" hidden aria-label="声音与录屏选项">
    <div class="audio-settings"><div class="panel-heading"><strong>声音设备</strong><button id="refresh-devices" type="button">刷新设备</button></div>
    <label class="device-label" for="microphone-device">麦克风设备</label><select id="microphone-device" aria-label="麦克风设备"><option value="default">跟随系统默认麦克风</option></select>
    <div class="meter-row"><span>输入电平</span><meter id="microphone-meter" min="0" max="1" value="0" aria-label="麦克风输入电平"></meter></div>
    <p id="microphone-hint" role="status">开启麦克风后可检测输入；检测声音不会保存。</p></div>
    <p id="audio-note">系统声音录制电脑播放的声音；麦克风录制你的声音。</p>
    <p id="status" role="status"></p><div class="record-only menu-actions"><button data-control="cancel" class="discard-button">放弃本次录像</button></div>
  </section></main>`;
  const element=<T extends HTMLElement>(selector:string)=>document.querySelector<T>(selector)!;
  const start=element<HTMLButtonElement>('#prepare'),format=element<HTMLSelectElement>('[data-record-format]'),device=element<HTMLSelectElement>('#microphone-device'),panel=element<HTMLElement>('#record-panel'),hint=element<HTMLElement>('#microphone-hint');
  let options:RecordingOptions={...request.options},latest:RecordingState|undefined,committed=false,busy=false,revision=0,expanded=false,disposed=false,hasSignal=false;
  format.value=options.mimeType.startsWith('video/mp4')?'mp4':'webm';let preview:MicrophonePreview;
  function message(text:string){element('#status').textContent=text;}
  function panelHeight(){return Math.max(56,Math.min(284,Math.ceil(element('.record-shell').getBoundingClientRect().height+8)));}
  function showPanel(show:boolean){expanded=show;panel.hidden=!show;void bridge.layout(request.id,{expanded:show,...(show?{height:panelHeight()}:{})}).catch(()=>{});}
  const panelObserver=new ResizeObserver(()=>{if(expanded)void bridge.layout(request.id,{height:panelHeight()}).catch(()=>{});});panelObserver.observe(element('.record-shell'));
  function render(){
    const preparing=!committed&&(!latest||latest.status==='preparing'),active=latest&&['recording','paused'].includes(latest.status),pending=busy||!!latest?.pending;
    for(const button of document.querySelectorAll<HTMLButtonElement>('[data-audio]')){
      const system=button.dataset.audio==='system',enabled=preparing?(system?options.systemAudio:options.microphone):!!(system?latest?.audio?.systemEnabled:latest?.audio?.microphoneEnabled);
      const available=preparing||!!(system?latest?.media?.audio?.systemAvailable:latest?.media?.audio?.microphoneAvailable);
      button.setAttribute('aria-pressed',String(enabled));button.disabled=!!pending||(!preparing&&!active)||!available;
      button.title=`${system?'系统声音':'麦克风'}：${!available?'本次未启用，请下次录制前开启':enabled?'开启，点击静音':'关闭，点击开启'}`;
    }
    start.disabled=!preparing||busy||(options.microphone&&!preview.ready);format.disabled=!preparing||busy;device.disabled=!preparing||busy;
    element<HTMLButtonElement>('#refresh-devices').disabled=!preparing||busy;element<HTMLButtonElement>('[data-control="reselect"]').disabled=!preparing||busy;element<HTMLElement>('.audio-settings').hidden=!preparing;
  }
  preview=new MicrophonePreview(value=>{
    element<HTMLMeterElement>('#microphone-meter').value=value;element<HTMLElement>('.input-level i').style.height=`${Math.round(value*100)}%`;
    if(value>.012&&!hasSignal){hasSignal=true;hint.textContent='已检测到麦克风输入。';hint.dataset.error='false';}
  },()=>{hint.textContent='麦克风已断开，请选择其他设备或关闭麦克风。';hint.dataset.error='true';message('设备已断开');showPanel(true);render();});
  async function refreshDevices(){
    const devices=(await navigator.mediaDevices.enumerateDevices()).filter(item=>item.kind==='audioinput'),selected=options.microphoneDeviceId??'default';device.replaceChildren(new Option('跟随系统默认麦克风','default'));
    let number=0;for(const item of devices){if(item.deviceId&&item.deviceId!=='default'&&item.deviceId!=='communications')device.add(new Option(item.label||`麦克风 ${++number}（开启后显示名称）`,item.deviceId));}
    if(selected!=='default'&&!Array.from(device.options).some(item=>item.value===selected))device.add(new Option('所选设备已断开',selected));device.value=selected;
  }
  async function saveSettings(restartMicrophone=false){
    if(committed||disposed)return;const version=++revision;busy=true;message('');if(restartMicrophone||!options.microphone)preview.stop();render();
    try{
      await bridge.configure(request.id,{...options});if(version!==revision||disposed)return;
      if(options.microphone&&restartMicrophone){
        hasSignal=false;hint.textContent='正在检查麦克风权限和设备…';hint.dataset.error='false';await preview.open(options.microphoneDeviceId);if(version!==revision||disposed)return;
        hint.textContent=hasSignal?'已检测到麦克风输入。':'麦克风已连接，暂未检测到输入；请说话并检查设备静音键。';await refreshDevices();
      }else if(!options.microphone){hint.textContent='麦克风已关闭，不会录入你的声音。';hint.dataset.error='false';}
    }catch(error){if(version===revision&&!disposed){hint.textContent=microphoneError(error);hint.dataset.error='true';message('可重新选择设备，或关闭麦克风后开始。');showPanel(true);}}
    finally{if(version===revision&&!disposed){busy=false;render();}}
  }
  format.onchange=()=>{options.mimeType=format.value==='mp4'?'video/mp4;codecs=avc1.42001E':'video/webm;codecs=vp8';void saveSettings();};
  device.onchange=()=>{options.microphoneDeviceId=device.value;options.microphone=true;void saveSettings(true);};
  element<HTMLButtonElement>('#refresh-devices').onclick=()=>{void refreshDevices().then(()=>{if(options.microphone)return saveSettings(true);}).catch(error=>message(microphoneError(error)));};
  const deviceChanged=()=>{if(!committed)void refreshDevices().catch(()=>{});};navigator.mediaDevices.addEventListener('devicechange',deviceChanged);
  for(const button of document.querySelectorAll<HTMLButtonElement>('[data-audio]'))button.onclick=()=>{
    const system=button.dataset.audio==='system';if(!committed){if(system)options.systemAudio=!options.systemAudio;else options.microphone=!options.microphone;void saveSettings(!system);return;}
    if(!latest?.audio)return;const audio={...latest.audio};if(system)audio.systemEnabled=!audio.systemEnabled;else audio.microphoneEnabled=!audio.microphoneEnabled;
    void bridge.control(request.id,'audio',audio).catch(error=>{message(error.message);showPanel(true);});
  };
  async function control(command:RecordingCommand|'reselect'){try{await bridge.control(request.id,command);}catch(error){message(error instanceof Error?error.message:'操作失败');showPanel(true);}}
  for(const button of document.querySelectorAll<HTMLButtonElement>('[data-control]'))button.onclick=()=>void control(button.dataset.control==='pause'&&latest?.status==='paused'?'resume':button.dataset.control as RecordingCommand|'reselect');
  for(const button of document.querySelectorAll<HTMLButtonElement>('[data-menu]'))button.onclick=()=>showPanel(!expanded);
  const unsubscribe=bridge.onState(state=>{
    if(state.id!==request.id||(latest&&state.sequence<=latest.sequence))return;const previous=latest;latest=state;const active=['recording','paused'].includes(state.status),seconds=Math.floor(state.elapsedMs/1000);
    document.body.dataset.phase=committed&&state.status==='preparing'?'acquiring':state.status;
    element('#record-clock').textContent=state.status==='countdown'?`00:${Math.max(1,Math.ceil((state.countdownRemainingMs??0)/1000)).toString().padStart(2,'0')}`:`${Math.floor(seconds/60).toString().padStart(2,'0')}:${(seconds%60).toString().padStart(2,'0')}`;
    element('#record-phase').textContent=state.status==='countdown'?'倒计时':state.status==='stopping'?'正在完成…':state.status==='preparing'?'正在准备…':'';element('#record-clock').title=state.status==='paused'?'已暂停':state.message??'录制时长';
    for(const button of document.querySelectorAll<HTMLButtonElement>('[data-control]')){if(['pause','finish'].includes(button.dataset.control!))button.hidden=!active;button.disabled=!!state.pending||state.status==='stopping';}
    const pause=element<HTMLButtonElement>('[data-control="pause"]');pause.innerHTML=icon(state.status==='paused'?'play':'pause');pause.title=state.status==='paused'?'继续 · Ctrl+Alt+Space':'暂停 · Ctrl+Alt+Space';pause.setAttribute('aria-label',state.status==='paused'?'继续':'暂停');
    if(state.status!==previous?.status&&state.status!=='preparing'&&expanded)showPanel(false);
    if(state.message){message(state.message);element('[data-menu="more"]').classList.toggle('has-warning',state.message.startsWith('快捷键被占用'));}render();
  });
  // Drag blank areas, handle, or clock; buttons and fields remain clickable.
  let drag:{id:number;x:number;y:number;left:number;top:number}|undefined,queued:{x:number;y:number}|undefined,moving=false;const row=element('#record-controls');
  async function moveWindow(){if(moving)return;moving=true;try{while(queued){const next=queued;queued=undefined;await bridge.layout(request.id,next);}}catch{queued=undefined;}finally{moving=false;}}
  row.onpointerdown=event=>{if(event.button!==0||(event.target as Element).closest('button,select,input'))return;event.preventDefault();row.setPointerCapture(event.pointerId);drag={id:event.pointerId,x:event.screenX,y:event.screenY,left:window.screenX,top:window.screenY};};
  row.onpointermove=event=>{if(!drag||drag.id!==event.pointerId)return;queued={x:drag.left+event.screenX-drag.x,y:drag.top+event.screenY-drag.y};void moveWindow();};
  const endDrag=(event:PointerEvent)=>{if(drag?.id===event.pointerId){drag=undefined;if(row.hasPointerCapture(event.pointerId))row.releasePointerCapture(event.pointerId);}};row.onpointerup=endDrag;row.onpointercancel=endDrag;
  const escape=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();if(expanded)showPanel(false);else void control('cancel');}};document.addEventListener('keydown',escape);
  const dispose=()=>{disposed=true;revision++;preview.stop();panelObserver.disconnect();unsubscribe();navigator.mediaDevices.removeEventListener('devicechange',deviceChanged);document.removeEventListener('keydown',escape);};window.addEventListener('beforeunload',dispose,{once:true});
  void refreshDevices().catch(()=>{});void saveSettings(options.microphone);
  return{begin(){if(busy||committed||(options.microphone&&!preview.ready))throw Error('请先完成麦克风设置，或关闭麦克风。');committed=true;request.options={...options};const microphone=preview.take();showPanel(false);document.body.dataset.phase='acquiring';render();return{options:{...options},microphone};}};
}
