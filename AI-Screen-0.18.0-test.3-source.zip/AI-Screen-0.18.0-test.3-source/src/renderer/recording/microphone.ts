export function microphoneError(error:unknown){
  const name=error instanceof Error?error.name:'';
  if(name==='NotAllowedError'||name==='SecurityError')return '麦克风权限被拒绝，请检查 Windows 麦克风隐私设置，或关闭麦克风后录制。';
  if(name==='NotFoundError')return '没有找到麦克风，请连接设备后刷新。';
  if(name==='OverconstrainedError')return '所选麦克风已不可用，请重新选择设备。';
  if(name==='NotReadableError'||name==='AbortError')return '无法读取麦克风，设备可能被独占或已断开，请重试。';
  return error instanceof Error?error.message:'麦克风检测失败，请重试。';
}
/** User-enabled local meter. No samples leave this renderer. */
export class MicrophonePreview{
  private stream?:MediaStream;private context?:AudioContext;private frame?:number;private generation=0;
  constructor(private level:(value:number)=>void,private ended:()=>void){}
  get ready(){return !!this.stream?.getAudioTracks().some(track=>track.readyState==='live');}
  async open(deviceId?:string){
    this.stop();const generation=this.generation;
    const stream=await navigator.mediaDevices.getUserMedia({video:false,audio:{...(deviceId&&deviceId!=='default'?{deviceId:{exact:deviceId}}:{}),echoCancellation:false,noiseSuppression:false,autoGainControl:false}});
    if(generation!==this.generation){stream.getTracks().forEach(track=>track.stop());return;}
    this.stream=stream;
    try{
      const context=this.context=new AudioContext(),source=context.createMediaStreamSource(stream),analyser=context.createAnalyser(),silent=context.createGain();
      analyser.fftSize=1024;silent.gain.value=0;source.connect(analyser).connect(silent).connect(context.destination);await context.resume();
      if(generation!==this.generation)return;
      const data=new Float32Array(analyser.fftSize);
      const tick=()=>{if(generation!==this.generation)return;analyser.getFloatTimeDomainData(data);let sum=0;for(const value of data)sum+=value*value;this.level(Math.min(1,Math.sqrt(sum/data.length)*5));this.frame=requestAnimationFrame(tick);};tick();
      for(const track of stream.getAudioTracks())track.onended=()=>{if(generation===this.generation){this.stop();this.ended();}};
    }catch(error){this.stop();throw error;}
  }
  take(){const stream=this.stream;this.stream=undefined;this.clearMeter();this.generation++;return stream;}
  stop(){this.generation++;this.stream?.getTracks().forEach(track=>{track.onended=null;track.stop();});this.stream=undefined;this.clearMeter();}
  private clearMeter(){if(this.frame!==undefined)cancelAnimationFrame(this.frame);this.frame=undefined;void this.context?.close().catch(()=>{});this.context=undefined;this.level(0);}
}
