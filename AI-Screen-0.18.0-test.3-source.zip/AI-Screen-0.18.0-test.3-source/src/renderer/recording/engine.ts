import { RECORDING_LIMITS, recordingRequestSchema, type RecordingHostBridge, type RecordingRequest, type RecordingStats, type HostCommand } from '../../shared/recording/contracts';
import { recordingPixelRect } from '../../shared/recording/geometry';
import {RecordingAudioMixer} from './audio';
import {mountRecordingControls} from './host-controls';
import {RECORDING_MIMES,recordingMime} from '../../shared/recording/format';

declare global { interface Window { recordingHost: RecordingHostBridge; } }
const bridge = window.recordingHost;
let request: RecordingRequest;
let source: MediaStream | undefined, output: MediaStream | undefined, video: HTMLVideoElement | undefined, canvas: HTMLCanvasElement | undefined;
let recorder: MediaRecorder | undefined, frameCallback: number | undefined;
let microphone:MediaStream|undefined,mixer:RecordingAudioMixer|undefined;
let controls:ReturnType<typeof mountRecordingControls>|undefined;
let disposed = false, failed = false, expectedEnd = false, pumping = false, capturing = false;
let pendingBytes = 0, pendingChunks = 0, nextSequence = 0;
const queue: { sequence: number; blob: Blob }[] = [];
const stats: RecordingStats = { frames: 0, chunks: 0, bytes: 0, pendingPeakBytes: 0, pendingPeakChunks: 0 };
const waiters: { resolve(): void; reject(error: Error): void }[] = [];
const status = (message: string) => { document.getElementById('status')!.textContent = message; };

function release() {
  disposed = true; capturing = false; expectedEnd = true;
  if (video && frameCallback !== undefined) video.cancelVideoFrameCallback(frameCallback);
  for (const track of source?.getTracks() ?? []) track.stop();
  for (const track of output?.getTracks() ?? []) track.stop();
  for(const track of microphone?.getTracks()??[])track.stop();void mixer?.dispose();
  video?.pause(); if (video) video.srcObject = null;
  video?.remove(); canvas?.remove(); queue.length = 0;
}
async function fail(error: unknown, code = 'media-failed') {
  if (failed || disposed) return;
  failed = true; const message = error instanceof Error ? error.message : String(error);
  status(message);
  if (recorder && recorder.state !== 'inactive') { expectedEnd = true; recorder.stop(); }
  release();
  for (const waiter of waiters.splice(0)) waiter.reject(new Error(message));
  await bridge.event({ id: request.id, type: 'failed', code, message: message.slice(0,400) }).catch(() => {});
}
function drained() {
  if (failed) return Promise.reject(new Error('录屏数据传输失败'));
  if (!pumping && !queue.length) return Promise.resolve();
  return new Promise<void>((resolve,reject) => waiters.push({resolve,reject}));
}
async function pump() {
  if (pumping) return; pumping = true;
  try {
    while (queue.length && !disposed) {
      const item = queue.shift()!;
      // Blob reservation remains counted until IPC/disk acknowledgement.
      const data = await item.blob.arrayBuffer();
      await bridge.chunk(request.id, item.sequence, data);
      pendingBytes -= item.blob.size; pendingChunks--;
    }
  } catch (error) { await fail(error, 'io-failed'); }
  finally { pumping = false; for (const waiter of waiters.splice(0)) failed ? waiter.reject(new Error('视频传输失败')) : waiter.resolve(); }
}
function enqueue(blob: Blob) {
  if (!blob.size || disposed || failed) return;
  if (blob.size > RECORDING_LIMITS.maxChunkBytes || pendingChunks >= RECORDING_LIMITS.maxPendingChunks || pendingBytes + blob.size > RECORDING_LIMITS.maxPendingBytes) {
    void fail(new Error('视频数据超过有界写入预算'), 'backpressure'); return;
  }
  pendingBytes += blob.size; pendingChunks++;
  stats.pendingPeakBytes = Math.max(stats.pendingPeakBytes, pendingBytes); stats.pendingPeakChunks = Math.max(stats.pendingPeakChunks,pendingChunks);
  stats.chunks++; stats.bytes += blob.size;
  queue.push({ sequence: nextSequence++, blob }); void pump();
}
async function prepare() {
  const button = document.getElementById('prepare') as HTMLButtonElement;
  button.disabled = true; status('正在读取所选显示器…');
  try {
    const selected=controls?.begin();if(selected){request.options=selected.options;microphone=selected.microphone;}
    const audio:MediaTrackConstraints&{restrictOwnAudio:boolean}={echoCancellation:false,noiseSuppression:false,autoGainControl:false,restrictOwnAudio:false};
    const acquired = await navigator.mediaDevices.getDisplayMedia({ audio: request.options.systemAudio?audio:false, video: { frameRate: { ideal: request.options.frameRate, max: request.options.frameRate }, width: { ideal: Math.round(request.target.displayBounds.width*request.target.scaleFactor) }, height: { ideal: Math.round(request.target.displayBounds.height*request.target.scaleFactor) } } });
    if (disposed) { acquired.getTracks().forEach(track=>track.stop()); return; }
    source = acquired;
    const track = source.getVideoTracks()[0];
    if (!track) throw new Error('没有获得屏幕视频轨');
    const interrupted=(reason:string)=>{if(!expectedEnd){if(recorder&&recorder.state!=='inactive')void bridge.event({id:request.id,type:'interrupted',reason});else void fail(new Error(reason),'source-ended');}};
    track.onended = () => interrupted('所选显示器视频流已结束，已保留有效录像');
    if(request.options.systemAudio&&!source.getAudioTracks().length)throw new Error('当前设备没有返回系统声音，请关闭系统声后重试');
    if(request.options.microphone&&!microphone){
      const mic=await navigator.mediaDevices.getUserMedia({audio:{...(request.options.microphoneDeviceId&&request.options.microphoneDeviceId!=='default'?{deviceId:{exact:request.options.microphoneDeviceId}}:{}),echoCancellation:false,noiseSuppression:false,autoGainControl:false},video:false});
      if(disposed){mic.getTracks().forEach(t=>t.stop());return;}microphone=mic;
    }
    for(const t of [...source.getAudioTracks(),...(microphone?.getAudioTracks()??[])])t.onended=()=>interrupted('声音设备已断开，已保留有效录像');
    video = document.createElement('video'); video.muted = true; video.srcObject = source; document.body.append(video); await video.play();
    if (disposed) return;
    const roi = recordingPixelRect(request.target, { width: video.videoWidth, height: video.videoHeight });
    const align = request.options.mimeType.startsWith('video/mp4') ? 2 : 1;
    canvas = document.createElement('canvas'); canvas.width = Math.ceil(roi.width/align)*align; canvas.height = Math.ceil(roi.height/align)*align; document.body.append(canvas);
    const context = canvas.getContext('2d', { alpha: false })!;
    const sourceWidth = video.videoWidth, sourceHeight = video.videoHeight;
    const draw = () => {
      if (disposed || failed) return;
      if (video!.videoWidth !== sourceWidth || video!.videoHeight !== sourceHeight) { interrupted('显示器尺寸发生变化，已保留有效录像'); return; }
      context.drawImage(video!, roi.x,roi.y,roi.width,roi.height,0,0,roi.width,roi.height);
      if (capturing) stats.frames++;
      frameCallback = video!.requestVideoFrameCallback(draw);
    };
    draw(); output = canvas.captureStream(request.options.frameRate);
    if(request.options.systemAudio||request.options.microphone){mixer=await RecordingAudioMixer.create(request.options.systemAudio?source:undefined,microphone);if(disposed){await mixer.dispose();return;}output.addTrack(mixer.track);}
    const codecs = Object.fromEntries(RECORDING_MIMES.flatMap(type=>[type,recordingMime({mimeType:type},true)]).map(type => [type,MediaRecorder.isTypeSupported(type)]));
    if (!codecs[request.options.mimeType]) throw new Error(`当前运行时不支持 ${request.options.mimeType}`);
    const mimeType=recordingMime(request.options,output.getAudioTracks().length>0);
    if(!MediaRecorder.isTypeSupported(mimeType))throw new Error('当前编码器不支持所选格式与声音组合，请重选 WebM 或关闭声音后重试');
    recorder = new MediaRecorder(output, { mimeType, videoBitsPerSecond: 6_000_000,audioBitsPerSecond:128000 });
    recorder.ondataavailable = e => enqueue(e.data);
    recorder.onerror = () => { void fail(new Error('视频编码器发生错误'), 'encoder-failed'); };
    recorder.onstart = () => { capturing = true; status('正在录制所选范围'); void bridge.event({ id: request.id, type: 'started' }); };
    recorder.onpause = () => { capturing = false; void bridge.event({ id: request.id, type: 'paused' }); };
    recorder.onresume = () => { capturing = true; void bridge.event({ id: request.id, type: 'resumed' }); };
    recorder.onstop = async () => {
      capturing = false;
      try { await drained(); if (!disposed && !failed) { release(); await bridge.event({ id: request.id, type: 'stopped', stats }); status('录制已结束'); } }
      catch (error) { await fail(error, 'io-failed'); }
    };
    await bridge.event({ id: request.id, type: 'prepared', media: { mimeType: recorder.mimeType, width: canvas.width, height: canvas.height, sourceWidth, sourceHeight, sourceFrameRate: track.getSettings().frameRate ?? 0, codecs, crop: roi, padding: {right:canvas.width-roi.width,bottom:canvas.height-roi.height},audio:{systemAvailable:source.getAudioTracks().length>0,microphoneAvailable:!!microphone?.getAudioTracks().length},options:request.options } });
    status('媒体就绪，等待录制命令');
  } catch (error) { await fail(error, error instanceof DOMException && error.name === 'NotAllowedError' ? 'permission-denied' : 'media-failed'); }
}
function command(input: HostCommand) {
  if (input.id !== request?.id) return;
  try {
    if (input.command === 'dispose') {
      expectedEnd = true; if (recorder && recorder.state !== 'inactive') recorder.stop(); release();
      void bridge.event({ id: request.id, type: 'released' }); return;
    }
    if (!recorder || disposed || failed) throw new Error('媒体宿主未就绪');
    if (input.command === 'start') recorder.start(RECORDING_LIMITS.chunkMs);
    if (input.command === 'pause') recorder.pause();
    if (input.command === 'resume') recorder.resume();
    if (input.command === 'stop') { capturing = false; expectedEnd = true; recorder.stop(); }
    if(input.command==='audio'){if(!mixer||!input.audio)throw new Error('没有可控制的声音轨');mixer.setEnabled(input.audio);void bridge.event({id:request.id,type:'audio-updated'});}
    if(input.command==='probe-audio'){if(!mixer)throw new Error('没有可检测的声音轨');void bridge.event({id:request.id,type:'audio-probe',...mixer.probe()});}
  } catch (error) { void fail(error); }
}
bridge.onCommand(command);
void bridge.config().then(value => {
  request = recordingRequestSchema.parse(value);
  if(request.ui==='toolbar')controls=mountRecordingControls(request,bridge);
  const button = document.getElementById('prepare') as HTMLButtonElement;if(request.ui!=='toolbar')button.disabled = false;
  button.addEventListener('click', () => { void prepare(); }, { once: true }); status(request.ui==='toolbar'?'点击开始后倒计时 3 秒':'等待点击开始实验');
}).catch(error => { status(error instanceof Error ? error.message : '配置无效'); });
window.addEventListener('beforeunload', release, { once: true });
