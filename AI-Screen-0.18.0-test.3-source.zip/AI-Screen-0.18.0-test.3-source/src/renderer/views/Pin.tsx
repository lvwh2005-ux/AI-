import { useCallback, useEffect, useRef, useState } from 'react';
import type { PinCommand, PinState } from '../../shared/pin';
import '../pin.css';

export function Pin() {
  const [pin, setPin] = useState<PinState | null>(null);
  const [error, setError] = useState('');
  const revision = useRef(0);
  const refresh = useCallback(async () => {
    const current = ++revision.current;
    try {
      const value = await window.screenAI.getPin();
      if (current === revision.current) setPin(value);
    } catch (failure) {
      if (current === revision.current) setError(failure instanceof Error ? failure.message : '无法加载贴图');
    }
  }, []);
  const command = useCallback(async (action: PinCommand) => {
    const current = ++revision.current;
    try {
      const value = await window.screenAI.controlPin(action);
      if (current === revision.current) { setPin(value); setError(''); }
    } catch (failure) {
      if (current === revision.current) setError(failure instanceof Error ? failure.message : '贴图操作失败');
    }
  }, []);
  useEffect(() => {
    void refresh();
    let resizeFrame = 0;
    const resize = () => {
      cancelAnimationFrame(resizeFrame);
      resizeFrame = requestAnimationFrame(() => { void refresh(); });
    };
    const keys = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); void command('close'); }
      else if (event.key === '+' || event.key === '=') { event.preventDefault(); void command('zoom-in'); }
      else if (event.key === '-') { event.preventDefault(); void command('zoom-out'); }
      else if (event.key === '0') { event.preventDefault(); void command('reset'); }
    };
    window.addEventListener('resize', resize);
    window.addEventListener('keydown', keys);
    return () => {
      revision.current++;
      cancelAnimationFrame(resizeFrame);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', keys);
    };
  }, [command, refresh]);

  return <main className="pin-window" aria-label="置顶贴图">
    {pin && <img className="pin-image" src={pin.image} alt="固定到桌面的截图" draggable={false}
      style={pin.originalSize ? { width: pin.originalSize.width * pin.zoom, height: pin.originalSize.height * pin.zoom } : undefined} />}
    <div className="pin-controls" role="toolbar" aria-label="贴图操作">
      <span className="pin-drag-handle" title="拖动移动贴图" aria-hidden="true">⠿</span>
      <div className="pin-zoom-controls">
        <button type="button" title="缩小（-）" aria-label="缩小" onClick={() => { void command('zoom-out'); }}>−</button>
        <button className="pin-zoom-label" type="button" title="恢复原尺寸（0 或双击）" onClick={() => { void command('reset'); }} onDoubleClick={() => { void command('reset'); }}>{Math.round((pin?.zoom ?? 1) * 100)}%</button>
        <button type="button" title="放大（+）" aria-label="放大" onClick={() => { void command('zoom-in'); }}>+</button>
      </div>
      <button className="pin-close" type="button" title="关闭贴图（Esc）" aria-label="关闭贴图" onClick={() => { void command('close'); }}>×</button>
    </div>
    {error && <div className="pin-error" role="alert">{error}</div>}
  </main>;
}
