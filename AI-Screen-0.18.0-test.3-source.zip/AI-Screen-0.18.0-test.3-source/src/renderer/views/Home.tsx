import { useEffect, useRef, useState, type FormEvent } from 'react';
import type { PublicSettings, SettingsInput } from '../../shared/contracts';
import type { CaptureMode } from '../../shared/capture-modes';
import { ShortcutRecorder } from '../components/ShortcutRecorder';
import { CustomActionsEditor } from '../components/CustomActionsEditor';
import { CaptureIcon, type CaptureIconName } from '../components/CaptureIcon';
import appIcon from '../../../assets/icon.svg';
import '../settings-extra.css';
import '../home.css';

type Page = 'overview' | 'service' | 'preferences' | 'actions';
const navigation: { id: Page; label: string; icon: CaptureIconName; description: string }[] = [
  { id: 'overview', label: '工作台', icon: 'dashboard', description: '从屏幕开始，让灵感与工作更进一步。' },
  { id: 'service', label: 'AI 服务', icon: 'analyze', description: '连接你常用的模型，让屏幕内容成为对话的起点。' },
  { id: 'preferences', label: '操作偏好', icon: 'settings', description: '让快捷键、语言和文字识别适合你的习惯。' },
  { id: 'actions', label: '自定义动作', icon: 'custom', description: '把常用提示词保存成动作，框选后即可使用。' },
];
const tools: { mode: CaptureMode; title: string; description: string; detail: string; tag: string }[] = [
  { mode: 'screenshot', title: '截图', description: '随手框选，精准表达', detail: '复制图片 · 文字识别 · 标注贴图', tag: '日常常用' },
  { mode: 'longshot', title: '长截图', description: '滚动内容，完整留存', detail: '滚动拼接 · 原图预览 · PNG 导出', tag: '内容收集' },
  { mode: 'record', title: '录像', description: '记录操作，也记录声音', detail: '区域录制 · 声音控制 · MP4 / WebM', tag: '演示记录' },
  { mode: 'ai-screen', title: 'AI 识屏', description: '屏幕上的问题，交给 AI', detail: '图像分析 · 翻译理解 · 连续追问', tag: '智能助手' },
];

export function Home() {
  const [page, setPage] = useState<Page>('overview');
  const [settings, setSettings] = useState<PublicSettings>();
  const [form, setForm] = useState<SettingsInput>();
  const [apiKey, setApiKey] = useState('');
  const [clearKey, setClearKey] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(false);
  const [launching, setLaunching] = useState(false);
  const [recordingShortcut, setRecordingShortcut] = useState(false);
  const content = useRef<HTMLDivElement>(null);
  useEffect(() => { window.screenAI.getSettings().then((value) => { setSettings(value); setForm(value); }).catch((e) => setError(e.message)); }, []);
  useEffect(() => { content.current?.scrollTo(0, 0); }, [page]);
  const update = (key: keyof SettingsInput, value: string) => setForm((prev) => prev && ({ ...prev, [key]: value }));
  const dirty = !!settings && !!form && (JSON.stringify(form) !== JSON.stringify(settings) || !!apiKey || clearKey);
  const locked = busy || testing || recordingShortcut || launching;
  async function launch(mode: CaptureMode = 'screenshot') {
    if (locked) return;
    setLaunching(true); setError('');
    try { await window.screenAI.startCapture(mode); }
    catch (e) { setError((e as Error).message); }
    finally { setLaunching(false); }
  }
  async function save(event: FormEvent) {
    event.preventDefault(); if (!form || locked) return;
    setBusy(true); setError(''); setMessage('');
    try {
      const value = await window.screenAI.saveSettings({ ...form, apiKey: apiKey || undefined, clearApiKey: clearKey });
      setSettings(value); setForm(value); setApiKey(''); setClearKey(false); setMessage('设置已保存，快捷键已生效。');
    } catch (e) { setError((e as Error).message); }
    finally { setBusy(false); }
  }
  async function testService() {
    if (!form || locked) return;
    setTesting(true); setError(''); setMessage('');
    try {
      const result = await window.screenAI.testService({ ...form, apiKey: apiKey || undefined, clearApiKey: clearKey });
      setMessage(`${result.message} 耗时 ${(result.elapsedMs / 1000).toFixed(1)} 秒。`);
    } catch (e) { setError((e as Error).message); }
    finally { setTesting(false); }
  }
  const current = navigation.find(item => item.id === page)!;
  const shortcutLabel = (settings?.shortcut ?? 'Alt+A').replace('Control', 'Ctrl');
  return <div className="home">
    <aside className="home-sidebar">
      <div className="home-brand"><span className="home-brand-mark"><img src={appIcon} alt="" /></span><div><strong>AI Screen</strong><small>你的屏幕工作伙伴</small></div></div>
      <button type="button" className="primary capture-button" disabled={locked} onClick={() => void launch()}><CaptureIcon name="screenshot" /><span>{launching ? '正在打开…' : '开始截图'}</span><kbd title={settings?.shortcut ?? 'Alt+A'}>{shortcutLabel}</kbd></button>
      <span className="home-nav-caption">工作空间</span>
      <nav className="home-navigation" aria-label="主导航">{navigation.map(item => <button type="button" key={item.id} data-home-page={item.id} aria-current={page === item.id ? 'page' : undefined} disabled={recordingShortcut} onClick={() => setPage(item.id)}><CaptureIcon name={item.icon} /><span>{item.label}</span>{item.id === 'service' && <i className={settings?.provider === 'compatible' ? 'configured' : ''} title={settings?.provider === 'compatible' ? '已配置 API 模式' : '演示模式'} />}</button>)}</nav>
      <div className="home-sidebar-bottom"><div className="home-local-note"><CaptureIcon name="shield" /><div><strong>由你掌控屏幕内容</strong><p>仅在执行 AI 操作时发送选区。</p></div></div><div className="home-version"><span>AI Screen</span><span>v{__APP_VERSION__}</span></div></div>
    </aside>
    <main className="home-main">
      {form ? <form className="home-settings-form" onSubmit={save} noValidate>
        <div className="home-content" ref={content}>
          <header className="home-page-title"><div><div className="home-eyebrow">AI SCREEN / {page === 'overview' ? 'WORKSPACE' : 'SETTINGS'}</div><h1>{current.label}</h1><p>{current.description}</p></div><span className={`home-mode ${settings?.provider === 'compatible' ? 'is-configured' : ''}`}><i />{settings?.provider === 'compatible' ? 'API 模式' : '演示模式'}</span></header>
          <div hidden={page !== 'overview'} className="home-overview">
            <section className="home-hero"><div className="home-hero-copy"><span className="home-hero-kicker"><CaptureIcon name="analyze" />捕捉屏幕，连接灵感</span><h2>看见的，都能成为<br />下一步的开始。</h2><p>截图、收集、记录，再交给 AI 理解。<br />让每一次框选，都更有用。</p><button type="button" disabled={locked} onClick={() => void launch()}><CaptureIcon name="screenshot" />框选屏幕<CaptureIcon name="send" /></button></div><div className="home-hero-art" aria-hidden="true"><div className="hero-window"><div className="hero-window-bar"><i /><i /><i /><span>SCREEN / SELECT</span></div><div className="hero-window-content"><div className="hero-document"><i /><i /><i /><div /><i /><i /></div><div className="hero-selection"><b /><b /><b /><b /><CaptureIcon name="analyze" /><span>发现更多可能</span></div></div></div><div className="hero-float"><CaptureIcon name="check" /><span>灵感，已捕捉</span><CaptureIcon name="custom" /></div></div></section>
            <div className="home-section-heading"><h2>选择一种开始方式</h2><span>四种工具，一个工作流</span></div>
            <div className="home-tool-grid">{tools.map(tool => <button type="button" key={tool.mode} data-launch-mode={tool.mode} className={`home-tool-card tool-${tool.mode}`} disabled={locked} onClick={() => void launch(tool.mode)}><div className="home-tool-top"><span className="home-tool-icon"><CaptureIcon name={tool.mode} /></span><span className="home-tool-tag">{tool.tag}</span></div><h3>{tool.title}<CaptureIcon name="send" /></h3><p>{tool.description}</p><small>{tool.detail}</small></button>)}</div>
            <section className="home-workflow"><div className="home-section-heading"><h2>三步，完成一次屏幕工作</h2><span>随时按 <kbd>Esc</kbd> 退出</span></div><div className="home-steps">{[['唤起工具', `点击功能入口，或按 ${settings?.shortcut ?? 'Alt+A'}`], ['选择内容', '单击选窗口，拖动框选所需区域'], ['完成操作', '复制、标注、保存，或交给 AI']].map(([title, description], index) => <div key={title}><b>0{index + 1}</b><span><strong>{title}</strong><small>{description}</small></span></div>)}</div></section>
            <button type="button" className="home-service-banner" onClick={() => setPage('service')}><span className="home-service-banner-icon"><CaptureIcon name="ai-screen" /></span><span><strong>{settings?.provider === 'compatible' ? 'AI 服务已配置' : '让 AI 读懂你的屏幕'}</strong><small>{settings?.provider === 'compatible' ? `${settings.model} · 查看或调整服务配置` : '当前为演示模式。连接视觉模型后，即可翻译、分析和追问。'}</small></span><CaptureIcon name="send" /></button>
          </div>
          <div hidden={page !== 'service'} className="home-settings-page">
            <section className="home-group" aria-labelledby="service-heading"><div className="home-group-heading"><span className="home-section-icon"><CaptureIcon name="analyze" /></span><div><h2 id="service-heading">连接 AI 服务</h2><p>使用兼容 Chat Completions 的视觉模型</p></div><span className="home-section-number">01</span></div>
              <div className="home-field-grid"><label className="home-full-width">服务类型<select value={form.provider} onChange={(e) => update('provider', e.target.value)}><option value="demo">演示模式 · 无需 API Key</option><option value="compatible">兼容 Chat Completions API</option></select></label><label className="home-full-width">API 根地址<input type="url" value={form.baseUrl} onChange={(e) => update('baseUrl', e.target.value)} placeholder="https://api.example.com/v1" required /><span className="field-hint">填写根地址，无需附加 /chat/completions</span></label><label className="home-full-width">视觉模型<input value={form.model} onChange={(e) => update('model', e.target.value)} placeholder="填写支持图片输入的模型名称" required={form.provider === 'compatible'} /></label><label className="home-full-width home-key-field">API Key <span>{settings?.hasApiKey ? '已加密保存 · 留空保持' : '本地免密服务可留空'}</span><input type="password" autoComplete="off" spellCheck={false} value={apiKey} onChange={(e) => { setApiKey(e.target.value); if (e.target.value) setClearKey(false); }} placeholder={settings?.hasApiKey ? '••••••••••••••••' : '输入服务商密钥'} /></label></div>
              {settings?.hasApiKey && <label className="check home-clear-key"><input type="checkbox" checked={clearKey} onChange={(e) => { setClearKey(e.target.checked); if (e.target.checked) setApiKey(''); }} />删除已保存的密钥</label>}
              <div className="home-info-note"><CaptureIcon name="shield" /><p>{form.provider === 'demo' ? '演示模式用于体验流程，不会上传截图。' : '执行 AI 操作时，选区图片与当前对话会发送至你填写的服务。'}</p></div>
            </section>
            <section className="home-group"><div className="home-group-heading"><span className="home-section-icon"><CaptureIcon name="ask" /></span><div><h2>回复与连接测试</h2><p>确认服务能够接收图片并返回回复</p></div><span className="home-section-number">02</span></div><label className="check home-stream-toggle"><div><strong>逐步显示 AI 回复</strong><small>边生成边阅读，减少等待</small></div><input type="checkbox" checked={form.stream} onChange={(e) => setForm((prev) => prev && ({ ...prev, stream: e.target.checked }))} /></label><div className="home-test-row"><div><strong>测试当前配置</strong><p>发送内置小图片，可能产生少量 API 费用。<br />使用当前表单，保存后配置生效。</p></div><button type="button" className="service-test" disabled={locked || form.provider !== 'compatible'} onClick={() => void testService()}>{testing ? '正在测试…' : '测试服务连接'}<CaptureIcon name="send" /></button></div></section>
          </div>
          <div hidden={page !== 'preferences'} className="home-settings-page"><section className="home-group" aria-labelledby="preferences-heading"><div className="home-group-heading"><span className="home-section-icon"><CaptureIcon name="settings" /></span><div><h2 id="preferences-heading">按你的习惯工作</h2><p>保存后应用新的操作偏好</p></div></div><div className="home-preferences-grid"><ShortcutRecorder value={form.shortcut} disabled={busy || testing} onChange={(value) => update('shortcut', value)} onRecordingChange={setRecordingShortcut} onError={setError} /><label>回答语言<input value={form.language} onChange={(e) => update('language', e.target.value)} required /></label><div><label>文字识别方式<select value={form.ocr} onChange={(e) => update('ocr', e.target.value)}><option value="vision">视觉模型</option><option value="windows">Windows 本地 OCR</option></select></label><p className="field-hint">本地 OCR 可离线复制文字，语言取决于 Windows 已安装语言包。</p></div></div>{settings && !settings.shortcutActive && <p className="notice error">快捷键未注册，请更换组合后保存。</p>}</section><section className="home-preference-note"><CaptureIcon name="pin" /><div><h3>关闭窗口，工具依然在</h3><p>通过快捷键或系统托盘继续使用。截图时右键可重新选择，Esc 可直接退出。</p></div></section></div>
          <div hidden={page !== 'actions'} className="home-settings-page"><CustomActionsEditor value={form.customActions} disabled={busy || testing} onChange={(customActions) => setForm((prev) => prev && ({ ...prev, customActions }))} /></div>
        </div>
        <footer className="home-save-bar"><div className={`home-save-feedback ${error ? 'has-error' : message ? 'has-success' : ''}`}>{error ? <p role="alert">{error}</p> : message ? <p role="status"><CaptureIcon name="check" />{message}</p> : <p>{dirty ? <><i />有未保存的更改</> : <><CaptureIcon name="shield" />截图保留在内存，密钥在本机加密保存</>}</p>}</div><button className="primary save-button" disabled={locked}>{busy ? '保存中…' : dirty ? '保存更改' : '保存设置'}<CaptureIcon name="check" /></button></footer>
      </form> : <div className="home-loading">{error ? <p role="alert">{error}</p> : <><span className="spinner" />正在准备工作空间…</>}</div>}
    </main>
  </div>;
}
