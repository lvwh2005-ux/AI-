import { useLayoutEffect, useRef } from 'react';
import { useScreenshotController } from '../capture/ScreenshotController';
import { SelectionOverlay } from '../capture/SelectionOverlay';
import { SelectionToolbar } from '../capture/SelectionToolbar';
import { ModeToolbar } from '../capture/ModeToolbar';
import { AnnotationLayer } from '../capture/AnnotationLayer';
import { MagnifierOverlay } from '../capture/MagnifierOverlay';
import '../capture-extra.css';

export function Capture() {
  const c = useScreenshotController();
  const imageRef = useRef<HTMLImageElement>(null);
  useLayoutEffect(() => {
    const image = imageRef.current, sessionId = c.session?.sessionId;
    if (!c.frame || !sessionId || !image) return;
    let active = true;
    void image.decode().then(() => { if (active) void window.screenAI.captureReady(sessionId, true).catch(() => {}); })
      .catch(() => { if (active) void window.screenAI.captureReady(sessionId, false).catch(() => {}); });
    return () => { active = false; };
  }, [c.frame, c.session?.sessionId]);
  return <SelectionOverlay controller={c} imageRef={imageRef}>
    {c.frame && !c.rect && !c.drawing && <ModeToolbar controller={c} />}
    {c.rect && <AnnotationLayer key={c.session?.sessionId} rect={c.rect} annotations={c.annotations} tool={c.tool} color={c.color} width={c.lineWidth} disabled={c.busy} onCommit={c.commitAnnotation} onError={c.setError} />}
    {c.rect && !c.drawing && <SelectionToolbar controller={c} />}
    {c.frame && <MagnifierOverlay sessionId={c.session?.sessionId ?? ''} point={!c.busy && !c.tool && (!c.rect || c.drawing) ? c.cursor : null} viewport={c.viewport} />}
  </SelectionOverlay>;
}
