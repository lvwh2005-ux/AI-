import { useEffect, useState } from 'react';
import type { RecordingView } from '../../main/recording-window';
import { recordingFormat } from '../../shared/recording/format';
import { CaptureIcon } from '../components/CaptureIcon';
import '../recording.css';

export function Recording() {
  const [view, setView] = useState<RecordingView>();
  const [error, setError] = useState('');
  useEffect(() => {
    let live = true;
    const update = (next: RecordingView) => {
      if (live) setView(old => old && old.state.id === next.state.id && old.state.sequence >= next.state.sequence ? old : next);
    };
    const off = window.screenAI.onRecording(update);
    void window.screenAI.getRecording().then(value => { if (value) update(value); }).catch(e => { if (live) setError(e.message); });
    return () => { live = false; off(); };
  }, []);
  const state = view?.state;
  if (!state) return <main className="recording-result"><div className="recording-empty">{error ? <p className="error" role="alert">{error}</p> : <><span className="spinner" /><p>正在读取录像…</p></>}</div></main>;
  const busy = state.status === 'saving';
  const format = recordingFormat(state.media?.mimeType ?? 'video/mp4');
  const seconds = Math.floor(state.elapsedMs / 1000);
  const duration = `${Math.floor(seconds / 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
  async function save() {
    setError('');
    try { await window.screenAI.saveRecording(state!.id); }
    catch (e) { setError((e as Error).message); }
  }
  return <main className="recording-result">
    <header className="recording-header"><div className="recording-title"><span className="recording-brand-icon"><CaptureIcon name="record" /></span><div><span className="recording-eyebrow">AI SCREEN / RECORDING</span><h2>{state.status === 'error' ? '录屏未完成' : '你的录像已就绪'}</h2></div></div><button className="recording-close" data-recording="close" disabled={busy} onClick={() => void window.screenAI.closeRecording(state.id).catch(e => setError(e.message))}><CaptureIcon name="close" />关闭</button></header>
    <div className="recording-stage"><div className="recording-stage-bar"><span><i />录像预览</span><span>{format.label}</span></div>{view?.videoURL && state.status !== 'error' ? <video data-recording="video" controls crossOrigin="anonymous" preload="metadata" src={view.videoURL} /> : <div className="recording-empty"><CaptureIcon name="record" /><p>{state.error?.message ?? '录像尚未就绪'}</p></div>}</div>
    <section className="recording-details" aria-label="录像信息"><span><CaptureIcon name="record" />{format.label}<small>文件格式</small></span><span><CaptureIcon name="screenshot" />{state.media ? `${state.media.width} × ${state.media.height}` : '—'}<small>画面尺寸</small></span><span className="recording-duration">{duration}<small>录制时长</small></span></section>
    <footer><div className="recording-save-message">{(error || state.error?.message) && <p className="error" role="alert">{error || state.error?.message}</p>}<p className={state.savedName ? 'recording-saved' : ''} role="status">{state.savedName && <CaptureIcon name="check" />}{state.savedName ? `已保存：${state.savedName}` : state.message ?? '预览确认后，选择位置保存你的录像。'}</p></div><button className="primary" data-recording="save" disabled={busy || state.status === 'error'} onClick={() => void save()}><CaptureIcon name={state.savedName ? 'check' : 'copy-image'} />{busy ? '正在保存…' : state.savedName ? '再次另存' : `另存 ${format.label}`}</button></footer>
  </main>;
}
