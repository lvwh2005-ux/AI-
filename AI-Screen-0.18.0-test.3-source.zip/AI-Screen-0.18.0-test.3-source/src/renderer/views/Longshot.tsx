import { useState } from 'react';
import { useLongshotSession } from '../longshot/useLongshotSession';
import { CaptureToolbar } from '../longshot/CaptureToolbar';
import { LongshotResultEditor, type ResultPane } from '../longshot/ResultEditor';
import '../longshot.css';

export function Longshot() {
  const { state, pending, notice, loadError, command, refresh } = useLongshotSession();
  const [pane,setPane]=useState<ResultPane>('view');
  const message = (notice?.error ? notice.message : '') || loadError || state?.error || state?.message || '正在准备长截图…';
  const error = !!notice?.error || !!loadError || !!state?.error;
  if (state?.status !== 'done') return <CaptureToolbar state={state} pending={pending} message={message} error={error} command={command} retry={refresh} edit={()=>{setPane('annotate');void command('finish');}} share={()=>{setPane('share');void command('finish');}} />;
  return <LongshotResultEditor key={state.id} state={state} pending={pending} notice={notice} message={message} error={error} initialPane={pane} command={command}/>;
}
