import { useCallback, useEffect, useState } from 'react';
import { actions } from '../../shared/actions';
import type { AIAction, ResultState } from '../../shared/contracts';
import { CaptureIcon } from '../components/CaptureIcon';
import { MarkdownAnswer } from '../components/MarkdownAnswer';
import '../components/markdown.css';
import './result.css';

export function Result() {
  const [state, setState] = useState<ResultState | null>(null);
  const [question, setQuestion] = useState('');
  const [notice, setNotice] = useState('');
  const copyCode = useCallback((text: string) => window.screenAI.copyText(text), []);
  const openLink = useCallback((url: string) => { void window.screenAI.openExternal(url).catch((e) => setNotice(e.message)); }, []);
  useEffect(() => {
    let active = true;
    let receivedUpdate = false;
    const unsubscribe = window.screenAI.onResult((next) => { receivedUpdate = true; if (active) setState(next); });
    const progress = window.screenAI.onProgress((next) => { if (active) setState((prev) => prev?.requestId === next.requestId && prev.status === 'loading' ? { ...prev, text: next.text } : prev); });
    window.screenAI.getResult().then((initial) => { if (active && !receivedUpdate) setState(initial); }).catch((e) => { if (active) setNotice(e.message); });
    return () => { active = false; unsubscribe(); progress(); };
  }, []);
  const loading = state?.status === 'loading';
  async function run(action: AIAction, text = '', customActionId?: string) {
    setNotice('');
    try { await window.screenAI.runAction({ action, question: text, ...(action === 'custom' ? { customActionId } : {}) }); setQuestion(''); }
    catch (e) { setNotice((e as Error).message); }
  }
  return <main className="result-page">
    <header className="result-header"><div className="brand"><span className="brand-mark"><CaptureIcon name="analyze" /></span><div>AI 工作区<small>AI Screen · 看见，然后理解</small></div></div><button className="result-settings" onClick={() => void window.screenAI.openSettings().catch((e) => setNotice(e.message))}><CaptureIcon name="settings" />设置</button></header>
    {state ? <>
      <details className="result-selection">
        <summary><div className="result-preview"><img src={state.image} alt="当前处理的选区" /><span>本次对话的屏幕内容<small>点击展开截图 · 追问沿用此选区</small></span></div><span className="selection-disclosure" aria-hidden="true">⌄</span></summary>
        <div className="selection-full"><img src={state.image} alt="当前选区完整截图" /></div>
      </details>
      <section className="result-answer-card" aria-label="处理结果">
        <div className="result-meta"><h2><CaptureIcon name={state.action} />{state.actionLabel ?? actions.find((action) => action.id === state.action)?.label ?? 'AI 结果'}</h2><span className={`badge status-${state.status} ${state.demo ? 'demo' : ''}`}><i />{loading ? '正在处理' : state.status === 'error' ? '处理失败' : state.status === 'cancelled' ? '已停止' : state.source === 'local-ocr' ? '本地识别' : state.demo ? '演示结果' : '已完成'}</span></div>
        {state.demo && <p className="field-hint result-demo-note">当前为演示内容，请在设置中配置 AI 服务。</p>}
        {state.question && <div className="user-question"><small>你的问题</small><p>{state.question}</p></div>}
        <div className={`result-content ${state.status === 'error' ? 'error' : ''}`} aria-live="polite">
          {state.text && (state.action === 'ocr' || state.source === 'local-ocr' || state.status === 'error'
            ? <div className="answer">{state.text}</div>
            : <MarkdownAnswer text={state.text} onCopy={copyCode} onOpenLink={openLink} />)}
          {loading && <div className="loading"><span className="spinner" /><p>{state.text ? '正在继续输出…' : state.source === 'local-ocr' ? '正在本地识别文字…' : '正在阅读你的选区…'}<small>可随时取消</small></p></div>}
        </div>
        {state.status === 'cancelled' && <p className="field-hint">已停止处理，保留已接收的内容。</p>}
        <div className="result-actions">{loading ? <button onClick={() => void window.screenAI.cancelRequest().catch((e) => setNotice(e.message))}>取消请求</button> : <>
          <button className="primary" disabled={!state.text || state.status !== 'done'} onClick={() => void window.screenAI.copyText(state.text).then(() => setNotice('结果已复制')).catch((e) => setNotice(e.message))}><CaptureIcon name="ocr" />复制结果</button>
          {(state.status === 'error' || state.status === 'cancelled') && <button onClick={() => void run(state.action, state.question, state.customActionId)}>重试</button>}
          <button className="result-recapture" onClick={() => void window.screenAI.startCapture().catch((e) => setNotice(e.message))}><CaptureIcon name="copy-image" />重新框选</button>
        </>}</div>
      </section>
      {state.action === 'ocr' && state.status === 'done' && !state.demo && <p className="field-hint">识别出的文字已自动复制到剪贴板。</p>}
      {state.history.length > 2 && <details className="history"><summary>查看前面的对话</summary>{state.history.slice(0, -2).map((turn, i) => <div key={i}><strong>{turn.role === 'user' ? '你' : 'AI'}</strong><p>{turn.content}</p></div>)}</details>}
      <form className="followup" onSubmit={(e) => { e.preventDefault(); if (!loading && question.trim()) void run('ask', question); }}><label htmlFor="followup">继续探索这个选区</label><div><textarea id="followup" value={question} maxLength={8000} onChange={(e) => setQuestion(e.target.value)} placeholder="输入问题，让 AI 再帮你多想一步…" /><button className="primary" disabled={loading || !question.trim()}><span>发送</span><CaptureIcon name="send" /></button></div><nav className="followup-suggestions" aria-label="追问建议">{['提取重点', '翻译成中文', '解释细节'].map((label, index) => <button type="button" key={label} disabled={loading} onClick={() => { setQuestion(['请提取这个选区中的重点内容。', '请将这个选区中的内容翻译成简体中文。', '请详细解释这个选区中值得关注的细节。'][index]); document.getElementById('followup')?.focus(); }}>{label}<CaptureIcon name="send" /></button>)}</nav><p className="field-hint"><CaptureIcon name="shield" />沿用当前截图与最近对话，关闭窗口后清除会话。</p></form>
    </> : <section className="result-empty"><span><CaptureIcon name="ai-screen" /></span><h2>从一个选区开始对话</h2><p>选中屏幕内容，让 AI 帮你翻译、分析或解答。</p><button className="primary" onClick={() => void window.screenAI.startCapture('ai-screen').catch((e) => setNotice(e.message))}><CaptureIcon name="screenshot" />选择屏幕内容</button></section>}
    {notice && <p role="status" className="notice result-notice">{notice}</p>}
  </main>;
}
