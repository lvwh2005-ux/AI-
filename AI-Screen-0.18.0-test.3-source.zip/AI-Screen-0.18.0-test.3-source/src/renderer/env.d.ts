import type { ScreenBridge } from '../shared/contracts';
declare global {
  interface Window { screenAI: ScreenBridge }
  const __APP_VERSION__: string;
}
