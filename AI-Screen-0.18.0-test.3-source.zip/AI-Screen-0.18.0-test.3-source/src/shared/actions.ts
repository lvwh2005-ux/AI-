import type { ActionId } from './contracts';

// New actions start here; keep native effects and provider calls in the main process.
export const actions: { id: ActionId; label: string; icon: string; description: string }[] = [
  { id: 'copy-image', label: '复制图片', icon: '▧', description: '原样复制选区到剪贴板' },
  { id: 'ocr', label: '复制文字', icon: 'T', description: '识别并复制图片中的文字' },
  { id: 'translate', label: '翻译', icon: '文', description: '把选区内容翻译成目标语言' },
  { id: 'analyze', label: '分析', icon: '✧', description: '解释内容、代码或报错' },
  { id: 'ask', label: '询问', icon: '↗', description: '带着截图问一个自己的问题' },
];
