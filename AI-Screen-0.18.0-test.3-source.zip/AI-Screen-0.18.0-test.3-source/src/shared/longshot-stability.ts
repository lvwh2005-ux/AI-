import type {BitmapFrame} from './longshot-stitcher';
/** Bounded distributed probes distinguish geometric movement from one small
 * changing patch. This gate never authorizes a seam: the worker still verifies
 * original pixels before committing or permitting continued automatic input. */
export function stableLongshotFrame(previous:BitmapFrame,next:BitmapFrame):boolean{
  if(previous.width!==next.width||previous.height!==next.height||previous.data.length!==next.data.length||previous.data.length!==previous.width*previous.height*4||!previous.data.length)return false;
  const rows=Math.min(128,previous.height),columns=Math.min(128,previous.width);
  let changed=0,minX=previous.width,maxX=-1,minY=previous.height,maxY=-1;
  for(let y=0;y<rows;y++)for(let x=0;x<columns;x++){
    const row=Math.floor((y+.37)*previous.height/rows),column=Math.floor((x+.61)*previous.width/columns),at=(row*previous.width+column)*4;
    let difference=0;for(let c=0;c<4;c++)difference=Math.max(difference,Math.abs(previous.data[at+c]-next.data[at+c]));
    if(difference<=8)continue;
    changed++;minX=Math.min(minX,column);maxX=Math.max(maxX,column);minY=Math.min(minY,row);maxY=Math.max(maxY,row);
  }
  if(changed/(rows*columns)<=.001)return true;
  return changed/(rows*columns)<=.008&&maxX-minX+1<=Math.max(8,previous.width*.12)&&maxY-minY+1<=Math.max(16,previous.height*.18);
}
