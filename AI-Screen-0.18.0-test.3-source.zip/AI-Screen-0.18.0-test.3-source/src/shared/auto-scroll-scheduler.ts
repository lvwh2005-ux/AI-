import type {StitchResult} from './scroll-capture/types';
/** Learn physical displacement per wheel unit from verified commits. A single
 * bounded native input follows each saved stable frame; never synthesize gaps. */
export class AutoScrollScheduler {
  private pixelsPerUnit?:number;
  private minimumUnits=60;
  private settle=100;
  units(viewportHeight:number){
    if(!this.pixelsPerUnit)return 120;
    const target=Math.max(16,viewportHeight*.25);
    return Math.max(this.minimumUnits,Math.min(480,Math.floor(target/this.pixelsPerUnit/15)*15));
  }
  observe(result:StitchResult,wheelUnits:number){
    // Some native controls accumulate fractional notches. Restore whole-notch
    // input after an unchanged fractional step, before bottom detection wins.
    if(result.kind==='duplicate'&&wheelUnits<120)this.minimumUnits=120;
    const delta=result.viewportDelta??result.appendedRows;
    if(result.kind!=='appended'||result.relocated||delta<=0||wheelUnits<15||wheelUnits>480)return;
    const value=delta/wheelUnits;
    // Prefer the larger observed ratio so nonlinear pages get smaller inputs.
    this.pixelsPerUnit=this.pixelsPerUnit===undefined?value:Math.max(value,this.pixelsPerUnit*.9);
  }
  unsettled(){this.settle=Math.min(450,this.settle+40);}
  settled(){this.settle=Math.max(60,this.settle-10);}
  get settleDelayMs(){return this.settle;}
  reset(){this.pixelsPerUnit=undefined;this.minimumUnits=60;this.settle=100;}
}
