import type { PixelRegion } from './scroll-capture/types';
import type { Annotation } from './annotations';
import type { LongshotTelemetry, TelemetryUpdate } from './scroll-capture/telemetry';
import type { PreviewWindowRequest, PreviewWindowState } from './scroll-capture/preview-window';
import type { ViewportMetadata } from './scroll-capture/preview-viewport';
import type {DiagnosticEnvironment} from './scroll-capture/diagnostics';

export const longshotStatuses = ['preparing', 'capturing', 'finishing', 'done', 'cancelled', 'error'] as const;
export type LongshotStatus = typeof longshotStatuses[number];
export type LongshotScrollMode = 'auto' | 'manual';
export type CaptureBackend='gdi-roi'|'electron-snapshot';

export interface LongshotState {
  id: string;
  status: LongshotStatus;
  scrollMode: LongshotScrollMode;
  paused?: boolean;
  telemetry?: LongshotTelemetry;
  diagnosticEnvironment?:DiagnosticEnvironment;
  captureBackend?:CaptureBackend;
  /** Number of automatic scroll steps sent to the original target window. */
  scrollSteps?: number;
  /** Actual accumulated PNG dimensions in physical pixels, not preview dimensions. */
  width: number;
  height: number;
  frames: number;
  message: string;
  /** Main supplies only a reduced PNG preview. The original remains in main. */
  preview?: string;
  /** Bounded thumbnail of accepted stitched content while collecting. */
  livePreview?: string;
  /** Source coordinates of the current overview, independent of newer frames. */
  livePreviewRegion?: PixelRegion;
  /** Width-fitted last section, without squeezing the whole document vertically. */
  liveDetailPreview?: string;
  liveDetailRegion?: PixelRegion;
  liveViewport?: ViewportMetadata & {image:string};
  initialHeight?: number;
  appendedRows?: number;
  fixedTop?: number;
  fixedBottom?: number;
  regionCandidate?: PixelRegion;
  contentRect?: PixelRegion;
  sourcePixelWidth?: number;
  sourcePixelHeight?: number;
  verifiedTransitions?: number;
  lastOverlapRows?: number;
  consecutiveRejections?: number; recoveredAfter?: number;
  verification?: 'strict'|'localized'; ignoredPixels?: number;
  addedTop?:number;addedBottom?:number;viewportY?:number;coveredTop?:number;coveredBottom?:number;
  viewportDelta?:number;revisited?:boolean;relocated?:boolean;
  panelOverlay?: boolean;
  controlsInTray?: boolean;
  error?: string;
  /** Explicitly true permits finishing accumulated content after a capture error. */
  canFinish?: boolean;
}

export type LongshotCommand = 'finish' | 'cancel' | 'copy' | 'save' | 'analyze' | 'close' | 'pause' | 'resume' | 'manual' | 'confirm-region' | 'keep-region' | 'export-diagnostics';
export interface LongshotCommandResult { message?: string; cancelled?: boolean }
export interface LongshotBridge {
  previewWindow(input: PreviewWindowRequest): Promise<PreviewWindowState>;
  onPreviewWindow(listener: (state: PreviewWindowState) => void): () => void;
  getLongshot(): Promise<LongshotState | null>;
  commandLongshot(id: string, command: LongshotCommand, annotations?: Annotation[]): Promise<LongshotCommandResult>;
  getLongshotImage(id: string): Promise<{image: string; width: number; height: number}>;
  onLongshot(listener: (state: LongshotState) => void): () => void;
  onLongshotTelemetry(listener: (update: TelemetryUpdate) => void): () => void;
}
