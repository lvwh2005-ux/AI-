import type {BitmapFrame} from './types';

/** Sparse analysis image: bounded source-pixel samples with exact coordinates.
 * No output pixels are rescaled. Row jitter avoids decimation phase lock. */
export const ANALYSIS_BUDGET={maxColumns:64,maxRows:2048,maxPixels:32_768,maxRowMatches:32,maxHypotheses:64,
  probeRows:32,probeColumns:32,maxProbePixels:65_536,maxCandidates:16} as const;
export interface AnalysisFrame {
  sourceWidth:number;sourceHeight:number;width:number;height:number;
  sourceRows:Uint32Array;sourceColumns:Uint32Array;data:Uint8Array;
}
export function analysisFrame(frame:BitmapFrame,maxPixels:number=ANALYSIS_BUDGET.maxPixels):AnalysisFrame{
  // Tall strip analyses used to spend almost all samples on rows: at 1543
  // source rows an 8192-pixel strip had only five columns. White page margins
  // then hid most glyphs. Keep horizontal evidence within the same pixel cap.
  const height=Math.min(ANALYSIS_BUDGET.maxRows,frame.height,Math.max(1,Math.floor(maxPixels/Math.min(16,frame.width))));
  const width=Math.min(ANALYSIS_BUDGET.maxColumns,frame.width,Math.floor(maxPixels/height));
  const sourceRows=new Uint32Array(height),sourceColumns=new Uint32Array(width),data=new Uint8Array(width*height*4);
  for(let x=0;x<width;x++)sourceColumns[x]=width===1?0:Math.round(x*(frame.width-1)/(width-1));
  for(let row=0;row<height;row++){
    const start=Math.floor(row*frame.height/height),end=Math.floor((row+1)*frame.height/height);
    let n=Math.imul(row+31,0x45d9f3b);n=Math.imul(n^(n>>>16),0x45d9f3b);
    const y=start+(n>>>0)%(end-start);sourceRows[row]=y;
    for(let x=0;x<width;x++){
      const source=(y*frame.width+sourceColumns[x])*4,target=(row*width+x)*4;
      data[target]=frame.data[source];data[target+1]=frame.data[source+1];data[target+2]=frame.data[source+2];data[target+3]=frame.data[source+3];
    }
  }
  return{sourceWidth:frame.width,sourceHeight:frame.height,width,height,sourceRows,sourceColumns,data};
}
/** Exact sampled row fingerprints generate hypotheses only. Full source-pixel
 * verification remains mandatory. Uninformative samples reject conservatively. */
export function analysisCandidates(before:AnalysisFrame,after:AnalysisFrame,maxShift:number,coarse=false):number[]|undefined{
  const key=(frame:AnalysisFrame,row:number):string|undefined=>{
    let low=255,high=0,hashA=2166136261,hashB=5381;
    for(let x=0;x<frame.width;x++){
      const at=(row*frame.width+x)*4;
      for(let c=0;c<3;c++){const value=frame.data[at+c];low=Math.min(low,value);high=Math.max(high,value);if(!coarse){hashA=Math.imul(hashA^value,16777619);hashB=Math.imul(hashB,33)^value;}}
    }
    // A second bounded pass over the same analysis bytes tolerates tiny colour
    // shifts. These coarse fingerprints never bypass source-pixel validation.
    if(coarse)for(let x=0;x<frame.width;x+=4)for(let c=0;c<3;c++){
      const count=Math.min(4,frame.width-x);let sum=0;
      for(let i=0;i<count;i++)sum+=frame.data[(row*frame.width+x+i)*4+c];
      const value=Math.floor(sum/count/16);hashA=Math.imul(hashA^value,16777619);hashB=Math.imul(hashB,33)^value;
    }
    return high-low>=20?`${hashA>>>0}:${hashB>>>0}`:undefined;
  };
  const index=new Map<string,number[]>();
  for(let row=0;row<before.height;row++){
    const signature=key(before,row);if(signature===undefined)continue;
    const rows=index.get(signature)??[];if(rows.length<=ANALYSIS_BUDGET.maxRowMatches)rows.push(before.sourceRows[row]);index.set(signature,rows);
  }
  const votes=new Map<number,{count:number;first:number;last:number}>();
  for(let row=0;row<after.height;row++){
    const signature=key(after,row),matches=signature===undefined?undefined:index.get(signature);
    if(!matches||matches.length>ANALYSIS_BUDGET.maxRowMatches)continue;
    const y=after.sourceRows[row];
    for(const previousY of matches){
      const shift=previousY-y;if(Math.abs(shift)>maxShift)continue;
      const vote=votes.get(shift)??{count:0,first:y,last:y};vote.count++;vote.last=y;votes.set(shift,vote);
    }
  }
  const candidates=[...votes].filter(([shift,vote])=>vote.count>=8&&vote.last-vote.first>=Math.max(24,(after.sourceHeight-Math.abs(shift))*.3));
  // Too many alternate translations cannot be certified within the fixed cap.
  if(!candidates.length||candidates.length>ANALYSIS_BUDGET.maxHypotheses)return;
  return candidates.sort((a,b)=>b[1].count-a[1].count).map(([shift])=>shift);
}
/** Fixed source-alignment probes resolve neighboring row-band hypotheses.
 * Their maximum count is explicit and independent of source W/H. */
export function probeAnalysisCandidate(before:BitmapFrame,after:BitmapFrame,shift:number,options:{allowLocalized?:boolean}={}):boolean{
  const rows=after.height-Math.abs(shift),columns=Math.min(ANALYSIS_BUDGET.probeColumns,after.width);
  const samples=Math.min(ANALYSIS_BUDGET.probeRows,rows),aTop=Math.max(0,shift),bTop=Math.max(0,-shift);
  let difference=0,changed=0,left=after.width,right=-1,top=rows,bottom=-1;
  const maximum=samples*columns*3*3;
  for(let y=0;y<samples;y++){
    const row=samples===1?0:Math.round(y*(rows-1)/(samples-1));
    for(let x=0;x<columns;x++){
      const column=columns===1?0:Math.round(x*(after.width-1)/(columns-1));
      const a=((aTop+row)*before.width+column)*4,b=((bTop+row)*after.width+column)*4;
      let maximumChannel=0;
      for(let c=0;c<3;c++){const delta=Math.abs(before.data[a+c]-after.data[b+c]);difference+=delta;maximumChannel=Math.max(maximumChannel,delta);}
      if(maximumChannel>6||Math.abs(before.data[a+3]-after.data[b+3])>1){
        changed++;left=Math.min(left,column);right=Math.max(right,column);top=Math.min(top,row);bottom=Math.max(bottom,row);
      }
      if(difference>maximum)return false;
    }
  }
  // Averaging over a mostly white desktop used to dilute wrong glyph matches.
  // More than one differing probe must form the same bounded patch allowed by
  // source verification; widely separated glyph disagreements cannot hide in
  // white margins. This only prunes hypotheses, never certifies a translation.
  return changed<=1||options.allowLocalized!==false
    &&right-left+1<=Math.max(8,Math.min(48,Math.floor(after.width*.08)))
    &&bottom-top+1<=Math.max(16,Math.min(64,Math.floor(rows*.12)));
}
