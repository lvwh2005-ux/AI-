import { sameBytes } from './content-region';
import { VerticalMatcher } from './vertical-matcher';
import { verifyTranslation } from './translation-verifier';
import type { BitmapFrame, PixelRegion } from './types';
import type { StageProfiler } from './profiler';
import {AnalysisWork} from './analysis-work';
import {matchesEdgeScrollControl} from './edge-scroll-control';

interface StripMatch { x: number; width: number; top: number; bottom: number; shift: number }
export interface RegionProposal { rect: PixelRegion; shift: number; overlapRows: number; supportingStrips: number }

export function cropFrame(frame: BitmapFrame, rect: PixelRegion): BitmapFrame {
  const data = new Uint8Array(rect.width * rect.height * 4);
  for (let y = 0; y < rect.height; y++) {
    const from = ((rect.y + y) * frame.width + rect.x) * 4;
    data.set(frame.data.subarray(from, from + rect.width * 4), y * rect.width * 4);
  }
  return { width: rect.width, height: rect.height, data };
}

/** Only proposes a contiguous, full-pixel-verified body. Cropping requires an
 * explicit UI confirmation; this detector never mutates an accepted document. */
export function proposeMotionRegion(before: BitmapFrame, after: BitmapFrame, profiler?: StageProfiler,work=new AnalysisWork()): RegionProposal | undefined {
  const count = Math.min(10, Math.floor(before.width / 24));
  if (count < 3) return;
  const matcher = new VerticalMatcher({allowLocalized:false,profiler,samplePixels:8192}), strips: (StripMatch | undefined)[] = [];
  for (let i = 0; i < count; i++) {
    const x = Math.floor(i * before.width / count), end = Math.floor((i + 1) * before.width / count);
    const a = cropFrame(before, { x, y: 0, width: end - x, height: before.height });
    const b = cropFrame(after, { x, y: 0, width: end - x, height: after.height });
    if (sameBytes(a.data, b.data)) { strips.push(undefined); continue; }
    const top = stationaryEdge(a, b, false), bottom = stationaryEdge(a, b, true);
    const body = { x: 0, y: top, width: a.width, height: a.height - top - bottom };
    const motion = matcher.match(cropFrame(a, body), cropFrame(b, body),work);
    strips.push(motion.kind === 'match' ? { x, width: end - x, top, bottom, shift: motion.shift } : undefined);
  }
  const byShift = new Map<number,StripMatch[]>();
  for (const strip of strips) {
    if(!strip)continue;
    const group=byShift.get(strip.shift)??[];group.push(strip);byShift.set(strip.shift,group);
  }
  // Missing strips may contain a blinking element in the fixed chrome. Include
  // the gap in the proposed rectangle; the entire body must still verify below.
  const groups=[...byShift.values()];
  // The evidence belongs to the moving body, not a percentage of the user's
  // selection. A narrow text column can establish a shift in a large desktop
  // ROI. Full body and outside validation below still certify the whole crop;
  // even a small independently moving column makes the proposal ambiguous.
  if (groups.length !== 1) return;
  const group = groups[0], shift = group[0].shift;
  const top = Math.max(...group.map(s => s.top)), bottom = Math.max(...group.map(s => s.bottom));
  let left = group[0].x, right = group.at(-1)!.x + group.at(-1)!.width;
  const end = before.height - bottom;
  // Refine tile boundaries one source-pixel column at a time. Do not discard
  // body text simply because it shares a coarse strip with a stationary sidebar.
  while (left > 0 && alignedColumn(before, after, left - 1, top, end, shift)) left--;
  while (right < before.width && alignedColumn(before, after, right, top, end, shift)) right++;
  const rect = { x: left, y: top, width: right - left, height: end - top };
  if (rect.width === before.width && rect.height === before.height) return;
  // A crop may remove stationary chrome or a narrowly shaped outer scroll
  // control, never another moving text column or an animated document patch.
  if (!stationaryOutside(before, after, rect,shift)) return;
  if(!work.take('verifications',1)||!verifyTranslation(cropFrame(before,rect),cropFrame(after,rect),shift,{allowLocalized:false}))return;
  return { rect, shift, overlapRows: rect.height-Math.abs(shift), supportingStrips: group.length };
}

function stationaryOutside(a: BitmapFrame, b: BitmapFrame, rect: PixelRegion,shift:number) {
  let changed=false;
  scan: for (let y = 0; y < a.height; y++) for (let x = 0; x < a.width; x++) {
    if (x >= rect.x && x < rect.x + rect.width && y >= rect.y && y < rect.y + rect.height) continue;
    const from = (y * a.width + x) * 4;
    for (let c = 0; c < 4; c++) if (a.data[from+c] !== b.data[from+c]) {changed=true;break scan;}
  }
  if(!changed)return true;
  const areas:PixelRegion[]=[{x:0,y:0,width:a.width,height:rect.y},
    {x:0,y:rect.y+rect.height,width:a.width,height:a.height-rect.y-rect.height},
    {x:0,y:rect.y,width:rect.x,height:rect.height},
    {x:rect.x+rect.width,y:rect.y,width:a.width-rect.x-rect.width,height:rect.height}];
  // Otherwise stationary chrome permits a bounded local change; the side
  // areas additionally permit the strictly shaped outer control below.
  return areas.filter(area=>area.width&&area.height).every((area)=>{
    if(verifyTranslation(cropFrame(a,area),cropFrame(b,area),0,{requireAnchors:false}))return true;
    // Only the side areas may contain a moving edge control. The crop remains
    // pending explicit confirmation and the entire retained body verifies.
    return area.y===rect.y&&area.height===rect.height
      &&matchesEdgeScrollControl(a,b,area,shift);
  });
}

function stationaryEdge(a: BitmapFrame, b: BitmapFrame, bottom: boolean) {
  const limit = a.height, stride = a.width * 4;
  let rows = 0;
  for (; rows < limit; rows++) {
    const y = bottom ? a.height - 1 - rows : rows, from = y * stride;
    if (!sameBytes(a.data.subarray(from, from + stride), b.data.subarray(from, from + stride))) break;
  }
  return rows;
}
function alignedColumn(a: BitmapFrame, b: BitmapFrame, x: number, top: number, end: number, shift: number) {
  const aTop=top+Math.max(0,shift),bTop=top+Math.max(0,-shift),rows=end-top-Math.abs(shift);
  for (let y = 0; y < rows; y++) {
    const ai = ((y + aTop) * a.width + x) * 4, bi = ((y+bTop) * b.width + x) * 4;
    for (let c = 0; c < 4; c++) if (Math.abs(a.data[ai+c] - b.data[bi+c]) > (c === 3 ? 1 : 2)) return false;
  }
  return true;
}
