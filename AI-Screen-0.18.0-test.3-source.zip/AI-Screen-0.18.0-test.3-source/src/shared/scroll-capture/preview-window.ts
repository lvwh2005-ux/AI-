import { z } from 'zod';
import type { Rect } from '../contracts';
import { PreviewPlacementManager, previewWorkArea } from './preview-placement';
import { previewViewSchema } from './preview-viewport';

export const previewEdges = ['move', 'n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw'] as const;
export type PreviewEdge = typeof previewEdges[number];
const pointSchema = z.object({ x: z.number().finite().min(-100000).max(100000), y: z.number().finite().min(-100000).max(100000) }).strict();
const id = z.string().uuid(), token = z.string().uuid();
export const previewWindowRequestSchema = z.discriminatedUnion('op', [
  z.object({ id, op: z.literal('get') }).strict(),
  z.object({ id, op: z.literal('auto') }).strict(),
  z.object({ id, op: z.literal('begin'), edge: z.enum(previewEdges), point: pointSchema }).strict(),
  z.object({ id, op: z.literal('update'), token, point: pointSchema }).strict(),
  z.object({ id, op: z.literal('end'), token, point: pointSchema.optional() }).strict(),
  z.object({ id, op: z.literal('view'), sequence: z.number().int().positive().max(Number.MAX_SAFE_INTEGER), view: previewViewSchema.nullable() }).strict(),
]);
export type PreviewWindowRequest = z.infer<typeof previewWindowRequestSchema>;
export interface PreviewWindowLayoutState { positionMode: 'auto' | 'manual'; bounds: Rect; revision: number }
export interface PreviewWindowState extends PreviewWindowLayoutState { id: string; token?: string }
type Point = { x: number; y: number };
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(value, max));

/** Session-local UI geometry. Capture coordinates/pixels never enter this model. */
export class PreviewWindowLayout {
  private state: PreviewWindowLayoutState;
  private gesture?: { token: string; edge: PreviewEdge; start: Point; bounds: Rect };
  private preferredSize?: Pick<Rect, 'width' | 'height'>;
  private manager = new PreviewPlacementManager();
  private area: Rect;
  constructor(private target: Rect, private workArea: Rect, private toolbar: Rect) {
    this.area = previewWorkArea(workArea);
    this.state = { positionMode: 'auto', bounds: this.manager.place(target, workArea, toolbar).bounds, revision: 0 };
  }
  snapshot(): PreviewWindowLayoutState { return { ...this.state, bounds: { ...this.state.bounds } }; }
  updateToolbar(toolbar: Rect) {
    this.toolbar = { ...toolbar };
    if (this.state.positionMode === 'auto' && !this.gesture) this.automatic();
    return this.snapshot();
  }
  restoreAuto() { this.gesture = undefined; this.automatic(); return this.snapshot(); }
  begin(token: string, edge: PreviewEdge, point: Point) {
    pointSchema.parse(point);
    if (this.gesture) throw new Error('请先结束当前预览拖动');
    this.gesture = { token, edge, start: { ...point }, bounds: { ...this.state.bounds } };
  }
  update(token: string, point: Point) {
    const gesture = this.requireGesture(token); pointSchema.parse(point);
    const base = gesture.bounds, area = this.area;
    const dx = Math.round(point.x - gesture.start.x), dy = Math.round(point.y - gesture.start.y);
    let x = base.x, y = base.y, right = x + base.width, bottom = y + base.height;
    if (gesture.edge === 'move') {
      x = clamp(x + dx, area.x, area.x + area.width - base.width);
      y = clamp(y + dy, area.y, area.y + area.height - base.height);
      right = x + base.width; bottom = y + base.height;
    } else {
      const minWidth = Math.min(240, base.width), minHeight = Math.min(240, base.height);
      if (gesture.edge.includes('w')) x = clamp(x + dx, area.x, right - minWidth);
      if (gesture.edge.includes('e')) right = clamp(right + dx, x + minWidth, area.x + area.width);
      if (gesture.edge.includes('n')) y = clamp(y + dy, area.y, bottom - minHeight);
      if (gesture.edge.includes('s')) bottom = clamp(bottom + dy, y + minHeight, area.y + area.height);
    }
    const bounds = { x, y, width: right - x, height: bottom - y };
    const changed = (Object.keys(bounds) as (keyof Rect)[]).some(key => bounds[key] !== this.state.bounds[key]);
    if (changed) {
      this.state = { bounds, positionMode: 'manual', revision: this.state.revision + 1 };
      if (gesture.edge !== 'move') this.preferredSize = { width: bounds.width, height: bounds.height };
    }
    return this.snapshot();
  }
  end(token: string, point?: Point) {
    this.requireGesture(token);
    if (point) this.update(token, point);
    this.gesture = undefined;
    return this.snapshot();
  }
  private requireGesture(token: string) {
    if (!this.gesture || this.gesture.token !== token) throw new Error('预览拖动已结束，请重新操作');
    return this.gesture;
  }
  private automatic() {
    const bounds = this.manager.place(this.target, this.workArea, this.toolbar, this.preferredSize).bounds;
    this.state = { bounds, positionMode: 'auto', revision: this.state.revision + 1 };
  }
}
