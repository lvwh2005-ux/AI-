import type { MatchIssue, StitchResult } from './types';

export type CaptureActivity = 'preparing'|'capturing'|'matching'|'previewing'|'waiting-change'|'waiting-stable'|'seeking-overlap'|'scrolling'|'paused'|'reviewing'|'finishing'|'completed'|'error';
export type ReadChange = 'first'|'same'|'changed';
export interface Timing { last: number; average: number; max: number; count: number }
export interface LongshotTelemetry {
  sequence: number; activity: CaptureActivity;
  captured: number; processed: number; appended: number; duplicates: number; rejected: number; reviews: number; discarded: number; readErrors: number;
  changedReads:number; identicalReads:number; identicalReadStreak:number;
  readRetries:number;
  capture: Timing; match: Timing; preview: Timing; queueWait:Timing;endToEnd:Timing;
  captureFps?: number;effectiveNewRowsPerSecond?:number;
  bufferedFrames: number; bufferedBytes: number; queuedFrames: number; peakFrames: number; peakBytes: number; backpressureWaits: number; waitingForSpace: boolean;
  localizedFrames: number; recoveries: number; rejectionStreak: number;
  prependedRows:number;appendedBottomRows:number;revisits:number;relocations:number;
  lastVerification?: 'strict'|'localized'; lastIgnoredPixels?: number;
  lastResult?: StitchResult['kind']; lastIssue?: MatchIssue|'capture-error'|'processing-error'|'input-error';
}
export interface TelemetryUpdate { id: string; telemetry: LongshotTelemetry }
const timing=():Timing=>({last:0,average:0,max:0,count:0});

/** Numeric session data only. Never retains pixels, titles, prompts or keys. */
export class CaptureTelemetry {
  private data: LongshotTelemetry={sequence:0,activity:'preparing',captured:0,processed:0,appended:0,duplicates:0,rejected:0,reviews:0,discarded:0,readErrors:0,readRetries:0,changedReads:0,identicalReads:0,identicalReadStreak:0,capture:timing(),match:timing(),preview:timing(),queueWait:timing(),endToEnd:timing(),bufferedFrames:0,bufferedBytes:0,queuedFrames:0,peakFrames:0,peakBytes:0,backpressureWaits:0,waitingForSpace:false,localizedFrames:0,recoveries:0,rejectionStreak:0,prependedRows:0,appendedBottomRows:0,revisits:0,relocations:0};
  private samples:number[]=[];
  private progress:{at:number;rows:number}[]=[];
  private rows=0;
  phase(activity:CaptureActivity){if(activity!==this.data.activity){this.data.activity=activity;this.data.sequence++;}}
  measure(stage:'capture'|'match'|'preview'|'queueWait'|'endToEnd',ms:number){
    if(!Number.isFinite(ms)||ms<0)return;
    const value=this.data[stage],count=value.count+1;
    this.data[stage]={last:ms,average:value.average+(ms-value.average)/count,max:Math.max(value.max,ms),count};this.data.sequence++;
  }
  captured(at:number,change:ReadChange='first'){
    if(change==='changed')this.data.changedReads++;
    if(change==='same')this.data.identicalReads++;
    this.data.identicalReadStreak=change==='same'?this.data.identicalReadStreak+1:0;
    this.data.captured++;this.data.sequence++;
    if(Number.isFinite(at)){this.samples.push(at);if(this.samples.length>32)this.samples.shift();}
  }
  result(result:StitchResult,preserveIssue=false,at=performance.now()){
    this.recordProgress(result,at);
    const previousIssue=this.data.lastIssue;
    this.data.processed++;this.data.lastResult=result.kind;this.data.sequence++;
    if(result.kind==='appended')this.data.appended++;
    if(result.kind==='duplicate')this.data.duplicates++;
    if(result.kind==='rejected')this.data.rejected++;
    if(result.kind==='review')this.data.reviews++;
    this.evidence(result);
    if(result.reasonCode)this.data.lastIssue=result.reasonCode;
    else if(result.kind==='appended'||result.kind==='initial'||result.recoveredAfter)this.data.lastIssue=undefined;
    if(preserveIssue)this.data.lastIssue=previousIssue;
  }
  resolveReview(result:StitchResult){
    this.recordProgress(result,performance.now());
    // Confirmation commits an already processed frame, not another capture.
    this.data.lastResult=result.kind;this.data.lastIssue=result.reasonCode;
    if(result.kind==='appended')this.data.appended++;
    this.evidence(result);
    this.data.sequence++;
  }
  private evidence(result:StitchResult){
    if(result.kind==='appended'){this.data.prependedRows+=result.addedTop??0;this.data.appendedBottomRows+=result.addedBottom??0;}
    if(result.revisited)this.data.revisits++;
    if(result.relocated)this.data.relocations++;
    this.data.rejectionStreak=result.consecutiveRejections??(result.kind==='rejected'?this.data.rejectionStreak+1:0);
    if(result.verification==='localized'&&(result.kind==='appended'||result.kind==='duplicate'))this.data.localizedFrames++;
    if(result.recoveredAfter)this.data.recoveries++;
    if(result.verification){this.data.lastVerification=result.verification;this.data.lastIgnoredPixels=result.ignoredPixels??0;}
  }
  discard(count=1){this.data.discarded+=count;this.data.sequence++;}
  retried(count:number){if(Number.isSafeInteger(count)&&count>0){this.data.readRetries+=count;this.data.sequence++;}}
  queue(stats:Pick<LongshotTelemetry,'bufferedFrames'|'bufferedBytes'|'queuedFrames'|'peakFrames'|'peakBytes'|'backpressureWaits'|'waitingForSpace'>){Object.assign(this.data,stats);this.data.sequence++;}
  error(kind:MatchIssue|'capture-error'|'processing-error'|'input-error'){
    this.data.lastIssue=kind;if(kind==='capture-error')this.data.readErrors++;this.data.sequence++;
  }
  private recordProgress(result:StitchResult,at:number){
    if(!Number.isFinite(at)||this.progress.length&&at<this.progress.at(-1)!.at)return;
    if(result.kind==='appended'&&Number.isSafeInteger(result.appendedRows)&&result.appendedRows>0)this.rows+=result.appendedRows;
    this.progress.push({at,rows:this.rows});if(this.progress.length>32)this.progress.shift();
  }
  resetRate(){this.samples=[];this.progress=[];this.rows=0;this.data.identicalReadStreak=0;this.data.sequence++;}
  snapshot():LongshotTelemetry{
    const span=this.samples.at(-1)!-this.samples[0];
    const last=this.progress.at(-1),first=this.progress[0],progressSpan=last&&first?last.at-first.at:0;
    return {...this.data,capture:{...this.data.capture},match:{...this.data.match},preview:{...this.data.preview},queueWait:{...this.data.queueWait},endToEnd:{...this.data.endToEnd},
      captureFps:this.samples.length>1&&span>0?(this.samples.length-1)*1000/span:undefined,
      effectiveNewRowsPerSecond:progressSpan>0?(last!.rows-first.rows)*1000/progressSpan:undefined};
  }
}
export const activityLabels:Record<CaptureActivity,string>={preparing:'准备采集',capturing:'正在采集',matching:'正在拼接',previewing:'更新预览','waiting-change':'等待页面变化','waiting-stable':'等待画面稳定','seeking-overlap':'等待重新接上',scrolling:'正在滚动',paused:'已暂停',reviewing:'等待确认正文',finishing:'正在生成长图',completed:'已完成',error:'采集已停止'};
