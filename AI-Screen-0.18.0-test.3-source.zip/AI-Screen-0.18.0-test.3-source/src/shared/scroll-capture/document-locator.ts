import {pixelRow, type BitmapFrame, type RowFrame} from './types';
import {AnalysisWork} from './analysis-work';

export type DocumentLocation={kind:'located';top:number}|{kind:'ambiguous'};

/** Bounded index of informative row fingerprints, no retained image copies.
 * Large revisits must match a complete already-covered viewport byte for byte.
 * This fallback never extends across a missing/unknown part of the document. */
export class DocumentLocator {
  private revision=-1;
  private width=0;private height=0;
  private columns=32;
  private rows=new Map<number,number[]|null>();
  clear(){this.revision=-1;this.rows.clear();}
  locate(document:RowFrame,frame:BitmapFrame,revision:number,work=new AnalysisWork()):DocumentLocation|undefined {
    if(document.width!==frame.width||document.height<=frame.height||frame.height<96||frame.width<64)return;
    if(this.revision!==revision||this.width!==document.width||this.height!==document.height){
      const columns=Math.min(32,Math.floor(work.remaining('samples')/(document.height+32)));
      if(columns<1||!work.take('samples',columns*document.height))return;
      this.columns=columns;
      this.rows.clear();this.revision=revision;this.width=document.width;this.height=document.height;
      for(let y=0;y<document.height;y++){
        const row=pixelRow(document,y),hash=fingerprint(row.data,row.offset,document.width,this.columns);
        if(hash===undefined)continue;
        const bucket=this.rows.get(hash);
        if(bucket===null)continue;
        if(bucket){if(bucket.length<64)bucket.push(y);else this.rows.set(hash,null);}
        else this.rows.set(hash,[y]);
      }
    }
    const candidates=new Map<number,{count:number;first:number;last:number}>();
    if(!work.take('samples',32*this.columns))return;
    for(let i=0;i<32;i++){
      const y=Math.round(i*(frame.height-1)/31),hash=fingerprint(frame.data,y*frame.width*4,frame.width,this.columns);
      if(hash===undefined)continue;
      for(const row of this.rows.get(hash)??[]){
        const top=row-y;if(top<0||top+frame.height>document.height)continue;
        const value=candidates.get(top)??{count:0,first:y,last:y};value.count++;value.last=y;candidates.set(top,value);
      }
    }
    const possible=[...candidates].filter(([,value])=>value.count>=3&&value.last-value.first>=Math.max(24,frame.height*.3));
    if(possible.length>16)return {kind:'ambiguous'};
    let found:number|undefined;
    for(const [top]of possible){
      if(!work.take('verifications',1))return;
      if(!identical(document,frame,top))continue;
      if(found!==undefined)return {kind:'ambiguous'};
      found=top;
    }
    return found===undefined?undefined:{kind:'located',top:found};
  }
}
function fingerprint(data:Uint8Array,offset:number,width:number,columns:number):number|undefined {
  let hash=2166136261,low=255,high=0;
  for(let i=0;i<columns;i++){
    const at=offset+(columns===1?Math.floor(width/2):Math.round(i*(width-1)/(columns-1)))*4;
    for(let c=0;c<4;c++){const value=data[at+c];hash=Math.imul(hash^value,16777619);if(c<3){low=Math.min(low,value);high=Math.max(high,value);}}
  }
  return high-low>=20?hash>>>0:undefined;
}
function identical(document:RowFrame,frame:BitmapFrame,top:number) {
  const stride=frame.width*4;
  for(let y=0;y<frame.height;y++){
    const row=pixelRow(document,top+y),at=y*stride;
    for(let x=0;x<stride;x++)if(row.data[row.offset+x]!==frame.data[at+x])return false;
  }return true;
}
