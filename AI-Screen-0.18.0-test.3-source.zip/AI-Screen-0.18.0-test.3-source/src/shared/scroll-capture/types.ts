export interface BitmapFrame { width: number; height: number; data: Uint8Array }
/** Internal, read-only row access; never transferred to renderer/IPC. */
export interface RowFrame { width: number; height: number; rowAt(y:number): {data:Uint8Array;offset:number} }
export type PixelFrame = BitmapFrame | RowFrame;
export function pixelRow(frame:PixelFrame,y:number) { return 'rowAt' in frame ? frame.rowAt(y) : {data:frame.data,offset:y*frame.width*4}; }
export interface PixelRegion { x: number; y: number; width: number; height: number }
export type MatchIssue = 'invalid-frame' | 'size-changed' | 'capacity' | 'fixed-region-changed' | 'history-changed' | 'no-overlap' | 'overlap-rejected' | 'ambiguous-overlap' | 'reverse-scroll' | 'no-motion' | 'body-too-small' | 'body-review';
export interface StitchResult {
  kind: 'initial' | 'appended' | 'duplicate' | 'rejected' | 'limit' | 'review';
  width: number; height: number; appendedRows: number; overlapRows?: number; reason?: string;
  reasonCode?: MatchIssue;
  /** Full-width fixed edge bands, kept once in the output. */
  fixedTop?: number; fixedBottom?: number;
  regionCandidate?: PixelRegion;
  contentRect?: PixelRegion;
  verifiedTransitions?: number;
  /** Pixel overlap verified on the last committed seam. */
  lastOverlapRows?: number;
  verification?: 'strict'|'localized'; ignoredPixels?: number;
  consecutiveRejections?: number; recoveredAfter?: number;
  addedTop?:number; addedBottom?:number; viewportY?:number; coveredTop?:number; coveredBottom?:number;
  viewportDelta?:number; revisited?:boolean; relocated?:boolean;
}
export type MotionMatch = { kind: 'match'; shift: number; overlapRows: number; verification?: 'strict'|'localized'; ignoredPixels?: number }
  | { kind: 'stationary'; verification: 'strict'|'localized'; ignoredPixels: number }
  | { kind: 'rejected'; reason: string; reasonCode?: MatchIssue };
export interface FrameMatcher { match(before: BitmapFrame, after: BitmapFrame,work?:import('./analysis-work').AnalysisWork): MotionMatch }
