interface Tap {index:number;weight:number}
/** Area coverage for ordinary reductions. Extreme overviews use at most eight
 * stratified taps per axis, so long documents never trigger an unbounded scan. */
export function previewFilterAxis(start:number,length:number,pixels:number):Tap[][] {
  const span=length/pixels;
  return Array.from({length:pixels},(_,pixel)=>{
    const left=start+pixel*span,right=start+(pixel+1)*span;
    if(Math.ceil(right)-Math.floor(left)>8){
      return Array.from({length:8},(_,i)=>({index:Math.min(start+length-1,Math.floor(left+(i+.5)*span/8)),weight:1/8}));
    }
    const taps:Tap[]=[];
    for(let index=Math.floor(left);index<Math.ceil(right);index++){
      const weight=(Math.min(right,index+1)-Math.max(left,index))/span;
      if(weight>0)taps.push({index:Math.min(start+length-1,index),weight});
    }
    return taps;
  });
}
