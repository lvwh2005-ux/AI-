import type {LongshotState} from '../longshot';
import type {LongshotTelemetry,Timing} from './telemetry';

export interface DiagnosticEnvironment {
  appVersion:string;systemVersion:string;platform:string;
  displayWidth:number;displayHeight:number;scaleFactor:number;
}
export interface DiagnosticGuidance {code:string;title:string;action:string}
const guidance=(code:string,title:string,action:string):DiagnosticGuidance=>({code,title,action});

/** Explain evidence without guessing whether a browser, GPU or input caused it. */
export function diagnosticGuidance(state:LongshotState|null):DiagnosticGuidance{
  if(!state)return guidance('preparing','正在准备采集','首屏出现后，把鼠标移到选区中的滚动正文上。');
  const value=state.telemetry,issue=value?.lastIssue;
  if(state.status==='done')return (state.appendedRows??0)>0
    ?guidance('stitched','已生成拼接结果','请检查两端和接缝；程序不会判断整篇内容是否已经截全。')
    :guidance('single-frame','只有首屏，尚未拼成长图','可以保存这一屏；若需要长图，请重新开始并确认滚动后预览高度增加。');
  if(state.status==='cancelled')return guidance('cancelled','本次采集已取消','重新框选即可开始新的采集。');
  if(state.status==='finishing')return guidance('finishing','正在生成结果','等待在途画面处理完成；请暂时保持页面静止。');
  if(state.status==='error'){
    if(issue==='capacity')return guidance('capacity','已达到容量限制','完成并保存已有内容，再分段截图。扩大预览不会增加长图容量。');
    if(issue==='capture-error')return guidance('capture-error','读取屏幕失败','已有内容仍可完成；确认目标可见且显示器布局未改变，再重新框选。');
    return guidance('stopped','采集已停止','可以完成已有可靠内容，或取消后重新框选。查看最近问题代码以定位原因。');
  }
  if(state.regionCandidate)return guidance('body-review','需要确认滚动正文','先停止滚动，检查蓝框；只有确认后才会裁去外围固定栏。');
  if(state.paused||value?.activity==='paused')return guidance('paused','采集暂时暂停','暂停期间的滚动不会加入长图；继续前请回到最后成功采集的位置。');
  if(value?.waitingForSpace)return guidance('backpressure','拼接正在追赶采集','请暂缓滚动，等待缓冲下降；继续快速滚动可能失去重叠。');
  if((value?.rejectionStreak??state.consecutiveRejections??0)>0){
    if(issue==='history-changed')return guidance('history-changed','已有内容变化或位置不一致','保留的长图没有被覆盖。回到可靠位置；页面重排或旧内容改变时需重新框选。');
    if(issue==='fixed-region-changed'||issue==='body-too-small')return guidance('fixed-region','固定区域影响拼接','重新框选滚动正文，尽量避开侧栏、固定输入框和浮动元素。');
    if(issue==='ambiguous-overlap')return guidance('ambiguous-overlap','找到多个相同位置','减小滚动距离，并尽量包含有区别的文字或图案；重复、空白区域可能无法定位。');
    if(issue==='size-changed'||issue==='invalid-frame')return guidance('frame-invalid','画面尺寸或数据不符合要求','停止调整目标窗口大小，取消后重新框选。');
    return guidance('overlap-rejected','画面未通过拼接，已有图像保留','往回滚到最后可靠位置，再以更小距离滚动。重叠不足、动态变化等都可能导致拒绝。');
  }
  if(!state.frames)return guidance('first-frame','等待首屏处理','先保持页面静止；有首屏后再滚动。');
  if((value?.identicalReadStreak??0)>=3)return guidance('unchanged-read','连续读到相同的选区画面','确认鼠标在滚动正文上，并查看原页面是否真的移动。相同画面本身不能区分“页面没动”和“采集未更新”。');
  if(value?.lastResult==='duplicate'&&value.lastVerification==='localized')return guidance('local-change','仅有局部变化，未增长长图','已去重；光标闪烁等变化不代表正文滚动，可以继续上下滚动。');
  if(value?.lastResult==='duplicate'&&(state.revisited||state.relocated))return guidance('revisit','正在回看已采集内容','回看不会重复增长；滚到已采集范围之外才能补充新内容。');
  return guidance('capturing','正在采集与拼接','上下滚动正文，并观察新增高度。若滚动后高度不变，可查看相邻读屏变化和拒绝计数。');
}

const count=(value:number|undefined)=>Number.isFinite(value)?Math.max(0,Math.min(Number.MAX_SAFE_INTEGER,Math.trunc(value!))):0;
const signed=(value:number|undefined)=>Number.isFinite(value)?Math.max(-100000,Math.min(100000,Math.trunc(value!))):0;
const duration=(value:number|undefined)=>Number.isFinite(value)&&value!>=0?Math.min(value!,Number.MAX_SAFE_INTEGER):0;
const version=(value:string|undefined)=>value&&/^\d{1,8}(\.\d{1,8}){1,3}(?:-[0-9A-Za-z.-]{1,32})?(?:\+[0-9A-Za-z.-]{1,16})?$/.test(value)?value:'unknown';
const timing=(value:Timing|undefined)=>({last:duration(value?.last),average:duration(value?.average),max:duration(value?.max),count:count(value?.count)});
const issueCodes:ReadonlyArray<NonNullable<LongshotTelemetry['lastIssue']>>=['invalid-frame','size-changed','capacity','fixed-region-changed','history-changed','no-overlap','overlap-rejected','ambiguous-overlap','reverse-scroll','no-motion','body-too-small','body-review','capture-error','processing-error','input-error'];
const activities=['preparing','capturing','matching','previewing','waiting-change','waiting-stable','seeking-overlap','scrolling','paused','reviewing','finishing','completed','error'];

/** Local, explicit allow-list. No pixels, hashes, titles, URLs, paths, session
 * IDs, free-form errors, prompts, settings or credentials can enter the report. */
export function buildDiagnosticReport(state:LongshotState,elapsedMs:number,environment?:DiagnosticEnvironment){
  const value=state.telemetry;
  const counts=['captured','processed','appended','duplicates','rejected','reviews','discarded','readErrors','readRetries','changedReads','identicalReads','identicalReadStreak','bufferedFrames','bufferedBytes','queuedFrames','peakFrames','peakBytes','backpressureWaits','localizedFrames','recoveries','rejectionStreak','prependedRows','appendedBottomRows','revisits','relocations'] as const;
  const numbers=Object.fromEntries(counts.map(key=>[key,count(value?.[key])])) as Record<typeof counts[number],number>;
  return {
    format:'ai-screen-longshot-diagnostics',schemaVersion:1,
    privacy:'仅含采集参数和数值诊断；不含图像、窗口标题、网址、文件路径、提示词或凭证。',
    environment:{appVersion:version(environment?.appVersion),systemVersion:version(environment?.systemVersion),
      platform:environment?.platform==='win32'?'win32':'unknown',displayWidth:count(environment?.displayWidth),displayHeight:count(environment?.displayHeight),
      scaleFactor:environment&&Number.isFinite(environment.scaleFactor)&&environment.scaleFactor>0&&environment.scaleFactor<=8?environment.scaleFactor:0},
    capture:{mode:state.scrollMode==='auto'?'auto':'manual',status:['preparing','capturing','finishing','done','cancelled','error'].includes(state.status)?state.status:'error',
      backend:state.captureBackend==='gdi-roi'||state.captureBackend==='electron-snapshot'?state.captureBackend:'unknown',
      paused:state.paused===true,elapsedMs:duration(elapsedMs),width:count(state.width),height:count(state.height),frames:count(state.frames),
      initialHeight:count(state.initialHeight),appendedRows:count(state.appendedRows),sourceWidth:count(state.sourcePixelWidth),sourceHeight:count(state.sourcePixelHeight),
      fixedTop:count(state.fixedTop),fixedBottom:count(state.fixedBottom),viewportY:signed(state.viewportY),coveredTop:signed(state.coveredTop),coveredBottom:signed(state.coveredBottom),
      hasBodyProposal:!!state.regionCandidate},
    telemetry:{...numbers,
      activity:value&&activities.includes(value.activity)?value.activity:'preparing',waitingForSpace:value?.waitingForSpace===true,
      lastIssue:value?.lastIssue&&issueCodes.includes(value.lastIssue)?value.lastIssue:null,
      captureFps:duration(value?.captureFps),effectiveNewRowsPerSecond:duration(value?.effectiveNewRowsPerSecond),
      capture:timing(value?.capture),match:timing(value?.match),preview:timing(value?.preview),queueWait:timing(value?.queueWait),endToEnd:timing(value?.endToEnd)},
    guidance:diagnosticGuidance(state),
    interpretation:['相邻读屏变化只表示读取到的像素是否相同，不代表已经拼接。','去重可能来自静止、局部变化或回看；不能据此认定采集失败。','耗时包含异步等待，不是CPU占用；内存计数不代表整个进程内存。','该报告不能证明某个浏览器、微信或GPU已兼容，也不能确定其失败根因。'],
  };
}
