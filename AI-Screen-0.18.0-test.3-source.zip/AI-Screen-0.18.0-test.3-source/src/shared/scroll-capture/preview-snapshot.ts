import type {BitmapFrame,PixelRegion} from './types';
import {validatePreviewSize,type PreviewSize,type PreviewBundle} from './preview';
import {viewportRegion,type PreviewDocument,type ViewportRequest,type ViewportBitmap} from './preview-viewport';
import {previewFilterAxis} from './preview-filter';
export interface SegmentSnapshot {width:number;height:number;parts:readonly Uint8Array[]}
export interface PreviewSnapshot extends SegmentSnapshot,PreviewDocument {revision:number;viewportY:number;detailTop:number;detailBottom:number}
/** Published segments are immutable. Worker snapshots share backing stores;
 * subsequent commits replace references, never modify published bytes. */
export function sampleSegments(document:SegmentSnapshot,maxWidth:number,maxHeight:number,region?:PixelRegion):BitmapFrame{
  validatePreviewSize({width:maxWidth,height:maxHeight});
  if(!document.width||!document.height)return{width:0,height:0,data:new Uint8Array()};
  const view=region??{x:0,y:0,width:document.width,height:document.height};
  if(![view.x,view.y,view.width,view.height].every(Number.isSafeInteger)||view.x<0||view.y<0||view.width<1||view.height<1||view.x+view.width>document.width||view.y+view.height>document.height)throw new Error('预览范围无效');
  const ratio=Math.min(1,maxWidth/view.width,maxHeight/view.height),width=Math.max(1,Math.floor(view.width*ratio)),height=Math.max(1,Math.floor(view.height*ratio));
  const data=new Uint8Array(width*height*4),stride=document.width*4,parts=document.parts;
  let index=0,top=0;
  // Native zoom tiles are copied exactly, without filtering or a full-document
  // bitmap. Preserve this path for text inspection and original-pixel checks.
  if(width===view.width&&height===view.height){
    for(let y=0;y<height;y++){
      const sourceY=view.y+y;
      while(index<parts.length-1&&sourceY>=top+parts[index].length/stride)top+=parts[index++].length/stride;
      const from=(sourceY-top)*stride+view.x*4;
      data.set(parts[index].subarray(from,from+width*4),y*width*4);
    }
    return{width,height,data};
  }
  const columns=previewFilterAxis(view.x,view.width,width),rows=previewFilterAxis(view.y,view.height,height);
  const sums=new Float64Array(width*4);
  for(let y=0;y<height;y++){
    sums.fill(0);
    for(const row of rows[y]){
      // Consecutive target areas may share a source row across a segment edge.
      while(index>0&&row.index<top){index--;top-=parts[index].length/stride;}
      while(index<parts.length-1&&row.index>=top+parts[index].length/stride)top+=parts[index++].length/stride;
      const bytes=parts[index],base=(row.index-top)*stride;
      for(let x=0;x<width;x++){
        let b=0,g=0,r=0,a=0;
        for(const column of columns[x]){
          const from=base+column.index*4,w=column.weight;
          b+=bytes[from]*w;g+=bytes[from+1]*w;r+=bytes[from+2]*w;a+=bytes[from+3]*w;
        }
        const at=x*4,w=row.weight;
        sums[at]+=b*w;sums[at+1]+=g*w;sums[at+2]+=r*w;sums[at+3]+=a*w;
      }
    }
    for(let x=0;x<sums.length;x++)data[y*width*4+x]=Math.round(sums[x]);
  }return{width,height,data};
}
export function snapshotViewport(document:PreviewSnapshot,request:ViewportRequest):ViewportBitmap{
  const region=viewportRegion(document,request);
  return{frame:sampleSegments(document,request.pixels.width,request.pixels.height,region),region,sequence:request.sequence,
    zoom:request.settings.zoom,follow:request.settings.follow,coveredTop:document.coveredTop,documentWidth:document.width,documentHeight:document.height};
}
export function snapshotPreviews(document:PreviewSnapshot,size:PreviewSize,view?:ViewportRequest):PreviewBundle{
  validatePreviewSize(size);
  const overviewRegion={x:0,y:0,width:document.width,height:document.height};
  const height=Math.min(document.height,Math.max(1,Math.floor(document.width*size.height/size.width)));
  const y=Math.max(0,Math.min(document.height-height,document.preferTop?document.detailTop:document.detailBottom-height));
  const detailRegion={x:0,y,width:document.width,height};
  const overview=sampleSegments(document,size.width,size.height),detail=height===document.height?overview:sampleSegments(document,size.width,size.height,detailRegion);
  let viewport:ViewportBitmap|undefined;
  if(view){
    const region=viewportRegion(document,view),ratio=Math.min(1,view.pixels.width/region.width,view.pixels.height/region.height);
    const w=Math.max(1,Math.floor(region.width*ratio)),h=Math.max(1,Math.floor(region.height*ratio));
    const cached=[{region:overviewRegion,frame:overview},{region:detailRegion,frame:detail}].find(item=>
      item.region.x===region.x&&item.region.y===region.y&&item.region.width===region.width&&item.region.height===region.height&&item.frame.width===w&&item.frame.height===h);
    viewport=cached?{frame:cached.frame,region,sequence:view.sequence,zoom:view.settings.zoom,follow:view.settings.follow,
      coveredTop:document.coveredTop,documentWidth:document.width,documentHeight:document.height}:snapshotViewport(document,view);
  }
  return{overview,detail,overviewRegion,detailRegion,viewportY:document.viewportY,coveredTop:document.coveredTop,...(viewport?{viewport}:{})};
}
