import type {BitmapFrame,FrameMatcher,MotionMatch,MatchIssue} from './types';
import {verifyTranslation} from './translation-verifier';
import {profiled,type StageProfiler} from './profiler';
import {analysisFrame,analysisCandidates,probeAnalysisCandidate,ANALYSIS_BUDGET} from './analysis-frame';
import {AnalysisWork} from './analysis-work';

/** Fixed-cost hypotheses, no exhaustive height-wide fallback. Uncertifiable
 * input preserves the accepted document; all candidates need source pixels. */
export class VerticalMatcher implements FrameMatcher {
  constructor(private options:{allowLocalized?:boolean;allowReverse?:boolean;profiler?:StageProfiler;samplePixels?:number}={}){}
  match(previous:BitmapFrame,current:BitmapFrame,work=new AnalysisWork()):MotionMatch{
    const reject=(reason:string,reasonCode:MatchIssue='no-overlap'):MotionMatch=>({kind:'rejected',reason,reasonCode});
    const maxShift=current.height-Math.max(64,Math.ceil(current.height*.25));
    if(maxShift<1)return reject('有效正文太小，无法识别重叠，请扩大选区','body-too-small');
    const pixels=this.options.samplePixels??ANALYSIS_BUDGET.maxPixels;
    if(!work.take('matches',1)||!work.take('samples',pixels*2))return reject('本帧分析预算已用完，请减小滚动距离');
    const profiler=this.options.profiler;
    const metrics={maxPixels:pixels,actualPixels:0};
    const [before,after]=profiled(profiler,'analysis-sample',()=>{
      const a=analysisFrame(previous,pixels),b=analysisFrame(current,pixels);metrics.actualPixels=b.width*b.height;return[a,b];
    },metrics);
    const proposals=profiled(profiler,'analysis-candidates',()=>analysisCandidates(before,after,maxShift)
      ??analysisCandidates(before,after,maxShift,true));
    if(!proposals)return reject('未找到可靠重叠，信息不足或图案重复，请减小滚动距离','no-overlap');
    const probePixels=proposals.length*Math.min(32,current.width)*Math.min(32,current.height);
    if(!work.take('probes',probePixels))return reject('本帧候选探测预算已用完，请减小滚动距离');
    const hypotheses=profiled(profiler,'analysis-candidate-probes',()=>proposals.filter(shift=>probeAnalysisCandidate(previous,current,shift,this.options)),{hypotheses:proposals.length,maxProbePixels:ANALYSIS_BUDGET.maxProbePixels});
    if(hypotheses.length>ANALYSIS_BUDGET.maxCandidates)return reject('重叠区域有过多相似位置','ambiguous-overlap');
    if(!work.take('verifications',hypotheses.length))return reject('本帧校验候选预算已用完，请减小滚动距离');
    const verified=hypotheses.flatMap(shift=>{
      const evidence=profiled(profiler,'candidate-verify',()=>verifyTranslation(previous,current,shift,this.options),{shift,overlapRows:current.height-Math.abs(shift)});
      return evidence?[{shift,...evidence}]:[];
    });
    if(!verified.length)return reject('画面变化或重叠不足，请暂停动画并减小滚动距离','overlap-rejected');
    if(verified.length!==1)return reject('重叠内容存在多个相似位置，请换一处包含更多文字或图案的区域','ambiguous-overlap');
    const {shift,verification,ignoredPixels}=verified[0];
    if(shift<0&&this.options.allowReverse===false)return reject('当前流程不接受向上滚动，请切换手动双向采集','reverse-scroll');
    return shift?{kind:'match',shift,overlapRows:current.height-Math.abs(shift),verification,ignoredPixels}:{kind:'stationary',verification,ignoredPixels};
  }
}
