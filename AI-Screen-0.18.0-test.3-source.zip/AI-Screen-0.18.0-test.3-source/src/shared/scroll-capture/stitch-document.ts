import type { BitmapFrame, PixelRegion, RowFrame } from './types';
import { validatePreviewSize } from './preview';
import {sampleSegments} from './preview-snapshot';

/** Owns source-pixel segments. A stationary footer is held separately so new
 * content is inserted before it, never after repeated copies of page chrome. */
export class StitchDocument {
  constructor(private shared=false){}
  private own(data:Uint8Array){const copy=new Uint8Array(this.shared?new SharedArrayBuffer(data.byteLength):new ArrayBuffer(data.byteLength));copy.set(data);return copy;}
  snapshot(){return{width:this.width,height:this.height,parts:this.parts(),revision:this.revision};}
  private segments: Uint8Array[] = [];
  private header:Uint8Array = new Uint8Array(0);
  private footer:Uint8Array = new Uint8Array(0);
  private edgesLocked=false;
  revision=0;
  width = 0;
  height = 0;
  get bytes() { return this.width * this.height * 4; }

  reset(frame: BitmapFrame) {
    this.width = frame.width; this.height = frame.height;
    this.segments = [this.own(frame.data)]; this.header=new Uint8Array(0); this.footer = new Uint8Array(0);this.edgesLocked=false;this.revision++;
  }
  splitFooter(rows: number) {
    if (!rows) return;
    this.lockEdges(0,rows);
  }
  lockEdges(top:number,bottom:number) {
    if(this.edgesLocked||this.segments.length!==1)throw new Error('固定头尾只能在首次扩展前锁定');
    if(!Number.isInteger(top)||!Number.isInteger(bottom)||top<0||bottom<0||top+bottom>=this.height)throw new Error('固定头尾范围无效');
    if(!top&&!bottom){this.edgesLocked=true;this.revision++;return;}
    const data=this.segments[0],stride=this.width*4,end=data.length-bottom*stride;
    this.header=this.own(data.subarray(0,top*stride));this.footer=this.own(data.subarray(end));this.segments=[this.own(data.subarray(top*stride,end))];
    this.edgesLocked=true;this.revision++;
  }
  append(frame: BitmapFrame, fromRow: number, rows: number) {
    if (frame.width !== this.width || !Number.isInteger(fromRow) || !Number.isInteger(rows) || rows < 1 || fromRow < 0 || fromRow + rows > frame.height) throw new Error('追加像素范围无效');
    this.segments.push(this.own(frame.data.subarray(fromRow * this.width * 4, (fromRow + rows) * this.width * 4)));
    this.height += rows;
    this.revision++;
  }
  prepend(frame:BitmapFrame,fromRow:number,rows:number) {
    if(frame.width!==this.width||!Number.isInteger(fromRow)||!Number.isInteger(rows)||rows<1||fromRow<0||fromRow+rows>frame.height)throw new Error('顶部插入像素范围无效');
    this.segments.unshift(this.own(frame.data.subarray(fromRow*this.width*4,(fromRow+rows)*this.width*4)));
    this.height+=rows;this.revision++;
  }
  /** Synchronous internal view: checks history without flattening/copying it. */
  view(fromRow:number,rows:number):RowFrame {
    if(!Number.isInteger(fromRow)||!Number.isInteger(rows)||fromRow<0||rows<1||fromRow+rows>this.height)throw new Error('文档读取范围无效');
    const stride=this.width*4,parts=this.parts(),starts:number[]=[];let start=0;
    for(const part of parts){starts.push(start);start+=part.length/stride;}
    return {width:this.width,height:rows,rowAt:(y)=>{
      if(!Number.isInteger(y)||y<0||y>=rows)throw new Error('文档行范围无效');
      const absolute=fromRow+y;let low=0,high=parts.length-1;
      while(low<high){const middle=Math.ceil((low+high)/2);if(starts[middle]<=absolute)low=middle;else high=middle-1;}
      return {data:parts[low],offset:(absolute-starts[low])*stride};
    }};
  }
  private parts() {
    return [...(this.header.length?[this.header]:[]),...this.segments,...(this.footer.length?[this.footer]:[])];
  }
  bitmap(): BitmapFrame {
    const data = new Uint8Array(this.bytes); let offset = 0;
    for (const part of this.parts()) { data.set(part, offset); offset += part.length; }
    return { width: this.width, height: this.height, data };
  }
  preview(maxWidth = 240, maxHeight = 360, region?: PixelRegion): BitmapFrame {
    return sampleSegments(this.snapshot(),maxWidth,maxHeight,region);
  }
  clear() { this.segments = [];this.header=new Uint8Array(0); this.footer = new Uint8Array(0);this.edgesLocked=false; this.width = 0; this.height = 0;this.revision++; }
}
