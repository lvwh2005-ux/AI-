import type {BitmapFrame,PixelRegion} from './types';

/** Evidence only for an explicit crop proposal, never a translation mask.
 * Admit a narrow outer rail with one solid thumb moving in the same direction
 * as the document offset. Textured, split and broad moving regions still fail. */
export function matchesEdgeScrollControl(a:BitmapFrame,b:BitmapFrame,area:PixelRegion,shift:number):boolean{
  if(!shift||area.width<2||area.width>Math.min(48,Math.floor(a.width*.04))||area.height<96
    ||(area.x!==0&&area.x+area.width!==a.width))return false;
  const before=rail(a,area),after=rail(b,area);
  return !!before&&!!after&&before.background.every((color,x)=>color===after.background[x])
    &&before.left===after.left&&before.right===after.right
    &&Math.abs((before.bottom-before.top)-(after.bottom-after.top))<=2
    &&Math.sign(after.top-before.top)===Math.sign(shift);
}

function rail(frame:BitmapFrame,area:PixelRegion){
  const background:number[]=[],rows=new Uint16Array(area.height),columns:number[]=[];
  let pixels=0;
  const color=(x:number,y:number)=>{
    const at=((area.y+y)*frame.width+area.x+x)*4,d=frame.data;
    return (d[at]|d[at+1]<<8|d[at+2]<<16|d[at+3]<<24)>>>0;
  };
  for(let x=0;x<area.width;x++){
    const counts=new Map<number,number>();let mode=0,most=0;
    for(let y=0;y<area.height;y++){
      const value=color(x,y),count=(counts.get(value)??0)+1;counts.set(value,count);
      if(counts.size>16)return;
      if(count>most){mode=value;most=count;}
    }
    if(most<area.height*.55)return;
    background.push(mode);let active=false;
    for(let y=0;y<area.height;y++)if(color(x,y)!==mode){rows[y]++;pixels++;active=true;}
    if(active)columns.push(x);
  }
  if(columns.length<2||columns.at(-1)!-columns[0]+1!==columns.length)return;
  const top=rows.findIndex(count=>count>0);let bottom=rows.length-1;
  while(bottom>=0&&!rows[bottom])bottom--;
  const height=bottom-top+1;
  if(top<0||height<16||height>area.height*.5||pixels<height*columns.length*.6)return;
  for(let y=top;y<=bottom;y++)if(!rows[y])return;
  return {top,bottom,left:columns[0],right:columns.at(-1)!,background};
}
