import type { Rect } from '../contracts';
import { PreviewPlacementManager } from './preview-placement';
export function intersects(a: Rect, b: Rect) { return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y; }
const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(v, max));
/** The selected hole is absent from the native window's drawing AND hit region.
 * Round outwards so fractional-DPI edges cannot intercept the selected content. */
export function selectionExterior(target: Rect, display: Rect): Rect[] {
  const left = clamp(Math.floor(target.x - display.x), 0, display.width);
  const top = clamp(Math.floor(target.y - display.y), 0, display.height);
  const right = clamp(Math.ceil(target.x + target.width - display.x), 0, display.width);
  const bottom = clamp(Math.ceil(target.y + target.height - display.y), 0, display.height);
  return [{x:0,y:0,width:display.width,height:top}, {x:0,y:bottom,width:display.width,height:display.height-bottom},
    {x:0,y:top,width:left,height:bottom-top}, {x:right,y:top,width:display.width-right,height:bottom-top}].filter(r => r.width > 0 && r.height > 0);
}
export function thumbnailBounds(target: Rect, area: Rect, toolbar: Rect): Rect {
  return new PreviewPlacementManager().place(target, area, toolbar).bounds;
}
