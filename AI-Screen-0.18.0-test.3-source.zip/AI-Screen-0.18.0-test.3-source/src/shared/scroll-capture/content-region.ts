import type { BitmapFrame } from './types';
import { verifyTranslation, type TranslationEvidence } from './translation-verifier';

export interface ContentRegion { top: number; bottom: number }

/** A conservative first-stage model: only full-width stationary edge bands.
 * A proposed body still has to pass unique motion and every-pixel verification.
 * Sidebars, moving overlays and changing edge bands are deliberately rejected. */
export function detectContentRegion(before: BitmapFrame, after: BitmapFrame): ContentRegion {
  const stride = before.width * 4, limit = Math.floor(before.height * .35);
  const edge = (bottom: boolean) => {
    let rows = 0, informative = 0;
    for (let i = 0; i < limit; i++) {
      const y = bottom ? before.height - i - 1 : i;
      const offset = y * stride;
      if (!sameBytes(before.data.subarray(offset, offset + stride), after.data.subarray(offset, offset + stride))) break;
      let low = 255, high = 0;
      for (let x = 0; x < stride; x += 4) {
        const v = before.data[offset + x]; low = Math.min(low, v); high = Math.max(high, v);
      }
      rows++; if (high - low >= 20) informative++;
    }
    // Hitting the search boundary means we did not observe its end.
    return rows >= 8 && rows < limit && informative >= 3 ? rows : 0;
  };
  return { top: edge(false), bottom: edge(true) };
}

export function verifyFixedRegion(before: BitmapFrame, after: BitmapFrame, region: ContentRegion): TranslationEvidence | undefined {
  const stride = before.width * 4;
  const band=(from:number,rows:number):TranslationEvidence|undefined=>!rows?{verification:'strict',ignoredPixels:0}:verifyTranslation(
    {width:before.width,height:rows,data:before.data.subarray(from*stride,(from+rows)*stride)},
    {width:after.width,height:rows,data:after.data.subarray(from*stride,(from+rows)*stride)},0,{requireAnchors:false});
  const top=band(0,region.top),bottom=band(before.height-region.bottom,region.bottom);
  if(top&&bottom)return {verification:top.verification==='localized'||bottom.verification==='localized'?'localized':'strict',ignoredPixels:top.ignoredPixels+bottom.ignoredPixels};
}

export function contentFrame(frame: BitmapFrame, region: ContentRegion): BitmapFrame {
  return { width: frame.width, height: frame.height - region.top - region.bottom,
    data: frame.data.subarray(region.top * frame.width * 4, (frame.height - region.bottom) * frame.width * 4) };
}

export function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
