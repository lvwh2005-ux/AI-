import type { Rect } from '../contracts';
import type { BitmapFrame, PixelRegion } from './types';
import type { ViewportBitmap } from './preview-viewport';

export interface PreviewSize { width: number; height: number }
export interface PreviewBundle {
  overview: BitmapFrame; detail: BitmapFrame;
  overviewRegion: PixelRegion; detailRegion: PixelRegion;
  viewportY?:number; coveredTop?:number;
  viewport?: ViewportBitmap;
}
export const PREVIEW_MAX_SIDE = 2048;
export const PREVIEW_INTERVAL_MS = 100;
// Must match the 32 DIP header, 28 DIP zoom row, 56 DIP footer and borders.
export function previewPixelSize(bounds: Pick<Rect, 'width' | 'height'>, scale: number): PreviewSize {
  const factor = Number.isFinite(scale) && scale > 0 ? scale : 1;
  const side = (value: number) => Math.max(1, Math.min(PREVIEW_MAX_SIDE, Math.round(value * factor)));
  return { width: side(Math.max(1, bounds.width - 2)), height: side(Math.max(1, bounds.height - 118)) };
}
export function validatePreviewSize(size: PreviewSize) {
  if (!size || ![size.width, size.height].every(value => Number.isSafeInteger(value) && value > 0 && value <= PREVIEW_MAX_SIDE)) throw new Error('预览尺寸无效');
}
