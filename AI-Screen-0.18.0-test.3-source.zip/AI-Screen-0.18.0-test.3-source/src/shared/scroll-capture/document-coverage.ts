export interface CoveragePlan {
  viewport: number; top: number; bottom: number;
  addedTop: number; addedBottom: number; overlapTop: number; overlapRows: number;
}

/** Signed body coordinates relative to the first viewport, independent of
 * screen/DIP coordinates. A plan is committed only after all pixel checks. */
export class DocumentCoverage {
  top=0; bottom:number; viewport=0;
  constructor(readonly viewportHeight:number) {
    if(!Number.isSafeInteger(viewportHeight)||viewportHeight<1)throw new Error('正文高度无效');
    this.bottom=viewportHeight;
  }
  plan(viewport:number):CoveragePlan|undefined {
    if(!Number.isSafeInteger(viewport))return;
    const end=viewport+this.viewportHeight,overlapTop=Math.max(this.top,viewport),overlapRows=Math.min(this.bottom,end)-overlapTop;
    if(!Number.isSafeInteger(end)||overlapRows<=0)return;
    return {viewport,top:Math.min(this.top,viewport),bottom:Math.max(this.bottom,end),
      addedTop:Math.max(0,this.top-viewport),addedBottom:Math.max(0,end-this.bottom),overlapTop,overlapRows};
  }
  commit(plan:CoveragePlan) { this.top=plan.top;this.bottom=plan.bottom;this.viewport=plan.viewport; }
}
