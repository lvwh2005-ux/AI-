/** Shared by all matching, body strips and history searches in one transition.
 * Original-pixel verification/copying stays separate and never loses precision. */
export const FRAME_ANALYSIS_LIMITS={samples:262_144,probes:131_072,verifications:64,matches:12} as const;
export class AnalysisWork {
  readonly used={samples:0,probes:0,verifications:0,matches:0};
  exhausted=false;
  remaining(kind:keyof typeof FRAME_ANALYSIS_LIMITS){return FRAME_ANALYSIS_LIMITS[kind]-this.used[kind];}
  take(kind:keyof typeof FRAME_ANALYSIS_LIMITS,count:number){
    if(!Number.isSafeInteger(count)||count<0||count>this.remaining(kind)){this.exhausted=true;return false;}
    this.used[kind]+=count;return true;
  }
}
