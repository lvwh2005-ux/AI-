/** Internal opt-in diagnostics. No pixels, window metadata or public IPC. */
export interface ProfileSpan {
  stage: string;
  startMs: number;
  durationMs: number;
  metrics?: Record<string, number>;
}
export class StageProfiler {
  constructor(private sink: (span: ProfileSpan) => void, private now = () => performance.now()) {}
  observe(spans: readonly ProfileSpan[]) { for (const span of spans) this.emit(span); }
  measure<T>(stage: string, run: () => T, metrics?: Record<string, number>): T {
    const startMs = this.now();
    try { return run(); }
    finally { this.emit({ stage, startMs, durationMs: this.now() - startMs, ...(metrics ? {metrics: {...metrics}} : {}) }); }
  }
  async measureAsync<T>(stage: string, run: () => Promise<T>, metrics?: Record<string, number>): Promise<T> {
    const startMs = this.now();
    try { return await run(); }
    finally { this.emit({ stage, startMs, durationMs: this.now() - startMs, ...(metrics ? {metrics: {...metrics}} : {}) }); }
  }
  private emit(span: ProfileSpan) {
    // An observer failure must never affect matching or a committed document.
    try { this.sink(span); } catch { /* Debug output is best effort. */ }
  }
}
export function profiled<T>(profiler: StageProfiler | undefined, stage: string, run: () => T, metrics?: Record<string, number>): T {
  return profiler ? profiler.measure(stage, run, metrics) : run();
}
