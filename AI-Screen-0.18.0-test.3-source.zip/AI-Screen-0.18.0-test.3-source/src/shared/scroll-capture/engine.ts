import { contentFrame, detectContentRegion, verifyFixedRegion, sameBytes, type ContentRegion } from './content-region';
import { VerticalMatcher } from './vertical-matcher';
import { StitchDocument } from './stitch-document';
import { cropFrame, proposeMotionRegion, type RegionProposal } from './motion-region';
import type { BitmapFrame, FrameMatcher, PixelRegion, StitchResult, MatchIssue } from './types';
import { LONGSHOT_LIMITS, LONGSHOT_MAX_WIDTH } from '../longshot-limits';
import { validatePreviewSize, type PreviewBundle, type PreviewSize } from './preview';
import {DocumentCoverage} from './document-coverage';
import {DocumentLocator} from './document-locator';
import {verifyTranslation, type TranslationEvidence} from './translation-verifier';
import { viewportRegion, type ViewportRequest, type ViewportBitmap } from './preview-viewport';
import { profiled, type StageProfiler } from './profiler';
import {AnalysisWork} from './analysis-work';
import type {PreviewSnapshot} from './preview-snapshot';
export type { BitmapFrame, StitchResult } from './types';

/** Orchestrates immutable matching and atomic document commits. No Electron/UI. */
export class ScrollCaptureEngine {
  private document:StitchDocument;
  private previous?: BitmapFrame;
  private region?: ContentRegion;
  private sourceSize?: { width: number; height: number };
  private contentRect?: PixelRegion;
  private proposal?: { proposal: RegionProposal; frame: BitmapFrame };
  private verifiedTransitions = 0;
  private lastOverlapRows?: number;
  private consecutiveRejections = 0;
  private coverage?:DocumentCoverage;
  private locator=new DocumentLocator();
  private previewAnchor:'top'|'bottom'='bottom';
  private maxHeight: number;
  private maxBytes: number;
  private matcher: FrameMatcher;
  private profiler?: StageProfiler;
  private work?:AnalysisWork;
  constructor(options: { maxHeight?: number; maxBytes?: number; matcher?: FrameMatcher; profiler?: StageProfiler;sharedDocument?:boolean } = {}) {
    this.document=new StitchDocument(options.sharedDocument);
    this.profiler = options.profiler;
    this.maxHeight = options.maxHeight ?? LONGSHOT_LIMITS.maxHeight; this.maxBytes = options.maxBytes ?? LONGSHOT_LIMITS.maxBytes;
    this.matcher = options.matcher ?? new VerticalMatcher({profiler: this.profiler});
    if (!Number.isSafeInteger(this.maxHeight) || this.maxHeight < 1 || !Number.isSafeInteger(this.maxBytes) || this.maxBytes < 4) throw new RangeError('长截图高度和内存上限必须是正整数');
  }
  push(frame: BitmapFrame): StitchResult {
    const work=new AnalysisWork();this.work=work;
    try{return this.pushFrame(frame);}finally{
      this.profiler?.observe([{stage:'frame-analysis-budget',startMs:performance.now(),durationMs:0,metrics:{...work.used,exhausted:Number(work.exhausted)}}]);
      this.work=undefined;
    }
  }
  private pushFrame(frame:BitmapFrame):StitchResult {
    if (!validFrame(frame)) return this.issue('rejected', '截图像素数据无效，请重新截图', 'invalid-frame');
    if (frame.width > LONGSHOT_MAX_WIDTH) return this.issue('limit', '选区宽度超过 8192 像素，请缩小范围', 'capacity');
    const bytes = frame.data.length;
    if (this.sourceSize && (frame.width !== this.sourceSize.width || frame.height !== this.sourceSize.height)) return this.issue('rejected', '截图范围或缩放比例发生变化，请重新开始长截图', 'size-changed');
    if (this.proposal) return this.issue('review', '已找到可滚动正文；请确认是否裁去固定栏，或保留原范围', 'body-review');
    if (this.contentRect) frame = cropFrame(frame, this.contentRect);
    if (!this.previous) {
      if (frame.height > this.maxHeight || bytes * 2 > this.maxBytes) return this.issue('limit', '截图超过长图的高度或内存上限，请缩小选区', 'capacity');
      profiled(this.profiler, 'initial-commit', () => {
        this.previous = { ...frame, data: new Uint8Array(frame.data) }; this.document.reset(frame);
      });
      this.sourceSize = { width: frame.width, height: frame.height };
      return this.connected('initial', frame.height);
    }
    if (frame.width !== this.previous.width || frame.height !== this.previous.height) return this.issue('rejected', '截图范围或缩放比例发生变化，请重新开始长截图', 'size-changed');
    if (profiled(this.profiler, 'exact-change-check', () => sameBytes(frame.data, this.previous!.data))) return this.connected('duplicate');
    const region = this.region ?? profiled(this.profiler, 'fixed-region-detect', () => detectContentRegion(this.previous!, frame));
    const fixed = profiled(this.profiler, 'fixed-region-verify', () => verifyFixedRegion(this.previous!, frame, region));
    if (!fixed) return this.issue('rejected', '固定头尾内容或边界发生变化，请重新框选正文', 'fixed-region-changed');
    const before = contentFrame(this.previous, region), after = contentFrame(frame, region);
    const motion = profiled(this.profiler, 'offset-match', () => this.matcher.match(before, after,this.work));
    if (motion.kind === 'rejected') {
      // Region changes are offered only before the first append. Never silently
      // change the coordinate model of an already accumulated image.
      if (this.allowProposal && !this.contentRect && !this.verifiedTransitions && this.document.bytes + this.previous.data.length + bytes <= this.maxBytes) {
        const proposal = profiled(this.profiler, 'motion-region-proposal', () => proposeMotionRegion(this.previous!, frame, this.profiler,this.work));
        if (proposal) {
          this.proposal = { proposal, frame: { ...frame, data: new Uint8Array(frame.data) } };
          return this.issue('review', '已找到可滚动正文；使用正文区域将裁去外围固定栏', 'body-review');
        }
      }
      const relocated=this.relocate(frame,after,region,fixed);
      if(relocated)return relocated;
      return this.issue('rejected', motion.reason, motion.reasonCode);
    }
    const evidence:TranslationEvidence={verification:fixed.verification==='localized'||motion.verification==='localized'?'localized':'strict',ignoredPixels:fixed.ignoredPixels+(motion.ignoredPixels??0)};
    if (motion.kind === 'stationary') return this.connected('duplicate',0,undefined,evidence);
    return this.move(frame,after,region,(this.coverage?.viewport??0)+motion.shift,motion.overlapRows,evidence);
  }
  private relocate(frame:BitmapFrame,body:BitmapFrame,region:ContentRegion,evidence:TranslationEvidence):StitchResult|undefined {
    const coverage=this.coverage;if(!coverage)return;
    const location=profiled(this.profiler,'history-locate',()=>this.locator.locate(this.document.view(region.top,coverage.bottom-coverage.top),body,this.document.revision,this.work));
    if(location?.kind==='ambiguous')return this.issue('rejected','已有长图中有多个相同视口，无法确定位置，请缩小滚动距离','ambiguous-overlap');
    if(location?.kind==='located')return this.move(frame,body,region,coverage.top+location.top,body.height,evidence,true);
  }
  private move(frame:BitmapFrame,body:BitmapFrame,region:ContentRegion,viewport:number,overlap:number,evidence:TranslationEvidence,relocated=false):StitchResult {
    const coverage=this.coverage??new DocumentCoverage(body.height),plan=coverage.plan(viewport);
    if(!plan)return this.issue('rejected','当前视口与已采集范围之间有缺口，请回到已采集位置','no-overlap');
    const from=plan.overlapTop-viewport,stride=body.width*4;
    const current={width:body.width,height:plan.overlapRows,data:body.data.subarray(from*stride,(from+plan.overlapRows)*stride)};
    const history=profiled(this.profiler,'history-verify',()=>verifyTranslation(this.document.view(region.top+plan.overlapTop-coverage.top,plan.overlapRows),current,0));
    if(!history){
      if(!relocated){const found=this.relocate(frame,body,region,evidence);if(found)return found;}
      return this.issue('rejected','已采集内容发生变化或位置不一致，未覆盖旧图；请回到可靠位置或重新框选','history-changed');
    }
    const rows=plan.addedTop+plan.addedBottom;
    const sourceBytes=this.sourceSize?this.sourceSize.width*this.sourceSize.height*4:frame.data.length;
    if(this.document.height+rows>this.maxHeight||this.document.bytes+sourceBytes+rows*frame.width*4>this.maxBytes)return this.issue('limit','长截图已达到高度或内存上限，请完成保存','capacity');
    // Verify against the whole covered intersection, not merely the last frame.
    // Only after that may origin, reference, edge bands or pixels change.
    const reference=profiled(this.profiler,'reference-copy',()=>({...frame,data:new Uint8Array(frame.data)})),delta=viewport-coverage.viewport;
    if(!this.region){this.document.lockEdges(region.top,region.bottom);this.region=region;}
    profiled(this.profiler,'stitch-rows',()=>{
      if(plan.addedTop)this.document.prepend(frame,region.top,plan.addedTop);
      if(plan.addedBottom)this.document.append(frame,frame.height-region.bottom-plan.addedBottom,plan.addedBottom);
    },{addedTop:plan.addedTop,addedBottom:plan.addedBottom});
    coverage.commit(plan);this.coverage=coverage;this.previous=reference;
    if(rows)this.verifiedTransitions++;this.lastOverlapRows=overlap;
    if(delta)this.previewAnchor=delta<0?'top':'bottom';
    return this.connected(rows?'appended':'duplicate',rows,overlap,
      {verification:evidence.verification==='localized'||history.verification==='localized'?'localized':'strict',ignoredPixels:Math.max(evidence.ignoredPixels,history.ignoredPixels)},
      {addedTop:plan.addedTop,addedBottom:plan.addedBottom,viewportDelta:delta,revisited:!rows,relocated});
  }
  confirmRegion(): StitchResult {
    if (!this.proposal || !this.previous) throw new Error('没有待确认的正文区域');
    const { proposal, frame } = this.proposal;
    const first = cropFrame(this.previous, proposal.rect), current = cropFrame(frame, proposal.rect);
    const rows=Math.abs(proposal.shift);
    if (first.height + rows > this.maxHeight || (first.data.length + current.data.length + rows * first.width * 4) > this.maxBytes) return this.issue('limit', '正文图片超过长图预算，请重新框选', 'capacity');
    this.document.reset(first);
    this.document.lockEdges(0,0);
    if(proposal.shift<0)this.document.prepend(current,0,rows);else this.document.append(current,current.height-rows,rows);
    this.coverage=new DocumentCoverage(first.height);this.coverage.commit(this.coverage.plan(proposal.shift)!);
    this.previewAnchor=proposal.shift<0?'top':'bottom';
    this.previous = current; this.region = {top:0,bottom:0}; this.contentRect = proposal.rect; this.proposal = undefined;
    this.verifiedTransitions = 1; this.lastOverlapRows = proposal.overlapRows;
    return this.connected('appended', rows, proposal.overlapRows,undefined,{addedTop:proposal.shift<0?rows:0,addedBottom:proposal.shift>0?rows:0,viewportDelta:proposal.shift});
  }
  keepRegion(): StitchResult {
    this.proposal = undefined;
    // Keep the snapshot and stop offering the same crop repeatedly.
    this.allowProposal = false;
    return this.issue('rejected', '已保留原范围；请重新框选避开固定栏，或完成已有部分','fixed-region-changed');
  }
  private allowProposal = true;
  bitmap() { return this.document.bitmap(); }
  previewSnapshot():PreviewSnapshot {
    const start=this.region&&this.coverage?this.region.top+this.coverage.viewport-this.coverage.top:0;
    const end=start+(this.coverage?.viewportHeight??this.document.height)+(this.region?.bottom??0);
    return{...this.document.snapshot(),coveredTop:this.coverage?.top??0,fixedTop:this.region?.top??0,
      followTop:this.coverage?.viewport===this.coverage?.top?0:start,followBottom:end,preferTop:this.previewAnchor==='top',
      viewportY:this.coverage?.viewport??0,detailTop:this.coverage?.viewport===this.coverage?.top?0:start,detailBottom:end};
  }
  preview(maxWidth = 240, maxHeight = 360) { return this.document.preview(maxWidth, maxHeight); }
  viewport(request: ViewportRequest): ViewportBitmap {
    const start = this.region && this.coverage ? this.region.top + this.coverage.viewport - this.coverage.top : 0;
    const region = viewportRegion({width:this.document.width,height:this.document.height,coveredTop:this.coverage?.top??0,
      fixedTop:this.region?.top??0,followTop:this.coverage?.viewport===this.coverage?.top?0:start,
      followBottom:start+(this.coverage?.viewportHeight??this.document.height)+(this.region?.bottom??0),preferTop:this.previewAnchor==='top'},request);
    return {frame:this.document.preview(request.pixels.width,request.pixels.height,region),region,
      sequence:request.sequence,zoom:request.settings.zoom,follow:request.settings.follow,
      coveredTop:this.coverage?.top??0,documentWidth:this.document.width,documentHeight:this.document.height};
  }
  previews(size: PreviewSize, view?: ViewportRequest): PreviewBundle {
    validatePreviewSize(size);
    const overviewRegion = {x:0,y:0,width:this.document.width,height:this.document.height};
    const height = Math.min(this.document.height, Math.max(1, Math.floor(this.document.width * size.height / size.width)));
    const viewportStart=this.region&&this.coverage?this.region.top+this.coverage.viewport-this.coverage.top:0;
    const end=viewportStart+(this.coverage?.viewportHeight??this.document.height)+(this.region?.bottom??0);
    const detailY=Math.max(0,Math.min(this.document.height-height,this.previewAnchor==='top'?(this.coverage?.viewport===this.coverage?.top?0:viewportStart):end-height));
    const detailRegion = {x:0,y:detailY,width:this.document.width,height};
    const overview=this.document.preview(size.width,size.height);
    const detail=detailRegion.height===overviewRegion.height ? overview : this.document.preview(size.width,size.height,detailRegion);
    return {overview,detail,overviewRegion,detailRegion,viewportY:this.coverage?.viewport??0,coveredTop:this.coverage?.top??0,
      ...(view?{viewport:this.viewport(view)}:{})};
  }
  clear() { this.document.clear(); this.previous = undefined; this.region = undefined; this.sourceSize = undefined; this.contentRect = undefined; this.proposal = undefined; this.allowProposal = true; this.verifiedTransitions = 0; this.lastOverlapRows = undefined; this.consecutiveRejections=0;this.coverage=undefined;this.locator.clear();this.previewAnchor='bottom'; }
  private connected(kind:'initial'|'appended'|'duplicate',rows=0,overlap?:number,evidence?:Pick<StitchResult,'verification'|'ignoredPixels'>,extra:Partial<StitchResult>={}):StitchResult {
    const recoveredAfter=this.consecutiveRejections;this.consecutiveRejections=0;
    return {...this.result(kind,undefined,rows,overlap),verification:evidence?.verification??'strict',ignoredPixels:evidence?.ignoredPixels??0,recoveredAfter:recoveredAfter||undefined,...extra};
  }
  private issue(kind: 'rejected'|'review'|'limit', reason: string, reasonCode?: MatchIssue) {
    if(kind==='rejected'&&this.previous)this.consecutiveRejections++;
    return {...this.result(kind,reason),reasonCode};
  }
  private result(kind: StitchResult['kind'], reason?: string, appendedRows = 0, overlapRows?: number): StitchResult {
    return { kind, width: this.document.width, height: this.document.height, appendedRows, reason, overlapRows,
      fixedTop: this.region?.top ?? 0, fixedBottom: this.region?.bottom ?? 0,
      regionCandidate: this.proposal ? { ...this.proposal.proposal.rect } : undefined,
      contentRect: this.contentRect ? { ...this.contentRect } : undefined,
      verifiedTransitions: this.verifiedTransitions, lastOverlapRows: this.lastOverlapRows, consecutiveRejections:this.consecutiveRejections,
      viewportY:this.coverage?.viewport??0,coveredTop:this.coverage?.top??0,coveredBottom:this.coverage?.bottom??this.previous?.height??0 };
  }
}
function validFrame(frame: BitmapFrame) {
  return !!frame && Number.isSafeInteger(frame.width) && Number.isSafeInteger(frame.height) && frame.width > 0 && frame.height > 0
    && frame.data instanceof Uint8Array && Number.isSafeInteger(frame.width * frame.height * 4) && frame.data.length === frame.width * frame.height * 4;
}
