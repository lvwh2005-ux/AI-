import type { Rect } from '../contracts';

type Side = 'right' | 'left' | 'top' | 'bottom' | 'inset';
export interface PreviewPlacement {
  bounds: Rect;
  side: Side;
  mode: 'outside' | 'overlay' | 'constrained';
  spaces: { left: number; right: number; top: number; bottom: number };
  overlapsToolbar: boolean;
  overlapsFocus: boolean;
}
interface Candidate { bounds: Rect; side: Side; score: number }
const GAP = 12;
const TOOLBAR_GAP = 8;
const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(value, high));
const right = (r: Rect) => r.x + r.width;
const bottom = (r: Rect) => r.y + r.height;

function overlap(a: Rect, b: Rect): number {
  return Math.max(0, Math.min(right(a), right(b)) - Math.max(a.x, b.x))
    * Math.max(0, Math.min(bottom(a), bottom(b)) - Math.max(a.y, b.y));
}
function validate(rect: Rect) {
  if (!rect || !Object.values(rect).every(Number.isFinite) || rect.width <= 0 || rect.height <= 0
    || !Number.isFinite(right(rect)) || !Number.isFinite(bottom(rect))) throw new Error('预览布局范围无效');
}
function integerArea(rect: Rect): Rect {
  const x = Math.ceil(rect.x), y = Math.ceil(rect.y);
  const width = Math.floor(right(rect)) - x, height = Math.floor(bottom(rect)) - y;
  if (width < 1 || height < 1) throw new Error('显示器没有可用的预览空间');
  return { x, y, width, height };
}
export function previewWorkArea(workArea: Rect): Rect {
  validate(workArea);
  const screen = integerArea(workArea);
  // Leave room for Windows to round frameless DIP extents outward.
  const mx = Math.min(2, Math.floor((screen.width - 1) / 2));
  const my = Math.min(2, Math.floor((screen.height - 1) / 2));
  return { x: screen.x + mx, y: screen.y + my, width: screen.width - mx * 2, height: screen.height - my * 2 };
}
/** Maximal free rectangles, not a pixel grid. Overlapping results are harmless:
 * every candidate must fit in one free rectangle and is scored independently. */
function subtract(rect: Rect, obstacle: Rect): Rect[] {
  if (!overlap(rect, obstacle)) return [rect];
  return [
    { ...rect, height: Math.floor(obstacle.y) - rect.y },
    { ...rect, y: Math.ceil(bottom(obstacle)), height: bottom(rect) - Math.ceil(bottom(obstacle)) },
    { ...rect, width: Math.floor(obstacle.x) - rect.x },
    { ...rect, x: Math.ceil(right(obstacle)), width: right(rect) - Math.ceil(right(obstacle)) },
  ].filter(value => value.width > 0 && value.height > 0);
}

/** All geometry is global screen DIP, including negative monitor origins.
 * Prefer a readable exterior window; only use a protected overlay when no side
 * can hold the minimum usable size. This never changes the capture rectangle. */
export class PreviewPlacementManager {
  place(target: Rect, workArea: Rect, toolbar: Rect, preferredSize?: Pick<Rect, 'width' | 'height'>): PreviewPlacement {
    [target, workArea, toolbar].forEach(validate);
    const area = previewWorkArea(workArea);
    if (preferredSize && ![preferredSize.width, preferredSize.height].every(value => Number.isFinite(value) && value > 0)) throw new Error('预览尺寸无效');
    const desired = {
      width: preferredSize ? Math.min(area.width, Math.max(1, Math.round(preferredSize.width))) : Math.min(390, Math.max(280, Math.round(area.width * .25)), area.width),
      height: Math.min(area.height, Math.max(1, Math.round(preferredSize?.height ?? Math.max(360, target.height + 48)))),
    };
    const minimum = { width: Math.min(240, desired.width), height: Math.min(240, desired.height) };
    const spaces = {
      left: clamp(Math.floor(target.x - GAP) - area.x, 0, area.width),
      right: clamp(right(area) - Math.ceil(right(target) + GAP), 0, area.width),
      top: clamp(Math.floor(target.y - GAP) - area.y, 0, area.height),
      bottom: clamp(bottom(area) - Math.ceil(bottom(target) + GAP), 0, area.height),
    };
    const avoidToolbar = {
      x: toolbar.x - TOOLBAR_GAP, y: toolbar.y - TOOLBAR_GAP,
      width: toolbar.width + 2 * TOOLBAR_GAP, height: toolbar.height + 2 * TOOLBAR_GAP,
    };
    // Reserve the central scrolling area, rather than merely a one-pixel point.
    const focus = {
      x: target.x + target.width * .3, y: target.y + target.height * .3,
      width: target.width * .4, height: target.height * .4,
    };
    const zones: { side: Side; rect: Rect }[] = [
      { side: 'right', rect: { ...area, x: right(area) - spaces.right, width: spaces.right } },
      { side: 'left', rect: { ...area, width: spaces.left } },
      { side: 'top', rect: { ...area, height: spaces.top } },
      { side: 'bottom', rect: { ...area, y: bottom(area) - spaces.bottom, height: spaces.bottom } },
    ];
    const exterior = zones.flatMap(({ side, rect }) => rect.width > 0 && rect.height > 0
      ? subtract(rect, avoidToolbar).map(free => this.candidate(free, side, desired, target, area)) : []);
    const usable = (candidate: Candidate) => candidate.bounds.width >= minimum.width && candidate.bounds.height >= minimum.height;
    const choose = (candidates: Candidate[]) => candidates.sort((a, b) => b.score - a.score)[0];
    const outside = choose(exterior.filter(usable));
    if (outside) return this.result(outside, 'outside', spaces, toolbar, focus);

    const free = subtract(area, avoidToolbar);
    const avoidFocus = { x: focus.x - 2, y: focus.y - 2, width: focus.width + 4, height: focus.height + 4 };
    const aroundFocus = free.flatMap(rect => subtract(rect, avoidFocus));
    const overlayCandidates = aroundFocus.map(rect => this.candidate(rect, 'inset', desired, target, area));
    const overlay = choose(overlayCandidates.filter(usable));
    if (overlay) return this.result(overlay, 'overlay', spaces, toolbar, focus);
    // Very small work areas may require a compact preview. Still keep controls
    // and the scrolling centre clear whenever any such rectangle exists.
    const compact = choose([...exterior, ...overlayCandidates]);
    if (compact) return this.result(compact, 'constrained', spaces, toolbar, focus);
    const remaining = choose(free.map(rect => this.candidate(rect, 'inset', desired, target, area)));
    return this.result(remaining ?? this.candidate(area, 'inset', desired, target, area), 'constrained', spaces, toolbar, focus);
  }

  private candidate(free: Rect, side: Side, desired: { width: number; height: number }, target: Rect, area: Rect): Candidate {
    const width = Math.min(desired.width, free.width);
    let height = Math.min(desired.height, free.height);
    if (side === 'right' || side === 'left') {
      const alignedHeight = Math.floor(bottom(target)) - free.y;
      if (alignedHeight >= Math.min(240, height)) height = Math.min(height, alignedHeight);
    }
    const x = side === 'right' ? free.x : side === 'left' ? right(free) - width
      : clamp(Math.floor(right(target)) - width, free.x, right(free) - width);
    const y = side === 'top' ? bottom(free) - height : side === 'bottom' ? free.y
      : clamp(Math.floor(bottom(target)) - height, free.y, bottom(free) - height);
    const bounds = { x, y, width, height };
    const readability = .65 * width / desired.width + .35 * height / desired.height;
    const obscured = overlap(bounds, target) / (desired.width * desired.height);
    const dx = Math.max(target.x - right(bounds), bounds.x - right(target), 0);
    const dy = Math.max(target.y - bottom(bounds), bounds.y - bottom(target), 0);
    const distance = Math.hypot(dx, dy) / Math.hypot(area.width, area.height);
    const preference = { right: 12, left: 8, bottom: 4, top: 0, inset: 0 }[side];
    return { bounds, side, score: readability * 1000 - obscured * 200 - distance * 20 + preference };
  }

  private result(candidate: Candidate, mode: PreviewPlacement['mode'], spaces: PreviewPlacement['spaces'], toolbar: Rect, focus: Rect): PreviewPlacement {
    return { bounds: candidate.bounds, side: candidate.side, mode, spaces,
      overlapsToolbar: overlap(candidate.bounds, toolbar) > 0, overlapsFocus: overlap(candidate.bounds, focus) > 0 };
  }
}
