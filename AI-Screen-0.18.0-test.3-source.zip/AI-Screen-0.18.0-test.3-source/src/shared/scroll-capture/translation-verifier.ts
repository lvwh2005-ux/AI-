import {pixelRow, type PixelFrame, type PixelRegion} from './types';

export interface TranslationEvidence { verification: 'strict'|'localized'; ignoredPixels: number }

/** Full-pixel verification first. The fallback admits one small, bounded patch
 * only; it never masks entire rows/columns or changes the output pixels. */
export function verifyTranslation(before: PixelFrame, after: PixelFrame, shift: number,
  options: {allowLocalized?: boolean; requireAnchors?: boolean} = {}): TranslationEvidence | undefined {
  const width = before.width, rows = before.height - Math.abs(shift);
  if (width !== after.width || before.height !== after.height || !Number.isInteger(shift) || rows <= 0) return;
  const previousTop = Math.max(0, shift), currentTop = Math.max(0, -shift), pixels = width * rows;
  const strictDifference = pixels * 3 * .35, strictChanged = Math.floor(pixels * .0002);
  const localBudget = Math.max(32, Math.min(1024, Math.floor(pixels * .002)));
  let difference = 0, changed = 0, left = width, right = -1, top = rows, bottom = -1;
  let lastA:Uint8Array|undefined,lastB:Uint8Array|undefined,wordsA:Uint32Array|undefined,wordsB:Uint32Array|undefined;
  for (let y = 0; y < rows; y++) {
    const ar=pixelRow(before,previousTop+y),br=pixelRow(after,currentTop+y),ad=ar.data,bd=br.data;
    // Equality has identical meaning on either endianness. Skip arithmetic for
    // exact BGRA pixels; retain all original tolerances for unequal pixels.
    // Segment views are reused across rows and unaligned inputs use the byte path.
    if(ad!==lastA){lastA=ad;wordsA=ad.byteOffset%4===0&&ad.byteLength%4===0?new Uint32Array(ad.buffer,ad.byteOffset,ad.byteLength/4):undefined;}
    if(bd!==lastB){lastB=bd;wordsB=bd.byteOffset%4===0&&bd.byteLength%4===0?new Uint32Array(bd.buffer,bd.byteOffset,bd.byteLength/4):undefined;}
    const aw=ar.offset%4===0?wordsA:undefined,bw=br.offset%4===0?wordsB:undefined;
    let a=ar.offset,b=br.offset;
    for (let x = 0; x < width; x++, a += 4, b += 4) {
      if(aw&&bw&&aw[a>>>2]===bw[b>>>2])continue;
      const blue = Math.abs(ad[a] - bd[b]), green = Math.abs(ad[a+1] - bd[b+1]), red = Math.abs(ad[a+2] - bd[b+2]);
      difference += blue + green + red;
      if (Math.max(blue,green,red) > 6 || Math.abs(ad[a+3] - bd[b+3]) > 1) {
        changed++; left = Math.min(left,x); right = Math.max(right,x); top = Math.min(top,y); bottom = Math.max(bottom,y);
      }
      if (changed > Math.max(strictChanged,localBudget) || difference > strictDifference + localBudget * 765) return;
    }
  }
  if (changed <= strictChanged && difference <= strictDifference) return {verification:'strict',ignoredPixels:0};
  const anchors = options.requireAnchors !== false;
  if (options.allowLocalized === false || width < (anchors ? 64 : 32) || rows < (anchors ? 96 : 24) || !changed || changed > localBudget) return;
  const box: PixelRegion = {x:left,y:top,width:right-left+1,height:bottom-top+1};
  const guard = Math.min(12,Math.max(4,Math.floor(rows * .03)));
  if (box.width > Math.max(8,Math.min(48,Math.floor(width * .08)))
    || box.height > Math.max(16,Math.min(64,Math.floor(rows * .12)))
    || box.y < guard || box.y + box.height > rows - guard) return;
  let patchDifference = 0;
  for (let y=box.y;y<box.y+box.height;y++) {
    const ar=pixelRow(before,previousTop+y),br=pixelRow(after,currentTop+y);
    for (let x=box.x;x<box.x+box.width;x++)for(let c=0;c<3;c++) patchDifference+=Math.abs(ar.data[ar.offset+x*4+c]-br.data[br.offset+x*4+c]);
  }
  // Distributed low-contrast changes cannot hide behind one high-contrast dot.
  if (difference - patchDifference > (pixels - box.width * box.height) * 3 * .35) return;
  if (anchors && !distributedAnchors(before,after,previousTop,currentTop,rows,box)) return;
  return {verification:'localized',ignoredPixels:changed};
}

/** Independent, stable texture in at least three vertical and two horizontal
 * zones. No candidate can rely on the changing patch as its only landmark. */
function distributedAnchors(before: PixelFrame, after: PixelFrame, aTop:number,bTop:number,rows:number,box:PixelRegion) {
  const counts = new Uint16Array(12), width = before.width;
  const dx=Math.max(1,Math.floor(width/128)),dy=Math.max(1,Math.floor(rows/96));
  for(let y=1;y<rows;y+=dy){
    const ar=pixelRow(before,aTop+y),br=pixelRow(after,bTop+y),prior=pixelRow(after,bTop+y-1);
    for(let x=1;x<width;x+=dx){
    if(x>=box.x-2&&x<box.x+box.width+2&&y>=box.y-2&&y<box.y+box.height+2)continue;
    const a=ar.offset+x*4,b=br.offset+x*4;
    let stable=true,contrast=0;
    for(let c=0;c<3;c++){
      if(Math.abs(ar.data[a+c]-br.data[b+c])>6)stable=false;
      contrast=Math.max(contrast,Math.abs(br.data[b+c]-br.data[b-4+c]),Math.abs(br.data[b+c]-prior.data[prior.offset+x*4+c]));
    }
    if(stable&&contrast>=20)counts[Math.min(3,Math.floor(y*4/rows))*3+Math.min(2,Math.floor(x*3/width))]++;
    }
  }
  const horizontal=new Set<number>(),vertical=new Set<number>();
  for(let i=0;i<counts.length;i++)if(counts[i]>=4){horizontal.add(i%3);vertical.add(Math.floor(i/3));}
  return horizontal.size>=2&&vertical.size>=3;
}
