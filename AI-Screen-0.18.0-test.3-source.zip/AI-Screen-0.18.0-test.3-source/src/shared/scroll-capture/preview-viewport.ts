import { z } from 'zod';
import type { BitmapFrame, PixelRegion } from './types';
import { validatePreviewSize, type PreviewSize } from './preview';

export const PREVIEW_ZOOM_PRESETS = [.5, .75, 1, 1.25] as const;
export const previewViewSchema = z.object({
  zoom: z.number().finite().min(.25).max(4), follow: z.boolean(),
  x: z.number().finite().min(0).max(100000), y: z.number().finite().min(0).max(100000),
  coveredTop: z.number().int().min(-30000).max(30000),
  viewportDip: z.object({ width: z.number().finite().positive().max(8192), height: z.number().finite().positive().max(8192) }).strict(),
}).strict();
export type PreviewViewInput = z.infer<typeof previewViewSchema>;
export interface PreviewViewRequest { sequence: number; view: PreviewViewInput | null }
export interface ViewportRequest { sequence: number; settings: PreviewViewInput; pixels: PreviewSize; visiblePixels?: PreviewSize }
export interface ViewportMetadata {
  sequence: number; region: PixelRegion; zoom: number; follow: boolean;
  coveredTop: number; documentWidth: number; documentHeight: number;
}
export interface ViewportBitmap extends ViewportMetadata { frame: BitmapFrame }
export interface PreviewDocument {
  width: number; height: number; coveredTop: number; fixedTop: number;
  followTop: number; followBottom: number; preferTop: boolean;
}
const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(v, max));
export const clampPreviewZoom = (zoom: number) => Math.round(clamp(Number.isFinite(zoom) ? zoom : 1, .25, 4) * 1000) / 1000;
export function wheelPreviewZoom(zoom: number, delta: number, mode = 0) {
  const pixels = delta * (mode === 1 ? 16 : mode === 2 ? 240 : 1);
  return clampPreviewZoom(zoom * Math.exp(-clamp(pixels, -240, 240) * .002));
}
/** 100% maps one source pixel to one physical display pixel. */
export function previewCssScale(zoom: number, dpi: number) { return zoom / (Number.isFinite(dpi) && dpi > 0 ? dpi : 1); }
export function zoomScroll(document: PreviewSize, viewport: PreviewSize, source: {x:number;y:number}, anchor: {x:number;y:number}, ratio: number) {
  const width = document.width * ratio, height = document.height * ratio;
  const margin = Math.max(0, (viewport.width - width) / 2);
  return { x: clamp(source.x * ratio + margin - anchor.x, 0, Math.max(0, width - viewport.width)),
    y: clamp(source.y * ratio - anchor.y, 0, Math.max(0, height - viewport.height)) };
}
export function viewportRegion(document: PreviewDocument, request: ViewportRequest): PixelRegion {
  validatePreviewSize(request.pixels); previewViewSchema.parse(request.settings);
  if (![document.width,document.height].every(v=>Number.isSafeInteger(v)&&v>0)) throw new Error('尚无可预览的长图');
  const view = request.settings;
  const visible=request.visiblePixels??request.pixels;
  if(![visible.width,visible.height].every(value=>Number.isSafeInteger(value)&&value>0&&value<=32768))throw new Error('可见区域尺寸无效');
  const width = Math.min(document.width, Math.max(1, Math.ceil(visible.width / view.zoom)));
  const height = Math.min(document.height, Math.max(1, Math.ceil(visible.height / view.zoom)));
  const y = view.follow ? document.preferTop ? document.followTop : document.followBottom - height
    : view.y + (view.y >= document.fixedTop ? view.coveredTop - document.coveredTop : 0);
  return { x: clamp(Math.floor(view.x),0,document.width-width), y: clamp(Math.floor(y),0,document.height-height), width, height };
}
