import { z } from 'zod';

export const annotationTools = ['pen', 'arrow', 'rectangle', 'text'] as const;
export type AnnotationTool = typeof annotationTools[number];
const pointSchema = z.object({ x: z.number().finite().min(0).max(1), y: z.number().finite().min(0).max(1) }).strict();
const base = {
  id: z.string().regex(/^[a-zA-Z0-9_-]{1,80}$/),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  width: z.number().finite().min(1).max(20),
};
export const annotationSchema = z.discriminatedUnion('kind', [
  z.object({ ...base, kind: z.literal('pen'), points: z.array(pointSchema).min(1).max(4000) }).strict(),
  z.object({ ...base, kind: z.literal('arrow'), start: pointSchema, end: pointSchema }).strict(),
  z.object({ ...base, kind: z.literal('rectangle'), start: pointSchema, end: pointSchema }).strict(),
  z.object({ ...base, kind: z.literal('text'), position: pointSchema, text: z.string().trim().min(1).max(1000), fontSize: z.number().finite().min(12).max(72) }).strict(),
]);
export type Annotation = z.infer<typeof annotationSchema>;
export const annotationsSchema = z.array(annotationSchema).max(200)
  .refine((items) => new Set(items.map((item) => item.id)).size === items.length, '标注 ID 不能重复')
  .refine((items) => items.reduce((count, item) => count + (item.kind === 'pen' ? item.points.length : 2), 0) <= 20_000, '标注点过多，请清除部分标注')
  .refine((items) => items.reduce((count, item) => count + (item.kind === 'text' ? item.text.length : 0), 0) <= 20_000, '标注文字过多');

export interface AnnotationPoint { x: number; y: number }
export interface AnnotationSize { width: number; height: number }
export interface AnnotationGeometry {
  paths: AnnotationPoint[][];
  dots?: AnnotationPoint[];
  text?: { position: AnnotationPoint; lines: string[]; fontSize: number };
}

export function normalizeAnnotationPoint(point: AnnotationPoint, rect: AnnotationPoint & AnnotationSize): AnnotationPoint {
  if (![point.x, point.y, rect.x, rect.y, rect.width, rect.height].every(Number.isFinite) || rect.width <= 0 || rect.height <= 0) throw new Error('无效的标注坐标');
  return { x: Math.max(0, Math.min(1, (point.x - rect.x) / rect.width)), y: Math.max(0, Math.min(1, (point.y - rect.y) / rect.height)) };
}

// This pure function also runs in the isolated compositor. Keep it self-contained
// so preview and exported PNG share exactly the same annotation geometry.
export function annotationGeometry(annotation: Annotation, size: AnnotationSize): AnnotationGeometry {
  const project = (point: AnnotationPoint) => ({ x: point.x * size.width, y: point.y * size.height });
  if (annotation.kind === 'pen') {
    const points = annotation.points.map(project);
    return points.length === 1 ? { paths: [], dots: points } : { paths: [points] };
  }
  if (annotation.kind === 'text') return { paths: [], text: { position: project(annotation.position), lines: annotation.text.split(/\r?\n/), fontSize: annotation.fontSize } };
  const start = project(annotation.start), end = project(annotation.end);
  if (annotation.kind === 'rectangle') return { paths: [[start, { x: end.x, y: start.y }, end, { x: start.x, y: end.y }, start]] };
  const dx = end.x - start.x, dy = end.y - start.y, length = Math.hypot(dx, dy);
  if (length === 0) return { paths: [], dots: [start] };
  const head = Math.min(Math.max(10, annotation.width * 4), length * 0.6), angle = Math.atan2(dy, dx), spread = Math.PI / 6;
  return { paths: [[start, end], [
    { x: end.x - head * Math.cos(angle - spread), y: end.y - head * Math.sin(angle - spread) },
    end,
    { x: end.x - head * Math.cos(angle + spread), y: end.y - head * Math.sin(angle + spread) },
  ]] };
}

export interface AnnotationBitmapInput { image: string; size: AnnotationSize; annotations: Annotation[] }

// Only invoked with trusted application code inside a sandboxed, hidden renderer.
// User text is passed as data to fillText; it never becomes HTML or JavaScript.
export async function drawAnnotatedBitmap(input: AnnotationBitmapInput, geometry: typeof annotationGeometry): Promise<string> {
  const image = new Image();
  image.src = input.image;
  await image.decode();
  const canvas = document.createElement('canvas');
  canvas.width = image.naturalWidth; canvas.height = image.naturalHeight;
  const context = canvas.getContext('2d');
  if (!context || !canvas.width || !canvas.height) throw new Error('无法绘制截图标注');
  try {
    context.drawImage(image, 0, 0);
    context.setTransform(canvas.width / input.size.width, 0, 0, canvas.height / input.size.height, 0, 0);
    context.lineCap = 'round'; context.lineJoin = 'round';
    for (const annotation of input.annotations) {
      const shape = geometry(annotation, input.size);
      context.strokeStyle = annotation.color; context.fillStyle = annotation.color; context.lineWidth = annotation.width;
      for (const points of shape.paths) {
        context.beginPath();
        points.forEach((point, index) => index ? context.lineTo(point.x, point.y) : context.moveTo(point.x, point.y));
        context.stroke();
      }
      for (const point of shape.dots ?? []) {
        context.beginPath(); context.arc(point.x, point.y, annotation.width / 2, 0, Math.PI * 2); context.fill();
      }
      if (shape.text) {
        const { position, lines, fontSize } = shape.text;
        context.font = `${fontSize}px "Segoe UI", "Microsoft YaHei", sans-serif`;
        context.textBaseline = 'alphabetic';
        lines.forEach((line, index) => context.fillText(line, position.x, position.y + fontSize + index * fontSize * 1.35));
      }
    }
    return canvas.toDataURL('image/png');
  } finally {
    // Drop the in-memory screenshot as soon as the PNG has been returned.
    image.src = ''; canvas.width = 0; canvas.height = 0;
  }
}
