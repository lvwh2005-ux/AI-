export const captureModes = ['screenshot', 'longshot', 'record', 'ai-screen'] as const;
export type CaptureMode = typeof captureModes[number];
export interface ModeCapability { mode: CaptureMode; available: boolean; explanation: string }
export const modeCapabilities: readonly ModeCapability[] = [
  { mode: 'screenshot', available: true, explanation: '单击选择窗口，拖动自由框选' },
  { mode: 'longshot', available: false, explanation: '滚动采集模块尚未接入。可先选择目标区域；目前不会执行滚动或生成长图。' },
  { mode: 'record', available: false, explanation: '视频编码与采集模块尚未接入。可先选择录制范围；目前不会开始录制。' },
  { mode: 'ai-screen', available: true, explanation: '分析鼠标所在窗口或当前显示器，无需精确框选' },
];
