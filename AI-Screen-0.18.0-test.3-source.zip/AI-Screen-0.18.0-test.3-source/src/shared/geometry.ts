import type { Rect } from './contracts';

export function selection(a: { x: number; y: number }, b: { x: number; y: number }): Rect {
  return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: Math.abs(a.x - b.x), height: Math.abs(a.y - b.y) };
}

// CSS / display DIP coordinates are converted using the actual captured bitmap size.
// This also covers fractional Windows scaling and thumbnails smaller than requested.
export function toPixelRect(rect: Rect, display: { width: number; height: number }, bitmap: { width: number; height: number }): Rect {
  if (![rect.x, rect.y, rect.width, rect.height, display.width, display.height, bitmap.width, bitmap.height].every(Number.isFinite)
    || rect.x < 0 || rect.y < 0 || rect.width <= 0 || rect.height <= 0
    || display.width <= 0 || display.height <= 0 || bitmap.width <= 0 || bitmap.height <= 0
    || rect.x >= display.width || rect.y >= display.height) throw new Error('无效的截图选区');
  const x = Math.floor(rect.x * bitmap.width / display.width);
  const y = Math.floor(rect.y * bitmap.height / display.height);
  const right = Math.min(bitmap.width, Math.ceil((rect.x + rect.width) * bitmap.width / display.width));
  const bottom = Math.min(bitmap.height, Math.ceil((rect.y + rect.height) * bitmap.height / display.height));
  return { x, y, width: right - x, height: bottom - y };
}

export function toolbarPosition(rect: Rect, viewport: { width: number; height: number }, size = { width: 500, height: 54 }) {
  const inset = Math.min(8, viewport.width / 2, viewport.height / 2);
  const left = Math.max(inset, Math.min(rect.x + rect.width - size.width, viewport.width - size.width - inset));
  const below = rect.y + rect.height + 12;
  const desiredTop = below + size.height <= viewport.height - inset ? below : rect.y - size.height - 12;
  return {
    left,
    top: Math.max(inset, Math.min(desiredTop, viewport.height - size.height - inset)),
  };
}

export interface CaptureDisplay {
  id: string; label: string; bounds: Rect; scaleFactor: number;
}

// Local DIPs index the bitmap; a negative desktop origin only places the window.
export function captureDisplayPlan(displays: readonly CaptureDisplay[], preferredId?: string) {
  return [...displays].sort((a, b) => Number(b.id === preferredId) - Number(a.id === preferredId)).map((display) => ({
    ...display, bounds: { ...display.bounds },
    pixelSize: {
      width: Math.max(1, Math.round(display.bounds.width * display.scaleFactor)),
      height: Math.max(1, Math.round(display.bounds.height * display.scaleFactor)),
    },
  }));
}

export const resizeHandles = ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w'] as const;
export type ResizeHandle = typeof resizeHandles[number];
export function adjustSelection(rect: Rect, mode: 'move' | ResizeHandle, delta: { x: number; y: number }, viewport: { width: number; height: number }): Rect {
  const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(value, high));
  if (mode === 'move') return { ...rect, x: clamp(rect.x + delta.x, 0, viewport.width - rect.width), y: clamp(rect.y + delta.y, 0, viewport.height - rect.height) };
  let left = rect.x, top = rect.y, right = rect.x + rect.width, bottom = rect.y + rect.height;
  if (mode.includes('w')) left = clamp(left + delta.x, 0, right - 4);
  if (mode.includes('e')) right = clamp(right + delta.x, left + 4, viewport.width);
  if (mode.includes('n')) top = clamp(top + delta.y, 0, bottom - 4);
  if (mode.includes('s')) bottom = clamp(bottom + delta.y, top + 4, viewport.height);
  return { x: left, y: top, width: right - left, height: bottom - top };
}
