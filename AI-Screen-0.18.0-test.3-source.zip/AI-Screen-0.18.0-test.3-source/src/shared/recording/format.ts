import type {RecordingOptions} from './contracts';

export const RECORDING_MIMES=['video/webm;codecs=vp8','video/webm;codecs=vp9','video/mp4;codecs=avc1.42001E'] as const;
export function recordingMime(options:Pick<RecordingOptions,'mimeType'>,audio:boolean){
  return options.mimeType+(audio?(options.mimeType.startsWith('video/mp4')?',mp4a.40.2':',opus'):'');
}
export function recordingFormat(mimeType:string){return mimeType.startsWith('video/mp4')?{extension:'mp4',label:'MP4'}as const:{extension:'webm',label:'WebM'}as const;}
