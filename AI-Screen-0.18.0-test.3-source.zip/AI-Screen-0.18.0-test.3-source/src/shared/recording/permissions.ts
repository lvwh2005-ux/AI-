/** 44.x uses media + []; later runtimes use display-capture. Named camera/mic types are denied. */
export function recordingDisplayPermission(permission:string,details:{isMainFrame:boolean;requestingUrl:string;mediaTypes?:unknown},expectedURL:string,audio=false):boolean{
  if(!details.isMainFrame||details.requestingUrl!==expectedURL)return false;
  if(permission==='media')return Array.isArray(details.mediaTypes)&&details.mediaTypes.length===0;
  return permission==='display-capture'&&Array.isArray(details.mediaTypes)&&details.mediaTypes.every(type=>type==='video'||(audio&&type==='audio'));
}
