import type { RecordingTarget } from './contracts';
import { RecordingError } from './contracts';

/** Map display-local DIP edges against the actual media bitmap, never desktop origins. */
export function recordingPixelRect(target: RecordingTarget, media: { width: number; height: number }) {
  const r = target.rect, d = target.displayBounds;
  if (![r.x,r.y,r.width,r.height,d.width,d.height,media.width,media.height].every(Number.isFinite)
    || d.width <= 0 || d.height <= 0 || media.width < 1 || media.height < 1 || !Number.isSafeInteger(media.width) || !Number.isSafeInteger(media.height)
    || r.x < 0 || r.y < 0 || r.width <= 0 || r.height <= 0 || r.x + r.width > d.width || r.y + r.height > d.height) {
    throw new RecordingError('invalid-region', '录屏选区超出所选显示器');
  }
  const x = Math.floor(r.x * media.width / d.width), y = Math.floor(r.y * media.height / d.height);
  const right = Math.min(media.width, Math.ceil((r.x + r.width) * media.width / d.width));
  const bottom = Math.min(media.height, Math.ceil((r.y + r.height) * media.height / d.height));
  if (right - x > 8192 || bottom - y > 8192 || (right-x)*(bottom-y)>3840*2160) throw new RecordingError('capacity', '录屏选区超过 4K 像素预算，请缩小范围');
  return { x, y, width: right-x, height: bottom-y };
}
export function recordingSource<T extends { display_id: string }>(sources: readonly T[], displayId: string): T {
  const matches = sources.filter(source => source.display_id === displayId);
  if (matches.length !== 1) throw new RecordingError('source-missing', '无法唯一匹配所选显示器，未切换到其他屏幕');
  return matches[0];
}
