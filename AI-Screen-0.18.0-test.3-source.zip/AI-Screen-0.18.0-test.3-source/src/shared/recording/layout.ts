import type {Rect} from '../contracts';
// Windows enforces a 56-DIP minimum height at 100% scaling even for
// transparent frameless windows. Use it consistently at every scale.
export const RECORDING_TOOLBAR_SIZE=Object.freeze({prepareWidth:424,activeWidth:328,height:56,expandedHeight:284});
export function recordingControlsBounds(target:Rect,area:Rect,width=560,height=54):Rect{
  width=Math.min(width,area.width);height=Math.min(height,area.height);
  const x=Math.max(area.x,Math.min(target.x+target.width-width,area.x+area.width-width));
  const y=Math.max(area.y,Math.min(target.y,area.y+area.height-height));
  const candidates=[{x,y:target.y+target.height+10,width,height},{x,y:target.y-height-10,width,height},
    {x:target.x+target.width+10,y,width,height},{x:target.x-width-10,y,width,height}];
  return candidates.find(r=>r.x>=area.x&&r.y>=area.y&&r.x+width<=area.x+area.width&&r.y+height<=area.y+area.height)
    ??{x:area.x+Math.max(0,area.width-width-12),y:area.y+12,width,height};
}
