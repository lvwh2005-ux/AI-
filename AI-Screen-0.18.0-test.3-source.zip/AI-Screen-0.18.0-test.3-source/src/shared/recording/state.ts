import { RecordingError, type RecordingState, type RecordingStatus } from './contracts';

const transitions: Record<RecordingStatus, readonly RecordingStatus[]> = {
  idle: ['preparing'], preparing: ['countdown', 'error', 'cancelled'], countdown: ['recording', 'error', 'cancelled'],
  recording: ['paused', 'stopping', 'error', 'cancelled'], paused: ['recording', 'stopping', 'error', 'cancelled'],
  stopping: ['ready', 'error', 'cancelled'], ready: ['saving', 'error', 'cancelled'], saving: ['ready', 'error', 'cancelled'], error: ['cancelled'], cancelled: [],
};
export function recordingTransition(state: RecordingState, next: RecordingStatus): RecordingState {
  if (!transitions[state.status].includes(next)) throw new RecordingError('invalid-state', `录屏状态不允许 ${state.status} → ${next}`);
  return { ...state, status: next, sequence: state.sequence + 1 };
}
export function newerRecordingState(current: RecordingState | undefined, incoming: RecordingState, expectedId: string): boolean {
  return incoming.id === expectedId && (!current || (current.id === incoming.id && incoming.sequence > current.sequence));
}
export function recordingActive(status: RecordingStatus): boolean {
  return ['preparing', 'countdown', 'recording', 'paused', 'stopping', 'saving'].includes(status);
}
