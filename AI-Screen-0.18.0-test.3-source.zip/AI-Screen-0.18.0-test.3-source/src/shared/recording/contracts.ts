import { z } from 'zod';
import { rectSchema } from '../contracts';

export const RECORDING_LIMITS = Object.freeze({ maxChunkBytes: 16 * 1024 * 1024, maxPendingBytes: 32 * 1024 * 1024, maxPendingChunks: 8, chunkMs: 1000 });
export const recordingOptionsSchema = z.object({
  frameRate: z.number().int().min(1).max(60).default(30),
  countdownMs: z.number().int().min(0).max(10000).default(3000),
  mimeType: z.enum(['video/webm;codecs=vp8', 'video/webm;codecs=vp9', 'video/mp4;codecs=avc1.42001E']).default('video/webm;codecs=vp8'),
  systemAudio: z.boolean().default(false), microphone: z.boolean().default(false),
  microphoneDeviceId: z.string().min(1).max(512).optional(),
}).strict();
export type RecordingOptions = z.infer<typeof recordingOptionsSchema>;
export const recordingTargetSchema = z.object({
  displayId: z.string().min(1).max(100),
  displayBounds: z.object({ x: z.number().finite(), y: z.number().finite(), width: z.number().positive().finite(), height: z.number().positive().finite() }).strict(),
  scaleFactor: z.number().positive().finite(), rect: rectSchema.strict(),
}).strict();
export type RecordingTarget = z.infer<typeof recordingTargetSchema>;
export const recordingRequestSchema = z.object({ id: z.string().uuid(), target: recordingTargetSchema, options: recordingOptionsSchema,ui:z.enum(['experiment','toolbar']).default('experiment') }).strict();
export type RecordingRequest = z.infer<typeof recordingRequestSchema>;
export type RecordingStatus = 'idle' | 'preparing' | 'countdown' | 'recording' | 'paused' | 'stopping' | 'ready' | 'saving' | 'error' | 'cancelled';
export const recordingCommandSchema=z.enum(['pause','resume','finish','cancel']);
export type RecordingCommand = z.infer<typeof recordingCommandSchema>;
export const recordingAudioSchema=z.object({systemEnabled:z.boolean(),microphoneEnabled:z.boolean()}).strict();
export type RecordingAudio=z.infer<typeof recordingAudioSchema>;
export interface RecordingCapability { productionReady: boolean; experimental: boolean; reason: string }
export interface RecordingMediaInfo { mimeType: string; width: number; height: number; sourceWidth: number; sourceHeight: number; sourceFrameRate: number; codecs: Record<string, boolean>; crop?: {x:number;y:number;width:number;height:number}; padding?: {right:number;bottom:number}; audio?:{systemAvailable:boolean;microphoneAvailable:boolean}; options?:RecordingOptions }
export interface RecordingStats { frames: number; chunks: number; bytes: number; pendingPeakBytes: number; pendingPeakChunks: number }
export interface RecordingState {
  id: string; sequence: number; status: RecordingStatus; elapsedMs: number; pending?: RecordingCommand|'audio';
  media?: RecordingMediaInfo; stats?: RecordingStats; error?: { code: string; message: string };
  countdownRemainingMs?:number; audio?:RecordingAudio; message?:string; savedName?:string;
}
export interface RecordingArtifact { path: string; mimeType: string; width: number; height: number; bytes: number; durationMs: number }
export class RecordingError extends Error {
  constructor(public readonly code: string, message: string) { super(message); this.name = 'RecordingError'; }
}
// This bridge exists only in the isolated local media host, never in the main UI.
export const RECORDING_IPC = { config: 'recording-host:config', configure:'recording-host:configure', layout:'recording-host:layout', event: 'recording-host:event', chunk: 'recording-host:chunk', command: 'recording-host:command',control:'recording-host:control',state:'recording-host:state' } as const;
export const mediaInfoSchema = z.object({
  mimeType: z.string().min(1).max(160), width: z.number().int().positive().max(8192), height: z.number().int().positive().max(8192),
  sourceWidth: z.number().int().positive().max(16384), sourceHeight: z.number().int().positive().max(16384), sourceFrameRate: z.number().finite().nonnegative(),
  codecs: z.record(z.string().max(160), z.boolean()),
  crop: rectSchema.strict().optional(), padding: z.object({right:z.number().int().min(0).max(1),bottom:z.number().int().min(0).max(1)}).strict().optional(),
  audio:z.object({systemAvailable:z.boolean(),microphoneAvailable:z.boolean()}).strict().optional(),
  options:recordingOptionsSchema.optional(),
}).strict();
export const statsSchema = z.object({ frames: z.number().int().nonnegative(), chunks: z.number().int().nonnegative(), bytes: z.number().int().nonnegative(), pendingPeakBytes: z.number().int().nonnegative(), pendingPeakChunks: z.number().int().nonnegative() }).strict();
export const hostEventSchema = z.discriminatedUnion('type', [
  z.object({ id: z.string().uuid(), type: z.literal('prepared'), media: mediaInfoSchema }).strict(),
  z.object({ id: z.string().uuid(), type: z.enum(['started', 'paused', 'resumed', 'released','audio-updated']) }).strict(),
  z.object({id:z.string().uuid(),type:z.literal('interrupted'),reason:z.string().max(200)}).strict(),
  z.object({id:z.string().uuid(),type:z.literal('audio-probe'),rms:z.number().finite().nonnegative(),amplitude440:z.number().finite().nonnegative()}).strict(),
  z.object({ id: z.string().uuid(), type: z.literal('stopped'), stats: statsSchema }).strict(),
  z.object({ id: z.string().uuid(), type: z.literal('failed'), code: z.string().max(80), message: z.string().max(400) }).strict(),
]);
export type HostEvent = z.infer<typeof hostEventSchema>;
export type HostCommand = { id: string; command: 'start' | 'pause' | 'resume' | 'stop' | 'dispose' | 'audio' | 'probe-audio';audio?:RecordingAudio };
export interface RecordingHostBridge {
  config(): Promise<RecordingRequest>;
  configure(id:string, options:RecordingOptions):Promise<void>;
  layout(id:string, layout:{expanded?:boolean;height?:number;x?:number;y?:number}):Promise<void>;
  event(event: HostEvent): Promise<void>;
  chunk(id: string, sequence: number, data: ArrayBuffer): Promise<void>;
  onCommand(listener: (command: HostCommand) => void): () => void;
  control(id:string,command:RecordingCommand|'audio'|'reselect',audio?:RecordingAudio):Promise<void>;
  onState(listener:(state:RecordingState)=>void):()=>void;
}
