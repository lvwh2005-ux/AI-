import { z } from 'zod';
import { annotationsSchema, type Annotation } from './annotations';
import type { DetectedWindow } from './window-candidates';
import type { CaptureMode, ModeCapability } from './capture-modes';
import type { PinCommand, PinState } from './pin';
import type { LongshotState, LongshotCommand, LongshotCommandResult, LongshotScrollMode } from './longshot';
import type { PreviewWindowRequest, PreviewWindowState } from './scroll-capture/preview-window';

export const actionIdSchema = z.enum(['copy-image', 'ocr', 'translate', 'analyze', 'ask', 'custom']);
export type ActionId = z.infer<typeof actionIdSchema>;
export type AIAction = Exclude<ActionId, 'copy-image'>;
export const rectSchema = z.object({
  x: z.number().finite().nonnegative(), y: z.number().finite().nonnegative(),
  width: z.number().finite().positive(), height: z.number().finite().positive(),
});
export type Rect = z.infer<typeof rectSchema>;
export const customActionSchema = z.object({
  id: z.string().regex(/^[a-z0-9-]{1,40}$/), label: z.string().trim().min(1).max(16),
  prompt: z.string().trim().min(1).max(4000), enabled: z.boolean().default(true),
});
export type CustomAction = z.infer<typeof customActionSchema>;
export const settingsSchema = z.object({
  provider: z.enum(['demo', 'compatible']).default('demo'),
  baseUrl: z.string().max(2048).default('https://api.openai.com/v1'),
  model: z.string().max(200).default(''),
  shortcut: z.string().min(3).max(80).default('Alt+A'),
  language: z.string().min(1).max(80).default('简体中文'),
  stream: z.boolean().default(true),
  ocr: z.enum(['vision', 'windows']).default('vision'),
  customActions: z.array(customActionSchema).max(8).default([]).refine((items) => new Set(items.map((item) => item.id)).size === items.length, '自定义动作 ID 不能重复'),
});
export type Settings = z.infer<typeof settingsSchema>;
export interface PublicSettings extends Settings { hasApiKey: boolean; shortcutActive: boolean }
export const settingsInputSchema = settingsSchema.extend({
  apiKey: z.string().max(4096).optional(), clearApiKey: z.boolean().optional(),
});
export type SettingsInput = z.infer<typeof settingsInputSchema>;
export const runInputSchema = z.object({
  action: actionIdSchema,
  rect: rectSchema.optional(),
  question: z.string().trim().max(8000).optional(),
  customActionId: z.string().regex(/^[a-z0-9-]{1,40}$/).optional(),
  annotations: annotationsSchema.optional(),
});
export type RunInput = z.infer<typeof runInputSchema>;
export interface CaptureFrame { image: string; width: number; height: number; displayId?: string; displayLabel?: string; scaleFactor?: number }
export interface CaptureSession { sessionId: string; frame: CaptureFrame; settings: PublicSettings; candidates?: DetectedWindow[]; capabilities?: ModeCapability[]; initialMode?:CaptureMode; cursor?: { x: number; y: number } }
export interface PixelSample { image: string; hex: string; rgb: [number, number, number]; position: { x: number; y: number }; width: number; height: number; center: { x: number; y: number } }
export interface Turn { role: 'user' | 'assistant'; content: string }
export interface ResultState {
  requestId: string; source: 'demo' | 'ai' | 'local-ocr';
  image: string; action: AIAction; status: 'loading' | 'done' | 'error' | 'cancelled';
  text: string; question: string; demo: boolean; history: Turn[];
  actionLabel?: string; customActionId?: string;
}
export interface ResultProgress { requestId: string; text: string }
export interface ServiceTestResult { message: string; elapsedMs: number }
export type Reply<T> = { ok: true; value: T } | { ok: false; error: string };
export interface ScreenBridge {
  getSettings(): Promise<PublicSettings>;
  saveSettings(input: SettingsInput): Promise<PublicSettings>;
  testService(input: SettingsInput): Promise<ServiceTestResult>;
  setShortcutRecording(recording: boolean): Promise<void>;
  openExternal(url: string): Promise<void>;
  startCapture(mode?: CaptureMode): Promise<void>;
  getCapture(): Promise<CaptureFrame | null>;
  capturePrepared(): Promise<void>;
  captureReady(sessionId: string, ready: boolean): Promise<void>;
  onCapture(listener: (session: CaptureSession | null) => void): () => void;
  cancelCapture(): Promise<void>;
  resetCaptureAction(): Promise<void>;
  samplePixel(sessionId: string, point: { x: number; y: number }): Promise<PixelSample | null>;
  pinSelection(input: Pick<RunInput, 'rect' | 'annotations'>): Promise<void>;
  startCaptureMode(mode: CaptureMode, rect: Rect, scrollMode?: LongshotScrollMode,recordingOptions?:import('./recording/contracts').RecordingOptions): Promise<void>;
  getRecording():Promise<import('../main/recording-window').RecordingView|null>;
  onRecording(listener:(view:import('../main/recording-window').RecordingView)=>void):()=>void;
  saveRecording(id:string):Promise<boolean>;
  closeRecording(id:string):Promise<void>;
  getPin(): Promise<PinState | null>;
  controlPin(command: PinCommand): Promise<PinState | null>;
  getLongshot(): Promise<LongshotState | null>;
  previewWindow(input: PreviewWindowRequest): Promise<PreviewWindowState>;
  onPreviewWindow(listener: (state: PreviewWindowState) => void): () => void;
  commandLongshot(id: string, command: LongshotCommand, annotations?: Annotation[]): Promise<LongshotCommandResult>;
  getLongshotImage(id: string): Promise<{image: string; width: number; height: number}>;
  onLongshot(listener: (state: LongshotState) => void): () => void;
  onLongshotTelemetry(listener: (update: import('./scroll-capture/telemetry').TelemetryUpdate) => void): () => void;
  runAction(input: RunInput): Promise<void>;
  getResult(): Promise<ResultState | null>;
  cancelRequest(): Promise<void>;
  copyText(text: string): Promise<void>;
  openSettings(): Promise<void>;
  onResult(listener: (state: ResultState) => void): () => void;
  onProgress(listener: (progress: ResultProgress) => void): () => void;
}
export const IPC = {
  getSettings: 'settings:get', saveSettings: 'settings:save', startCapture: 'capture:start',
  getCapture: 'capture:get', cancelCapture: 'capture:cancel', runAction: 'action:run',
  getResult: 'result:get', cancelRequest: 'request:cancel', copyText: 'clipboard:text',
  openSettings: 'settings:open', resultChanged: 'result:changed', resultProgress: 'result:progress', testService: 'service:test',
  setShortcutRecording: 'shortcut:recording', openExternal: 'link:external',
  capturePrepared: 'capture:prepared', captureReady: 'capture:ready', captureChanged: 'capture:changed',
  samplePixel: 'capture:sample', pinSelection: 'capture:pin', getPin: 'pin:get', controlPin: 'pin:control',
  startCaptureMode: 'capture:mode:start',
  resetCaptureAction: 'capture:action:reset',
  getRecording:'recording:get',saveRecording:'recording:save',closeRecording:'recording:close',recordingChanged:'recording:changed',
  getLongshot: 'longshot:get', commandLongshot: 'longshot:command', longshotChanged: 'longshot:changed',
  getLongshotImage: 'longshot:image',
  longshotTelemetry: 'longshot:telemetry',
  previewWindow: 'longshot:preview-window', previewWindowChanged: 'longshot:preview-window-changed',
} as const;
