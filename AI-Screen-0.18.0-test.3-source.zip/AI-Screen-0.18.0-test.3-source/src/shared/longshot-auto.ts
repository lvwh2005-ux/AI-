import type { StitchResult } from './longshot-stitcher';

export type AutoCaptureAction =
  | { kind: 'scroll' }
  | { kind: 'verify'; delayMs: number }
  | { kind: 'finish' | 'pause'; reason: string };

/** A still frame is not proof of reaching the bottom. Recheck after a settling
 * interval, then try another wheel step. Never auto-complete a non-moving page. */
export class AutoScrollPolicy {
  private verification = false;
  private unchangedSteps = 0;
  private progressed = false;
  private steps = 0;
  private startedAt: number;
  constructor(private options: { maxSteps?: number; maxDurationMs?: number; now?: () => number } = {}) {
    this.startedAt = this.now();
  }
  private now() { return this.options.now?.() ?? Date.now(); }
  didScroll() { this.steps++; }
  resume() { this.verification = false; this.unchangedSteps = 0; this.startedAt = this.now(); }
  observe(result: StitchResult): AutoCaptureAction {
    if((result.viewportDelta??0)<0||result.relocated)return {kind:'pause',reason:'检测到反向滚动或历史位置切换，自动滚动已暂停；可切换手动继续双向采集'};
    if (result.kind === 'rejected' || result.kind === 'review') return { kind: 'pause', reason: result.reason ?? '无法可靠拼接，自动滚动已暂停；可完成已有部分或转为手动' };
    if (result.kind === 'limit') return { kind: 'pause', reason: result.reason ?? '已达到长截图上限' };
    if (result.kind === 'appended') this.progressed = true;
    if (this.steps >= (this.options.maxSteps ?? 1200) || this.now() - this.startedAt >= (this.options.maxDurationMs ?? 600_000)) {
      return { kind: 'pause', reason: '已达到自动滚动次数或时长上限，请完成已有部分或转为手动' };
    }
    if (result.kind !== 'duplicate') {
      this.verification = false; this.unchangedSteps = 0;
      return { kind: 'scroll' };
    }
    if (!this.verification) {
      this.verification = true;
      return { kind: 'verify', delayMs: 1200 };
    }
    this.verification = false;
    if (++this.unchangedSteps < 3) return { kind: 'scroll' };
    return this.progressed
      ? { kind: 'finish', reason: '连续滚动后画面不再变化，已自动完成；请在预览中确认末尾完整。' }
      : { kind: 'pause', reason: '滚动后画面始终没有变化，无法确认页面可滚动；请选择正确的内容区域，或转为手动滚动。' };
  }
}
