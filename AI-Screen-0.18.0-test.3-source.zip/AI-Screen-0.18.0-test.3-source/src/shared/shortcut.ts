export interface ShortcutKeyEvent {
  code: string;
  ctrlKey: boolean;
  altKey: boolean;
  shiftKey: boolean;
  metaKey: boolean;
  repeat?: boolean;
  isComposing?: boolean;
}

const specialKeys: Readonly<Record<string, string>> = {
  Space: 'Space', Tab: 'Tab', Enter: 'Enter', NumpadEnter: 'Enter',
  Backspace: 'Backspace', Delete: 'Delete', Insert: 'Insert',
  ArrowUp: 'Up', ArrowDown: 'Down', ArrowLeft: 'Left', ArrowRight: 'Right',
  Home: 'Home', End: 'End', PageUp: 'PageUp', PageDown: 'PageDown',
  Minus: '-', Equal: '=', BracketLeft: '[', BracketRight: ']',
  Backslash: '\\', IntlBackslash: '\\', Semicolon: ';', Backquote: '`',
  Comma: ',', Period: '.', Slash: '/',
  NumpadDecimal: 'numdec', NumpadAdd: 'numadd', NumpadSubtract: 'numsub',
  NumpadMultiply: 'nummult', NumpadDivide: 'numdiv',
};

/** Use physical key codes so the saved shortcut is independent of input language. */
export function shortcutFromKeyEvent(event: ShortcutKeyEvent): string | null {
  if (event.repeat || event.isComposing || event.code === 'Escape') return null;
  const modifiers = [event.ctrlKey && 'Control', event.altKey && 'Alt', event.shiftKey && 'Shift', event.metaKey && 'Super'].filter(Boolean);
  if (!modifiers.length) return null;
  let key: string | undefined;
  if (/^Key[A-Z]$/.test(event.code)) key = event.code.slice(3);
  else if (/^Digit[0-9]$/.test(event.code)) key = event.code.slice(5);
  else if (/^Numpad[0-9]$/.test(event.code)) key = `num${event.code.slice(6)}`;
  else if (/^F(?:[1-9]|1[0-9]|2[0-4])$/.test(event.code)) key = event.code;
  else key = Object.hasOwn(specialKeys, event.code) ? specialKeys[event.code] : undefined;
  return key ? [...modifiers, key].join('+') : null;
}
