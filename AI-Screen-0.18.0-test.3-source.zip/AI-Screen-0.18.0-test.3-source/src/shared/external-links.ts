export function externalLink(value: string): string {
  if (value.length > 4096 || /[\u0000-\u001f\u007f]/.test(value)) throw new Error('链接格式不正确');
  let url: URL;
  try { url = new URL(value); } catch { throw new Error('链接格式不正确'); }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password) throw new Error('只允许打开 HTTP/HTTPS 网页链接');
  return url.href;
}
