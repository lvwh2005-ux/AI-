export type ScreenshotPhase = 'idle' | 'window-hover' | 'selecting' | 'selected' | 'annotating' | 'ai-processing';
export type ScreenshotEvent = 'START' | 'POINTER_DOWN' | 'SELECT' | 'RESET' | 'ANNOTATE' | 'EDIT' | 'PROCESS' | 'FAIL' | 'CLOSE';
const transitions: Record<ScreenshotPhase, Partial<Record<ScreenshotEvent, ScreenshotPhase>>> = {
  idle: { START: 'window-hover' },
  'window-hover': { POINTER_DOWN: 'selecting', SELECT: 'selected', CLOSE: 'idle' },
  selecting: { SELECT: 'selected', RESET: 'window-hover', CLOSE: 'idle' },
  selected: { POINTER_DOWN: 'selecting', RESET: 'window-hover', ANNOTATE: 'annotating', PROCESS: 'ai-processing', CLOSE: 'idle' },
  annotating: { EDIT: 'selected', POINTER_DOWN: 'selecting', RESET: 'window-hover', PROCESS: 'ai-processing', CLOSE: 'idle' },
  'ai-processing': { FAIL: 'selected', RESET: 'window-hover', CLOSE: 'idle' },
};
export function screenshotTransition(phase: ScreenshotPhase, event: ScreenshotEvent): ScreenshotPhase {
  return transitions[phase][event] ?? phase;
}
