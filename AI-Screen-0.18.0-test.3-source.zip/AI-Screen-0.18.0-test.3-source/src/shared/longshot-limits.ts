/** Retained BGRA pixels plus one source frame. Native images and PNG encoding
 * have additional temporary allocations, so this is not a process RSS limit. */
export const LONGSHOT_LIMITS = { maxHeight: 30_000, maxBytes: 256 * 1024 * 1024 } as const;
export const LONGSHOT_MAX_WIDTH = 8192;
