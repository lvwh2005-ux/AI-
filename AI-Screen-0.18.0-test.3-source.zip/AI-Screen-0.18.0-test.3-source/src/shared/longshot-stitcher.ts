// Compatibility entry for existing services; implementation lives in scroll-capture.
export { ScrollCaptureEngine as LongshotStitcher } from './scroll-capture/engine';
export type { BitmapFrame, StitchResult } from './scroll-capture/types';
