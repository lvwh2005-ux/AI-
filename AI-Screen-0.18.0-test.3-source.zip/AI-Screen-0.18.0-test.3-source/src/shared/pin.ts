export interface PinState {
  id: string;
  image: string;
  /** Display size relative to the selection's original DIP size. */
  zoom: number;
  /** Keeps tiny snippets at the requested scale inside a usable window. */
  originalSize?: { width: number; height: number };
}

export type PinCommand = 'close' | 'zoom-in' | 'zoom-out' | 'reset';
