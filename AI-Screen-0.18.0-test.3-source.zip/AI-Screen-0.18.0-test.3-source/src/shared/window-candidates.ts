/** Native window bounds are physical desktop pixels; renderer candidates are local DIPs. */
export interface WindowRect { x: number; y: number; width: number; height: number }
export interface DetectedWindow { id: string; title: string; bounds: WindowRect }

function validRect(rect: WindowRect): boolean {
  return [rect.x, rect.y, rect.width, rect.height].every(Number.isFinite) && rect.width > 0 && rect.height > 0;
}

/**
 * Clip before conversion so a window spanning two scales gets an independent
 * local selection on each monitor. Physical origins must come from Windows /
 * Electron's DIP conversion, never from multiplying the global DIP origin.
 */
export function clipWindowToDisplay(candidate: DetectedWindow, displayDipBounds: WindowRect, displayPhysicalBounds: WindowRect): DetectedWindow | undefined {
  if (!validRect(candidate.bounds) || !validRect(displayDipBounds) || !validRect(displayPhysicalBounds)) return undefined;
  const left = Math.max(candidate.bounds.x, displayPhysicalBounds.x);
  const top = Math.max(candidate.bounds.y, displayPhysicalBounds.y);
  const right = Math.min(candidate.bounds.x + candidate.bounds.width, displayPhysicalBounds.x + displayPhysicalBounds.width);
  const bottom = Math.min(candidate.bounds.y + candidate.bounds.height, displayPhysicalBounds.y + displayPhysicalBounds.height);
  if (right <= left || bottom <= top) return undefined;
  const scaleX = displayDipBounds.width / displayPhysicalBounds.width;
  const scaleY = displayDipBounds.height / displayPhysicalBounds.height;
  return {
    id: candidate.id, title: candidate.title,
    bounds: { x: (left - displayPhysicalBounds.x) * scaleX, y: (top - displayPhysicalBounds.y) * scaleY, width: (right - left) * scaleX, height: (bottom - top) * scaleY },
  };
}

/** Candidates retain native front-to-back order; a covered window must not win. */
export function pickWindow(candidates: readonly DetectedWindow[], point: { x: number; y: number }): DetectedWindow | undefined {
  if (!Number.isFinite(point.x) || !Number.isFinite(point.y)) return undefined;
  return candidates.find(({ bounds }) => validRect(bounds) && point.x >= bounds.x && point.y >= bounds.y && point.x < bounds.x + bounds.width && point.y < bounds.y + bounds.height);
}
