import type { CustomAction } from './contracts';

export function customAction(items: CustomAction[], id: string | undefined): CustomAction {
  const selected = items.find((item) => item.id === id && item.enabled);
  if (!selected) throw new Error('自定义动作不存在或已停用，请在设置中检查');
  return selected;
}
export function expandPrompt(prompt: string, language: string, question: string): string {
  return prompt.replace(/\{\{(language|question)\}\}/g, (_match, name: string) => name === 'language' ? language : question);
}
