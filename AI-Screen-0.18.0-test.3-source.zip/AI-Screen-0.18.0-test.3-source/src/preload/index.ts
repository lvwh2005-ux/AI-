import { contextBridge, ipcRenderer } from 'electron';
import { IPC, type Reply, type ScreenBridge, type ResultState, type ResultProgress, type CaptureSession } from '../shared/contracts';
import type { LongshotState } from '../shared/longshot';
import type { TelemetryUpdate } from '../shared/scroll-capture/telemetry';
import type { PreviewWindowState } from '../shared/scroll-capture/preview-window';

async function invoke<T>(channel: string, ...args: unknown[]): Promise<T> {
  const reply = await ipcRenderer.invoke(channel, ...args) as Reply<T>;
  if (!reply.ok) throw new Error(reply.error);
  return reply.value;
}
const bridge: ScreenBridge = {
  getSettings: () => invoke(IPC.getSettings), saveSettings: (input) => invoke(IPC.saveSettings, input),
  testService: (input) => invoke(IPC.testService, input),
  setShortcutRecording: (recording) => invoke(IPC.setShortcutRecording, recording),
  openExternal: (url) => invoke(IPC.openExternal, url),
  startCapture: (mode) => invoke(IPC.startCapture, mode), getCapture: () => invoke(IPC.getCapture),
  capturePrepared: () => invoke(IPC.capturePrepared),
  captureReady: (sessionId, ready) => invoke(IPC.captureReady, { sessionId, ready }),
  onCapture: (listener) => {
    const handler = (_event: Electron.IpcRendererEvent, session: CaptureSession | null) => listener(session);
    ipcRenderer.on(IPC.captureChanged, handler);
    return () => ipcRenderer.removeListener(IPC.captureChanged, handler);
  },
  cancelCapture: () => invoke(IPC.cancelCapture), runAction: (input) => invoke(IPC.runAction, input),
  resetCaptureAction: () => invoke(IPC.resetCaptureAction),
  samplePixel: (sessionId, point) => invoke(IPC.samplePixel, { sessionId, point }),
  pinSelection: (input) => invoke(IPC.pinSelection, input),
  startCaptureMode: (mode, rect, scrollMode,recordingOptions) => invoke(IPC.startCaptureMode, { mode, rect, ...(scrollMode ? { scrollMode } : {}),...(recordingOptions?{recordingOptions}:{}) }),
  getRecording:()=>invoke(IPC.getRecording),saveRecording:id=>invoke(IPC.saveRecording,{id}),closeRecording:id=>invoke(IPC.closeRecording,{id}),
  onRecording:listener=>{const handler=(_event:Electron.IpcRendererEvent,view:import('../main/recording-window').RecordingView)=>listener(view);ipcRenderer.on(IPC.recordingChanged,handler);return()=>ipcRenderer.removeListener(IPC.recordingChanged,handler);},
  getPin: () => invoke(IPC.getPin), controlPin: (command) => invoke(IPC.controlPin, command),
  getLongshot: () => invoke(IPC.getLongshot),
  previewWindow: (input) => invoke(IPC.previewWindow, input),
  onPreviewWindow: (listener) => {
    const handler = (_event: Electron.IpcRendererEvent, state: PreviewWindowState) => listener(state);
    ipcRenderer.on(IPC.previewWindowChanged, handler);
    return () => ipcRenderer.removeListener(IPC.previewWindowChanged, handler);
  },
  commandLongshot: (id, command, annotations) => invoke(IPC.commandLongshot, { id, command, ...(annotations ? {annotations} : {}) }),
  getLongshotImage: (id) => invoke(IPC.getLongshotImage, {id}),
  onLongshot: (listener) => {
    const handler = (_event: Electron.IpcRendererEvent, state: LongshotState) => listener(state);
    ipcRenderer.on(IPC.longshotChanged, handler);
    return () => ipcRenderer.removeListener(IPC.longshotChanged, handler);
  },
  onLongshotTelemetry: (listener) => {
    const handler = (_event: Electron.IpcRendererEvent, update: TelemetryUpdate) => listener(update);
    ipcRenderer.on(IPC.longshotTelemetry, handler);
    return () => ipcRenderer.removeListener(IPC.longshotTelemetry, handler);
  },
  getResult: () => invoke(IPC.getResult), cancelRequest: () => invoke(IPC.cancelRequest),
  copyText: (text) => invoke(IPC.copyText, text), openSettings: () => invoke(IPC.openSettings),
  onResult: (listener) => {
    const handler = (_event: Electron.IpcRendererEvent, state: ResultState) => listener(state);
    ipcRenderer.on(IPC.resultChanged, handler);
    return () => ipcRenderer.removeListener(IPC.resultChanged, handler);
  },
  onProgress: (listener) => {
    const handler = (_event: Electron.IpcRendererEvent, progress: ResultProgress) => listener(progress);
    ipcRenderer.on(IPC.resultProgress, handler);
    return () => ipcRenderer.removeListener(IPC.resultProgress, handler);
  },
};
contextBridge.exposeInMainWorld('screenAI', bridge);
