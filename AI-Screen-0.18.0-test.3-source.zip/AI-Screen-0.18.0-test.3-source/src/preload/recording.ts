import { contextBridge, ipcRenderer } from 'electron';
import type { RecordingHostBridge, HostCommand, RecordingRequest, HostEvent } from '../shared/recording/contracts';

// Sandbox preload intentionally has no runtime imports beyond Electron.
async function invoke<T>(channel:string,...args:unknown[]):Promise<T>{
  const reply=await ipcRenderer.invoke(channel,...args) as {ok:true;value:T}|{ok:false;error:string};
  if(!reply.ok)throw new Error(reply.error);return reply.value;
}
const bridge: RecordingHostBridge = {
  config: () => invoke<RecordingRequest>('recording-host:config'),
  configure:(id,options)=>invoke('recording-host:configure',{id,options}),
  layout:(id,layout)=>invoke('recording-host:layout',{id,...layout}),
  event: (event: HostEvent) => invoke('recording-host:event', event),
  chunk: (id, sequence, data) => invoke('recording-host:chunk', { id, sequence, data }),
  control:(id,command,audio)=>invoke('recording-host:control',{id,command,...(audio?{audio}:{})}),
  onState:listener=>{const handler=(_event:Electron.IpcRendererEvent,state:import('../shared/recording/contracts').RecordingState)=>listener(state);ipcRenderer.on('recording-host:state',handler);return()=>ipcRenderer.removeListener('recording-host:state',handler);},
  onCommand: listener => {
    const handler = (_event: Electron.IpcRendererEvent, command: HostCommand) => listener(command);
    ipcRenderer.on('recording-host:command', handler);
    return () => ipcRenderer.removeListener('recording-host:command', handler);
  },
};
contextBridge.exposeInMainWorld('recordingHost', bridge);
